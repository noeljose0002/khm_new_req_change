<?php

namespace App\Controllers;

use App\Models\EnquiryFollowupModel;
use App\Models\CallFollowUpModel;
use App\Models\ArrivalFollowUpModel;
use App\Models\DepartureFollowUpModel;
use App\Models\ExecutiveFollowUpModel;
use App\Models\Dashboard_m;
use CodeIgniter\Controller;

class Enwuiryfollowup extends Controller
{
    protected $enquiryModel;
    protected $callFollowUpModel;
    protected $ArrivalFollowUpModel;
    protected $DepartureFollowUpModel;
    protected $ExecutiveFollowUpModel;
    protected $Dashboard_m;
    protected $db;

    public function __construct()
    {
        $this->enquiryModel           = new EnquiryFollowupModel();
        $this->callFollowUpModel      = new CallFollowUpModel();
        $this->ArrivalFollowUpModel   = new ArrivalFollowUpModel();
        $this->DepartureFollowUpModel = new DepartureFollowUpModel();
        $this->ExecutiveFollowUpModel = new ExecutiveFollowUpModel();
        $this->Dashboard_m = new Dashboard_m();
        $this->db                     = \Config\Database::connect();
    }

    // Display the list of enquiries
    public function index()
    {
        $Dashboard_model = new Dashboard_m();
        $entity_id = session('user_id');
        $active_role = session('active_role');
        $all_roles = $Dashboard_model->get_all_entity_roles($entity_id);
        $all_systems = $Dashboard_model->get_all_systems($entity_id);
        $data['all_systems'] = $all_systems;
        if (!empty($all_roles)) {
            $data['all_roles_assn'] = $all_roles;
            $all_menus = $Dashboard_model->get_all_role_menus($active_role);
            if (!empty($all_menus)) {
                $data['all_menus'] = $all_menus;
            } else {
                $data['all_menus'] = [];
            }
            $all_permissions = $Dashboard_model->get_all_entity_permissions($active_role, 3);
            if (!empty($all_permissions)) {
                $data['all_permissions'] = $all_permissions;
            } else {
                $data['all_permissions'] = [];
            }
        } else {
            $data['all_roles_assn'] = [];
            $data['all_menus'] = [];
            $data['all_permissions'] = [];
        }
        $parent_menu = $Dashboard_model->get_parent_menus();
        $sub_menu = $Dashboard_model->get_sub_menus();
        $data['parent_menu'] = $parent_menu;
        $data['sub_menu'] = $sub_menu;
        $data['enquiries'] = $this->enquiryModel->getEnquiries();
        return view('masters/enquiries_view', $data);
    }

    // AJAX endpoint to get followup types by enterprise_id
    public function getFollowupTypes()
    {
        $enterprise_id = $this->request->getPost('enterprise_id');
        $followupTypes = $this->enquiryModel->getActiveFollowupTypes($enterprise_id);
        return $this->response->setJSON($followupTypes);
    }

    // AJAX endpoint to get call follow-ups
    public function getCallFollowups()
    {
        $followupTypeId = $this->request->getPost('followupTypeId');
        $objectId       = $this->request->getPost('objectId');
        log_message('debug', 'getCallFollowups - Received object_id: ' . $objectId);

        $header = $this->db->table('khm_obj_enquiry_header')
            ->select('enquiry_header_id, enterprise_id')
            ->where('object_id', $objectId)
            ->get()
            ->getRowArray();

        if (!$header) {
            log_message('debug', 'getCallFollowups - Invalid object id: ' . $objectId);
            return $this->response->setJSON(['data' => []]);
        }

        $enquiryHeaderId = $header['enquiry_header_id'];
        $followups       = $this->callFollowUpModel->getFollowups($followupTypeId, $enquiryHeaderId);

        return $this->response->setJSON(['data' => $followups]);
    }

    // AJAX endpoint to insert or update a call follow-up record
    public function saveCallFollowup()
    {
        $followupTypeId = $this->request->getPost('followup_type_id');
        $objectId       = $this->request->getPost('object_id');
        $callStatus     = $this->request->getPost('call_status');
        $callTime       = $this->request->getPost('call_time');
        $comments       = $this->request->getPost('comments');
        $id             = $this->request->getPost('call_follow_up_id');

        log_message('debug', 'saveCallFollowup - POST data: ' . print_r($this->request->getPost(), true));

        $header = $this->db->table('khm_obj_enquiry_header')
            ->select('enquiry_header_id, enterprise_id')
            ->where('object_id', $objectId)
            ->get()
            ->getRowArray();

        if (!$header) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Invalid object id']);
        }

        $enquiryHeaderId = $header['enquiry_header_id'];
        $enterpriseId    = $header['enterprise_id'];

        $data = [
            'followup_type_id'  => $followupTypeId,
            'enquiry_header_id' => $enquiryHeaderId,
            'call_status'       => $callStatus,
            'call_time'         => $callTime,
            'comments'          => $comments,
            'deleted'           => 0,
            'enterprise_id'     => $enterpriseId
        ];

        if ($id) {
            // update existing
            $success = $this->callFollowUpModel->update($id, $data);
        } else {
            // insert new
            $success = $this->callFollowUpModel->insert($data);
        }

        if ($success) {
            return $this->response->setJSON(['status' => 'success']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Could not save record']);
        }
    }

    /**
     * AJAX endpoint to update a call follow-up record (alias to saveCallFollowup).
     */
    public function updateCallFollowup()
    {
        // Simply delegate to saveCallFollowup which handles both insert and update
        return $this->saveCallFollowup();
    }

    // AJAX endpoint to delete a call follow-up record
    public function deleteCallFollowup()
    {
        $id     = $this->request->getPost('id');
        $result = $this->callFollowUpModel->softDelete($id);
        return $this->response->setJSON(['status' => $result ? 'success' : 'error']);
    }

    // AJAX endpoint to retrieve a single call follow-up record
    public function getCallFollowupById()
    {
        $id = $this->request->getPost('id');
        if (!$id) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Missing ID']);
        }

        $followup = $this->callFollowUpModel->find($id);
        if ($followup && $followup['deleted'] == 0) {
            return $this->response->setJSON($followup);
        }

        return $this->response->setJSON(['status' => 'error', 'message' => 'Record not found or deleted']);
    }

    /**
     * AJAX endpoint to retrieve arrival follow-ups.
     * Expects 'followupTypeId' and 'objectId' via POST.
     */
    public function getArrivalFollowups()
    {
        $followupTypeId = $this->request->getPost('followupTypeId');
        $objectId       = $this->request->getPost('objectId');

        // Debug log the received object id
        log_message('debug', 'getArrivalFollowups - Received object_id: ' . $objectId);

        // Retrieve the enquiry header record from khm_obj_enquiry_header
        $header = $this->db->table('khm_obj_enquiry_header')
            ->select('enquiry_header_id, enterprise_id')
            ->where('object_id', $objectId)
            ->get()
            ->getRowArray();

        if (!$header) {
            log_message('debug', 'getArrivalFollowups - Invalid object id: ' . $objectId);
            return $this->response->setJSON(['data' => []]);
        }

        $enquiryHeaderId = $header['enquiry_header_id'];
        $followups = $this->ArrivalFollowUpModel->getArrivalFollowUp($followupTypeId, $enquiryHeaderId);

        return $this->response->setJSON(['data' => $followups]);
    }

    /**
     * AJAX endpoint to save (insert/update) an arrival follow-up record.
     * Expects form data via POST.
     */
    public function saveArrivalFollowup()
    {
        // Retrieve POST data from form
        $followupTypeId = $this->request->getPost('followup_type_id');
        $objectId       = $this->request->getPost('object_id');
        $callDate       = $this->request->getPost('call_date');   // Expected as YYYY-MM-DD
        $callTime       = $this->request->getPost('call_time');   // Expected as HH:ii:ss (or HH:ii)
        $mode           = $this->request->getPost('mode');
        $city           = $this->request->getPost('city');
        $flightTrain    = $this->request->getPost('flight_train');
        $arrivalDate    = $this->request->getPost('arrival');     // Expected as YYYY-MM-DD
        $arrivalTime    = $this->request->getPost('time');        // Expected as HH:ii:ss (or HH:ii)
        $comments       = $this->request->getPost('comments');

        // Log POST data for debugging
        log_message('debug', 'saveArrivalFollowup - POST data: ' . print_r($this->request->getPost(), true));

        // Retrieve the enquiry header record
        $header = $this->db->table('khm_obj_enquiry_header')
            ->select('enquiry_header_id, enterprise_id')
            ->where('object_id', $objectId)
            ->get()
            ->getRowArray();

        if (!$header) {
            return $this->response->setJSON([
                'status'  => 'error',
                'message' => 'Invalid object id'
            ]);
        }

        $enquiryHeaderId = $header['enquiry_header_id'];
        $enterpriseId    = $header['enterprise_id'];

        // Combine call date and time into a datetime string
        $callDatetime = date('Y-m-d H:i:s', strtotime($callDate . ' ' . $callTime));
        // Combine arrival date and time into a datetime string
        $arrivalDatetime = date('Y-m-d H:i:s', strtotime($arrivalDate . ' ' . $arrivalTime));

        // Prepare data array matching the model's allowed fields.
        $data = [
            'followup_type_id'   => $followupTypeId,
            'enquiry_header_id'  => $enquiryHeaderId,
            'call_date'          => $callDatetime,
            'mode_of_arrival'    => $mode,
            'city'               => $city,
            'flight_train_no'    => $flightTrain,
            'arrival_date'       => $arrivalDatetime,
            'comments'           => $comments,
            'deleted'            => 0,
            'enterprise_id'      => $enterpriseId
        ];

        // If updating an existing record, include its ID.
        $id = $this->request->getPost('arrival_follow_up_id');
        if ($id) {
            $data['arrival_follow_up_id'] = $id;
        }

        $result = $this->ArrivalFollowUpModel->saveArrivalFollowup($data);

        if ($result) {
            return $this->response->setJSON(['status' => 'success']);
        } else {
            return $this->response->setJSON([
                'status'  => 'error',
                'message' => 'Could not save record'
            ]);
        }
    }

    /**
     * AJAX endpoint to retrieve a single arrival follow-up record by its ID.
     */
    public function getArrivalFollowupById()
    {
        $id = $this->request->getPost('id');

        if (!$id) {
            return $this->response->setJSON([
                'status'  => 'error',
                'message' => 'Missing ID'
            ]);
        }

        $followup = $this->ArrivalFollowUpModel->find($id);

        if ($followup && $followup['deleted'] == 0) {
            return $this->response->setJSON($followup);
        } else {
            return $this->response->setJSON([
                'status'  => 'error',
                'message' => 'Record not found or deleted'
            ]);
        }
    }

    /**
     * AJAX endpoint to soft-delete an arrival follow-up record.
     */
    public function deleteArrivalFollowup()
    {
        $id = $this->request->getPost('id');
        $result = $this->ArrivalFollowUpModel->softDelete($id);

        if ($result) {
            return $this->response->setJSON(['status' => 'success']);
        } else {
            return $this->response->setJSON([
                'status'  => 'error',
                'message' => 'Could not delete record'
            ]);
        }
    }



    ///departure controller goes here 

    public function getDepartureFollowups()
    {
        $followupTypeId = $this->request->getPost('followupTypeId');
        $objectId       = $this->request->getPost('objectId');

        // Debug log the received object id
        log_message('debug', 'getDepartureFollowups - Received object_id: ' . $objectId);

        // Retrieve the enquiry header record from khm_obj_enquiry_header
        $header = $this->db->table('khm_obj_enquiry_header')
            ->select('enquiry_header_id, enterprise_id')
            ->where('object_id', $objectId)
            ->get()
            ->getRowArray();

        if (!$header) {
            log_message('debug', 'getDepartureFollowups - Invalid object id: ' . $objectId);
            return $this->response->setJSON(['data' => []]);
        }

        $enquiryHeaderId = $header['enquiry_header_id'];
        $followups = $this->DepartureFollowUpModel->getDepartureFollowups($followupTypeId, $enquiryHeaderId);

        return $this->response->setJSON(['data' => $followups]);
    }





    public function saveDepartureFollowup()
    {
        // Retrieve POST data from form
        $followupTypeId = $this->request->getPost('followup_type_id');
        $objectId       = $this->request->getPost('object_id');
        $callDate       = $this->request->getPost('call_date');   // Expected as YYYY-MM-DD
        $callTime       = $this->request->getPost('call_time');   // Expected as HH:ii:ss (or HH:ii)
        $mode           = $this->request->getPost('mode');
        $city           = $this->request->getPost('city');
        $flightTrain    = $this->request->getPost('flight_train');
        $departureDate    = $this->request->getPost('departure');     // Expected as YYYY-MM-DD
        $departureTime    = $this->request->getPost('time');        // Expected as HH:ii:ss (or HH:ii)
        $comments       = $this->request->getPost('comments');

        // Log POST data for debugging
        log_message('debug', 'saveDepartureFollowup - POST data: ' . print_r($this->request->getPost(), true));

        // Retrieve the enquiry header record
        $header = $this->db->table('khm_obj_enquiry_header')
            ->select('enquiry_header_id, enterprise_id')
            ->where('object_id', $objectId)
            ->get()
            ->getRowArray();

        if (!$header) {
            return $this->response->setJSON([
                'status'  => 'error',
                'message' => 'Invalid object id'
            ]);
        }

        $enquiryHeaderId = $header['enquiry_header_id'];
        $enterpriseId    = $header['enterprise_id'];

        // Combine call date and time into a datetime string
        $callDatetime = date('Y-m-d H:i:s', strtotime($callDate . ' ' . $callTime));
        // Combine arrival date and time into a datetime string
        $departureDatetime = date('Y-m-d H:i:s', strtotime($departureDate . ' ' . $departureTime));

        // Prepare data array matching the model's allowed fields.
        $data = [
            'followup_type_id'   => $followupTypeId,
            'enquiry_header_id'  => $enquiryHeaderId,
            'call_date'          => $callDatetime,
            'mode_of_departure'    => $mode,
            'city'               => $city,
            'flight_train_no'    => $flightTrain,
            'departure_date'     => $departureDatetime,
            'comments'           => $comments,
            'deleted'            => 0,
            'enterprise_id'      => $enterpriseId
        ];

        // If updating an existing record, include its ID.
        $id = $this->request->getPost('departure_follow_up_id');
        if ($id) {
            $data['departure_follow_up_id'] = $id;
        }

        $result = $this->DepartureFollowUpModel->saveDepartureFollowup($data);

        if ($result) {
            return $this->response->setJSON(['status' => 'success']);
        } else {
            return $this->response->setJSON([
                'status'  => 'error',
                'message' => 'Could not save record'
            ]);
        }
    }



    public function getDepartureFollowupById()
    {
        $id = $this->request->getPost('id');

        if (!$id) {
            return $this->response->setJSON([
                'status'  => 'error',
                'message' => 'Missing ID'
            ]);
        }

        $followup = $this->DepartureFollowUpModel->find($id);

        if ($followup && $followup['deleted'] == 0) {
            return $this->response->setJSON($followup);
        } else {
            return $this->response->setJSON([
                'status'  => 'error',
                'message' => 'Record not found or deleted'
            ]);
        }
    }

    /**
     * AJAX endpoint to soft-delete an arrival follow-up record.
     */
    public function deleteDepartureFollowup()
    {
        $id = $this->request->getPost('id');
        $result = $this->DepartureFollowUpModel->softDelete($id);

        if ($result) {
            return $this->response->setJSON(['status' => 'success']);
        } else {
            return $this->response->setJSON([
                'status'  => 'error',
                'message' => 'Could not delete record'
            ]);
        }
    }
    public function getExecutiveFollowups()
    {
        $followupTypeId = $this->request->getPost('followupTypeId');
        $objectId       = $this->request->getPost('objectId');

        // 1. Build query: header + detail + object + geography names
        $builder = $this->db->table('khm_obj_enquiry_header h');
        $builder->select([
            'h.enquiry_header_id',
            'd.date_of_tour_start',
            'a.geog_name AS arrival_location_name',
            'b.geog_name AS departure_location_name',
            'd.no_of_night',
            'o.object_name',

            // — remove [, ], " so ["a","b"] → a,b —
            'REPLACE(
               REPLACE(
                 REPLACE(
                   JSON_UNQUOTE(JSON_EXTRACT(o.object_email,   \'$\')),
                   \'[\', \'\'
                 ),
                 \']\', \'\'
               ),
               \'"\', \'\'
             ) AS object_email',

            'REPLACE(
               REPLACE(
                 REPLACE(
                   JSON_UNQUOTE(JSON_EXTRACT(o.object_ph_no,   \'$\')),
                   \'[\', \'\'
                 ),
                 \']\', \'\'
               ),
               \'"\', \'\'
             ) AS object_phone',

            'REPLACE(
               REPLACE(
                 REPLACE(
                   JSON_UNQUOTE(JSON_EXTRACT(o.object_address, \'$\')),
                   \'[\', \'\'
                 ),
                 \']\', \'\'
               ),
               \'"\', \'\'
             ) AS object_address',
        ]);

        $builder
            ->join('khm_obj_enquiry_details      d', 'd.enquiry_header_id = h.enquiry_header_id')
            ->join('khm_obj_mst                  o', 'o.object_id           = h.object_id',         'left')
            ->join('khm_loc_mst_geography        a', 'a.geog_id             = d.arrival_location',   'left')
            ->join('khm_loc_mst_geography        b', 'b.geog_id             = d.departure_location', 'left')
            ->where('h.object_id', $objectId)
            ->where('d.is_active', 1);

        $header = $builder->get()->getRowArray();
        log_message('debug', '[getExecutiveFollowups] header = ' . print_r($header, true));

        if (! $header) {
            log_message('error', "[getExecutiveFollowups] no header found for object_id={$objectId}");
            return $this->response
                ->setStatusCode(404)
                ->setJSON(['message' => 'Object not found']);
        }

        // 2. Load follow-ups
        $followups = $this->ExecutiveFollowUpModel
            ->getExecutiveFollowUp($followupTypeId, $header['enquiry_header_id']);
        log_message('debug', '[getExecutiveFollowups] followups = ' . print_r($followups, true));

        // 3. Return JSON payload
        return $this->response->setJSON([
            'header'    => $header,
            'followups' => $followups
        ]);
    }

    public function saveExecutiveFollowup()
    {
        $data = $this->request->getPost();

        // 1) combine date + time
        $data['follow_up_time'] = $data['followup_date'] . ' ' . $data['followup_time'];
        if (!empty($data['next_followup_date']) && !empty($data['next_followup_time'])) {
            $data['next_follow_up_time'] = $data['next_followup_date'] . ' ' . $data['next_followup_time'];
        }

        // 2) lookup enquiry_header_id by object_id
        if (!empty($data['object_id'])) {
            $db      = \Config\Database::connect();
            $builder = $db->table('khm_obj_enquiry_header');
            $row     = $builder
                ->select('enquiry_header_id')
                ->where('object_id', $data['object_id'])
                ->get()
                ->getRowArray();

            if ($row) {
                $data['enquiry_header_id'] = $row['enquiry_header_id'];
            } else {
                return $this->response
                    ->setStatusCode(400)
                    ->setJSON([
                        'success' => false,
                        'message' => 'No enquiry_header found for object_id ' . $data['object_id']
                    ]);
            }
        }

        // 3) clean up raw date/time fields
        unset(
            $data['followup_date'],
            $data['followup_time'],
            $data['next_followup_date'],
            $data['next_followup_time']
        );

        // 4) insert or update via your existing model
        try {
            if (!empty($data['executive_follow_up_id'])) {
                $this->ExecutiveFollowUpModel->saveExecutiveFollowUp( $data);
                $message = 'Follow‑up updated successfully';
            } else {
                $this->ExecutiveFollowUpModel->saveExecutiveFollowUp($data);
                $message = 'Follow‑up created successfully';
            }

            return $this->response
                ->setStatusCode(200)
                ->setJSON(['success' => true, 'message' => $message]);
        } catch (\Exception $e) {
            log_message('error', 'Error saving follow‑up: ' . $e->getMessage());
            return $this->response
                ->setStatusCode(500)
                ->setJSON(['success' => false, 'message' => 'Server error']);
        }
    }

    public function editExecutiveFollowup()
    {
        $id = $this->request->getPost('id');
        if (! $id) {
            return $this->response->setStatusCode(400)
                ->setJSON(['success' => false, 'message' => 'No ID provided']);
        }

        $followup = $this->ExecutiveFollowUpModel->find($id);
        if (! $followup) {
            return $this->response->setStatusCode(404)
                ->setJSON(['success' => false, 'message' => 'Follow‑up not found']);
        }

        return $this->response->setJSON(['success' => true, 'data' => $followup]);
    }

    /**
     * Soft‑delete a follow‑up by ID.
     */
    public function deleteExecutiveFollowup()
    {
        $id = $this->request->getPost('id');
        if (! $id) {
            return $this->response->setStatusCode(400)
                ->setJSON(['success' => false, 'message' => 'No ID provided']);
        }

        // sodtDelete sets `deleted = 1`
        $this->ExecutiveFollowUpModel->sodtDelete($id);

        return $this->response->setJSON(['success' => true, 'message' => 'Follow‑up deleted']);
    }
}
