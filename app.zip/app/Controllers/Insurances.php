<?php

namespace App\Controllers;

use App\Models\InsuranceModel;
use CodeIgniter\Controller;
use App\Models\Dashboard_m;

class Insurances extends Controller
{
    public function index()
    {
        $Dashboard_model = new Dashboard_m();
        $entity_id = session('user_id');
        $active_role = session('active_role');
        $all_roles = $Dashboard_model->get_all_entity_roles($entity_id);
        $all_systems = $Dashboard_model->get_all_systems($entity_id);
        $data['all_systems'] = $all_systems;
        if (!empty($all_roles)) {
            $data['all_roles_assn'] = $all_roles;
            $all_menus = $Dashboard_model->get_all_role_menus($active_role);
            if (!empty($all_menus)) {
                $data['all_menus'] = $all_menus;
            } else {
                $data['all_menus'] = [];
            }
            $all_permissions = $Dashboard_model->get_all_entity_permissions($active_role, 3);
            if (!empty($all_permissions)) {
                $data['all_permissions'] = $all_permissions;
            } else {
                $data['all_permissions'] = [];
            }
        } else {
            $data['all_roles_assn'] = [];
            $data['all_menus'] = [];
            $data['all_permissions'] = [];
        }
        $parent_menu = $Dashboard_model->get_parent_menus();
        $sub_menu = $Dashboard_model->get_sub_menus();
        $data['parent_menu'] = $parent_menu;
        $data['sub_menu'] = $sub_menu;
        return view('masters/insurance_view', $data);
    }

    public function fetch()
    {
        try {
            $model = new InsuranceModel();
            $data  = $model->getActiveInsurances();
            return $this->response->setJSON($data);
        } catch (\Exception $e) {
            log_message('error', $e->getMessage());
            return $this->response->setStatusCode(500)
                ->setJSON(['status' => 'error', 'message' => 'Internal Server Error']);
        }
    }

    public function save()
    {
        try {
            $insuranceId = $this->request->getPost('insurance_id');
            $paxFrom     = (int)$this->request->getPost('pax_count_from');
            $paxTo       = (int)$this->request->getPost('pax_count_to');
            $amount      = $this->request->getPost('insurance_amount');

            // Basic validation
            if ($paxFrom === 0 || $paxTo === 0 || !$amount) {
                return $this->response->setJSON([
                    'status'  => 'error',
                    'message' => 'All fields are required',
                ]);
            }

            // 1️⃣ Ensure 'to' is strictly greater than 'from'
            if ($paxTo <= $paxFrom) {
                return $this->response->setJSON([
                    'status'  => 'error',
                    'message' => "'Pax To' must be greater than 'Pax From'.",
                ]);
            }

            $model = new InsuranceModel();

            // 2️⃣ Check for overlapping ranges
            if ($model->isOverlapping($paxFrom, $paxTo, $insuranceId ?: null)) {
                return $this->response->setJSON([
                    'status'  => 'duplicate',
                    'message' => 'This pax range overlaps with an existing record.',
                ]);
            }

            // 3️⃣ (Optional) Your existing duplicate‐by‐amount logic:
            if ($model->isDuplicate($paxFrom, $paxTo, $amount, $insuranceId ?: null)) {
                return $this->response->setJSON([
                    'status'  => 'duplicate',
                    'message' => 'Duplicate insurance record exists for the same pax range and amount.',
                ]);
            }

            // Insert or update
            if (empty($insuranceId)) {
                $res = $model->insertInsurance($paxFrom, $paxTo, $amount);
                $msg = $res
                    ? 'Record added successfully'
                    : 'Failed to add record';
            } else {
                $res = $model->updateInsurance($insuranceId, $paxFrom, $paxTo, $amount);
                $msg = $res !== false
                    ? 'Record updated successfully'
                    : 'Failed to update record';
            }

            return $this->response->setJSON([
                'status'  => $res ? 'success' : 'error',
                'message' => $msg,
            ]);
        } catch (\Exception $e) {
            log_message('error', $e->getMessage());
            return $this->response
                ->setStatusCode(500)
                ->setJSON([
                    'status'  => 'error',
                    'message' => 'Internal Server Error',
                ]);
        }
    }


    public function delete()
    {
        try {
            $insuranceId = $this->request->getPost('insurance_id');
            $model       = new InsuranceModel();
            $res         = $model->softDelete($insuranceId);

            if ($res) {
                return $this->response->setJSON(['status' => 'success', 'message' => 'Record soft-deleted successfully']);
            } else {
                return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to delete record']);
            }
        } catch (\Exception $e) {
            log_message('error', $e->getMessage());
            return $this->response->setStatusCode(500)
                ->setJSON(['status' => 'error', 'message' => 'Internal Server Error']);
        }
    }
}
