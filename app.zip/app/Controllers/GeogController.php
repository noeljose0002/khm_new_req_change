<?php

namespace App\Controllers;

use App\Models\GeogModel;
use CodeIgniter\RESTful\ResourceController;
use App\Models\Dashboard_m;

class GeogController extends ResourceController
{
    protected $geogModel;

    protected $db;

    public function __construct()
    {
        // Initialize the database connection
        $this->db = \Config\Database::connect();
        $this->geogModel = new GeogModel();
    }
    // ===== Geography Endpoints =====

    // Main view (Geography listing).
    public function index()
    {
        $levels  = $this->geogModel->getLevels();
        $records = $this->geogModel->getAllGeogRecordsWithLevel();
        return view('Geog_view', ['levels' => $levels, 'records' => $records]);
    }

    // Get geography levels (AJAX).
    public function getLevels()
    {
        $levels = $this->geogModel->getLevels();
        return $this->respond($levels);
    }

    // Insert a new geography record.
    public function insertGeog()
    {
        // Changed to getJSON(true) to properly receive JSON payload from AJAX call.
        $data = $this->request->getJSON(true);
        // or $data = $this->request->getPost(); depending on how you're submitting

        if (
            empty($data['geog_level_id'])
            || empty($data['enterprise_id'])
            || empty($data['geog_name'])
            || empty($data['geog_parent_id'])
        ) {
            return $this->failValidationErrors('geog_level_id, enterprise_id, geog_name, and geog_parent_id are required');
        }

        // Now $data['geog_parent_id'] should be available 
        // because we used a hidden (not disabled) field in the form.
        $insertId = $this->geogModel->insertGeogRecord($data);
        if ($insertId) {
            return $this->respond(['success' => true, 'message' => 'Record added successfully', 'insertId' => $insertId]);
        }
        return $this->failServerError('Error inserting record');
    }
    private function getDescendantIds(int $rootId): array
    {
        $db      = \Config\Database::connect();
        $builder = $db->table('khm_loc_mst_geography');  // ← your table
        $toVisit = [$rootId];
        $allIds  = [];

        while (! empty($toVisit)) {
            $parent = array_shift($toVisit);

            $rows = $builder
                ->select('geog_id')
                ->where('geog_parent_id', $parent)
                ->where('deleted', 0)
                ->get()
                ->getResultArray();

            foreach ($rows as $r) {
                $cid = (int)$r['geog_id'];
                if (! in_array($cid, $allIds, true)) {
                    $allIds[]  = $cid;
                    $toVisit[] = $cid;
                }
            }
        }

        return $allIds;
    }

    public function countChildren($id = null)
    {
        if (! is_numeric($id)) {
            return $this->response
                ->setStatusCode(400)
                ->setJSON(['error' => 'Invalid ID']);
        }

        $descIds = $this->getDescendantIds((int)$id);
        return $this->response
            ->setJSON(['count' => count($descIds)]);
    }



    // Update an existing geography record.
    public function updateGeog($id = null)
    {
        $data = $this->request->getJSON(true);
        if (!$id) {
            return $this->failValidationErrors('No geog_id provided');
        }
        if (empty($data['enterprise_id']) || empty($data['geog_name'])) {
            return $this->failValidationErrors('enterprise_id and geog_name are required');
        }
        $update = $this->geogModel->updateGeogRecord($id, $data);
        if ($update) {
            return $this->respond(['success' => true, 'message' => 'Record updated successfully']);
        }
        return $this->failServerError('Update failed');
    }

    // Soft delete a geography record.
    public function deleteGeog($id = null)
    {
        if (!$id) {
            return $this->failValidationErrors('No geog_id provided');
        }
        $delete = $this->geogModel->deleteGeogRecord($id);
        if ($delete) {
            return $this->respond(['success' => true, 'message' => 'Record deleted successfully']);
        }
        return $this->failServerError('Deletion failed');
    }

    // Get all geography records.
    public function getGeogs()
    {
        $data = $this->geogModel->getAllGeogRecordsWithLevel();
        return $this->respond($data);
    }

    // Load the Edit Geography view.
    public function editView()
    {
        $levels  = $this->geogModel->getLevels();
        $records = $this->geogModel->getAllGeogRecordsWithLevel();
        return view('masters/geog_edit_view', ['levels' => $levels, 'records' => $records]);
    }

    // Load the Distance Calculator view.
    public function distanceView()
    {
        $Dashboard_model = new Dashboard_m();
        $entity_id = session('user_id');
        $active_role = session('active_role');
        $all_roles = $Dashboard_model->get_all_entity_roles($entity_id);
        $all_systems = $Dashboard_model->get_all_systems($entity_id);
        $data['all_systems'] = $all_systems;
        if (!empty($all_roles)) {
            $data['all_roles_assn'] = $all_roles;
            $all_menus = $Dashboard_model->get_all_role_menus($active_role);
            if (!empty($all_menus)) {
                $data['all_menus'] = $all_menus;
            } else {
                $data['all_menus'] = [];
            }
            $all_permissions = $Dashboard_model->get_all_entity_permissions($active_role, 3);
            if (!empty($all_permissions)) {
                $data['all_permissions'] = $all_permissions;
            } else {
                $data['all_permissions'] = [];
            }
        } else {
            $data['all_roles_assn'] = [];
            $data['all_menus'] = [];
            $data['all_permissions'] = [];
        }
        $parent_menu = $Dashboard_model->get_parent_menus();
        $sub_menu = $Dashboard_model->get_sub_menus();
        $data['parent_menu'] = $parent_menu;
        $data['sub_menu'] = $sub_menu;



        $levels  = $this->geogModel->getLevels();
        $records = $this->geogModel->getAllGeogRecordsWithLevel();
        $data['levels'] = $levels;
        $data['records'] = $records;


        return view('masters/distance_view', $data);
    }

    // Save a calculated distance record.
    public function saveDistance()
    {
        $data = $this->request->getJSON(true);

        // 1) Basic validation (allow zero)
        if (
            empty($data['geog_from_id']) ||
            empty($data['geog_to_id']) ||
            !isset($data['geog_km_distance']) ||
            !is_numeric($data['geog_km_distance']) ||
            $data['geog_km_distance'] < 0
        ) {
            return $this->failValidationErrors('geog_from_id, geog_to_id, and non‑negative geog_km_distance are required');
        }

        // 2) Ensure both geography IDs exist and have lat/lng
        $from = $this->geogModel->getGeogById($data['geog_from_id']);
        $to   = $this->geogModel->getGeogById($data['geog_to_id']);
        if (!$from || !$to) {
            return $this->failValidationErrors('Selected locations must exist');
        }
        if (empty($from['geog_latitude']) || empty($from['geog_longitude'])) {
            return $this->failValidationErrors('Start location missing coordinates');
        }
        if (empty($to['geog_latitude']) || empty($to['geog_longitude'])) {
            return $this->failValidationErrors('End location missing coordinates');
        }

        // Helper: find active record only
        $findActive = function ($fromId, $toId) {
            return $this->geogModel
                ->where([
                    'geog_from_id' => $fromId,
                    'geog_to_id'   => $toId,
                    'deleted'      => 0
                ])
                ->first();
        };

        // 3) Handle A → B
        $recAB = $findActive($data['geog_from_id'], $data['geog_to_id']);
        if ($recAB) {
            // Active exists → update it
            $this->geogModel->update($recAB['geog_dist_id'], [
                'geog_km_distance' => $data['geog_km_distance']
            ]);
            $savedAB = $recAB['geog_dist_id'];
        } else {
            // No active row (even if a deleted row exists) → insert new
            $savedAB = $this->geogModel->insert([
                'geog_from_id'     => $data['geog_from_id'],
                'geog_to_id'       => $data['geog_to_id'],
                'geog_km_distance' => $data['geog_km_distance'],
                'deleted'          => 0
            ]);
        }

        // 4) Handle B → A
        $reverse = [
            'geog_from_id'     => $data['geog_to_id'],
            'geog_to_id'       => $data['geog_from_id'],
            'geog_km_distance' => $data['geog_km_distance'],
        ];
        $recBA = $findActive($reverse['geog_from_id'], $reverse['geog_to_id']);
        if ($recBA) {
            $this->geogModel->update($recBA['geog_dist_id'], ['geog_km_distance' => $reverse['geog_km_distance']]);
            $savedBA = $recBA['geog_dist_id'];
        } else {
            $savedBA = $this->geogModel->insert($reverse + ['deleted' => 0]);
        }

        // 5) Respond
        return $this->respond([
            'success'    => true,
            'message'    => 'Distance records saved successfully.',
            'from_to_id' => $savedAB,
            'to_from_id' => $savedBA,
        ]);
    }


    // Update an existing distance record.
    // If no record exists, this method will insert a new one.
    public function updateDistance()
    {
        $data = $this->request->getJSON(true);

        if (
            empty($data['geog_from_id']) ||
            empty($data['geog_to_id']) ||
            !isset($data['geog_km_distance']) || !is_numeric($data['geog_km_distance'])
        ) {
            return $this->failValidationErrors('geog_from_id, geog_to_id, and geog_km_distance are required');
        }

        // 🔄 Update or insert original direction (A → B)
        $result1 = $this->geogModel->updateDistanceRecord($data);
        if ($result1 === 'not_found') {
            $insert1 = $this->geogModel->saveDistanceRecord($data);
            if ($insert1 === 'duplicate') {
                return $this->failServerError('Duplicate record (from → to) already exists.');
            } elseif (!$insert1) {
                return $this->failServerError('Error saving distance record (from → to).');
            }
        } elseif ($result1 === 'duplicate') {
            return $this->failServerError('Duplicate record (from → to) already exists.');
        } elseif ($result1 !== true) {
            return $this->failServerError('Error updating distance record (from → to).');
        }

        // 🔁 Update or insert reverse direction (B → A)
        $reverseData = $data;
        $reverseData['geog_from_id'] = $data['geog_to_id'];
        $reverseData['geog_to_id'] = $data['geog_from_id'];

        $result2 = $this->geogModel->updateDistanceRecord($reverseData);
        if ($result2 === 'not_found') {
            $insert2 = $this->geogModel->saveDistanceRecord($reverseData);
            if ($insert2 === 'duplicate') {
                return $this->failServerError('Duplicate record (to → from) already exists.');
            } elseif (!$insert2) {
                return $this->failServerError('Error saving distance record (to → from).');
            }
        } elseif ($result2 === 'duplicate') {
            return $this->failServerError('Duplicate record (to → from) already exists.');
        } elseif ($result2 !== true) {
            return $this->failServerError('Error updating distance record (to → from).');
        }

        // ✅ Success
        return $this->respond([
            'success' => true,
            'message' => 'Distance records updated or inserted successfully.'
        ]);
    }

    // New: Get a distance record by from and to IDs.
    public function getDistance()
    {
        $fromId = $this->request->getGet('geog_from_id');
        $toId   = $this->request->getGet('geog_to_id');
        if (!$fromId || !$toId) {
            return $this->failValidationErrors('Both geog_from_id and geog_to_id are required');
        }
        $builder = $this->db->table('khm_loc_mst_geography_distance');
        // Retrieve all records for the combination (both orders)
        $builder->groupStart()
            ->where('geog_from_id', $fromId)
            ->where('geog_to_id', $toId)
            ->groupEnd()
            ->orGroupStart()
            ->where('geog_from_id', $toId)
            ->where('geog_to_id', $fromId)
            ->groupEnd();
        $records = $builder->get()->getResultArray();
        if ($records) {
            // Return the array of matching records.
            return $this->respond(['records' => $records]);
        }
        return $this->respond(['not_found' => true]);
    }

    // ===== Sightseeing Endpoints =====

    // Get sightseeing records for a specific location.
    public function getSightseeingByLocation($location_id = null)
    {
        if (!$location_id) {
            return $this->failValidationErrors('Location ID is required');
        }
        $records = $this->geogModel->getSightseeingByLocation($location_id);
        return $this->respond($records);
    }

    // Update a sightseeing record (handles image upload if provided).
    public function updateSightseeingRecord()
    {
        $data = $this->request->getPost();
        $id   = $data['sightseeing_id'] ?? null;
        if (!$id) {
            return $this->failValidationErrors('Sightseeing ID is required');
        }

        $updateData = [
            'sightseeing_name'     => $data['sightseeing_name'] ?? '',
            'sightseeing_distance' => $data['sightseeing_distance'] ?? 0,
            'tariff'               => $data['tariff'] ?? 0,
            'is_pax'               => isset($data['is_pax']) ? $data['is_pax'] : 0,
        ];

        // Handle image upload.
        $file = $this->request->getFile('sightseeing_image');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            $newName = $file->getRandomName();
            $file->move('./uploads', $newName);
            $updateData['img_path'] = 'uploads/' . $newName;
        }

        $result = $this->geogModel->updateSightseeingRecord($id, $updateData);
        if ($result) {
            return $this->respond(['success' => true, 'message' => 'Record updated successfully']);
        }
        return $this->failServerError('Update failed');
    }

    //default_ss
    public function setDefault($id, $loc_id)
    {
        if (!$id) {
            return $this->failValidationErrors('Sightseeing ID is required');
        }
        $reset_ss = $this->geogModel->resetDefaultSS($loc_id, $id);
        return json_encode($reset_ss);
    }


    // ===== New: Refresh Node Endpoint =====
    // Returns a partial view for the children of a given node.
    public function refreshNode($id = null)
    {
        if (!$id) {
            return $this->failValidationErrors('No node ID provided');
        }

        // Retrieve the child nodes for the given parent ID.
        $children = $this->geogModel->getChildren($id);
        // Return a partial view containing the refreshed node children.
        return view('partials/refreshNode', ['children' => $children]);
    }

    // ===== New: Sublocations Endpoint =====
    // Returns refreshed HTML for the sublocation datatable.
    public function sublocations($id = null)
    {
        if (!$id) {
            return $this->failValidationErrors('No location ID provided');
        }

        // Retrieve child nodes (sublocations) for the given location.
        $children = $this->geogModel->getChildren($id);

        // Build an HTML table for the sublocations.
        $tableHtml  = '<table id="geog-datatable" class="display" style="width:100%">';
        $tableHtml .= '<thead><tr><th>ID</th><th>Name</th><th>Latitude</th><th>Longitude</th><th>Action</th></tr></thead>';
        $tableHtml .= '<tbody>';
        if (!empty($children)) {
            foreach ($children as $child) {
                $tableHtml .= '<tr>';
                $tableHtml .= '<td>' . $child['geog_id'] . '</td>';
                $tableHtml .= '<td>' . $child['geog_name'] . '</td>';
                $tableHtml .= '<td>' . $child['geog_latitude'] . '</td>';
                $tableHtml .= '<td>' . $child['geog_longitude'] . '</td>';
                $tableHtml .= '<td>';
                $tableHtml .= '<button class="btn btn-primary btn-sm edit-sublocation" data-id="' . $child['geog_id'] . '">Edit</button> ';
                $tableHtml .= '<button class="btn btn-danger btn-sm delete-sublocation" data-id="' . $child['geog_id'] . '">Delete</button>';
                $tableHtml .= '</td>';
                $tableHtml .= '</tr>';
            }
        } else {
            $tableHtml .= '<tr><td colspan="5">No sublocations available.</td></tr>';
        }
        $tableHtml .= '</tbody></table>';

        return $tableHtml;
    }
}
