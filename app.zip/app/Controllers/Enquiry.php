<?php

namespace App\Controllers;
use App\Models\Dashboard_m;
use App\Models\Enquiry_m;
use DateTime;
use DateTimeZone;
use DateInterval;
use DatePeriod;

class Enquiry extends BaseController
{
    public function enquiry_list_view($object_class_id)
    {
        if (!empty(session()->get('user_id'))) {
            $Dashboard_model = new Dashboard_m();
            $Enquiry_model = new Enquiry_m();
            $parent_id = session('parent_id');
            $hierarchy_id = session('hierarchy_id');
            $hotel_categories = $Dashboard_model->get_hotel_categories();
            $entity_id = session('user_id');
            $active_role = session('active_role');
            $all_systems = $Dashboard_model->get_all_systems($entity_id);
            $data['all_systems'] = $all_systems;
            $all_roles = $Dashboard_model->get_all_entity_roles($entity_id);
            if(!empty($all_roles)){
                $data['all_roles_assn'] = $all_roles;
                $all_menus = $Dashboard_model->get_all_role_menus($active_role);
                if(!empty($all_menus)){
                    $data['all_menus'] = $all_menus;
                }
                else{
                    $data['all_menus'] = [];
                }
                $all_permissions = $Dashboard_model->get_all_entity_permissions($active_role,3);
                if(!empty($all_permissions)){
                    $data['all_permissions'] = $all_permissions;
                }
                else{
                    $data['all_permissions'] = [];
                }
            }
            else{
                $data['all_roles_assn'] = [];
                $data['all_menus'] = [];
                $data['all_permissions'] = [];
            }
            $object_class_det = $Dashboard_model->get_object_class_details($object_class_id);
            if(!empty($object_class_det)){
                $data['object_class_name'] = $object_class_det[0]['object_class_name'];
            }
            else{
                $data['object_class_name'] = null;
            }
            
            $parent_menu = $Dashboard_model->get_parent_menus();
            $sub_menu = $Dashboard_model->get_sub_menus();
            $data['parent_menu'] = $parent_menu;
            $data['sub_menu'] = $sub_menu;
            $data['object_class_id'] = $object_class_id;
            $data['hotel_categories'] = $hotel_categories;
            $data['parent_id'] = $parent_id;
            $data['hierarchy_id'] = $hierarchy_id;
            return view('enquiry/enquiry_list_view',$data);
        }
        else{
            return redirect()->to('Login');
        }    
    }

    public function sales_report()
    {
        if (!empty(session()->get('user_id'))) {
            $Dashboard_model = new Dashboard_m();
            $Enquiry_model = new Enquiry_m();
            $parent_id = session('parent_id');
            $hierarchy_id = session('hierarchy_id');
            $entity_id = session('user_id');
            $active_role = session('active_role');
            $all_systems = $Dashboard_model->get_all_systems($entity_id);
            $data['all_systems'] = $all_systems;
            $all_roles = $Dashboard_model->get_all_entity_roles($entity_id);
            if(!empty($all_roles)){
                $data['all_roles_assn'] = $all_roles;
                $all_menus = $Dashboard_model->get_all_role_menus($active_role);
                if(!empty($all_menus)){
                    $data['all_menus'] = $all_menus;
                }
                else{
                    $data['all_menus'] = [];
                }
                $all_permissions = $Dashboard_model->get_all_entity_permissions($active_role,3);
                if(!empty($all_permissions)){
                    $data['all_permissions'] = $all_permissions;
                }
                else{
                    $data['all_permissions'] = [];
                }
            }
            else{
                $data['all_roles_assn'] = [];
                $data['all_menus'] = [];
                $data['all_permissions'] = [];
            }
            $all_executives = $Dashboard_model->get_all_executives();
            $all_status = $Enquiry_model->get_all_status();
            $all_agents = $Enquiry_model->get_all_agents();
            $parent_menu = $Dashboard_model->get_parent_menus();
            $sub_menu = $Dashboard_model->get_sub_menus();
            $data['parent_menu'] = $parent_menu;
            $data['sub_menu'] = $sub_menu;
            $data['parent_id'] = $parent_id;
            $data['hierarchy_id'] = $hierarchy_id;
            $data['all_executives'] = $all_executives;
            $data['all_status'] = $all_status;
            $data['all_agents'] = $all_agents;
            return view('enquiry/sales_report',$data);
        }
        else{
            return redirect()->to('Login');
        }    
    }
    public function sales_report_new()
    {
        if (!empty(session()->get('user_id'))) {
            $Dashboard_model = new Dashboard_m();
            $Enquiry_model = new Enquiry_m();
            $parent_id = session('parent_id');
            $hierarchy_id = session('hierarchy_id');
            $entity_id = session('user_id');
            $active_role = session('active_role');
            $all_systems = $Dashboard_model->get_all_systems($entity_id);
            $data['all_systems'] = $all_systems;
            $all_roles = $Dashboard_model->get_all_entity_roles($entity_id);
            if(!empty($all_roles)){
                $data['all_roles_assn'] = $all_roles;
                $all_menus = $Dashboard_model->get_all_role_menus($active_role);
                if(!empty($all_menus)){
                    $data['all_menus'] = $all_menus;
                }
                else{
                    $data['all_menus'] = [];
                }
                $all_permissions = $Dashboard_model->get_all_entity_permissions($active_role,3);
                if(!empty($all_permissions)){
                    $data['all_permissions'] = $all_permissions;
                }
                else{
                    $data['all_permissions'] = [];
                }
            }
            else{
                $data['all_roles_assn'] = [];
                $data['all_menus'] = [];
                $data['all_permissions'] = [];
            }
            $all_executives = $Dashboard_model->get_all_executives();
            $all_status = $Enquiry_model->get_all_status();
            $all_agents = $Enquiry_model->get_all_agents();
            $parent_menu = $Dashboard_model->get_parent_menus();
            $sub_menu = $Dashboard_model->get_sub_menus();
            $data['parent_menu'] = $parent_menu;
            $data['sub_menu'] = $sub_menu;
            $data['parent_id'] = $parent_id;
            $data['hierarchy_id'] = $hierarchy_id;
            $data['all_executives'] = $all_executives;
            $data['all_status'] = $all_status;
            $data['all_agents'] = $all_agents;
            return view('enquiry/sales_report_new',$data);
        }
        else{
            return redirect()->to('Login');
        }    
    }
    public function payment_tracker()
    {
        if (!empty(session()->get('user_id'))) {
            $Dashboard_model = new Dashboard_m();
            $Enquiry_model = new Enquiry_m();
            $parent_id = session('parent_id');
            $hierarchy_id = session('hierarchy_id');
            $entity_id = session('user_id');
            $active_role = session('active_role');
            $all_systems = $Dashboard_model->get_all_systems($entity_id);
            $data['all_systems'] = $all_systems;
            $all_roles = $Dashboard_model->get_all_entity_roles($entity_id);
            if(!empty($all_roles)){
                $data['all_roles_assn'] = $all_roles;
                $all_menus = $Dashboard_model->get_all_role_menus($active_role);
                if(!empty($all_menus)){
                    $data['all_menus'] = $all_menus;
                }
                else{
                    $data['all_menus'] = [];
                }
                $all_permissions = $Dashboard_model->get_all_entity_permissions($active_role,3);
                if(!empty($all_permissions)){
                    $data['all_permissions'] = $all_permissions;
                }
                else{
                    $data['all_permissions'] = [];
                }
            }
            else{
                $data['all_roles_assn'] = [];
                $data['all_menus'] = [];
                $data['all_permissions'] = [];
            }
            $all_executives = $Dashboard_model->get_all_executives();
            $all_status = $Enquiry_model->get_all_status();
            $all_agents = $Enquiry_model->get_all_agents();
            $parent_menu = $Dashboard_model->get_parent_menus();
            $sub_menu = $Dashboard_model->get_sub_menus();
            $data['parent_menu'] = $parent_menu;
            $data['sub_menu'] = $sub_menu;
            $data['parent_id'] = $parent_id;
            $data['hierarchy_id'] = $hierarchy_id;
            $data['all_executives'] = $all_executives;
            $data['all_status'] = $all_status;
            $data['all_agents'] = $all_agents;
            return view('enquiry/payment_tracker',$data);
        }
        else{
            return redirect()->to('Login');
        }    
    }

    public function confirm_costing_sheet($enquiry_header_id,$object_id){
        $Dashboard_model = new Dashboard_m();
        $Enquiry_model = new Enquiry_m();
        $object_class_id = 10; 
        $entity_id = session('user_id');
        $active_role = session('active_role');
        $all_systems = $Dashboard_model->get_all_systems($entity_id);
        $data['all_systems'] = $all_systems;
        $all_roles = $Dashboard_model->get_all_entity_roles($entity_id);
        if(!empty($all_roles)){
            $data['all_roles_assn'] = $all_roles;
            $all_menus = $Dashboard_model->get_all_role_menus($active_role);
            if(!empty($all_menus)){
                $data['all_menus'] = $all_menus;
            }
            else{
                $data['all_menus'] = [];
            }
            $all_permissions = $Dashboard_model->get_all_entity_permissions($active_role,3);
            if(!empty($all_permissions)){
                $data['all_permissions'] = $all_permissions;
            }
            else{
                $data['all_permissions'] = [];
            }
        }
        else{
            $data['all_roles_assn'] = [];
            $data['all_menus'] = [];
            $data['all_permissions'] = [];
        }
        $enterprise_id = 1;
        $object_type_id = 5;
        $parent_menu = $Dashboard_model->get_parent_menus();
        $sub_menu = $Dashboard_model->get_sub_menus();
        $data['parent_menu'] = $parent_menu;
        $data['sub_menu'] = $sub_menu;
        $data['object_class_id'] = $object_class_id;
        $data['object_type_id'] = $object_type_id;
        $data['enquiry_header_id'] = $enquiry_header_id;
        $data['object_det'] = $Enquiry_model->get_object_details($object_id);
        //$data['cs_datas'] = $Enquiry_model->get_all_cs_details($enquiry_header_id);
        $data['object_class_name'] = "Enquiry";
        return view('enquiry/itinerary_details_view',$data);
    }
    public function payments($enquiry_header_id,$cs_confirmed_id){
        $Dashboard_model = new Dashboard_m();
        $Enquiry_model = new Enquiry_m();
        $parent_id = session('parent_id');
        $object_class_id = 10; 
        $entity_id = session('user_id');
        $active_role = session('active_role');
        $all_systems = $Dashboard_model->get_all_systems($entity_id);
        $data['all_systems'] = $all_systems;
        $all_roles = $Dashboard_model->get_all_entity_roles($entity_id);
        if(!empty($all_roles)){
            $data['all_roles_assn'] = $all_roles;
            $all_menus = $Dashboard_model->get_all_role_menus($active_role);
            if(!empty($all_menus)){
                $data['all_menus'] = $all_menus;
            }
            else{
                $data['all_menus'] = [];
            }
            $all_permissions = $Dashboard_model->get_all_entity_permissions($active_role,3);
            if(!empty($all_permissions)){
                $data['all_permissions'] = $all_permissions;
            }
            else{
                $data['all_permissions'] = [];
            }
        }
        else{
            $data['all_roles_assn'] = [];
            $data['all_menus'] = [];
            $data['all_permissions'] = [];
        }
        $enterprise_id = 1;
        $object_type_id = 5;
        $parent_menu = $Dashboard_model->get_parent_menus();
        $sub_menu = $Dashboard_model->get_sub_menus();
        $data['parent_menu'] = $parent_menu;
        $data['sub_menu'] = $sub_menu;
        $data['object_class_id'] = $object_class_id;
        $data['cs_confirmed_id'] = $cs_confirmed_id;
        $data['enquiry_header_id'] = $enquiry_header_id;
        $data['parent_id'] = $parent_id;
        //$data['object_det'] = $Enquiry_model->get_object_details($object_id);
        //$data['cs_datas'] = $Enquiry_model->get_all_cs_details($enquiry_header_id);
        $data['object_class_name'] = "Enquiry";
        return view('enquiry/payment_view',$data);
    }
    public function followup_form($enquiry_header_id,$confirm_cs_id){ 
        $Dashboard_model = new Dashboard_m();
        $Enquiry_model = new Enquiry_m();
        $extension_ref_id = "";
        $tour_plan_ref_id = "";
        $enquiry_ref_id = "";
        $all_transporter = $Dashboard_model->get_all_transporter();
        $vehicle_details = [];
        $no_of_adult = "";
        $no_of_child_with_bed = "";
        $no_of_child_without_bed = "";
        $object_class_id = 10; 
        $entity_id = session('user_id');
        $active_role = session('active_role');
        $all_systems = $Dashboard_model->get_all_systems($entity_id);
        $data['all_systems'] = $all_systems;
        $all_roles = $Dashboard_model->get_all_entity_roles($entity_id);
        if(!empty($all_roles)){
            $data['all_roles_assn'] = $all_roles;
            $all_menus = $Dashboard_model->get_all_role_menus($active_role);
            if(!empty($all_menus)){
                $data['all_menus'] = $all_menus;
            }
            else{
                $data['all_menus'] = [];
            }
            $all_permissions = $Dashboard_model->get_all_entity_permissions($active_role,3);
            if(!empty($all_permissions)){
                $data['all_permissions'] = $all_permissions;
            }
            else{
                $data['all_permissions'] = [];
            }
        }
        else{
            $data['all_roles_assn'] = [];
            $data['all_menus'] = [];
            $data['all_permissions'] = [];
        }
        $enterprise_id = 1;
        $object_type_id = 5;
        $parent_menu = $Dashboard_model->get_parent_menus();
        $sub_menu = $Dashboard_model->get_sub_menus();
        $data['parent_menu'] = $parent_menu;
        $data['sub_menu'] = $sub_menu;
        $data['object_class_id'] = $object_class_id;
        $data['object_type_id'] = $object_type_id;
        $data['enquiry_header_id'] = $enquiry_header_id;
        $data['confirm_cs_id'] = $confirm_cs_id;
        $object_det = $Enquiry_model->get_object_details_byheader($enquiry_header_id);
        $guest_det = $Enquiry_model->get_guest_details_for_followup($enquiry_header_id);
        $ext_det = $Enquiry_model->getExtensionDetailsbyid($confirm_cs_id);
        $cut_off_date = $object_det[0]['cut_off_date'];
        $data['cut_off_date'] = $cut_off_date;
        $data['object_det'] = $object_det;
        $data['guest_det'] = $guest_det;
        if(!empty($ext_det)){
            $extension_ref_id = $ext_det[0]['extension_ref_id'];
            $tour_plan_ref_id = $ext_det[0]['tour_plan_ref_id'];
            $enquiry_ref_id = $ext_det[0]['enquiry_ref_id'];
        }
        
        $data['extension_ref_id'] = $extension_ref_id;
        $data['tour_plan_ref_id'] = $tour_plan_ref_id;
        $data['enquiry_ref_id'] = $enquiry_ref_id;
        
        $enq_details = $Enquiry_model->get_enquiry_details_data($enquiry_header_id,$enquiry_ref_id);
        if(!empty($enq_details)){
            $no_of_adult = $enq_details[0]['no_of_adult'];
            $no_of_child_with_bed = $enq_details[0]['no_of_child_with_bed'];
            $no_of_child_without_bed = $enq_details[0]['no_of_child_without_bed'];
            if($enq_details[0]['is_vehicle_required'] == 1){
                $vehicle_details = $enq_details[0]['vehicle_type_id'];
            }
        }
        $data['no_of_adult'] = $no_of_adult;
        $data['no_of_child_with_bed'] = $no_of_child_with_bed;
        $data['no_of_child_without_bed'] = $no_of_child_without_bed;
        if(!empty($vehicle_details)){
            $data['vehicle_details'] = json_decode($vehicle_details, true);
        }
        else{
            $data['vehicle_details'] = [];
        }
        $data['all_transporter'] = $all_transporter;
        $data['object_class_name'] = "Enquiry";
        return view('enquiry/followup_view',$data);
    }
    public function enquiry_list_data()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $data = $Enquiry_model->enquiry_list_data($this->request->getPost());
            echo json_encode($data);
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function add_object_enquiry($object_class_id,$edit_id = null)
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $Dashboard_model = new Dashboard_m();
            $entity_id = session('user_id');
            $active_role = session('active_role');
            $all_systems = $Dashboard_model->get_all_systems($entity_id);
            $data['all_systems'] = $all_systems;
            $all_roles = $Dashboard_model->get_all_entity_roles($entity_id);
            if(!empty($all_roles)){
                $data['all_roles_assn'] = $all_roles;
                $all_menus = $Dashboard_model->get_all_role_menus($active_role);
                if(!empty($all_menus)){
                    $data['all_menus'] = $all_menus;
                }
                else{
                    $data['all_menus'] = [];
                }
                $all_permissions = $Dashboard_model->get_all_entity_permissions($active_role,3);
                if(!empty($all_permissions)){
                    $data['all_permissions'] = $all_permissions;
                }
                else{
                    $data['all_permissions'] = [];
                }
            }
            else{
                $data['all_roles_assn'] = [];
                $data['all_menus'] = [];
                $data['all_permissions'] = [];
            }
            if($edit_id){
                $object_datas = $Enquiry_model->load_object_enquiry_datas_foredit($edit_id);
                $obj_name = $object_datas[0]['object_name'];
                $obj_loc = $object_datas[0]['object_location_id'];
                if(!empty($object_datas[0]['agentid'])){
                    $agentid = $object_datas[0]['agentid'];
                    $agent_details = $Enquiry_model->getAgentDetailsforedit($agentid);
                    foreach($agent_details as $keys => $vals){
                        if($vals['entity_attribute_id'] == "15"){
                            $agent_state_id = $vals['entity_attr_value'];
                        }
                    }
                }
                else{
                    $agentid = '';
                    $agent_details = [];
                    $agent_state_id = '';
                }
                $guestid = $object_datas[0]['guestid'];
                $date_of_tour_start = $object_datas[0]['date_of_tour_start'];
                $no_of_night = $object_datas[0]['no_of_night'];
                $date_of_tour_completion = $object_datas[0]['date_of_tour_completion'];
                $enquiry_source = $object_datas[0]['enquiry_source'];
                $total_no_of_pax = $object_datas[0]['total_no_of_pax'];
                $no_of_adult = $object_datas[0]['no_of_adult'];
                $no_of_child_with_bed = $object_datas[0]['no_of_child_with_bed'];
                $no_of_child_without_bed = $object_datas[0]['no_of_child_without_bed'];
                $no_of_double_room = $object_datas[0]['no_of_double_room'];
                $no_of_single_room = $object_datas[0]['no_of_single_room'];
                $no_of_extra_bed = $object_datas[0]['no_of_extra_bed'];
                $gstin = $object_datas[0]['gstin'];
                $vehicle_from_location = $object_datas[0]['vehicle_from_location'];
                $arrival_location = $object_datas[0]['arrival_location'];
                $departure_location = $object_datas[0]['departure_location'];
                $hotel_category = $object_datas[0]['hotel_category'];
                $meal_plan = $object_datas[0]['meal_plan'];
                $is_vehicle_required = $object_datas[0]['is_vehicle_required'];
                $is_sight_seeing_required = $object_datas[0]['is_sight_seeing_required'];
                $is_quick_quote = $object_datas[0]['is_quick_quote'];
                $enq_description = $object_datas[0]['enq_description'];

                $obj_mobiles = json_decode($object_datas[0]['object_ph_no'],true);
                $obj_emails = json_decode($object_datas[0]['object_email'],true);
                $obj_addresss = json_decode($object_datas[0]['object_address'],true);

                $obj_mobile = $obj_mobiles[0];
                $obj_email = $obj_emails[0];
                $obj_address = $obj_addresss[0];

                $agentaddress = json_decode($object_datas[0]['agentaddress'],true);
                $vehicle_type_id = json_decode($object_datas[0]['vehicle_type_id'],true);

                
            }
            else{
          
                $obj_name = '';
                $obj_loc = '';

                $agentid = '';
                $guestid = '';
                $date_of_tour_start = '';
                $no_of_night = '';
                $date_of_tour_completion = '';
                $enquiry_source = '';
                $total_no_of_pax = '';
                $no_of_adult = '';
                $no_of_child_with_bed = '';
                $no_of_child_without_bed = '';
                $no_of_double_room = '';
                $no_of_single_room = '';
                $no_of_extra_bed = '';
                $gstin = '';
                $vehicle_from_location = '';
                $arrival_location = '';
                $departure_location = '';
                $hotel_category = '';
                $meal_plan = '';
                $is_vehicle_required = '';
                $is_sight_seeing_required = '';
                $is_quick_quote = '';
                $enq_description = '';
                
                $obj_mobile = '';
                $obj_email = '';
                $obj_address = '';

                $agentaddress = [];
                $vehicle_type_id = [];
                $agent_details = [];
                $agent_state_id = '';
            }
            $all_locations = $Dashboard_model->get_all_locations();
            $arrival_locations = $Dashboard_model->get_arrival_locations();
            $departure_locations = $Dashboard_model->get_departure_locations();
            $hotel_categories = $Dashboard_model->get_hotel_categories();
            $meal_plans = $Dashboard_model->get_meal_plan();
            $hub_loc = $Dashboard_model->get_hub_location();
            $enterprise_id = 1;
            //$attributes = $Dashboard_model->get_all_obj_attributes($object_class_id);
            //$boolean_attributes = $Dashboard_model->get_obj_boolean_attributes($object_class_id);
            $object_class_det = $Dashboard_model->get_object_class_details($object_class_id);
            $object_type_id = 5;
            $parent_menu = $Dashboard_model->get_parent_menus();
            $sub_menu = $Dashboard_model->get_sub_menus();
            $data['parent_menu'] = $parent_menu;
            $data['sub_menu'] = $sub_menu;
            $data['object_class_id'] = $object_class_id;
            $data['object_type_id'] = $object_type_id;
            if(!empty($object_class_det)){
                $data['object_class_name'] = $object_class_det[0]['object_class_name'];
            }
            else{
                $data['object_class_name'] = null;
            }
            $data['states'] = $Enquiry_model->indian_states();
            $data['all_agents'] = $Enquiry_model->get_all_agents();
            $data['all_locations'] = $all_locations;
            $data['arrival_locations'] = $arrival_locations;
            $data['departure_locations'] = $departure_locations;
            $data['hotel_categories'] = $hotel_categories;
            $data['meal_plans'] = $meal_plans;
            $data['hub_loc'] = $hub_loc;
            $data['enterprise_id'] = $enterprise_id;
            $data['edit_id'] = $edit_id;

            $data['obj_name'] = $obj_name;
            $data['obj_loc'] = $obj_loc;
            $data['agentid'] = $agentid;
            $data['guestid'] = $guestid;
            $data['date_of_tour_start'] = $date_of_tour_start;
            $data['no_of_night'] = $no_of_night;
            $data['date_of_tour_completion'] = $date_of_tour_completion;
            $data['enquiry_source'] = $enquiry_source;
            $data['total_no_of_pax'] = $total_no_of_pax;
            $data['no_of_adult'] = $no_of_adult;
            $data['no_of_child_with_bed'] = $no_of_child_with_bed;
            $data['no_of_child_without_bed'] = $no_of_child_without_bed;
            $data['no_of_double_room'] = $no_of_double_room;
            $data['no_of_single_room'] = $no_of_single_room;
            $data['no_of_extra_bed'] = $no_of_extra_bed;
            $data['gstin'] = $gstin;
            $data['vehicle_from_location'] = $vehicle_from_location;
            $data['arrival_location'] = $arrival_location;
            $data['departure_location'] = $departure_location;
            $data['hotel_category'] = $hotel_category;
            $data['meal_plan'] = $meal_plan;
            $data['is_vehicle_required'] = $is_vehicle_required;
            $data['is_sight_seeing_required'] = $is_sight_seeing_required;
            $data['is_quick_quote'] = $is_quick_quote;
            $data['enq_description'] = $enq_description;

            $data['obj_mobile'] = $obj_mobile;
            $data['obj_email'] = $obj_email;
            $data['obj_address'] = $obj_address;
            $data['agentaddress'] = $agentaddress;
            $data['vehicle_type_id'] = $vehicle_type_id;
            $data['agent_details'] = $agent_details; 
            $data['agent_state_id'] = $agent_state_id;
            return view('enquiry/add_object_enquiry',$data);
        }
        else{
            return redirect()->to('Login');
        }
    }
    function getAgents()
    {
        $Enquiry_model = new Enquiry_m();
        if ($this->request->getPost('location_id')) {
            echo $Enquiry_model->get_agents($this->request->getPost('location_id'));
        }
    }
    function getTourHotels()
    {
        $Enquiry_model = new Enquiry_m();
        $is_quick_quote = $this->request->getPost('is_quick_quote');
        $tour_location_id = $this->request->getPost('tour_location_id');
        if ($this->request->getPost('hotel_cat_id')) {
            echo $Enquiry_model->getTourHotels($this->request->getPost('hotel_cat_id'),$tour_location_id,$is_quick_quote);
        }
    }
    function getTourHotelsDraft()
    {
        $Enquiry_model = new Enquiry_m();
        $is_quick_quote = $this->request->getPost('is_quick_quote');
        $tour_location_id = $this->request->getPost('tour_location_id');
        $hid = $this->request->getPost('hid');
        if ($this->request->getPost('hotel_cat_id')) {
            echo $Enquiry_model->getTourHotelsDraft($this->request->getPost('hotel_cat_id'),$tour_location_id,$is_quick_quote,$hid);
        }
    }
    function getTourRoomCategory()
    {
        $Enquiry_model = new Enquiry_m();
        //if ($this->request->getPost('hotel_id')) {
            echo $Enquiry_model->getTourRoomCategory($this->request->getPost('hotel_id'),$this->request->getPost('no_of_double_room'),$this->request->getPost('no_of_single_room'));
        //}
    }
    function getHotelfacilities()
    {
        $Enquiry_model = new Enquiry_m();
        echo $Enquiry_model->getHotelfacilities($this->request->getPost('hotel_id'));
    }
    function getHotelFacilityTariff()
    {
        $Enquiry_model = new Enquiry_m();
        //if ($this->request->getPost('hotel_id')) {
            $result =  $Enquiry_model->getHotelFacilityTariff($this->request->getPost('facility_id'));
            echo json_encode($result);
        //}
    }
    function getSightSeeingTariff()
    {
        $Enquiry_model = new Enquiry_m();
        //if ($this->request->getPost('hotel_id')) {
            $result =  $Enquiry_model->getSightSeeingTariff($this->request->getPost('sight_seeing_id'));
            if(!empty($result)){
                echo json_encode($result);
            }
            else{
                echo 0;
            }
        //}
    }
    function getItineraryDetailsById()
    {
        $Enquiry_model = new Enquiry_m();
            $result =  $Enquiry_model->getItineraryDetailsById($this->request->getPost('itinerary_id'));
            if(!empty($result)){
                echo json_encode($result);
            }
            else{
                echo 0;
            }
    }
    function getallitineraryids()
    {
        $Enquiry_model = new Enquiry_m();
            $result =  $Enquiry_model->getallitineraryids($this->request->getPost('final_save_flag'));
            echo json_encode($result);
    }
    function getTourRoomCategoryDraft()
    {
        $Enquiry_model = new Enquiry_m();
        //if ($this->request->getPost('hotel_id')) {
            echo $Enquiry_model->getTourRoomCategoryDraft($this->request->getPost('hotel_id'),$this->request->getPost('rid'),$this->request->getPost('no_of_double_room'),$this->request->getPost('no_of_single_room'));
        //}
    }
    function loadTourLocation()
    {
        $Enquiry_model = new Enquiry_m();
        $response =  $Enquiry_model->loadTourLocation($this->request->getPost('enquiry_header_id'),$this->request->getPost('enquiry_details_id'));
        echo json_encode($response);
    }
    function loadTourLocationEdit()
    {
        $Enquiry_model = new Enquiry_m();
        $response =  $Enquiry_model->loadTourLocationEdit($this->request->getPost('enquiry_header_id'),$this->request->getPost('enquiry_details_id'),$this->request->getPost('extension_ref_id'));
        echo json_encode($response);
    }
    function getVehicleTypes()
    {
        $Enquiry_model = new Enquiry_m();
        if ($this->request->getPost('location_id')) {
            echo $Enquiry_model->getVehicleTypes($this->request->getPost('location_id'));
        }
    }
    public function getAgentDetails()
    {
        $Enquiry_model = new Enquiry_m();
        $adetails = $Enquiry_model->getAgentDetails($this->request->getPost('agent_id'));
        echo json_encode($adetails); 
    }
    public function getHotelConfirmationData()
    {
        $Enquiry_model = new Enquiry_m();
        $adetails = $Enquiry_model->getHotelConfirmationData($this->request->getPost('itinerary_details_id'));
        echo json_encode($adetails); 
    }
    public function getPaymentHistoryData()
    {
        $Enquiry_model = new Enquiry_m();
        $adetails = $Enquiry_model->getPaymentHistoryData($this->request->getPost('payment_id'));
        echo json_encode($adetails); 
    }
    public function getTransportFollowupData()
    {
        $Enquiry_model = new Enquiry_m();
        $adetails = $Enquiry_model->getTransportFollowupData($this->request->getPost('transport_follow_up_id'));
        echo json_encode($adetails); 
    }
    public function updateConfirmHotel()
    {
        $Enquiry_model = new Enquiry_m();
        $itinerary_details_id = $this->request->getPost('itinerary_details_id');
        $tour_details_id = $this->request->getPost('tour_details_id');
        $cn_exist = $Enquiry_model->is_exist_confirm_hotel($itinerary_details_id);
        if($cn_exist == 0){
            $cn_data = array(
                'itinerary_details_id' => $itinerary_details_id,
                'tour_details_id' => $tour_details_id,
                'confirm_status' => $this->request->getPost('confirm_status'),
                'confirm_date' => $this->request->getPost('confirm_date'),
                'confirmed_by' => $this->request->getPost('confirmed_by'),
                'reference_id' => $this->request->getPost('reference_id'),
                'rate' => $this->request->getPost('rate'),
                'cut_off_date' => $this->request->getPost('cut_off_date'),
                'advance' => $this->request->getPost('advance'),
                'comments' => $this->request->getPost('comments'),
                'reconfirm_status' => $this->request->getPost('reconfirm_status'),
                'reconfirm_date' => $this->request->getPost('reconfirm_date'),
                'reconfirmed_by' => $this->request->getPost('reconfirmed_by'),
                'rcomments' => $this->request->getPost('rcomments'),
                'enterprise_id' => 1
            );
            $cn_insert = $Enquiry_model->insert_confirm_hotel($cn_data);  
            echo 1;
        }
        else if($cn_exist > 0){
            $cn_data = array(
                'confirm_status' => $this->request->getPost('confirm_status'),
                'confirm_date' => $this->request->getPost('confirm_date'),
                'confirmed_by' => $this->request->getPost('confirmed_by'),
                'reference_id' => $this->request->getPost('reference_id'),
                'rate' => $this->request->getPost('rate'),
                'cut_off_date' => $this->request->getPost('cut_off_date'),
                'advance' => $this->request->getPost('advance'),
                'comments' => $this->request->getPost('comments'),
                'reconfirm_status' => $this->request->getPost('reconfirm_status'),
                'reconfirm_date' => $this->request->getPost('reconfirm_date'),
                'reconfirmed_by' => $this->request->getPost('reconfirmed_by'),
                'rcomments' => $this->request->getPost('rcomments')
            );
            $cn_update = $Enquiry_model->update_confirm_hotel($cn_data,$itinerary_details_id);  
            echo 1;
        }
        else{
            echo 0;
        }
    }
    

    public function updatePaymentHistoryDet()
    {
        $Enquiry_model = new Enquiry_m();
        $payment_id = $this->request->getPost('payment_id');
        
            $cn_data = array(
                'payment_date' => $this->request->getPost('payment_date'),
                'paid_amount' => $this->request->getPost('paid_amount'),
                'payment_type' => $this->request->getPost('payment_type'),
                'payment_bank' => $this->request->getPost('payment_bank'),
                'payment_details' => $this->request->getPost('payment_details'),
                'edit_reason' => $this->request->getPost('edit_reason')
            );
            $cn_update = $Enquiry_model->update_payment_history_det($cn_data,$payment_id);  
            if($cn_update){
                echo 1;
            }
            else{
                echo 0;
            }
            
    }


    public function updateExecutiveFollowup()
    {
        $Enquiry_model = new Enquiry_m();
            $cn_data = array(
                'followup_type_id' => 1,
                'enquiry_header_id' => $this->request->getPost('enquiry_header_id'),
                'contacted_person' => $this->request->getPost('con_person'),
                'follow_up_time' => $this->request->getPost('ftime'),
                'next_follow_up_time' => $this->request->getPost('next_ftime'),
                'follow_up_type' => $this->request->getPost('ftype'),
                'disposition' => $this->request->getPost('disposition'),
                'remarks' => $this->request->getPost('fremarks'),
                'deleted' => 0,
                'enterprise_id' => 1
            );
            $cn_insert = $Enquiry_model->insert_executive_followup($cn_data);  
            if($cn_insert){

                echo 1;
            }
            else{
                 echo 0;
            }
    }
    
    public function savePaymentDetails()
    {
        $Enquiry_model = new Enquiry_m();
        $enquiry_header_id = $this->request->getPost('enquiry_header_id');
        $cs_confirmed_id = $this->request->getPost('cs_confirmed_id');
        $payment_amount = $this->request->getPost('payment_amount');
        $payment_date = $this->request->getPost('payment_date');
        $payment_type = $this->request->getPost('payment_type');
        $payment_bank = $this->request->getPost('payment_bank');
        $payment_details = $this->request->getPost('payment_details');
        $er_det = $Enquiry_model->getEditRequestDetails($enquiry_header_id);
        $ext_det = $Enquiry_model->getExtensionDetailsbyid($cs_confirmed_id);    
        $enq_det = $Enquiry_model->getEnquiryDetailsforpayments($enquiry_header_id,$ext_det[0]['enquiry_ref_id'],$er_det[0]['enquiry_edit_request_id']);      
            $cn_data = array(
                'enquiry_header_id' => $enquiry_header_id,
                'ref_no' => $enq_det[0]['ref_no'],
                'guest_id' =>  $enq_det[0]['guest_entity_id'],
                'agent_id' =>  $enq_det[0]['agent_entity_id'],
                'executive_id' =>  $enq_det[0]['executive_id'],
                'sop_executive_id' =>  $enq_det[0]['sop_id'],
                'invoice_no' =>  $enq_det[0]['ref_no'],
                'check_in' =>  $enq_det[0]['date_of_tour_start'],
                'check_out' =>  $enq_det[0]['date_of_tour_completion'],
                'total_amount' =>  $ext_det[0]['tpc'],
                'paid_amount' => $payment_amount,
                'payment_date' => $payment_date,
                'payment_type' => $payment_type,
                'payment_bank' => $payment_bank,
                'payment_details' => $payment_details,
                'approved_status' => 0,
                'is_active' => 1,
                'enterprise_id' => 1
            );
            $cn_insert = $Enquiry_model->insert_payment_details($cn_data);  
            if($cn_insert){

                echo 1;
            }
            else{
                 echo 0;
            }
    }
    public function updateTransportFollowup()
    {
        $Enquiry_model = new Enquiry_m();
        $vehicle_id = $this->request->getPost('vehicle_id');
        $enquiry_header_id = $this->request->getPost('enquiry_header_id');
        $v_exist = $Enquiry_model->is_vehicle_id_exist($vehicle_id,$enquiry_header_id);     
        $parts = explode("_", $vehicle_id);
        $vehicle_model_id = $parts[0];
        $hd_transport_follow_up_id = $this->request->getPost('hd_transport_follow_up_id');
        $tr_edit_id = $this->request->getPost('tr_edit_id');
        if($tr_edit_id == 1){
                $up_data = array(
                    'vehicle_time' => $this->request->getPost('vehicle_time'),
                    'vehicle_id' => $vehicle_id,
                    'vehicle_model_id' => $vehicle_model_id,
                    'transporter_id' => $this->request->getPost('transporter_id'),
                    'vehicle_rate' => $this->request->getPost('vehicle_rate'),
                    'vehicle_no' => $this->request->getPost('vehicle_no'),
                    'driver_name' => $this->request->getPost('driver_name'),
                    'agreed_amount' => $this->request->getPost('agreed_amount'),
                    'vehicle_mode' => $this->request->getPost('vehicle_mode'),
                    'phone_number' => $this->request->getPost('phone_number'),
                    'confirmed_by' => $this->request->getPost('confirmed_by'),
                    'remarks' => $this->request->getPost('remarks'),
                    'meet_greet' => $this->request->getPost('meet_greet')
                );
            $cn_update = $Enquiry_model->update_transport_followup($up_data,$hd_transport_follow_up_id);  
            if($cn_update){
                echo 1;
            }
            else{
                echo 0 ;
            }
        }
        else{
            
            if($v_exist == 0){
                $cn_data = array(
                    'enquiry_header_id' => $this->request->getPost('enquiry_header_id'),
                    'vehicle_time' => $this->request->getPost('vehicle_time'),
                    'vehicle_id' => $vehicle_id,
                    'vehicle_model_id' => $vehicle_model_id,
                    'transporter_id' => $this->request->getPost('transporter_id'),
                    'vehicle_rate' => $this->request->getPost('vehicle_rate'),
                    'vehicle_no' => $this->request->getPost('vehicle_no'),
                    'driver_name' => $this->request->getPost('driver_name'),
                    'agreed_amount' => $this->request->getPost('agreed_amount'),
                    'vehicle_mode' => $this->request->getPost('vehicle_mode'),
                    'phone_number' => $this->request->getPost('phone_number'),
                    'confirmed_by' => $this->request->getPost('confirmed_by'),
                    'remarks' => $this->request->getPost('remarks'),
                    'meet_greet' => $this->request->getPost('meet_greet'),
                    'is_active' => 1,
                    'enterprise_id' => 1
                );
                $cn_insert = $Enquiry_model->insert_transport_followup($cn_data);  
                echo 1;
            }
            else{
                 echo 0;
            }
        }
    }
    
    public function updateArrDetFollowup()
    {
        $Enquiry_model = new Enquiry_m();
            $cn_data = array(
                'followup_type_id' => 2,
                'enquiry_header_id' => $this->request->getPost('enquiry_header_id'),
                'call_date' => $this->request->getPost('call_date'),
                'mode_of_arrival' => $this->request->getPost('mode_of_arrival'),
                'city' => $this->request->getPost('city'),
                'flight_train_no' => $this->request->getPost('flight_train_no'),
                'arrival_date' => $this->request->getPost('arrival_date'),
                'comments' => $this->request->getPost('comments'),
                'deleted' => 0,
                'enterprise_id' => 1
            );
            $cn_insert = $Enquiry_model->insert_arr_det_followup($cn_data);  
            if($cn_insert){

                echo 1;
            }
            else{
                 echo 0;
            }
    }
    public function updateDepDetFollowup()
    {
        $Enquiry_model = new Enquiry_m();
            $cn_data = array(
                'followup_type_id' => 3,
                'enquiry_header_id' => $this->request->getPost('enquiry_header_id'),
                'call_date' => $this->request->getPost('call_date'),
                'mode_of_departure' => $this->request->getPost('mode_of_departure'),
                'city' => $this->request->getPost('city'),
                'flight_train_no' => $this->request->getPost('flight_train_no'),
                'departure_date' => $this->request->getPost('departure_date'),
                'comments' => $this->request->getPost('comments'),
                'deleted' => 0,
                'enterprise_id' => 1
            );
            $cn_insert = $Enquiry_model->insert_dep_det_followup($cn_data);  
            if($cn_insert){

                echo 1;
            }
            else{
                 echo 0;
            }
    }
    public function updateAllCallFollowup()
    {
        $Enquiry_model = new Enquiry_m();
            $cn_data = array(
                'followup_type_id' => $this->request->getPost('followup_type_id'),
                'enquiry_header_id' => $this->request->getPost('enquiry_header_id'),
                'call_status' => $this->request->getPost('call_status'),
                'call_time' => $this->request->getPost('call_time'),
                'comments' => $this->request->getPost('comments'),
                'deleted' => 0,
                'enterprise_id' => 1
            );
            $cn_insert = $Enquiry_model->insert_all_call_followup($cn_data);  
            if($cn_insert){

                echo 1;
            }
            else{
                 echo 0;
            }
    }
    public function reassignEmployee()
    {
        $Enquiry_model = new Enquiry_m();
        $assigned_to = $this->request->getPost('assigned_to');
        $enquiry_header_id = $this->request->getPost('enquiry_header_id');
        $status_id = $this->request->getPost('status_id');
        $reassigned_data = array(
            'assigned_to' => $assigned_to
        );
        $reassigned = $Enquiry_model->reassignEmployee($reassigned_data,$enquiry_header_id,$status_id);   
        echo json_encode($reassigned); 
    }
    
    public function submitEditRequest()
    {
        $Enquiry_model = new Enquiry_m();
        $user_id = session('user_id');
        date_default_timezone_set('Asia/Kolkata');
        $updated_time = date('Y-m-d H:i:s');
        $edit_request_reason_id = $this->request->getPost('edit_request_reason_id');
        $enquiry_header_id = $this->request->getPost('enquiry_header_id');
        $erdet = $Enquiry_model->getEditRequestDetails($enquiry_header_id);  
        $current_edit_request_id = $erdet[0]['enquiry_edit_request_id'];
        $status_id = $this->request->getPost('status_id');
        $object_id = $this->request->getPost('object_id');
        $er_exist = $Enquiry_model->is_edit_request_exist($enquiry_header_id);     
        if($er_exist > 0){
            echo 0;
        }
        else{
            $cls_data = array(
                'is_active' => 0
            );
            $clear_ia = $Enquiry_model->clearEditRequest_isactive($cls_data,$enquiry_header_id);
            if($clear_ia){
                $er_data = array(
                    'object_id' => $object_id,
                    'enquiry_header_id' => $enquiry_header_id,
                    'updated_time' => $updated_time,
                    'edit_request_status' => 2,
                    'is_active' => 0,
                    'edit_request_reason' => $edit_request_reason_id,
                    'updated_by' => $user_id,
                    'enterprise_id' => 1
                );
                $er_insert = $Enquiry_model->insertEditRequest($er_data);   
                $cur_stat = $Enquiry_model->getEnquiryStatusDet($enquiry_header_id,$current_edit_request_id);   
                $er_status_data = array(
                    'object_id' => $object_id,
                    'enquiry_header_id' => $enquiry_header_id,
                    'current_status_id' => 20,
                    'updated_time' => $updated_time,
                    'assigned_to' => $cur_stat[0]['assigned_to'],
                    'assigned_status' => 1,
                    'edit_request_id' => $er_insert,
                    'updated_by' => $user_id,
                    'enterprise_id' => 1                            
                );
                $confirm_insert = $Enquiry_model->insertEnquirystatus($er_status_data);                
                echo 1; 
            }
        }
    }

    public function approveActionSubmit()
    {
        $Enquiry_model = new Enquiry_m();
        $user_id = session('user_id');
        date_default_timezone_set('Asia/Kolkata');
        $updated_time = date('Y-m-d H:i:s');
        $payment_id = $this->request->getPost('payment_id');
        $selectedValue = $this->request->getPost('selectedValue');
        $remarks = $this->request->getPost('remarks');
            $app_data = array(
                'approved_status' => $selectedValue,
                'remarks' => $remarks
            );
            $app_update = $Enquiry_model->update_approve_action($app_data,$payment_id); 
        if($app_update){
            echo 1;
        }
        else{
            echo 0;
        }
    }
    public function submitEditRequestAction()
    {
        $Enquiry_model = new Enquiry_m();
        $user_id = session('user_id');
        date_default_timezone_set('Asia/Kolkata');
        $updated_time = date('Y-m-d H:i:s');
        $edit_request_action_id = $this->request->getPost('edit_request_action_id');
        $enquiry_header_id = $this->request->getPost('enquiry_header_id');
        //$erdet = $Enquiry_model->getEditRequestDetails($enquiry_header_id);  
        $current_edit_request_id = $this->request->getPost('enquiry_edit_request_id');
        $object_id = $this->request->getPost('object_id');
        if($edit_request_action_id == 1){
            $current_status_id = 21;
            $cls_data = array(
                'edit_request_status' => 1,
                'is_active' => 1
            );
        }
        if($edit_request_action_id == 3){
            $current_status_id = 21;
            $cls_data = array(
                'edit_request_status' => 3
            );
        }
            $updated = $Enquiry_model->updateEditRequestAction($cls_data,$current_edit_request_id);
            if($updated){
                $cur_stat = $Enquiry_model->getEnquiryStatusDetforer($enquiry_header_id,$current_edit_request_id);   

                $er_status_data = array(
                    'object_id' => $object_id,
                    'enquiry_header_id' => $enquiry_header_id,
                    'current_status_id' => $current_status_id,
                    'updated_time' => $updated_time,
                    'assigned_to' => $cur_stat[0]['assigned_to'],
                    'assigned_status' => 1,
                    'edit_request_id' => $current_edit_request_id,
                    'updated_by' => $user_id,
                    'enterprise_id' => 1                            
                );
                $confirm_insert = $Enquiry_model->insertEnquirystatus($er_status_data);  
                
                if($edit_request_action_id == 1){
                    $df_status_data = array(
                        'object_id' => $object_id,
                        'enquiry_header_id' => $enquiry_header_id,
                        'current_status_id' => 1,
                        'updated_time' => $updated_time,
                        'assigned_to' => $cur_stat[0]['assigned_to'],
                        'assigned_status' => 1,
                        'edit_request_id' => $current_edit_request_id,
                        'updated_by' => $user_id,
                        'enterprise_id' => 1                            
                    );
                    $df_confirm_insert = $Enquiry_model->insertEnquirystatus($df_status_data);  
                }
                echo 1; 
            }
        
    }

    public function save_final_costing_sheet()
    {
        $Enquiry_model = new Enquiry_m();
        $enquiry_detail_details_id = $this->request->getPost('enquiry_detail_details_id');
        $cs_content = $this->request->getPost('cs_content');
        $cs_data = array(
            'costing_sheet' => $cs_content
        );
        $cs_update = $Enquiry_model->save_final_costing_sheet($cs_data,$enquiry_detail_details_id);   
        echo json_encode($cs_update); 
    }
    public function save_final_itinerary_sheet()
    {
        $Enquiry_model = new Enquiry_m();
        $enquiry_detail_details_id = $this->request->getPost('enquiry_detail_details_id');
        $iti_content = $this->request->getPost('iti_content');
        $cs_data = array(
            'itinerary' => $iti_content
        );
        $iti_update = $Enquiry_model->save_final_costing_sheet($cs_data,$enquiry_detail_details_id);   
        echo json_encode($iti_update); 
    }
    public function confirmCostingSheet()
    {
        $Enquiry_model = new Enquiry_m();
        $user_id = session('user_id');
        date_default_timezone_set('Asia/Kolkata');
        $updated_time = date('Y-m-d H:i:s');
        $enquiry_detail_details_id = $this->request->getPost('enquiry_detail_details_id');
        $ext_det = $Enquiry_model->getExtensionDetailsbyid($enquiry_detail_details_id);   
        $enquiry_header_id = $ext_det[0]['enquiry_header_id'];
        if(empty($ext_det[0]['costing_sheet'])){
            echo 1;
        }
        else if(empty($ext_det[0]['itinerary'])){
            echo 2;
        }
        else{
            $c_data = array(
                'cs_confirmed_id' => $enquiry_detail_details_id
            );
            $c_update = $Enquiry_model->confirm_costing_sheet_finalize($c_data,$enquiry_header_id);  
            if($c_update){
                $top_assigned_to = $this->round_robin_assignment_top($user_id);
                $er_det = $Enquiry_model->getEditRequestDetails($enquiry_header_id);
                $top_status_data = array(
                    'object_id' => $ext_det[0]['object_id'],
                    'enquiry_header_id' => $ext_det[0]['enquiry_header_id'],
                    'current_status_id' => 14,
                    'updated_time' => $updated_time,
                    'assigned_to' => $top_assigned_to,
                    'assigned_status' => 1,
                    'edit_request_id' => $er_det[0]['enquiry_edit_request_id'],
                    'updated_by' => $user_id,
                    'enterprise_id' => 1                            
                );
                $status_top_insert = $Enquiry_model->insertEnquirystatus($top_status_data);

                $ac_exist = $Enquiry_model->is_availability_check_exist($enquiry_header_id);
                if(!empty($ac_exist)){
                    $sop_assigned_to = $ac_exist[0]['assigned_to'];
                }
                else{
                    $sop_assigned_to = $this->round_robin_assignment_sop($user_id);
                }
                $sop_status_data = array(
                    'object_id' => $ext_det[0]['object_id'],
                    'enquiry_header_id' => $ext_det[0]['enquiry_header_id'],
                    'current_status_id' => 13,
                    'updated_time' => $updated_time,
                    'assigned_to' => $sop_assigned_to,
                    'assigned_status' => 1,
                    'edit_request_id' => $er_det[0]['enquiry_edit_request_id'],
                    'updated_by' => $user_id,
                    'enterprise_id' => 1                            
                );
                $status_sop_insert = $Enquiry_model->insertEnquirystatus($sop_status_data);

                $confirm_status_data = array(
                    'object_id' => $ext_det[0]['object_id'],
                    'enquiry_header_id' => $ext_det[0]['enquiry_header_id'],
                    'current_status_id' => 12,
                    'updated_time' => $updated_time,
                    'assigned_to' => $sop_assigned_to,
                    'assigned_status' => 1,
                    'edit_request_id' => $er_det[0]['enquiry_edit_request_id'],
                    'updated_by' => $user_id,
                    'enterprise_id' => 1                            
                );
                $confirm_insert = $Enquiry_model->insertEnquirystatus($confirm_status_data);
                if($status_top_insert && $status_sop_insert && $confirm_insert){
                    echo 3;
                }
            }
        }
    }
    public function getLocationName()
    {
        $Enquiry_model = new Enquiry_m();
        $loc_det = $Enquiry_model->getLocationName($this->request->getPost('tour_location_id'),$this->request->getPost('hotel_category_exist'));
        echo json_encode($loc_det); 
    }
    public function get_vehicle_name()
    {
        $Enquiry_model = new Enquiry_m();
        $data = $Enquiry_model->getVehicleName($this->request->getPost('v_id'));
        echo json_encode($data);
    }
    public function check_guest_exist()
    {
        $Enquiry_model = new Enquiry_m();
        $guest_name = $this->request->getPost('guest_name');
        $guest_mobile = $this->request->getPost('guest_mobile');
        $guest_email = $this->request->getPost('guest_email');
        $gexist = $Enquiry_model->check_guest_exist($guest_name,$guest_mobile,$guest_email);
        echo json_encode($gexist);
    }
    public function saveAvailabilityCheck()
    {
        $Enquiry_model = new Enquiry_m();
        $user_id = session('user_id');
        date_default_timezone_set('Asia/Kolkata');
        $updated_time = date('Y-m-d H:i:s');
        $availabilityData = $this->request->getPost('availabilityData');
        $enquiry_header_id = $this->request->getPost('enquiry_header_id');
        $overallStatus = $this->request->getPost('overallStatus');
        $ac_data = array(
                    'availability_check' => $overallStatus,
                    'ac_remarks' => $availabilityData
                );
        $ac_update = $Enquiry_model->updateAvailabilityCheck($ac_data,$enquiry_header_id);
        $ac_exist = $Enquiry_model->is_availability_check_exist($enquiry_header_id);
        $er_det = $Enquiry_model->getEditRequestDetails($enquiry_header_id);
        if($overallStatus == 2){
                $ac_ha_data = array(
                    'object_id' => $ac_exist[0]['object_id'],
                    'enquiry_header_id' => $ac_exist[0]['enquiry_header_id'],
                    'current_status_id' => 9,
                    'updated_time' => $updated_time,
                    'assigned_to' => $ac_exist[0]['assigned_to'],
                    'assigned_status' => 1,
                    'edit_request_id' => $er_det[0]['enquiry_edit_request_id'],
                    'updated_by' => $user_id,
                    'enterprise_id' => 1                            
                );
                $ha_insert = $Enquiry_model->insertEnquirystatus($ac_ha_data);
        }
        if($overallStatus == 3){
                $ac_hna_data = array(
                    'object_id' => $ac_exist[0]['object_id'],
                    'enquiry_header_id' => $ac_exist[0]['enquiry_header_id'],
                    'current_status_id' => 10,
                    'updated_time' => $updated_time,
                    'assigned_to' => $ac_exist[0]['assigned_to'],
                    'assigned_status' => 1,
                    'edit_request_id' => $er_det[0]['enquiry_edit_request_id'],
                    'updated_by' => $user_id,
                    'enterprise_id' => 1                            
                );
                $hna_insert = $Enquiry_model->insertEnquirystatus($ac_hna_data);
        }
        echo json_encode($ac_update);
    }
    public function availabilitycheckform()
    {
        $Enquiry_model = new Enquiry_m();
        $hot_det = [];
        $enquiry_header_id = $this->request->getPost('enquiry_header_id');
        $ext_det = $Enquiry_model->getExtensionDetailsbystatus($enquiry_header_id); 
        if(!empty($ext_det)){
            $hot_det = $Enquiry_model->get_hotel_details_forac($enquiry_header_id,$ext_det[0]['extension_ref_id']);
        }
        $data['hot_det'] = $hot_det;
        $data['enquiry_header_id'] = $enquiry_header_id;
        echo view('enquiry/ac_check_form',$data);
    }
    public function getHotelConfirmationforMail()
    {
        $Enquiry_model = new Enquiry_m();
        $hot_det = [];
        $itinerary_details_id = $this->request->getPost('itinerary_details_id');
        $hot_det = $Enquiry_model->get_hotel_confirmation_mail($itinerary_details_id);
        $data['hotels'] = $hot_det;
        $data['itinerary_details_id'] = $itinerary_details_id;
        echo view('enquiry/hotel_confirmation_mail',$data);
    }
    public function getTransportItineraryData()
    {
        $Enquiry_model = new Enquiry_m();
        $hot_det = [];
        $transport_follow_up_id = $this->request->getPost('transport_follow_up_id');
        $trans_det = $Enquiry_model->getTransportItineraryData($transport_follow_up_id);
        $data['cdata'] = $trans_det;
        $data['transport_follow_up_id'] = $transport_follow_up_id;
        echo view('enquiry/transport_itinerary_view',$data);
    }
    public function getHotelVoucherData()
    {
        $Enquiry_model = new Enquiry_m();
        $sdate = date('Y-m-d');
        $hot_det = [];
        $enquiry_header_id = $this->request->getPost('enquiry_header_id');
        $confirm_cs_id = $this->request->getPost('confirm_cs_id');
        $ext_det = $Enquiry_model->getExtensionDetailsbyid($confirm_cs_id); 
        $hot_det = $Enquiry_model->get_hotels_for_vouchers($ext_det[0]['tour_plan_ref_id']);
        $data['cdata'] = $hot_det;
        $data['cdate'] = $sdate;
        $data['enquiry_header_id'] = $enquiry_header_id;
        $data['confirm_cs_id'] = $confirm_cs_id;
        echo view('enquiry/hotel_voucher_view',$data);
    }
    public function getProformaGuestData()
    {
        $Enquiry_model = new Enquiry_m();
        $sdate = date('Y-m-d');
        $hot_det = [];
        $enquiry_header_id = $this->request->getPost('enquiry_header_id');
        $confirm_cs_id = $this->request->getPost('confirm_cs_id');
        $enquiry_edit_request_id = $this->request->getPost('enquiry_edit_request_id');
        $ext_det = $Enquiry_model->getExtensionDetailsbyid($confirm_cs_id); 
        $hot_det = $Enquiry_model->get_proforma_guest_data($enquiry_header_id,$ext_det[0]['extension_ref_id'],$confirm_cs_id);
        $data['cdata'] = $hot_det;
        $data['cdate'] = $sdate;
        $data['enquiry_header_id'] = $enquiry_header_id;
        $data['confirm_cs_id'] = $confirm_cs_id;
        $data['enquiry_edit_request_id'] = $enquiry_edit_request_id;
        echo view('enquiry/proforma_guest_view',$data);
    }
    public function getProformaOfficeData()
    {
        $Enquiry_model = new Enquiry_m();
        $sdate = date('Y-m-d');
        $hot_det = [];
        $enquiry_header_id = $this->request->getPost('enquiry_header_id');
        $confirm_cs_id = $this->request->getPost('confirm_cs_id');
        $enquiry_edit_request_id = $this->request->getPost('enquiry_edit_request_id');
        $ext_det = $Enquiry_model->getExtensionDetailsbyid($confirm_cs_id); 
        $hot_det = $Enquiry_model->get_proforma_office_data($enquiry_header_id,$ext_det[0]['extension_ref_id'],$confirm_cs_id,$enquiry_edit_request_id);
        $tour_plan = $Enquiry_model->get_proforma_office_tpdata($enquiry_header_id,$ext_det[0]['tour_plan_ref_id'],$confirm_cs_id);
        $data['tour_plan'] = $tour_plan;
        $data['cdata'] = $hot_det;
        $data['cdate'] = $sdate;
        $data['enquiry_header_id'] = $enquiry_header_id;
        $data['confirm_cs_id'] = $confirm_cs_id;
        $data['enquiry_edit_request_id'] = $enquiry_edit_request_id;
        echo view('enquiry/proforma_office_view',$data);
    }
    public function hotelconformationform()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $data = $Enquiry_model->get_hotel_confirmation_data($this->request->getPost());
            echo json_encode($data);
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function executive_followup_form()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $data = $Enquiry_model->executive_followup_form($this->request->getPost());
            echo json_encode($data);
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function transport_followup_form()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $data = $Enquiry_model->transport_followup_form($this->request->getPost());
            echo json_encode($data);
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function arrival_details_form()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $data = $Enquiry_model->arrival_details_form($this->request->getPost());
            echo json_encode($data);
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function departure_details_form()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $data = $Enquiry_model->departure_details_form($this->request->getPost());
            echo json_encode($data);
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function all_call_followup_form()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $data = $Enquiry_model->all_call_followup_form($this->request->getPost());
            echo json_encode($data);
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function hotelvoucherform()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $data = $Enquiry_model->hotelvoucherdata($this->request->getPost());
            echo json_encode($data);
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function proformaguestform()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $data = $Enquiry_model->proformaguestdata($this->request->getPost());
            echo json_encode($data);
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function proformaofficeform()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $data = $Enquiry_model->proformaofficedata($this->request->getPost());
            echo json_encode($data);
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function hotel_not_available_details()
    {
        $Enquiry_model = new Enquiry_m();
        $hot_det = [];
        $enquiry_detail_details_id = $this->request->getPost('enquiry_detail_details_id');
        $hot_det = $Enquiry_model->get_hotel_details_foracbyid($enquiry_detail_details_id);
        $data['hot_det'] = $hot_det;
        echo view('enquiry/hotel_not_available_form',$data);
    }
    public function getMoreEnquiryDetails()
    {
        $Enquiry_model = new Enquiry_m();
        $Dashboard_model = new Dashboard_m();
        $user_id = session('user_id');
        $parent_id = session('parent_id');
        $hierarchy_id = session('hierarchy_id');
        $users = [];
        if($hierarchy_id == 4){
            $users = $Dashboard_model->get_employees_under_teamlead($user_id);
        }
        else {
            $users = $Dashboard_model->get_employees_under_adminusers();
        }
        $enquiry_header_id = $this->request->getPost('enquiry_header_id');
        $header_det = $Enquiry_model->get_enquiry_header_details($enquiry_header_id);
        $edit_det = $Enquiry_model->get_current_edit_request_details($enquiry_header_id);
        if(!empty($edit_det)){
            $is_confirmed = ($edit_det[0]['cs_confirmed_id'] > 0) ? 1: 0;
        }
        else{
            $is_confirmed = 0;
        }
        $data['object_id'] = $header_det[0]['object_id'];
        $data['enquiry_header_id'] = $enquiry_header_id;
        $data['more_enq'] = $Enquiry_model->get_more_enquiry_details($enquiry_header_id);
        $data['status_history'] = $Enquiry_model->get_status_history($enquiry_header_id);
        $data['edit_reasons'] = $Enquiry_model->get_edit_request_reasons();
        $data['user_id'] = $user_id;
        $data['parent_id'] = $parent_id;
        $data['hierarchy_id'] = $hierarchy_id;
        $data['users'] = $users;
        $data['is_confirmed'] = $is_confirmed;
        echo view('enquiry/get_more_enquiry_details_view',$data);
    }
    public function getEditRequestDetailsforAdmin()
    {
        $Enquiry_model = new Enquiry_m();
        $Dashboard_model = new Dashboard_m();
        $enquiry_header_id = $this->request->getPost('enquiry_header_id');
        $header_det = $Enquiry_model->get_enquiry_header_details($enquiry_header_id);
        $data['object_id'] = $header_det[0]['object_id'];
        $er_det = $Enquiry_model->getEditRequestDetailsforAdmin($enquiry_header_id);
        $data['er_det'] = $er_det;
        echo view('enquiry/edit_request_view',$data);
    }
    public function saveEnquiry()
    {
        if (!empty(session()->get('user_id'))) {
            $Dashboard_model = new Dashboard_m();
            $Enquiry_model = new Enquiry_m();

            date_default_timezone_set('Asia/Kolkata');
            $updated_time = date('Y-m-d H:i:s');
            $sdate = date('Y-m-d');
            $system_id = session('system_id');
            $user_id = session('user_id');
            $role_id = session('active_role');
            $assigned_to = $this->round_robin_assignment($user_id, $role_id);
            $edit_id = $this->request->getPost('edit_id');
 
            if($edit_id > 0){
                $enq_header_ids = $Enquiry_model->get_enquiry_header_id($edit_id);
                $enq_header_id = $enq_header_ids[0]['enquiry_header_id'];
                $up_data = array(
                    'is_active' => 0
                );
                $up_itidata = array(
                    'is_active' => 0,
                    'is_draft' => 0
                );
                $up_extdata = array(
                    'is_edit' => 0
                );
                $enq_update = $Enquiry_model->update_enquiry_isactive($up_data,$enq_header_id);
                $tp_update = $Enquiry_model->update_tourplan_isactive($up_itidata,$enq_header_id);
                $iti_update = $Enquiry_model->update_itinerary_isactive($up_itidata,$enq_header_id);
                $ext_update = $Enquiry_model->update_extension_isedit($up_extdata,$enq_header_id);
            }
            
            $guest_name = $this->request->getPost('guest_name');
            $guest_mobile = $this->request->getPost('guest_mobile');
            $guest_email = $this->request->getPost('guest_email');
            $guest_address = $this->request->getPost('guest_address');
            $guest_exist = $this->request->getPost('hd_guest_exist');
            $no_of_arrivals = $this->request->getPost('no_of_arrivals');

                $bURL = config('App')->baseURL;
                $class_id = $this->request->getPost('object_class_id');
                $sURL = site_url('Enquiry/enquiry_list_view/'.$class_id);
                $baseURL = ($bURL === '') ? $bURL : rtrim($bURL, '/ ') . '/';
                $object_location_id = '';
                $object_datas = array(
                    'object_name' => $guest_name,
                    'object_location_id' => $object_location_id,
                    'object_class_id' => $class_id,
                    'object_type_id' => 5,
                    'enterprise_id' => $this->request->getPost('enterprise_id'),
                    'object_ph_no' => json_encode([$guest_mobile]),
                    'object_email' => json_encode([$guest_email]),
                    'object_address' => json_encode([$guest_address])
                );
                if($edit_id > 0){
                    $object_id = $edit_id;
                }
                else{
                    $object_id = $Dashboard_model->insert_object($object_datas);
                }
                if ($object_id) {

                    if($edit_id > 0){
                        $enquiry_header_id = $enq_header_id;
                    }
                    else{
                        if($guest_exist){
                            $entity_ids = $Enquiry_model->get_guest_details($guest_name,$guest_mobile,$guest_email);
                            $entity_id = $entity_ids[0]['entity_id'];
                        }
                        else{
                            $entity_datas = array(
                                'entity_parent_id' => 1,
                                'entity_name' => $guest_name,
                                'entity_location_id' => $object_location_id,
                                'entity_class_id' => 13,
                                'entity_type_id' => 1,
                                'enterprise_id' => $this->request->getPost('enterprise_id'),
                                'entity_mobile' => json_encode($guest_mobile),
                                'entity_email' => json_encode($guest_email),
                                'entity_address' => json_encode($guest_address)
                            );
                            $entity_id = $Dashboard_model->insert_entity($entity_datas);
                        }
                        $sys_ids = $system_id-1;
                        $ref_no = $sys_ids.$object_id;
                        $enquiry_header = array(
                            'object_id' => $object_id,
                            'guest_entity_id' => $entity_id,
                            'agent_entity_id' => $this->request->getPost('agent_id'),
                            'employee_entity_id' => $user_id,
                            'enq_added_date' => $sdate,
                            'enq_type_id' => $system_id,
                            'is_active' => 1,
                            'ref_no' => $ref_no,
                            'is_multiple' => $no_of_arrivals,
                            'enterprise_id' => $this->request->getPost('enterprise_id')
                        );
                        $enquiry_header_id = $Enquiry_model->insert_enquiry_header($enquiry_header);
                    }
                    if($enquiry_header_id){
                        $addmore = $this->request->getPost('addmore');
                        if(!empty($addmore)){
                            $vehicle_data = [];
                            foreach ($addmore as $item) {
                                $vehicle_data[] = [
                                    'vehicle_type_id' => $item['v_id'] ?? null,
                                    'vehicle_model_name' => $item['v_name'] ?? null,
                                    'vehicle_count' => $item['v_count'] ?? null
                                ];
                            }
                            $vehicle_json = json_encode($vehicle_data);
                        }
                        else{
                            $vehicle_json = json_encode([]);
                        }

                        $enquiry_details = array(
                            'enquiry_header_id' => $enquiry_header_id,
                            'date_of_tour_start' => $this->request->getPost('tour_start_date'),
                            'no_of_night' => $this->request->getPost('no_of_days'),
                            'date_of_tour_completion' =>$this->request->getPost('tour_end_date'),
                            'enquiry_source' => $this->request->getPost('enq_source'),
                            'total_no_of_pax' => $this->request->getPost('total_no_of_pax'),
                            'no_of_adult' => $this->request->getPost('no_of_adult'),
                            'no_of_child_with_bed' => $this->request->getPost('no_of_child_with_bed') ? $this->request->getPost('no_of_child_with_bed') : 0,
                            'no_of_child_without_bed' => $this->request->getPost('no_of_child_without_bed') ? $this->request->getPost('no_of_child_without_bed') : 0,
                            'no_of_double_room' => $this->request->getPost('no_of_double_room'),
                            'no_of_single_room' => $this->request->getPost('no_of_single_room') ? $this->request->getPost('no_of_single_room') : 0,
                            'no_of_extra_bed' => $this->request->getPost('no_of_extra_bed') ? $this->request->getPost('no_of_extra_bed') : 0,
                            'gstin' => $this->request->getPost('gstin'),
                            'vehicle_from_location' => $this->request->getPost('hub_location'),
                            'arrival_location' => $this->request->getPost('arrival_location'),
                            'departure_location' => $this->request->getPost('departure_location'),
                            'hotel_category' => $this->request->getPost('hotel_category'),
                            'meal_plan' => $this->request->getPost('meal_plan'),
                            'is_vehicle_required' => $this->request->getPost('is_vehicle_req'),
                            'is_sight_seeing_required' => $this->request->getPost('is_ss_req'),
                            'is_quick_quote' => $this->request->getPost('is_qq_req'),
                            'vehicle_type_id' => $vehicle_json,
                            'enq_description' => $this->request->getPost('enq_description'),
                            'is_active' => 1,
                            'created_date' => $updated_time,
                            'created_by' => $user_id,
                            'enterprise_id' => $this->request->getPost('enterprise_id'),
                            'arrival_number' => 1
                        );
                        $enquiry_details_id = $Enquiry_model->insert_enquiry_details($enquiry_details);
                        if($enquiry_details_id){
                            $ext_enq_data = array(
                                'extension_ref_id' => $enquiry_details_id
                            );
                            $ext_enq_updated = $Enquiry_model->linkItinearywithEnquiry($ext_enq_data,$enquiry_header_id,$enquiry_details_id); 
                        }

                        if($edit_id == 0){
                            $edit_request_data = array(
                                'object_id' => $object_id,
                                'enquiry_header_id' => $enquiry_header_id,
                                'updated_time' => $updated_time,
                                'edit_request_status' => 1,
                                'is_active' => 1,
                                'updated_by' => $user_id,
                                'enterprise_id' => 1                            
                            );
                            $edit_request_id = $Enquiry_model->insertEditRequest($edit_request_data);
                            if($edit_request_id){
                                $status_data = array(
                                    'object_id' => $object_id,
                                    'enquiry_header_id' => $enquiry_header_id,
                                    'current_status_id' => 1,
                                    'updated_time' => $updated_time,
                                    'assigned_to' => $assigned_to,
                                    'assigned_status' => 1,
                                    'edit_request_id' => $edit_request_id,
                                    'updated_by' => $user_id,
                                    'enterprise_id' => 1                            
                                );
                                $status_data_insert = $Enquiry_model->insertEnquirystatus($status_data);
                            }
                            
                        }


                        /*********** Multiple Arrival Start************************ */
                        $additional_arrivals = $this->request->getPost('arrival');
                        
                        if (!empty($additional_arrivals) && $no_of_arrivals > 1) {
                            foreach ($additional_arrivals as $key => $arr) {
                                //if ($key == 1) continue;
                                if($edit_id > 0){
                                    $object_id = $edit_id;
                                }
                                else{
                                    $object_id = $Dashboard_model->insert_object($object_datas);
                                }

                                $enquiry_header = array(
                                    'object_id' => $object_id,
                                    'guest_entity_id' => $entity_id,
                                    'agent_entity_id' => $this->request->getPost('agent_id'),
                                    'employee_entity_id' => $user_id,
                                    'enq_added_date' => $sdate,
                                    'enq_type_id' => $system_id,
                                    'is_active' => 1,
                                    'ref_no' => $ref_no,
                                    'is_multiple' => $no_of_arrivals,
                                    'enterprise_id' => $this->request->getPost('enterprise_id')
                                );
                                $enquiry_header_id = $Enquiry_model->insert_enquiry_header($enquiry_header);
                                $veh_arr = isset($arr['vehicles']) ? json_encode(array_values($arr['vehicles'])) : json_encode([]);

                                $additional = array(
                                    'enquiry_header_id' => $enquiry_header_id,
                                    'date_of_tour_start' => $arr['start_date'] ?? '',
                                    'no_of_night' => $arr['ndays'] ?? '',
                                    'date_of_tour_completion' =>$arr['end_date'] ?? '',
                                    'enquiry_source' => $this->request->getPost('enq_source'),
                                    'total_no_of_pax' => $this->request->getPost('total_no_of_pax'),
                                    'no_of_adult' => $this->request->getPost('no_of_adult'),
                                    'no_of_child_with_bed' => $this->request->getPost('no_of_child_with_bed') ? $this->request->getPost('no_of_child_with_bed') : 0,
                                    'no_of_child_without_bed' => $this->request->getPost('no_of_child_without_bed') ? $this->request->getPost('no_of_child_without_bed') : 0,
                                    'no_of_double_room' => $this->request->getPost('no_of_double_room'),
                                    'no_of_single_room' => $this->request->getPost('no_of_single_room') ? $this->request->getPost('no_of_single_room') : 0,
                                    'no_of_extra_bed' => $this->request->getPost('no_of_extra_bed') ? $this->request->getPost('no_of_extra_bed') : 0,
                                    'gstin' => $this->request->getPost('gstin'),
                                    'vehicle_from_location' => $arr['hub_location'] ?? '',
                                    'arrival_location' => $arr['arrival_place'] ?? '',
                                    'departure_location' => $arr['departure_place'] ?? '',
                                    'hotel_category' => $this->request->getPost('hotel_category'),
                                    'meal_plan' => $this->request->getPost('meal_plan'),
                                    'is_vehicle_required' => $this->request->getPost('is_vehicle_req'),
                                    'is_sight_seeing_required' => $this->request->getPost('is_ss_req'),
                                    'is_quick_quote' => $this->request->getPost('is_qq_req'),
                                    'vehicle_type_id' => $veh_arr,
                                    'enq_description' => $this->request->getPost('enq_description'),
                                    'is_active' => 1,
                                    'created_date' => $updated_time,
                                    'created_by' => $user_id,
                                    'enterprise_id' => $this->request->getPost('enterprise_id'),
                                    'arrival_number' => $key
                                );
                                $enquiry_details_id = $Enquiry_model->insert_enquiry_details($additional);
                                if($enquiry_details_id){
                                    $ext_enq_data = array(
                                        'extension_ref_id' => $enquiry_details_id
                                    );
                                    $ext_enq_updated = $Enquiry_model->linkItinearywithEnquiry($ext_enq_data,$enquiry_header_id,$enquiry_details_id); 
                                }

                                
                                if($edit_id == 0){
                                    $edit_request_data = array(
                                        'object_id' => $object_id,
                                        'enquiry_header_id' => $enquiry_header_id,
                                        'updated_time' => $updated_time,
                                        'edit_request_status' => 1,
                                        'is_active' => 1,
                                        'updated_by' => $user_id,
                                        'enterprise_id' => 1                            
                                    );
                                    $edit_request_id = $Enquiry_model->insertEditRequest($edit_request_data);
                                    if($edit_request_id){
                                        $status_data = array(
                                            'object_id' => $object_id,
                                            'enquiry_header_id' => $enquiry_header_id,
                                            'current_status_id' => 1,
                                            'updated_time' => $updated_time,
                                            'assigned_to' => $assigned_to,
                                            'assigned_status' => 1,
                                            'edit_request_id' => $edit_request_id,
                                            'updated_by' => $user_id,
                                            'enterprise_id' => 1                            
                                        );
                                        $status_data_insert = $Enquiry_model->insertEnquirystatus($status_data);
                                    }
                                    
                                }

                            }
                        }
                        /**************Multiple Arrival End************************* */
                        return redirect()->to($sURL);
                    }
                } else {
                    return redirect()->to($sURL);
                }
            }
       
        else{
            return redirect()->to('Login');
        }
    }

    public function round_robin_assignment($user_id,$role_id){
        $Dashboard_model = new Dashboard_m();
        if($role_id == 5){
            $assigned_to = $user_id;
        }
        else if($role_id == 4){
            /*$users = $Dashboard_model->get_employees_under_tl($user_id);
            if(!empty($users)){
                $user_ids = array_column($users, 'entity_id');
                $last_assigned_ids = $Dashboard_model->get_last_assigned_user($user_id); 
                if(!empty($last_assigned_ids)){
                    $last_assigned_id = $last_assigned_ids[0]['assigned_to'];
                    $last_index = array_search($last_assigned_id, $user_ids);
                    $next_index = ($last_index === false || $last_index + 1 >= count($user_ids)) ? 0 : $last_index + 1;
                    $assigned_to = $user_ids[$next_index];
                }
                else{
                    $assigned_to = $users[0]['entity_id'];
                }
            }
            else{
                $assigned_to = $user_id;
            }*/
            $assigned_to = $user_id;
        }
        else{
            /*$users = $Dashboard_model->get_employees_under_admin();
            if(!empty($users)){
                $user_ids = array_column($users, 'entity_id');
                $last_assigned_ids = $Dashboard_model->get_last_assigned_user_admin(); 
                if(!empty($last_assigned_ids)){
                    $last_assigned_id = $last_assigned_ids[0]['assigned_to'];
                    $last_index = array_search($last_assigned_id, $user_ids);
                    $next_index = ($last_index === false || $last_index + 1 >= count($user_ids)) ? 0 : $last_index + 1;
                    $assigned_to = $user_ids[$next_index];
                }
                else{
                    $assigned_to = $users[0]['entity_id'];
                }
            }
            else{
                $assigned_to = $user_id;
            }*/
            $assigned_to = $user_id;
        }
        return $assigned_to;
    }

    public function tour_plan($object_id,$edit_id=null)
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $Dashboard_model = new Dashboard_m();
            $pre_enq_details = [];
            $pre_tour_plan = [];
            $pre_start_date = '1978-01-01';
            $pre_no_night = 0;
            $object_det = $Enquiry_model->get_object_details($object_id);
            if($edit_id > 0){
                $enquiry_details_id_new = $edit_id;
            }
            else{
                $enquiry_details_id_new = $object_det[0]['enquiry_details_id'];
            }
            $pre_enq_details = $Enquiry_model->get_previous_enquiry_details($object_det[0]['enquiry_header_id']);
            if(!empty($pre_enq_details)){
                $pre_start_date = $pre_enq_details[0]['date_of_tour_start'];
                $pre_no_night = $pre_enq_details[0]['no_of_night'];
                $pre_tour_plan_temp = $Enquiry_model->get_previous_tour_plan($pre_enq_details[0]['enquiry_header_id'],$pre_enq_details[0]['enquiry_details_id']);
                if(!empty($pre_tour_plan_temp)){
                    $extension_ref_id_temp = $pre_tour_plan_temp[0]['extension_ref_id'];
                    if($extension_ref_id_temp){
                        $pre_tour_plan = $Enquiry_model->get_previous_tour_plan_lastupdated($extension_ref_id_temp);
                    }
                }
            }
            
            $cur_tour_plan = $Enquiry_model->get_current_tour_plan($object_det[0]['enquiry_header_id'],$enquiry_details_id_new);
            $tour_start_date = $object_det[0]['date_of_tour_start_temp'];
            $today = date('Y-m-d');
            if (strtotime($tour_start_date) < strtotime($today)) {
                session()->setFlashdata('error', 'Tour start date must be greater than today!');
                return redirect()->to('Enquiry/enquiry_list_view/10');
            }
            else{
                $tour_plan_det = [];
                $quick_quote_det = [];
                $object_class_id = 10;
                $entity_id = session('user_id');
                $active_role = session('active_role');
                $all_systems = $Dashboard_model->get_all_systems($entity_id);
                $data['all_systems'] = $all_systems;
                $all_roles = $Dashboard_model->get_all_entity_roles($entity_id);
                if(!empty($all_roles)){
                    $data['all_roles_assn'] = $all_roles;
                    $all_menus = $Dashboard_model->get_all_role_menus($active_role);
                    if(!empty($all_menus)){
                        $data['all_menus'] = $all_menus;
                    }
                    else{
                        $data['all_menus'] = [];
                    }
                    $all_permissions = $Dashboard_model->get_all_entity_permissions($active_role,3);
                    if(!empty($all_permissions)){
                        $data['all_permissions'] = $all_permissions;
                    }
                    else{
                        $data['all_permissions'] = [];
                    }
                }
                else{
                    $data['all_roles_assn'] = [];
                    $data['all_menus'] = [];
                    $data['all_permissions'] = [];
                }
            
                    $object_transport_name = '';
                    $tour_travel_daily_rate_exist = '';
                    $tour_travel_max_km_exist = '';
                    $extra_km_rate_exist = '';

                    $local_travel_daily_rate_exist = '';
                    $local_travel_max_km_exist = '';
                    $registration_no_exist = '';

                    $is_tour_travel_exist = 1;
                    $is_local_travel_exist = 1;
                    $is_active_exist = 1;

                    $hub_exist = '';
                    $mod_exist = '';
                    $seat_exist = '';
                    $obj_name = '';
                    $obj_loc = '';
                    $obj_mobile = [];
                    $obj_email = [];
                    $obj_address = [];
            
                $all_locations = $Enquiry_model->get_tour_locations();
                $arrival_locations = $Dashboard_model->get_arrival_locations();
                $departure_locations = $Dashboard_model->get_departure_locations();
                $hotel_categories = $Dashboard_model->get_hotel_categories();
                $all_hotels = $Enquiry_model->get_all_hotels();
                $all_room_categories = $Enquiry_model->get_all_room_categories();
                $meal_plans = $Dashboard_model->get_meal_plan();
                $hub_loc = $Dashboard_model->get_hub_location();
                $enterprise_id = 1;
                //$attributes = $Dashboard_model->get_all_obj_attributes($object_class_id);
                //$boolean_attributes = $Dashboard_model->get_obj_boolean_attributes($object_class_id);
                
                $object_type_id = 5;
                $parent_menu = $Dashboard_model->get_parent_menus();
                $sub_menu = $Dashboard_model->get_sub_menus();
                $data['parent_menu'] = $parent_menu;
                $data['sub_menu'] = $sub_menu;
                $data['object_class_id'] = $object_class_id;
                $data['object_type_id'] = $object_type_id;
                if(!empty($object_class_det)){
                    $data['object_class_name'] = $object_class_det[0]['object_class_name'];
                }
                else{
                    $data['object_class_name'] = null;
                }
                $data['states'] = $Enquiry_model->indian_states();
                $data['all_agents'] = $Enquiry_model->get_all_agents();
                $tour_plan_det = $Enquiry_model->get_tour_plan_details($object_det[0]['enquiry_header_id'],$enquiry_details_id_new);
                $data['tour_plan_det'] = $tour_plan_det;
                $tour_plan_draft_det = $Enquiry_model->get_tour_plan_draft_details($object_det[0]['enquiry_header_id'],$enquiry_details_id_new);
                $data['tour_plan_draft_det'] = $tour_plan_draft_det;

                if($object_det[0]['is_quick_quote'] && !empty($tour_plan_det)){
                    $quick_quote_det = $Enquiry_model->get_quick_quote_details($object_det[0]['enquiry_header_id'],$enquiry_details_id_new,$tour_plan_det[0]['tour_details_id']);
                   
                }
                $data['quick_quote_det'] = $quick_quote_det;
                $data['all_locations'] = $all_locations;
                $data['arrival_locations'] = $arrival_locations;
                $data['departure_locations'] = $departure_locations;
                $data['hotel_categories'] = $hotel_categories;
                $data['all_hotels'] = $all_hotels;
                $data['all_room_categories'] = $all_room_categories;
                $data['meal_plans'] = $meal_plans;
                $data['hub_loc'] = $hub_loc;
                $data['enterprise_id'] = $enterprise_id;
                $data['object_det'] = $object_det;
                $data['obj_name'] = $obj_name;
                $data['obj_loc'] = $obj_loc;
                $data['object_id'] = $object_id;
                $data['pre_tour_plan'] = $pre_tour_plan;
                $data['cur_tour_plan'] = $cur_tour_plan;
                $data['pre_start_date'] = $pre_start_date;
                $data['pre_no_night'] = $pre_no_night;
                $data['edit_id'] = $edit_id;
                return view('enquiry/tour_plan_view',$data);
            }
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function fetchEnquiryDetails()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $object_id = $this->request->getPost('object_id');
            $des_det = $Enquiry_model->fetchEnquiryDetails($object_id);
            echo json_encode($des_det);
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function availabilityCheck()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            date_default_timezone_set('Asia/Kolkata');
            $updated_time = date('Y-m-d H:i:s');
            $user_id = session('user_id');
            $enquiry_detail_details_id = $this->request->getPost('enquiry_detail_details_id');
            $ext_det = $Enquiry_model->getExtensionDetailsbyid($enquiry_detail_details_id);
            $ac_exist = $Enquiry_model->check_ac_exist($ext_det[0]['enquiry_header_id']);

            $clear_status = array(
                'assigned_status' => 0           
            );
            $clear_status_data = $Enquiry_model->updateAssignedStatus($clear_status,$ext_det[0]['enquiry_header_id']);


            if($ac_exist == 0){
                $ac_data = array(
                    'availability_check' => 1
                );
                $ac_update = $Enquiry_model->update_availability_check($ac_data,$enquiry_detail_details_id);   
                if($ac_update){
                    $assigned_sops = $Enquiry_model->getAlreadyAssignedsop($ext_det[0]['enquiry_header_id']);
                    if(!empty($assigned_sops)){
                        $assigned_to = $assigned_sops[0]['assigned_to'];
                    }
                    else{
                        $assigned_to = $this->round_robin_assignment_sop($user_id);
                    }
                    $er_det = $Enquiry_model->getEditRequestDetails($ext_det[0]['enquiry_header_id']);
                    $status_data = array(
                        'object_id' => $ext_det[0]['object_id'],
                        'enquiry_header_id' => $ext_det[0]['enquiry_header_id'],
                        'current_status_id' => 8,
                        'updated_time' => $updated_time,
                        'assigned_to' => $assigned_to,
                        'assigned_status' => 1,
                        'edit_request_id' => $er_det[0]['enquiry_edit_request_id'],
                        'updated_by' => $user_id,
                        'enterprise_id' => 1                            
                    );
                    $status_data_insert = $Enquiry_model->insertEnquirystatus($status_data);
                    $sop_det = $Enquiry_model->getSOPName($assigned_to);
                    echo json_encode($sop_det);    
                }   
                else{
                    echo 0;
                }   
            }
            else{
                echo 0;
            }
        }
        else{
            return redirect()->to('Login');
        }
    }

    public function round_robin_assignment_sop($user_id){
        $Dashboard_model = new Dashboard_m();
        $users = $Dashboard_model->get_sop_employees_under_admin();
            if(!empty($users)){
                $user_ids = array_column($users, 'entity_id');
                $last_assigned_ids = $Dashboard_model->get_last_assigned_sop_user_admin(); 
                if(!empty($last_assigned_ids)){
                    $last_assigned_id = $last_assigned_ids[0]['assigned_to'];
                    $last_index = array_search($last_assigned_id, $user_ids);
                    $next_index = ($last_index === false || $last_index + 1 >= count($user_ids)) ? 0 : $last_index + 1;
                    $assigned_to = $user_ids[$next_index];
                }
                else{
                    $assigned_to = $users[0]['entity_id'];
                }
            }
            else{
                $users = $Dashboard_model->get_soplead_employees_under_admin();
                if(!empty($users)){
                    $user_ids = array_column($users, 'entity_id');
                    $last_assigned_ids = $Dashboard_model->get_last_assigned_soplead_user_admin(); 
                    if(!empty($last_assigned_ids)){
                        $last_assigned_id = $last_assigned_ids[0]['assigned_to'];
                        $last_index = array_search($last_assigned_id, $user_ids);
                        $next_index = ($last_index === false || $last_index + 1 >= count($user_ids)) ? 0 : $last_index + 1;
                        $assigned_to = $user_ids[$next_index];
                    }
                    else{
                        $assigned_to = $users[0]['entity_id'];
                    }
                }
                else{
                    $assigned_to = $user_id;
                }
            }
        
        return $assigned_to;
    }

    public function round_robin_assignment_top($user_id){
        $Dashboard_model = new Dashboard_m();
        $users = $Dashboard_model->get_top_employees_under_admin();
            if(!empty($users)){
                $user_ids = array_column($users, 'entity_id');
                $last_assigned_ids = $Dashboard_model->get_last_assigned_top_user_admin(); 
                if(!empty($last_assigned_ids)){
                    $last_assigned_id = $last_assigned_ids[0]['assigned_to'];
                    $last_index = array_search($last_assigned_id, $user_ids);
                    $next_index = ($last_index === false || $last_index + 1 >= count($user_ids)) ? 0 : $last_index + 1;
                    $assigned_to = $user_ids[$next_index];
                }
                else{
                    $assigned_to = $users[0]['entity_id'];
                }
            }
            else{
                $users = $Dashboard_model->get_toplead_employees_under_admin();
                if(!empty($users)){
                    $user_ids = array_column($users, 'entity_id');
                    $last_assigned_ids = $Dashboard_model->get_last_assigned_toplead_user_admin(); 
                    if(!empty($last_assigned_ids)){
                        $last_assigned_id = $last_assigned_ids[0]['assigned_to'];
                        $last_index = array_search($last_assigned_id, $user_ids);
                        $next_index = ($last_index === false || $last_index + 1 >= count($user_ids)) ? 0 : $last_index + 1;
                        $assigned_to = $user_ids[$next_index];
                    }
                    else{
                        $assigned_to = $users[0]['entity_id'];
                    }
                }
                else{
                    $assigned_to = $user_id;
                }
            }
        
        return $assigned_to;
    }

    public function getselectedtourplandetails()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $object_id = $this->request->getPost('object_id');
            $enquiry_header_id = $this->request->getPost('enquiry_header_id');
            $enquiry_details_id = $this->request->getPost('enquiry_details_id');
          
            $t_det = $Enquiry_model->getselectedtourplandetails($object_id,$enquiry_header_id,$enquiry_details_id);
            echo json_encode($t_det);
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function fetchEnquiryDetailsEdit()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $object_id = $this->request->getPost('object_id');
            $enquiry_details_id = $this->request->getPost('enquiry_details_id');
            $des_det = $Enquiry_model->fetchEnquiryDetailsEdit($object_id,$enquiry_details_id);
            echo json_encode($des_det);
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function getTourTariffDetails()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $vehicle_models = $this->request->getPost('vehicle_models');
            $hotel_id = $this->request->getPost('hotel_id');
            $room_cat_id = $this->request->getPost('room_cat_id');
            $mealplan = $this->request->getPost('mealplan');
            $checkin = $this->request->getPost('checkin');
            $checkout = $this->request->getPost('checkout');
            $no_of_night = $this->request->getPost('no_of_night');
            $double = $this->request->getPost('double');
            $single = $this->request->getPost('single');

            $id = $this->request->getPost('id');
            $duration = $this->request->getPost('duration');
            $totalNights = $this->request->getPost('totalNights');
            $tour_location_id = $this->request->getPost('tour_location_id');
            $previous_location_id = $this->request->getPost('previous_location_id');
            $vehicle_from_location = $this->request->getPost('vehicle_from_location');
            $vehicle_from_locations = $Enquiry_model->getLocationidfromhub($vehicle_from_location);
            $arrival_location = $this->request->getPost('arrival_location');
            if(!empty($vehicle_from_locations)){
                $vehicle_from_loc_id = $vehicle_from_locations[0]['geog_id'];
            }
            else{
                $vehicle_from_loc_id = $arrival_location;
            }
            $departure_location = $this->request->getPost('departure_location');
            $dist1 = 0;
            $dist2 = 0;
            $dist3 = 0;
            $dist4 = 0;
            $total_distance = 0;
            if($id == 1){
                if($duration == $totalNights){
                    $distance1 = $Enquiry_model->getDistancebyLocations($vehicle_from_loc_id,$arrival_location);
                    $distance2 = $Enquiry_model->getDistancebyLocations($arrival_location,$tour_location_id);
                    $distance3 = $Enquiry_model->getDistancebyLocations($tour_location_id,$departure_location);
                    $distance4 = $Enquiry_model->getDistancebyLocations($departure_location,$vehicle_from_loc_id);
                    if(!empty($distance1)){
                        $dist1 = $distance1[0]['geog_km_distance'];
                    }
                    else{
                        $dist1 = 0;
                    }
                    if(!empty($distance2)){
                        $dist2 = $distance2[0]['geog_km_distance'];
                    }
                    else{
                        $dist2 = 0;
                    }
                    if(!empty($distance3)){
                        $dist3 = $distance3[0]['geog_km_distance'];
                    }
                    else{
                        $dist3 = 0;
                    }
                    if(!empty($distance4)){
                        $dist4 = $distance4[0]['geog_km_distance'];
                    }
                    else{
                        $dist4 = 0;
                    }
                    $total_distance = $dist1 + $dist2 + $dist3 + $dist4;
                    $distance_type = 1;
                }
                else{
                    $distance1 = $Enquiry_model->getDistancebyLocations($vehicle_from_loc_id,$arrival_location);
                    $distance2 = $Enquiry_model->getDistancebyLocations($arrival_location,$tour_location_id);
                    if(!empty($distance1)){
                        $dist1 = $distance1[0]['geog_km_distance'];
                    }
                    else{
                        $dist1 = 0;
                    }
                    if(!empty($distance2)){
                        $dist2 = $distance2[0]['geog_km_distance'];
                    }
                    else{
                        $dist2 = 0;
                    }
                    $total_distance = $dist1 + $dist2;
                    $distance_type = 2;
                }
            }
            else{
                if($duration == $totalNights){
                    $distance1 = $Enquiry_model->getDistancebyLocations($tour_location_id,$departure_location);
                    $distance2 = $Enquiry_model->getDistancebyLocations($departure_location,$vehicle_from_loc_id);
                    if(!empty($distance1)){
                        $dist1 = $distance1[0]['geog_km_distance'];
                    }
                    else{
                        $dist1 = 0;
                    }
                    if(!empty($distance2)){
                        $dist2 = $distance2[0]['geog_km_distance'];
                    }
                    else{
                        $dist2 = 0;
                    }
                    $total_distance = $dist1 + $dist2;
                    $distance_type = 3;
                }
                else{
                    $distance = $Enquiry_model->getDistancebyLocations($previous_location_id,$tour_location_id);
                    if(!empty($distance)){
                        $total_distance = $distance[0]['geog_km_distance'];
                    }
                    else{
                        $total_distance = 0;
                    }
                    $distance_type = 4;
                }
            }

            $tariff_det = [];

            $object_ids = $Enquiry_model->getObjectidByhotel($hotel_id);
            $object_id = $object_ids[0]['object_id'];
            $startDate = new DateTime($checkin);
            $endDate = new DateTime($checkout);
            //$endDate->modify('+1 day');
            $interval = new DateInterval('P1D');
            $period = new DatePeriod($startDate, $interval, $endDate);
            $d_room_tariff = 0;
            $d_child_tariff = 0;
            $d_child_wb_tariff = 0;
            $d_extra_tariff = 0;

            $s_room_tariff = 0;
            $s_child_tariff = 0;
            $s_child_wb_tariff = 0;
            $s_extra_tariff = 0;
            $season_id_t = null;
            $veh_tariffs = [];

            if(!empty($vehicle_models)){
                foreach($vehicle_models as $key => $val) {
                    $veh_object_ids = $Enquiry_model->getObjectidByvehicle($val['vehicle_type_id']);
                    $veh_object_id = $veh_object_ids[0]['object_id'];
                    $rate_per_day = 0;
                    $max_km_day = 0;
                    $extra_km_rate = 0;
                    $km_rate = 0;
                    $veh_tariffs[$key]['vehicle_count'] = $val['vehicle_count'];
                    $veh_tariffs[$key]['vehicle_type_id'] = $val['vehicle_type_id'];
                    $veh_tariffs[$key]['vehicle_model_name'] = $val['vehicle_model_name'];
                    $vehicle_basic_tariffs = $Enquiry_model->getTourtravelbasic(1,$val['vehicle_type_id']);
                    $max_km_day = $vehicle_basic_tariffs[0]['tour_travel_max_km'];
                    $extra_km_rate = $vehicle_basic_tariffs[0]['extra_km_rate'];  
                    foreach ($period as $date) {
                        $v_tour_date = $date->format('Y-m-d');
                        $vehicle_basic_tariffs = $Enquiry_model->getTourtravelbasic(1,$val['vehicle_type_id']);
                        $v_season_tariff = $Enquiry_model->checkVehicleSeasonExist($v_tour_date,$veh_object_id);
                        if(!empty($v_season_tariff)){
                            $vehicle_season_tariffs = $Enquiry_model->getTourtravelseason(2,$v_season_tariff[0]['season_id'],$val['vehicle_type_id']);
                            $rate_per_day = $rate_per_day + $vehicle_season_tariffs[0]['rate_per_day'];
                            $extra_km_rate = $vehicle_season_tariffs[0]['extra_km_rate'];
                            $km_rate = $vehicle_season_tariffs[0]['km_rate'];
                        }
                        else{
                            $vehicle_tariffs = $Enquiry_model->getTourtravelbasic(1,$val['vehicle_type_id']);
                            $rate_per_day = $rate_per_day + $vehicle_tariffs[0]['tour_travel_daily_rate'];
                        }
                    }
                    $veh_tariffs[$key]['rate_per_day'] = $rate_per_day/$no_of_night;
                    $veh_tariffs[$key]['max_km_day'] = $max_km_day;
                    $veh_tariffs[$key]['extra_km_rate'] = $extra_km_rate;
                }
            }
            
            if($double > 0){    
                $room_type = 2;
               
                foreach ($period as $date) { 
                    $tour_date = $date->format('Y-m-d');
                    $weekend_tariff = $Enquiry_model->checkWeekendExist($tour_date,$object_id);
                    $season_tariff = $Enquiry_model->checkSeasonExist($tour_date,$object_id);
                    
                    if(!empty($weekend_tariff)){
                        $room_tariffs = $Enquiry_model->getTourTariffDetails(7,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan);
                        if(!empty($room_tariffs)){
                            $d_room_tariff = $d_room_tariff + $room_tariffs[0]['tariff'];
                        }
                        else{
                            $d_room_tariff = 0;
                        } 

                        $child_tariffs = $Enquiry_model->getTourTariffDetailsChild(13,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan,1);
                        if(!empty($child_tariffs)){
                            $d_child_tariff = $d_child_tariff + $child_tariffs[0]['tariff'];
                        }
                        else{
                            $d_child_tariff = 0;
                        }

                        $child_wb_tariffs = $Enquiry_model->getTourTariffDetailsChild(16,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan,2);
                        if(!empty($child_wb_tariffs)){
                            $d_child_wb_tariff = $d_child_wb_tariff + $child_wb_tariffs[0]['tariff'];
                        }
                        else{
                            $d_child_wb_tariff = 0;
                        }

                        $extra_tariffs = $Enquiry_model->getTourTariffDetailsChild(10,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan,3);
                        if(!empty($extra_tariffs)){
                            $d_extra_tariff = $d_extra_tariff + $extra_tariffs[0]['tariff'];
                        }
                        else{
                            $d_extra_tariff = 0;
                        }
                    }
                    else if(!empty($season_tariff)){

                        

                        $room_tariffs = $Enquiry_model->getTourTariffDetails(6,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan);
                        if(!empty($room_tariffs)){
                            $d_room_tariff = $d_room_tariff + $room_tariffs[0]['tariff'];
                        }
                        else{
                            $d_room_tariff = 0;
                        }

                        $child_tariffs = $Enquiry_model->getTourTariffDetailsChild(12,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan,1);
                        if(!empty($child_tariffs)){
                            $d_child_tariff = $d_child_tariff + $child_tariffs[0]['tariff'];
                        }
                        else{
                            $d_child_tariff = 0;
                        }

                        $child_wb_tariffs = $Enquiry_model->getTourTariffDetailsChild(15,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan,2);
                        if(!empty($child_wb_tariffs)){
                            $d_child_wb_tariff = $d_child_wb_tariff + $child_wb_tariffs[0]['tariff'];
                        }
                        else{
                            $d_child_wb_tariff = 0;
                        }

                        $extra_tariffs = $Enquiry_model->getTourTariffDetailsChild(9,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan,3);
                        if(!empty($extra_tariffs)){
                            $d_extra_tariff = $d_extra_tariff + $extra_tariffs[0]['tariff'];
                        }
                        else{
                            $d_extra_tariff = 0;
                        }

                    }
                    else{

                        $room_tariffs = $Enquiry_model->getTourTariffDetailsBasic(5,$room_cat_id,$room_type,$object_id,$mealplan);
                        if(!empty($room_tariffs)){
                            $d_room_tariff = $d_room_tariff + $room_tariffs[0]['tariff'];
                        }
                        else{
                            $d_room_tariff = 0;
                        }

                        $child_tariffs = $Enquiry_model->getTourTariffDetailsChildBasic(11,$room_cat_id,$room_type,$object_id,$mealplan,1);
                        if(!empty($child_tariffs)){
                            $d_child_tariff = $d_child_tariff + $child_tariffs[0]['exclusive_tariff'];
                        }
                        else{
                            $d_child_tariff = 0;
                        }

                        $child_wb_tariffs = $Enquiry_model->getTourTariffDetailsChildBasic(11,$room_cat_id,$room_type,$object_id,$mealplan,2);
                        if(!empty($child_wb_tariffs)){
                            $d_child_wb_tariff = $d_child_wb_tariff + $child_wb_tariffs[0]['exclusive_tariff'];
                        }
                        else{
                            $d_child_wb_tariff = 0;
                        }

                        $extra_tariffs = $Enquiry_model->getTourTariffDetailsChildBasic(11,$room_cat_id,$room_type,$object_id,$mealplan,3);
                        if(!empty($extra_tariffs)){
                            $d_extra_tariff = $d_extra_tariff + $extra_tariffs[0]['exclusive_tariff'];
                        }
                        else{
                            $d_extra_tariff = 0;
                        }
                    }
                }
            }

            if($single > 0){    
                $room_type = 1;
                
                foreach ($period as $date) {
                    $tour_date = $date->format('Y-m-d');
                    $weekend_tariff = $Enquiry_model->checkWeekendExist($tour_date,$object_id);
                    $season_tariff = $Enquiry_model->checkSeasonExist($tour_date,$object_id);
                   
                    
                    if(!empty($weekend_tariff)){
                     
                        $s_room_tariffs = $Enquiry_model->getTourTariffDetails(7,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan);
                        if(!empty($s_room_tariffs)){
                            $s_room_tariff = $s_room_tariff + $s_room_tariffs[0]['tariff'];
                        }
                        else{
                            $s_room_tariff = 0;
                        }

                        $s_child_tariffs = $Enquiry_model->getTourTariffDetailsChild(13,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan,1);
                        if(!empty($s_child_tariffs)){
                            $s_child_tariff = $s_child_tariff + $s_child_tariffs[0]['tariff'];
                        }
                        else{
                            $s_child_tariff = 0;
                        }

                        $s_child_wb_tariffs = $Enquiry_model->getTourTariffDetailsChild(16,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan,2);
                        if(!empty($s_child_wb_tariffs)){
                            $s_child_wb_tariff = $s_child_wb_tariff + $s_child_wb_tariffs[0]['tariff'];
                        }
                        else{
                            $s_child_wb_tariff = 0;
                        }

                        $s_extra_tariffs = $Enquiry_model->getTourTariffDetailsChild(10,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan,3);
                        if(!empty($s_extra_tariffs)){
                            $s_extra_tariff = $s_extra_tariff + $s_extra_tariffs[0]['tariff'];
                        }
                        else{
                            $s_extra_tariff = 0;
                        }
                    }
                    else if(!empty($season_tariff)){
                        $s_room_tariffs = $Enquiry_model->getTourTariffDetails(6,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan);
                        if(!empty($s_room_tariffs)){
                            $s_room_tariff = $s_room_tariff + $s_room_tariffs[0]['tariff'];
                        }
                        else{
                            $s_room_tariff = 0;
                        }

                        $s_child_tariffs = $Enquiry_model->getTourTariffDetailsChild(12,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan,1);
                        if(!empty($s_child_tariffs)){
                            $s_child_tariff = $s_child_tariff + $s_child_tariffs[0]['tariff'];
                        }
                        else{
                            $s_child_tariff = 0;
                        }

                        $s_child_wb_tariffs = $Enquiry_model->getTourTariffDetailsChild(15,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan,2);
                        if(!empty($s_child_wb_tariffs)){
                            $s_child_wb_tariff = $s_child_wb_tariff + $s_child_wb_tariffs[0]['tariff'];
                        }
                        else{
                            $s_child_wb_tariff = 0;
                        }

                        $s_extra_tariffs = $Enquiry_model->getTourTariffDetailsChild(9,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan,3);
                        if(!empty($s_extra_tariffs)){
                            $s_extra_tariff = $s_extra_tariff + $s_extra_tariffs[0]['tariff'];
                        }
                        else{
                            $s_extra_tariff = 0;
                        }

                    }
                    else{

                        $room_tariffs = $Enquiry_model->getTourTariffDetailsBasic(5,$room_cat_id,$room_type,$object_id,$mealplan);
                        if(!empty($room_tariffs)){
                            $s_room_tariff = $s_room_tariff + $room_tariffs[0]['tariff'];
                        }
                        else{
                            $s_room_tariff = 0;
                        }

                        $child_tariffs = $Enquiry_model->getTourTariffDetailsChildBasic(11,$room_cat_id,$room_type,$object_id,$mealplan,1);
                        if(!empty($child_tariffs)){
                            $s_child_tariff = $s_child_tariff + $child_tariffs[0]['exclusive_tariff'];
                        }
                        else{
                            $s_child_tariff = 0;
                        }

                        $child_wb_tariffs = $Enquiry_model->getTourTariffDetailsChildBasic(11,$room_cat_id,$room_type,$object_id,$mealplan,2);
                        if(!empty($child_wb_tariffs)){
                            $s_child_wb_tariff = $s_child_wb_tariff + $child_wb_tariffs[0]['exclusive_tariff'];
                        }
                        else{
                            $s_child_wb_tariff = 0;
                        }

                        $extra_tariffs = $Enquiry_model->getTourTariffDetailsChildBasic(11,$room_cat_id,$room_type,$object_id,$mealplan,3);
                        if(!empty($extra_tariffs)){
                            $s_extra_tariff = $s_extra_tariff + $extra_tariffs[0]['exclusive_tariff'];
                        }
                        else{
                            $s_extra_tariff = 0;
                        }
                    }
                }
            }
            $tariff_det['d_room_tariff']=intval($d_room_tariff/$no_of_night);
            $tariff_det['d_child_tariff']=intval($d_child_tariff/$no_of_night);
            $tariff_det['d_child_wb_tariff']=intval($d_child_wb_tariff/$no_of_night);
            $tariff_det['d_extra_tariff']=intval($d_extra_tariff/$no_of_night);

            $tariff_det['s_room_tariff']=intval($s_room_tariff/$no_of_night);
            $tariff_det['s_child_tariff']=intval($s_child_tariff/$no_of_night);
            $tariff_det['s_child_wb_tariff']=intval($s_child_wb_tariff/$no_of_night);
            $tariff_det['s_extra_tariff']=intval($s_extra_tariff/$no_of_night);
            $tariff_det['vehicles']=$veh_tariffs;
            $tariff_det['total_distance']=$total_distance;
            $tariff_det['dist1']=$dist1;
            $tariff_det['dist2']=$dist2;
            $tariff_det['dist3']=$dist3;
            $tariff_det['dist4']=$dist4;
            $tariff_det['distance_type']=$distance_type;
           
            echo json_encode($tariff_det);
        }
        else{
            return redirect()->to('Login');
        }
    }

    public function saveTourPlan()
    {
        if (!empty(session()->get('user_id'))) {
            $Dashboard_model = new Dashboard_m();
            $Enquiry_model = new Enquiry_m();
            date_default_timezone_set('Asia/Kolkata');
            $updated_time = date('Y-m-d H:i:s');
            $sdate = date('Y-m-d');
            $system_id = session('system_id');
            $user_id = session('user_id');
            $edit_id = $this->request->getPost('edit_id');
            $enquiry_header_id = $this->request->getPost('enquiry_header_id');
            if($edit_id > 0){
                $up_data = array(
                    'is_active' => 0,
                    'is_draft' => 0
                );
                $up_itidata = array(
                    'is_active' => 0,
                    'is_draft' => 0
                );
                $up_extdata = array(
                    'is_edit' => 0
                );
              
                $tp_update = $Enquiry_model->update_tourplan_isactive($up_data,$enquiry_header_id);
                $iti_update = $Enquiry_model->update_itinerary_isactive($up_itidata,$enquiry_header_id);
                $ext_update = $Enquiry_model->update_extension_isedit($up_extdata,$enquiry_header_id);
            }

            $object_id = $this->request->getPost('object_id');
            $sURL = site_url('Enquiry/tour_plan/'.$object_id);
            
            $submit_type = $this->request->getPost('submit_type');
            $enquiry_details_id = $this->request->getPost('enquiry_details_id');
            $no_of_double_room = $this->request->getPost('no_of_double_room');
            $no_of_single_room = $this->request->getPost('no_of_single_room');
            $is_quick_quote = $this->request->getPost('is_quick_quote');
            
            $addloc = $this->request->getPost('addloc');
           
                if(!empty($addloc)){
                    if($submit_type == "draft"){
                        $edited_count = count($addloc);
                        $original_count = $Enquiry_model->get_tour_locations_count($enquiry_header_id,$enquiry_details_id);
                        if($original_count > $edited_count){
                            $deleted_count = $original_count - $edited_count;
                            $deleted_id = $Enquiry_model->delete_tour_locations($enquiry_header_id,$enquiry_details_id,$deleted_count);
                        }
                        foreach ($addloc as $item) {
                            $tour_exist = $Enquiry_model->check_tour_location_exist($enquiry_header_id,$enquiry_details_id,$item['location_sequence']);
                            if($tour_exist > 0){
                                $json_data = [];
                                $rt_data = [];
                                if (!empty(array_filter($item['veh_model'] ?? []))) {
                                    foreach ($item['veh_model'] as $index => $model_name) {
                                        $json_data[] = [
                                            "vehicle_model" => $model_name,
                                            "veh_type_id" => $item['veh_type_id'][$index],
                                            "vehicle_count" => $item['veh_count'][$index],
                                            "day_rent" => $item['day_rent'][$index],
                                            "max_km_day" => $item['max_km_day'][$index],
                                            "extra_km_rate" => $item['extra_km_rate'][$index],
                                            "travel_distance" => $item['travel_distance'][$index],
                                            "extra_kilometer" => $item['extra_kilometer'][$index],
                                            "veh_total" => $item['veh_total'][$index],
                                            'veh_header' => $item['veh_header'],
                                            'pre_to_cur' => $item['pre_to_cur'],
                                            'cur_to_dep' => $item['cur_to_dep'],
                                            'dep_to_arr' => $item['dep_to_arr'],
                                            'hub_to_arr' => $item['hub_to_arr'],
                                            'arr_to_loc' => $item['arr_to_loc']
                                        ];
                                    }
                                }
                                $json_output = json_encode($json_data, JSON_PRETTY_PRINT);

                                $rt_data[] = [
                                    "double" => $no_of_double_room,
                                    "single" => $no_of_single_room
                                ];
                                $rt_json = json_encode($rt_data, JSON_PRETTY_PRINT);
                                $tour_details_ids = $Enquiry_model->get_tour_details_id($enquiry_header_id,$enquiry_details_id,$item['location_sequence']);
                                $tour_details_id = $tour_details_ids[0]['tour_details_id'];
                                $tour_data_update = array(
                                    'tour_location' => $item['tour_location_id'],
                                    'no_of_days' => $item['no_of_night'],
                                    'check_in_date' => $item['checkin'],
                                    'check_out_date' => $item['checkout'],
                                    'hot_cat_id' => $item['hotelcat'],
                                    'meal_plan_id' => $item['mealplan'],
                                    'hotel_id' => $item['hotelid'],
                                    'room_category_id' => $item['roomcat'],
                                    'is_own_arrangement' => $item['own_arrange'],
                                    'room_type' => $rt_json,
                                    'vehicle_details' => $json_output,
                                    'location_sequence' => $item['location_sequence'],
                                    'is_active' => 1,
                                    'is_draft' => 1,
                                    'updated_time' => $updated_time
                                );
                                $tour_updated = $Enquiry_model->update_tour_details($tour_data_update,$tour_details_id);
                                if($tour_updated){
                                    //if($is_quick_quote == 1){
                                        $d_room_rate = array(
                                            'quick_quote_tariff' => $item['d_adult_rate']
                                        );
                                        $qq_update = $Enquiry_model->update_qq_details($d_room_rate,$tour_details_id,6,2);   
                                        $s_room_rate = array(
                                            'quick_quote_tariff' => $item['s_adult_rate']
                                        );
                                        $qq_update = $Enquiry_model->update_qq_details($s_room_rate,$tour_details_id,6,1);   
                                        $d_c_rate = array(
                                            'quick_quote_tariff' => $item['d_child_rate']
                                        );
                                        $qq_update = $Enquiry_model->update_qq_details($d_c_rate,$tour_details_id,12,2);   
                                        $s_c_rate = array(
                                            'quick_quote_tariff' => $item['s_child_rate']
                                        );
                                        $qq_update = $Enquiry_model->update_qq_details($s_c_rate,$tour_details_id,12,1);   
                                        $d_cw_rate = array(
                                            'quick_quote_tariff' => $item['d_child_wb_rate']
                                        );
                                        $qq_update = $Enquiry_model->update_qq_details($d_cw_rate,$tour_details_id,15,2);   
                                        $s_cw_rate = array(
                                            'quick_quote_tariff' => $item['s_child_wb_rate']
                                        );
                                        $qq_update = $Enquiry_model->update_qq_details($s_cw_rate,$tour_details_id,15,1);   

                                        $d_e_rate = array(
                                            'quick_quote_tariff' => $item['d_extra_bed_rate']
                                        );
                                        $qq_update = $Enquiry_model->update_qq_details($d_e_rate,$tour_details_id,9,2);   
                                        $s_e_rate = array(  
                                            'quick_quote_tariff' => $item['s_extra_bed_rate']
                                        );
                                        $qq_update = $Enquiry_model->update_qq_details($s_e_rate,$tour_details_id,9,1);   
                                    //}
                                }
                            }
                            else{
                                $json_data = [];
                                $rt_data = [];
                                if (!empty(array_filter($item['veh_model'] ?? []))) {
                                    foreach ($item['veh_model'] as $index => $model_name) {
                                        $json_data[] = [
                                            "vehicle_model" => $model_name,
                                            "veh_type_id" => $item['veh_type_id'][$index],
                                            "vehicle_count" => $item['veh_count'][$index],
                                            "day_rent" => $item['day_rent'][$index],
                                            "max_km_day" => $item['max_km_day'][$index],
                                            "extra_km_rate" => $item['extra_km_rate'][$index],
                                            "travel_distance" => $item['travel_distance'][$index],
                                            "extra_kilometer" => $item['extra_kilometer'][$index],
                                            "veh_total" => $item['veh_total'][$index],
                                            'veh_header' => $item['veh_header'],
                                            'pre_to_cur' => $item['pre_to_cur'],
                                            'cur_to_dep' => $item['cur_to_dep'],
                                            'dep_to_arr' => $item['dep_to_arr'],
                                            'hub_to_arr' => $item['hub_to_arr'],
                                            'arr_to_loc' => $item['arr_to_loc']
                                        ];
                                    }
                                }
                                $json_output = json_encode($json_data, JSON_PRETTY_PRINT);

                                $rt_data[] = [
                                    "double" => $no_of_double_room,
                                    "single" => $no_of_single_room
                                ];
                                $rt_json = json_encode($rt_data, JSON_PRETTY_PRINT);
                                
                                $tour_data = array(
                                    'enquiry_header_id' => $enquiry_header_id,
                                    'enquiry_details_id' => $enquiry_details_id,
                                    'tour_location' => $item['tour_location_id'],
                                    'no_of_days' => $item['no_of_night'],
                                    'check_in_date' => $item['checkin'],
                                    'check_out_date' => $item['checkout'],
                                    'hot_cat_id' => $item['hotelcat'],
                                    'meal_plan_id' => $item['mealplan'],
                                    'hotel_id' => $item['hotelid'],
                                    'room_category_id' => $item['roomcat'],
                                    'is_own_arrangement' => $item['own_arrange'],
                                    'room_type' => $rt_json,
                                    'vehicle_details' => $json_output,
                                    'location_sequence' => $item['location_sequence'],
                                    'is_active' => 1,
                                    'is_draft' => 1,
                                    'updated_time' => $updated_time,
                                    'enterprise_id' => 1
                                );
                                $tour_details_id = $Enquiry_model->insert_tour_details($tour_data);   
                                //if($is_quick_quote == 1){
                                    if($tour_details_id){
                                        $d_room_rate = array(
                                            'enquiry_header_id' => $enquiry_header_id,
                                            'enquiry_details_id' => $enquiry_details_id,
                                            'tour_details_id' => $tour_details_id,
                                            'room_type_id' => 2,
                                            'cost_component_id' => 6,
                                            'quick_quote_tariff' => $item['d_adult_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 1,
                                            'enterprise_id' => 1
                                        );
                                        $qq_insert = $Enquiry_model->insert_qq_details($d_room_rate);   
                                        $s_room_rate = array(
                                            'enquiry_header_id' => $enquiry_header_id,
                                            'enquiry_details_id' => $enquiry_details_id,
                                            'tour_details_id' => $tour_details_id,
                                            'room_type_id' => 1,
                                            'cost_component_id' => 6,
                                            'quick_quote_tariff' => $item['s_adult_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 1,
                                            'enterprise_id' => 1
                                        );
                                        $qq_insert = $Enquiry_model->insert_qq_details($s_room_rate);   

                                        $d_c_rate = array(
                                            'enquiry_header_id' => $enquiry_header_id,
                                            'enquiry_details_id' => $enquiry_details_id,
                                            'tour_details_id' => $tour_details_id,
                                            'room_type_id' => 2,
                                            'cost_component_id' => 12,
                                            'quick_quote_tariff' => $item['d_child_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 1,
                                            'enterprise_id' => 1
                                        );
                                        $qq_insert = $Enquiry_model->insert_qq_details($d_c_rate);   
                                        $s_c_rate = array(
                                            'enquiry_header_id' => $enquiry_header_id,
                                            'enquiry_details_id' => $enquiry_details_id,
                                            'tour_details_id' => $tour_details_id,
                                            'room_type_id' => 1,
                                            'cost_component_id' => 12,
                                            'quick_quote_tariff' => $item['s_child_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 1,
                                            'enterprise_id' => 1
                                        );
                                        $qq_insert = $Enquiry_model->insert_qq_details($s_c_rate);   

                                        $d_cw_rate = array(
                                            'enquiry_header_id' => $enquiry_header_id,
                                            'enquiry_details_id' => $enquiry_details_id,
                                            'tour_details_id' => $tour_details_id,
                                            'room_type_id' => 2,
                                            'cost_component_id' => 15,
                                            'quick_quote_tariff' => $item['d_child_wb_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 1,
                                            'enterprise_id' => 1
                                        );
                                        $qq_insert = $Enquiry_model->insert_qq_details($d_cw_rate);   
                                        $s_cw_rate = array(
                                            'enquiry_header_id' => $enquiry_header_id,
                                            'enquiry_details_id' => $enquiry_details_id,
                                            'tour_details_id' => $tour_details_id,
                                            'room_type_id' => 1,
                                            'cost_component_id' => 15,
                                            'quick_quote_tariff' => $item['s_child_wb_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 1,
                                            'enterprise_id' => 1
                                        );
                                        $qq_insert = $Enquiry_model->insert_qq_details($s_cw_rate);   

                                        $d_e_rate = array(
                                            'enquiry_header_id' => $enquiry_header_id,
                                            'enquiry_details_id' => $enquiry_details_id,
                                            'tour_details_id' => $tour_details_id,
                                            'room_type_id' => 2,
                                            'cost_component_id' => 9,
                                            'quick_quote_tariff' => $item['d_extra_bed_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 1,
                                            'enterprise_id' => 1
                                        );
                                        $qq_insert = $Enquiry_model->insert_qq_details($d_e_rate);   
                                        $s_e_rate = array(
                                            'enquiry_header_id' => $enquiry_header_id,
                                            'enquiry_details_id' => $enquiry_details_id,
                                            'tour_details_id' => $tour_details_id,
                                            'room_type_id' => 1,
                                            'cost_component_id' => 9,
                                            'quick_quote_tariff' => $item['s_extra_bed_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 1,
                                            'enterprise_id' => 1
                                        );
                                        $qq_insert = $Enquiry_model->insert_qq_details($s_e_rate);   
                                    }
                                //}
                            }
                        }
                        
                    }
                    if($submit_type == "final"){
                        foreach ($addloc as $item) {
                           $tour_exist = $Enquiry_model->check_tour_location_exist($enquiry_header_id,$enquiry_details_id,$item['location_sequence']);
                           if($tour_exist > 0){
                                $json_data = [];
                                $rt_data = [];
                                if (!empty(array_filter($item['veh_model'] ?? []))) {
                                    foreach ($item['veh_model'] as $index => $model_name) {
                                        $json_data[] = [
                                            "vehicle_model" => $model_name,
                                            "veh_type_id" => $item['veh_type_id'][$index],
                                            "vehicle_count" => $item['veh_count'][$index],
                                            "day_rent" => $item['day_rent'][$index],
                                            "max_km_day" => $item['max_km_day'][$index],
                                            "extra_km_rate" => $item['extra_km_rate'][$index],
                                            "travel_distance" => $item['travel_distance'][$index],
                                            "extra_kilometer" => $item['extra_kilometer'][$index],
                                            "veh_total" => $item['veh_total'][$index],
                                            'veh_header' => $item['veh_header'],
                                            'pre_to_cur' => $item['pre_to_cur'],
                                            'cur_to_dep' => $item['cur_to_dep'],
                                            'dep_to_arr' => $item['dep_to_arr'],
                                            'hub_to_arr' => $item['hub_to_arr'],
                                            'arr_to_loc' => $item['arr_to_loc']
                                        ];
                                    }
                                }
                                $json_output = json_encode($json_data, JSON_PRETTY_PRINT);

                                $rt_data[] = [
                                    "double" => $no_of_double_room,
                                    "single" => $no_of_single_room
                                ];
                                $rt_json = json_encode($rt_data, JSON_PRETTY_PRINT);
                                $tour_details_ids = $Enquiry_model->get_tour_details_id($enquiry_header_id,$enquiry_details_id,$item['location_sequence']);
                                $tour_details_id = $tour_details_ids[0]['tour_details_id'];
                                $tour_data_update = array(
                                    'tour_location' => $item['tour_location_id'],
                                    'no_of_days' => $item['no_of_night'],
                                    'check_in_date' => $item['checkin'],
                                    'check_out_date' => $item['checkout'],
                                    'hot_cat_id' => $item['hotelcat'],
                                    'meal_plan_id' => $item['mealplan'],
                                    'hotel_id' => $item['hotelid'],
                                    'room_category_id' => $item['roomcat'],
                                    'is_own_arrangement' => $item['own_arrange'],
                                    'room_type' => $rt_json,
                                    'vehicle_details' => $json_output,
                                    'location_sequence' => $item['location_sequence'],
                                    'is_active' => 1,
                                    'is_draft' => 0,
                                    'updated_time' => $updated_time
                                );
                                $tour_updated = $Enquiry_model->update_tour_details($tour_data_update,$tour_details_id);
                                if($tour_updated){
                                    //if($is_quick_quote == 1){
                                        $d_room_rate = array(
                                            'quick_quote_tariff' => $item['d_adult_rate'],
                                            'is_draft' => 0
                                        );
                                        $qq_update = $Enquiry_model->update_qq_details($d_room_rate,$tour_details_id,6,2);   
                                        $s_room_rate = array(
                                            'quick_quote_tariff' => $item['s_adult_rate'],
                                            'is_draft' => 0
                                        );
                                        $qq_update = $Enquiry_model->update_qq_details($s_room_rate,$tour_details_id,6,1);   
                                        $d_c_rate = array(
                                            'quick_quote_tariff' => $item['d_child_rate'],
                                            'is_draft' => 0
                                        );
                                        $qq_update = $Enquiry_model->update_qq_details($d_c_rate,$tour_details_id,12,2);   
                                        $s_c_rate = array(
                                            'quick_quote_tariff' => $item['s_child_rate'],
                                            'is_draft' => 0
                                        );
                                        $qq_update = $Enquiry_model->update_qq_details($s_c_rate,$tour_details_id,12,1);   
                                        $d_cw_rate = array(
                                            'quick_quote_tariff' => $item['d_child_wb_rate'],
                                            'is_draft' => 0
                                        );
                                        $qq_update = $Enquiry_model->update_qq_details($d_cw_rate,$tour_details_id,15,2);   
                                        $s_cw_rate = array(
                                            'quick_quote_tariff' => $item['s_child_wb_rate'],
                                            'is_draft' => 0
                                        );
                                        $qq_update = $Enquiry_model->update_qq_details($s_cw_rate,$tour_details_id,15,1);   

                                        $d_e_rate = array(
                                            'quick_quote_tariff' => $item['d_extra_bed_rate'],
                                            'is_draft' => 0
                                        );
                                        $qq_update = $Enquiry_model->update_qq_details($d_e_rate,$tour_details_id,9,2);   
                                        $s_e_rate = array(  
                                            'quick_quote_tariff' => $item['s_extra_bed_rate'],
                                            'is_draft' => 0
                                        );
                                        $qq_update = $Enquiry_model->update_qq_details($s_e_rate,$tour_details_id,9,1);   
                                    //}
                                }
                           }
                           else{
                                $json_data = [];
                                $rt_data = [];
                                if (!empty(array_filter($item['veh_model'] ?? []))) {
                                    foreach ($item['veh_model'] as $index => $model_name) {
                                        $json_data[] = [
                                            "vehicle_model" => $model_name,
                                            "veh_type_id" => $item['veh_type_id'][$index],
                                            "vehicle_count" => $item['veh_count'][$index],
                                            "day_rent" => $item['day_rent'][$index],
                                            "max_km_day" => $item['max_km_day'][$index],
                                            "extra_km_rate" => $item['extra_km_rate'][$index],
                                            "travel_distance" => $item['travel_distance'][$index],
                                            "extra_kilometer" => $item['extra_kilometer'][$index],
                                            "veh_total" => $item['veh_total'][$index],
                                            'veh_header' => $item['veh_header'],
                                            'pre_to_cur' => $item['pre_to_cur'],
                                            'cur_to_dep' => $item['cur_to_dep'],
                                            'dep_to_arr' => $item['dep_to_arr'],
                                            'hub_to_arr' => $item['hub_to_arr'],
                                            'arr_to_loc' => $item['arr_to_loc']
                                        ];
                                    }
                                }
                                $json_output = json_encode($json_data, JSON_PRETTY_PRINT);

                                $rt_data[] = [
                                    "double" => $no_of_double_room,
                                    "single" => $no_of_single_room
                                ];
                                $rt_json = json_encode($rt_data, JSON_PRETTY_PRINT);
                                
                                $tour_data = array(
                                    'enquiry_header_id' => $enquiry_header_id,
                                    'enquiry_details_id' => $enquiry_details_id,
                                    'tour_location' => $item['tour_location_id'],
                                    'no_of_days' => $item['no_of_night'],
                                    'check_in_date' => $item['checkin'],
                                    'check_out_date' => $item['checkout'],
                                    'hot_cat_id' => $item['hotelcat'],
                                    'meal_plan_id' => $item['mealplan'],
                                    'hotel_id' => $item['hotelid'],
                                    'room_category_id' => $item['roomcat'],
                                    'is_own_arrangement' => $item['own_arrange'],
                                    'room_type' => $rt_json,
                                    'vehicle_details' => $json_output,
                                    'location_sequence' => $item['location_sequence'],
                                    'is_active' => 1,
                                    'is_draft' => 0,
                                    'updated_time' => $updated_time,
                                    'enterprise_id' => 1
                                );
                                $tour_details_id = $Enquiry_model->insert_tour_details($tour_data);   
                                //if($is_quick_quote == 1){
                                    if($tour_details_id){
                                        $d_room_rate = array(
                                            'enquiry_header_id' => $enquiry_header_id,
                                            'enquiry_details_id' => $enquiry_details_id,
                                            'tour_details_id' => $tour_details_id,
                                            'room_type_id' => 2,
                                            'cost_component_id' => 6,
                                            'quick_quote_tariff' => $item['d_adult_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $qq_insert = $Enquiry_model->insert_qq_details($d_room_rate);   
                                        $s_room_rate = array(
                                            'enquiry_header_id' => $enquiry_header_id,
                                            'enquiry_details_id' => $enquiry_details_id,
                                            'tour_details_id' => $tour_details_id,
                                            'room_type_id' => 1,
                                            'cost_component_id' => 6,
                                            'quick_quote_tariff' => $item['s_adult_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $qq_insert = $Enquiry_model->insert_qq_details($s_room_rate);   

                                        $d_c_rate = array(
                                            'enquiry_header_id' => $enquiry_header_id,
                                            'enquiry_details_id' => $enquiry_details_id,
                                            'tour_details_id' => $tour_details_id,
                                            'room_type_id' => 2,
                                            'cost_component_id' => 12,
                                            'quick_quote_tariff' => $item['d_child_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $qq_insert = $Enquiry_model->insert_qq_details($d_c_rate);   
                                        $s_c_rate = array(
                                            'enquiry_header_id' => $enquiry_header_id,
                                            'enquiry_details_id' => $enquiry_details_id,
                                            'tour_details_id' => $tour_details_id,
                                            'room_type_id' => 1,
                                            'cost_component_id' => 12,
                                            'quick_quote_tariff' => $item['s_child_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $qq_insert = $Enquiry_model->insert_qq_details($s_c_rate);   

                                        $d_cw_rate = array(
                                            'enquiry_header_id' => $enquiry_header_id,
                                            'enquiry_details_id' => $enquiry_details_id,
                                            'tour_details_id' => $tour_details_id,
                                            'room_type_id' => 2,
                                            'cost_component_id' => 15,
                                            'quick_quote_tariff' => $item['d_child_wb_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $qq_insert = $Enquiry_model->insert_qq_details($d_cw_rate);   
                                        $s_cw_rate = array(
                                            'enquiry_header_id' => $enquiry_header_id,
                                            'enquiry_details_id' => $enquiry_details_id,
                                            'tour_details_id' => $tour_details_id,
                                            'room_type_id' => 1,
                                            'cost_component_id' => 15,
                                            'quick_quote_tariff' => $item['s_child_wb_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $qq_insert = $Enquiry_model->insert_qq_details($s_cw_rate);   

                                        $d_e_rate = array(
                                            'enquiry_header_id' => $enquiry_header_id,
                                            'enquiry_details_id' => $enquiry_details_id,
                                            'tour_details_id' => $tour_details_id,
                                            'room_type_id' => 2,
                                            'cost_component_id' => 9,
                                            'quick_quote_tariff' => $item['d_extra_bed_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $qq_insert = $Enquiry_model->insert_qq_details($d_e_rate);   
                                        $s_e_rate = array(
                                            'enquiry_header_id' => $enquiry_header_id,
                                            'enquiry_details_id' => $enquiry_details_id,
                                            'tour_details_id' => $tour_details_id,
                                            'room_type_id' => 1,
                                            'cost_component_id' => 9,
                                            'quick_quote_tariff' => $item['s_extra_bed_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $qq_insert = $Enquiry_model->insert_qq_details($s_e_rate);   
                                    }
                                //}
                           }
                        }
                        $tour_plan_det = $Enquiry_model->get_tour_plan_details($enquiry_header_id,$enquiry_details_id);
                        $ext_ref_id_tour_plan = $tour_plan_det[0]['tour_details_id'];
                        $ext_tp_data = array(
                            'extension_ref_id' => $ext_ref_id_tour_plan
                        );
                        $ext_tp_updated = $Enquiry_model->linkItinearywithTourplan($ext_tp_data,$enquiry_header_id,$enquiry_details_id); 
                    }
                    return redirect()->to($sURL);
                }
       
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function saveTourLocation()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $is_quick_quote = $this->request->getPost('is_quick_quote');
            $enquiry_header_id = $this->request->getPost('enquiry_header_id');
            $enquiry_details_id = $this->request->getPost('enquiry_details_id');
            $location_sequence = $this->request->getPost('location_sequence');
            $tour_exist = $Enquiry_model->check_tour_location_exist($enquiry_header_id,$enquiry_details_id,$location_sequence);
            if($tour_exist > 0){
                $tour_details_ids = $Enquiry_model->get_tour_details_id($enquiry_header_id,$enquiry_details_id,$location_sequence);
                $tour_details_id = $tour_details_ids[0]['tour_details_id'];
                $tour_data_update = array(
                    'tour_location' => $this->request->getPost('tour_location'),
                    'no_of_days' => $this->request->getPost('no_of_days'),
                    'check_in_date' => $this->request->getPost('check_in_date'),
                    'check_out_date' => $this->request->getPost('check_out_date'),
                    'hotel_id' => $this->request->getPost('hotel_id'),
                    'room_category_id' => $this->request->getPost('room_category_id'),
                    'room_type' => json_encode($this->request->getPost('room_type')),
                    'vehicle_details' => json_encode($this->request->getPost('vehicle_details'))
                );
                $tour_updated = $Enquiry_model->update_tour_details($tour_data_update,$tour_details_id);
                if($tour_updated){
                    if($is_quick_quote == 1){
                        $d_room_rate = array(
                            'quick_quote_tariff' => $this->request->getPost('d_adult_rate')
                        );
                        $qq_update = $Enquiry_model->update_qq_details($d_room_rate,$tour_details_id,6,2);   
                        $s_room_rate = array(
                            'quick_quote_tariff' => $this->request->getPost('s_adult_rate')
                        );
                        $qq_update = $Enquiry_model->update_qq_details($s_room_rate,$tour_details_id,6,1);   
                        $d_c_rate = array(
                            'quick_quote_tariff' => $this->request->getPost('d_child_rate'),
                        );
                        $qq_update = $Enquiry_model->update_qq_details($d_c_rate,$tour_details_id,12,2);   
                        $s_c_rate = array(
                            'quick_quote_tariff' => $this->request->getPost('s_child_rate')
                        );
                        $qq_update = $Enquiry_model->update_qq_details($s_c_rate,$tour_details_id,12,1);   
                        $d_cw_rate = array(
                            'quick_quote_tariff' => $this->request->getPost('d_child_wb_rate')
                        );
                        $qq_update = $Enquiry_model->update_qq_details($d_cw_rate,$tour_details_id,15,2);   
                        $s_cw_rate = array(
                            'quick_quote_tariff' => $this->request->getPost('s_child_wb_rate')
                        );
                        $qq_update = $Enquiry_model->update_qq_details($s_cw_rate,$tour_details_id,15,1);   

                        $d_e_rate = array(
                            'quick_quote_tariff' => $this->request->getPost('d_extra_bed_rate')
                        );
                        $qq_update = $Enquiry_model->update_qq_details($d_e_rate,$tour_details_id,9,2);   
                        $s_e_rate = array(  
                            'quick_quote_tariff' => $this->request->getPost('s_extra_bed_rate')
                        );
                        $qq_update = $Enquiry_model->update_qq_details($s_e_rate,$tour_details_id,9,1);   
                    }
                }
            }
            else{
                $tour_data = array(
                    'enquiry_header_id' => $this->request->getPost('enquiry_header_id'),
                    'enquiry_details_id' => $this->request->getPost('enquiry_details_id'),
                    'tour_location' => $this->request->getPost('tour_location'),
                    'no_of_days' => $this->request->getPost('no_of_days'),
                    'check_in_date' => $this->request->getPost('check_in_date'),
                    'check_out_date' => $this->request->getPost('check_out_date'),
                    'hotel_id' => $this->request->getPost('hotel_id'),
                    'room_category_id' => $this->request->getPost('room_category_id'),
                    'room_type' => json_encode($this->request->getPost('room_type')),
                    'vehicle_details' => json_encode($this->request->getPost('vehicle_details')),
                    'location_sequence' => $this->request->getPost('location_sequence'),
                    'is_active' => 1,
                    'is_draft' => 1,
                    'enterprise_id' => 1
                );
                $tour_details_id = $Enquiry_model->insert_tour_details($tour_data);
                if($is_quick_quote == 1){
                    if($tour_details_id){
                        $d_room_rate = array(
                            'enquiry_header_id' => $enquiry_header_id,
                            'enquiry_details_id' => $enquiry_details_id,
                            'tour_details_id' => $tour_details_id,
                            'room_type_id' => 2,
                            'cost_component_id' => 6,
                            'quick_quote_tariff' => $this->request->getPost('d_adult_rate'),
                            'is_active' => 1,
                            'is_draft' => 1,
                            'enterprise_id' => 1
                        );
                        $qq_insert = $Enquiry_model->insert_qq_details($d_room_rate);   
                        $s_room_rate = array(
                            'enquiry_header_id' => $enquiry_header_id,
                            'enquiry_details_id' => $enquiry_details_id,
                            'tour_details_id' => $tour_details_id,
                            'room_type_id' => 1,
                            'cost_component_id' => 6,
                            'quick_quote_tariff' => $this->request->getPost('s_adult_rate'),
                            'is_active' => 1,
                            'is_draft' => 1,
                            'enterprise_id' => 1
                        );
                        $qq_insert = $Enquiry_model->insert_qq_details($s_room_rate);   

                        $d_c_rate = array(
                            'enquiry_header_id' => $enquiry_header_id,
                            'enquiry_details_id' => $enquiry_details_id,
                            'tour_details_id' => $tour_details_id,
                            'room_type_id' => 2,
                            'cost_component_id' => 12,
                            'quick_quote_tariff' => $this->request->getPost('d_child_rate'),
                            'is_active' => 1,
                            'is_draft' => 1,
                            'enterprise_id' => 1
                        );
                        $qq_insert = $Enquiry_model->insert_qq_details($d_c_rate);   
                        $s_c_rate = array(
                            'enquiry_header_id' => $enquiry_header_id,
                            'enquiry_details_id' => $enquiry_details_id,
                            'tour_details_id' => $tour_details_id,
                            'room_type_id' => 1,
                            'cost_component_id' => 12,
                            'quick_quote_tariff' => $this->request->getPost('s_child_rate'),
                            'is_active' => 1,
                            'is_draft' => 1,
                            'enterprise_id' => 1
                        );
                        $qq_insert = $Enquiry_model->insert_qq_details($s_c_rate);   

                        $d_cw_rate = array(
                            'enquiry_header_id' => $enquiry_header_id,
                            'enquiry_details_id' => $enquiry_details_id,
                            'tour_details_id' => $tour_details_id,
                            'room_type_id' => 2,
                            'cost_component_id' => 15,
                            'quick_quote_tariff' => $this->request->getPost('d_child_wb_rate'),
                            'is_active' => 1,
                            'is_draft' => 1,
                            'enterprise_id' => 1
                        );
                        $qq_insert = $Enquiry_model->insert_qq_details($d_cw_rate);   
                        $s_cw_rate = array(
                            'enquiry_header_id' => $enquiry_header_id,
                            'enquiry_details_id' => $enquiry_details_id,
                            'tour_details_id' => $tour_details_id,
                            'room_type_id' => 1,
                            'cost_component_id' => 15,
                            'quick_quote_tariff' => $this->request->getPost('s_child_wb_rate'),
                            'is_active' => 1,
                            'is_draft' => 1,
                            'enterprise_id' => 1
                        );
                        $qq_insert = $Enquiry_model->insert_qq_details($s_cw_rate);   

                        $d_e_rate = array(
                            'enquiry_header_id' => $enquiry_header_id,
                            'enquiry_details_id' => $enquiry_details_id,
                            'tour_details_id' => $tour_details_id,
                            'room_type_id' => 2,
                            'cost_component_id' => 9,
                            'quick_quote_tariff' => $this->request->getPost('d_extra_bed_rate'),
                            'is_active' => 1,
                            'is_draft' => 1,
                            'enterprise_id' => 1
                        );
                        $qq_insert = $Enquiry_model->insert_qq_details($d_e_rate);   
                        $s_e_rate = array(
                            'enquiry_header_id' => $enquiry_header_id,
                            'enquiry_details_id' => $enquiry_details_id,
                            'tour_details_id' => $tour_details_id,
                            'room_type_id' => 1,
                            'cost_component_id' => 9,
                            'quick_quote_tariff' => $this->request->getPost('s_extra_bed_rate'),
                            'is_active' => 1,
                            'is_draft' => 1,
                            'enterprise_id' => 1
                        );
                        $qq_insert = $Enquiry_model->insert_qq_details($s_e_rate);   
                    }
                }
                echo json_encode($tour_details_id);
            }
        }
        else{
            return redirect()->to('Login');
        }
    }

    public function getVehicleTariffDetails()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $vehicle_models = $this->request->getPost('vehicle_models');
            $id = $this->request->getPost('id');
            $checkin = $this->request->getPost('checkin');
            $checkout = $this->request->getPost('checkout');
            $no_of_night = $this->request->getPost('no_of_night');
            $duration = $this->request->getPost('duration');
            $totalNights = $this->request->getPost('totalNights');
            $tour_location_id = $this->request->getPost('tour_location_id');
            $previous_location_id = $this->request->getPost('previous_location_id');
            $vehicle_from_location = $this->request->getPost('vehicle_from_location');
            $vehicle_from_locations = $Enquiry_model->getLocationidfromhub($vehicle_from_location);
            $arrival_location = $this->request->getPost('arrival_location');
            if(!empty($vehicle_from_locations)){
                $vehicle_from_loc_id = $vehicle_from_locations[0]['geog_id'];
            }
            else{
                $vehicle_from_loc_id = $arrival_location;
            }
            $departure_location = $this->request->getPost('departure_location');
            $dist1 = 0;
            $dist2 = 0;
            $dist3 = 0;
            $dist4 = 0;
            $total_distance = 0;
            if($id == 1){
                if($duration == $totalNights){
                    $distance1 = $Enquiry_model->getDistancebyLocations($vehicle_from_loc_id,$arrival_location);
                    $distance2 = $Enquiry_model->getDistancebyLocations($arrival_location,$tour_location_id);
                    $distance3 = $Enquiry_model->getDistancebyLocations($tour_location_id,$departure_location);
                    $distance4 = $Enquiry_model->getDistancebyLocations($departure_location,$vehicle_from_loc_id);
                    if(!empty($distance1)){
                        $dist1 = $distance1[0]['geog_km_distance'];
                    }
                    else{
                        $dist1 = 0;
                    }
                    if(!empty($distance2)){
                        $dist2 = $distance2[0]['geog_km_distance'];
                    }
                    else{
                        $dist2 = 0;
                    }
                    if(!empty($distance3)){
                        $dist3 = $distance3[0]['geog_km_distance'];
                    }
                    else{
                        $dist3 = 0;
                    }
                    if(!empty($distance4)){
                        $dist4 = $distance4[0]['geog_km_distance'];
                    }
                    else{
                        $dist4 = 0;
                    }
                    $total_distance = $dist1 + $dist2 + $dist3 + $dist4;
                    $distance_type = 1;
                }
                else{
                    $distance1 = $Enquiry_model->getDistancebyLocations($vehicle_from_loc_id,$arrival_location);
                    $distance2 = $Enquiry_model->getDistancebyLocations($arrival_location,$tour_location_id);
                    if(!empty($distance1)){
                        $dist1 = $distance1[0]['geog_km_distance'];
                    }
                    else{
                        $dist1 = 0;
                    }
                    if(!empty($distance2)){
                        $dist2 = $distance2[0]['geog_km_distance'];
                    }
                    else{
                        $dist2 = 0;
                    }
                    $total_distance = $dist1 + $dist2;
                    $distance_type = 2;
                }
            }
            else{
                if($duration == $totalNights){
                    $distance3 = $Enquiry_model->getDistancebyLocations($previous_location_id,$tour_location_id);
                    if(!empty($distance3)){
                        $dist3 = $distance3[0]['geog_km_distance'];
                    }
                    else{
                        $dist3 = 0;
                    }
                    $distance1 = $Enquiry_model->getDistancebyLocations($tour_location_id,$departure_location);
                    $distance2 = $Enquiry_model->getDistancebyLocations($departure_location,$vehicle_from_loc_id);
                    if(!empty($distance1)){
                        $dist1 = $distance1[0]['geog_km_distance'];
                    }
                    else{
                        $dist1 = 0;
                    }
                    if(!empty($distance2)){
                        $dist2 = $distance2[0]['geog_km_distance'];
                    }
                    else{
                        $dist2 = 0;
                    }
                    $total_distance = $dist1 + $dist2 + $dist3;
                    $distance_type = 3;
                }
                else{
                    $distance = $Enquiry_model->getDistancebyLocations($previous_location_id,$tour_location_id);
                    if(!empty($distance)){
                        $total_distance = $distance[0]['geog_km_distance'];
                    }
                    else{
                        $total_distance = 0;
                    }
                    $distance_type = 4;
                }
            }
            $tariff_det = [];
          
            $startDate = new DateTime($checkin);
            $endDate = new DateTime($checkout);
            //$endDate->modify('+1 day');
            $interval = new DateInterval('P1D');
            $period = new DatePeriod($startDate, $interval, $endDate);
            $season_id_t = null;
            $veh_tariffs = [];
           
            if(!empty($vehicle_models)){
                foreach($vehicle_models as $key => $val) {
                    $veh_object_ids = $Enquiry_model->getObjectidByvehicle($val['vehicle_type_id']);
                    $veh_object_id = $veh_object_ids[0]['object_id'];
                    $rate_per_day = 0;
                    $max_km_day = 0;
                    $extra_km_rate = 0;
                    $km_rate = 0;
                    $veh_tariffs[$key]['vehicle_count'] = $val['vehicle_count'];
                    $veh_tariffs[$key]['vehicle_type_id'] = $val['vehicle_type_id'];
                    $veh_tariffs[$key]['vehicle_model_name'] = $val['vehicle_model_name'];
                    $vehicle_basic_tariffs = $Enquiry_model->getTourtravelbasic(1,$val['vehicle_type_id']);  
                    $max_km_day = $vehicle_basic_tariffs[0]['tour_travel_max_km'];
                    $extra_km_rate = $vehicle_basic_tariffs[0]['extra_km_rate'];
                  
                    foreach ($period as $date) {
                        $v_tour_date = $date->format('Y-m-d'); 
                        $vehicle_basic_tariffs = $Enquiry_model->getTourtravelbasic(1,$val['vehicle_type_id']);
                        $v_season_tariff = $Enquiry_model->checkVehicleSeasonExist($v_tour_date,$veh_object_id);
                      
                        if(!empty($v_season_tariff)){
                            $vehicle_season_tariffs = $Enquiry_model->getTourtravelseason(2,$v_season_tariff[0]['season_id'],$val['vehicle_type_id']);
                            $rate_per_day = $rate_per_day + $vehicle_season_tariffs[0]['rate_per_day'];
                            $extra_km_rate = $vehicle_season_tariffs[0]['extra_km_rate'];
                            $km_rate = $vehicle_season_tariffs[0]['km_rate'];
                        }
                        else{
                            $vehicle_tariffs = $Enquiry_model->getTourtravelbasic(1,$val['vehicle_type_id']);
                            $rate_per_day = $rate_per_day + $vehicle_tariffs[0]['tour_travel_daily_rate'];
                        }
                    } 
                    $veh_tariffs[$key]['rate_per_day'] = $rate_per_day/$no_of_night;
                    $veh_tariffs[$key]['max_km_day'] = $max_km_day;
                    $veh_tariffs[$key]['extra_km_rate'] = $extra_km_rate;
                }
            }  
            $tariff_det['vehicles']=$veh_tariffs;
            $tariff_det['total_distance']=$total_distance;
            $tariff_det['dist1']=$dist1;
            $tariff_det['dist2']=$dist2;
            $tariff_det['dist3']=$dist3;
            $tariff_det['dist4']=$dist4;
            $tariff_det['distance_type']=$distance_type;
            echo json_encode($tariff_det);
        }
        else{
            return redirect()->to('Login');
        }
    }

    public function itinerary($object_id,$final_save_flag,$edit_id = null,$iti_edit_id = null,$extension_ref_id = null)
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $Dashboard_model = new Dashboard_m();
            $system_name = session('system_name');
            $markups = $Enquiry_model->get_markup_details($system_name);
            if(!empty( $markups)){
                $mark_up = $markups[0]['mark_up'];
            }
            else{
                $mark_up = 0;
            }
            $tariff_details_iti = [];
            $tour_plan_tariff = [];
            $tour_plan_det = [];
            $itinerary_details = [];
            $itinerary_details_draft = [];
            $itinerary_details_save = [];
            $edit_history = [];
            $all_edit_history = [];
            if($edit_id > 0){
                $enq_ext_ids = $Enquiry_model->get_enquiry_extensions_byid($edit_id);
                $extension_ref_id_temp = $enq_ext_ids[0]['extension_ref_id'];
            }
            else{
                $extension_ref_id_temp = 0;
            }
            $object_det = $Enquiry_model->get_object_details($object_id);
            if($edit_id > 0 && $extension_ref_id !== null && (int)$extension_ref_id === 0){
                $enq_ext_ids = $Enquiry_model->get_enquiry_extensions_byid($edit_id);
                if(!empty($enq_ext_ids)){
                    $make_current = $this->make_current_function($object_det[0]['enquiry_header_id'],$enq_ext_ids[0]['enquiry_ref_id'],$enq_ext_ids[0]['tour_plan_ref_id'],$enq_ext_ids[0]['extension_ref_id']);
                    $enquiry_details_id_new = $enq_ext_ids[0]['enquiry_ref_id'];
                    $extension_ref_id_temp = $enq_ext_ids[0]['extension_ref_id'];
                }
                else{
                    $enquiry_details_id_new = $object_det[0]['enquiry_details_id'];
                }
                $iti_cost_datas = $Enquiry_model->get_iti_cost_byid($edit_id);
            }
            else{
                $enquiry_details_id_new = $object_det[0]['enquiry_details_id'];
                $iti_cost_datas = $Enquiry_model->get_iti_cost_active($object_det[0]['enquiry_header_id'],$object_det[0]['enquiry_details_id']);
            }

            $tour_plan_det = $Enquiry_model->get_tour_plan_details($object_det[0]['enquiry_header_id'],$enquiry_details_id_new);
            $iti_cost_datas_all = $Enquiry_model->get_iti_cost_all($object_det[0]['enquiry_header_id'],$enquiry_details_id_new);
            foreach($tour_plan_det as $keys => $vals){
                $tid = $vals['tour_details_id'];
                $tour_plan_tariff[$tid] = $Enquiry_model->get_tour_plan_tariff_bydate($vals['tour_details_id']);
                $result1 = $Enquiry_model->get_itinerary_draft_details($object_det[0]['enquiry_header_id'],$enquiry_details_id_new,$vals['tour_details_id']);
                $result2 = $Enquiry_model->get_itinerary_save_details($object_det[0]['enquiry_header_id'],$enquiry_details_id_new,$vals['tour_details_id']);
                if (!empty($result1)) {
                    $itinerary_details_draft = [...$itinerary_details_draft, ...$result1];
                }
                if (!empty($result2)) {
                    $itinerary_details_save = [...$itinerary_details_save, ...$result2];
                }
                $checkindate = $vals['check_in_date'];
                $checkoutdate = $vals['check_out_date'];

                $start1 = new DateTime($checkindate);
                $end1 = new DateTime($checkoutdate);
                for ($date = clone $start1; $date < $end1; $date->modify('+1 day')) {
                    $tour_date = $date->format('Y-m-d');
                    $tariff_details_iti[] = $this->getTourTariffDetailsbyTourDetails($tour_date,$vals['hotel_id'],$vals['room_category_id'],$vals['meal_plan_id'],$object_det[0]['no_of_double_room'],$object_det[0]['no_of_single_room']);
                    /*if($iti_edit_id > 0){
                        $edit_history[$tour_date] = $Enquiry_model->get_edit_history($object_det[0]['enquiry_header_id'],$enquiry_details_id_new,$vals['tour_details_id'],$tour_date);
                        
                    }*/
                }

            }
            $all_edit_history = $Enquiry_model->get_all_edit_history($object_det[0]['enquiry_header_id']);
            $data['edit_history'] = $all_edit_history; 

            /*if(!empty($iti_cost_datas_all) && $edit_id == null){
                $object_class_id = 10; 
                $entity_id = session('user_id');
                $active_role = session('active_role');
                $all_systems = $Dashboard_model->get_all_systems($entity_id);
                $data['all_systems'] = $all_systems;
                $all_roles = $Dashboard_model->get_all_entity_roles($entity_id);
                if(!empty($all_roles)){
                    $data['all_roles_assn'] = $all_roles;
                    $all_menus = $Dashboard_model->get_all_role_menus($active_role);
                    if(!empty($all_menus)){
                        $data['all_menus'] = $all_menus;
                    }
                    else{
                        $data['all_menus'] = [];
                    }
                    $all_permissions = $Dashboard_model->get_all_entity_permissions($active_role,3);
                    if(!empty($all_permissions)){
                        $data['all_permissions'] = $all_permissions;
                    }
                    else{
                        $data['all_permissions'] = [];
                    }
                }
                else{
                    $data['all_roles_assn'] = [];
                    $data['all_menus'] = [];
                    $data['all_permissions'] = [];
                }
                $enterprise_id = 1;
                $object_type_id = 5;
                $parent_menu = $Dashboard_model->get_parent_menus();
                $sub_menu = $Dashboard_model->get_sub_menus();
                $data['parent_menu'] = $parent_menu;
                $data['sub_menu'] = $sub_menu;
                $data['object_class_id'] = $object_class_id;
                $data['object_type_id'] = $object_type_id;
                $data['enquiry_header_id'] = $object_det[0]['enquiry_header_id'];
                $data['enquiry_details_id'] = $enquiry_details_id_new;
                $data['object_det'] = $object_det;
                if(!empty($object_class_det)){
                    $data['object_class_name'] = $object_class_det[0]['object_class_name'];
                }
                else{
                    $data['object_class_name'] = null;
                }
                return view('enquiry/itinerary_details_view',$data);
            }
            else{*/
                $tour_start_date = $object_det[0]['date_of_tour_start_temp'];
                $today = date('Y-m-d');
                if (empty($tour_plan_det)) {
                    session()->setFlashdata('error', 'Tour plan is not created!');
                    return redirect()->to('Enquiry/enquiry_list_view/10');
                }
                else{
                    $quick_quote_det = [];
                    $object_class_id = 10;
                    $entity_id = session('user_id');
                    $active_role = session('active_role');
                    $all_systems = $Dashboard_model->get_all_systems($entity_id);
                    $data['all_systems'] = $all_systems;
                    $all_roles = $Dashboard_model->get_all_entity_roles($entity_id);
                    if(!empty($all_roles)){
                        $data['all_roles_assn'] = $all_roles;
                        $all_menus = $Dashboard_model->get_all_role_menus($active_role);
                        if(!empty($all_menus)){
                            $data['all_menus'] = $all_menus;
                        }
                        else{
                            $data['all_menus'] = [];
                        }
                        $all_permissions = $Dashboard_model->get_all_entity_permissions($active_role,3);
                        if(!empty($all_permissions)){
                            $data['all_permissions'] = $all_permissions;
                        }
                        else{
                            $data['all_permissions'] = [];
                        }
                    }
                    else{
                        $data['all_roles_assn'] = [];
                        $data['all_menus'] = [];
                        $data['all_permissions'] = [];
                    }
                
                        $object_transport_name = '';
                        $tour_travel_daily_rate_exist = '';
                        $tour_travel_max_km_exist = '';
                        $extra_km_rate_exist = '';

                        $local_travel_daily_rate_exist = '';
                        $local_travel_max_km_exist = '';
                        $registration_no_exist = '';

                        $is_tour_travel_exist = 1;
                        $is_local_travel_exist = 1;
                        $is_active_exist = 1;

                        $hub_exist = '';
                        $mod_exist = '';
                        $seat_exist = '';
                        $obj_name = '';
                        $obj_loc = '';
                        $obj_mobile = [];
                        $obj_email = [];
                        $obj_address = [];
                
                    
                    $all_locations = $Enquiry_model->get_tour_locations();
                    $arrival_locations = $Dashboard_model->get_arrival_locations();
                    $departure_locations = $Dashboard_model->get_departure_locations();
                    $hotel_categories = $Dashboard_model->get_hotel_categories();
                    $all_hotels = $Enquiry_model->get_all_hotels();
                    $all_room_categories = $Enquiry_model->get_all_room_categories();
                    $meal_plans = $Dashboard_model->get_meal_plan();
                    $hub_loc = $Dashboard_model->get_hub_location();
                    $enterprise_id = 1;
                    //$attributes = $Dashboard_model->get_all_obj_attributes($object_class_id);
                    //$boolean_attributes = $Dashboard_model->get_obj_boolean_attributes($object_class_id);
                    
                    $object_type_id = 5;
                    $parent_menu = $Dashboard_model->get_parent_menus();
                    $sub_menu = $Dashboard_model->get_sub_menus();
                    $data['parent_menu'] = $parent_menu;
                    $data['sub_menu'] = $sub_menu;
                    $data['object_class_id'] = $object_class_id;
                    $data['object_type_id'] = $object_type_id;
                    if(!empty($object_class_det)){
                        $data['object_class_name'] = $object_class_det[0]['object_class_name'];
                    }
                    else{
                        $data['object_class_name'] = null;
                    }
                    $data['states'] = $Enquiry_model->indian_states();
                    $data['all_agents'] = $Enquiry_model->get_all_agents();
                    
                    $data['tour_plan_det'] = $tour_plan_det;
                    $tour_plan_draft_det = $Enquiry_model->get_tour_plan_draft_details($object_det[0]['enquiry_header_id'],$enquiry_details_id_new);
                    $data['tour_plan_draft_det'] = $tour_plan_draft_det;

                    if($object_det[0]['is_quick_quote'] && !empty($tour_plan_det)){
                        $quick_quote_det = $Enquiry_model->get_quick_quote_details($object_det[0]['enquiry_header_id'],$enquiry_details_id_new,$tour_plan_det[0]['tour_details_id']);
                    
                    }
                
                    $data['quick_quote_det'] = $quick_quote_det;
                    $data['all_locations'] = $all_locations;
                    $data['arrival_locations'] = $arrival_locations;
                    $data['departure_locations'] = $departure_locations;
                    $data['hotel_categories'] = $hotel_categories;
                    $data['all_hotels'] = $all_hotels;
                    $data['all_room_categories'] = $all_room_categories;
                    $data['meal_plans'] = $meal_plans;
                    $data['hub_loc'] = $hub_loc;
                    $data['enterprise_id'] = $enterprise_id;
                    $data['object_det'] = $object_det;
                    $data['obj_name'] = $obj_name;
                    $data['obj_loc'] = $obj_loc;
                    $data['object_id'] = $object_id;
                    $data['tour_plan_tariff'] = $tour_plan_tariff;
                    $data['itinerary_details_draft'] = $itinerary_details_draft;
                    $data['itinerary_details_save'] = $itinerary_details_save;
                    $data['tariff_details_iti'] = $tariff_details_iti;
                    $data['iti_cost_datas'] = $iti_cost_datas;
                    $data['edit_id'] = $edit_id;
                    if(!empty($edit_id)){
                        if((int)$iti_edit_id === 0){
                            $iti_edit_id_temp = 1;
                            $version_count = null;
                        }
                        else{
                            $iti_edit_id_temp = null;
                            $version_count = $iti_edit_id;
                        }
                    }
                    else{
                        $iti_edit_id_temp = null;
                        $version_count = null;
                    }

                    if(!empty($iti_cost_datas_all) && $edit_id == null){
                        $iti_edit_id_temp = 1;
                        $extension_disable = 1;
                    }
                    else{
                        $extension_disable = 0;
                    }
                    $total_extra_klm_cost = 0;
                    $data['total_extra_klm_cost'] = $total_extra_klm_cost;
                    $data['iti_edit_id'] = $iti_edit_id_temp;
                    $data['version_count'] = $version_count;
                    $data['mark_up'] = $mark_up;
                    $data['final_save_flag'] = $final_save_flag;
                    $data['extension_ref_id'] = $extension_ref_id;
                    $data['extension_disable'] = $extension_disable;
                    $data['extension_ref_id_temp'] = $extension_ref_id_temp;
                    $data['tour_plan_ref_id'] = $tour_plan_det[0]['extension_ref_id'];
                    return view('enquiry/itinerary_view',$data);
                }
            //}
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function make_current_function($enquiry_header_id,$enquiry_ref_id,$tour_plan_ref_id,$extension_ref_id){
        $Enquiry_model = new Enquiry_m();
        date_default_timezone_set('Asia/Kolkata');
        $updated_time = date('Y-m-d H:i:s');
        /****Enquiry Details */
        $ed_clear_data = array(
            'is_active' => 0
        );
        $ed_clear = $Enquiry_model->enquiry_details_clear_status($ed_clear_data,$enquiry_header_id);
        if($ed_clear){
            $ed_mc_data = array(
                'created_date' => $updated_time,
                'is_active' => 1
            );
            $ed_mc = $Enquiry_model->enquiry_details_mc_status($ed_mc_data,$enquiry_header_id,$enquiry_ref_id);
        }

        /****Tour Plan */

        $tp_clear_data = array(
            'is_active' => 0,
            'is_draft' => 0
        );
        $tp_clear = $Enquiry_model->tour_plan_clear_status($tp_clear_data,$enquiry_header_id);
        if($tp_clear){
            $tp_mc_data = array(
                'updated_time' => $updated_time,
                'is_active' => 1,
                'is_draft' => 0
            );
            $tp_mc = $Enquiry_model->tour_plan_mc_status($tp_mc_data,$enquiry_header_id,$tour_plan_ref_id);
        }
       
        /****Itinerary Details */

        $iti_clear_data = array(
            'is_active' => 0,
            'is_draft' => 0
        );
        $iti_clear = $Enquiry_model->itinerary_clear_status($iti_clear_data,$enquiry_header_id);
        if($iti_clear){
            $iti_mc_data = array(
                'updated_time' => $updated_time,
                'is_active' => 1,
                'is_draft' => 1
            );
            $iti_mc = $Enquiry_model->itinerary_mc_status($iti_mc_data,$enquiry_header_id,$extension_ref_id);
            if($iti_mc){
                return $iti_mc;
            }
        }

    }

    public function saveItinerary()
    {
        if (!empty(session()->get('user_id'))) {
            $Dashboard_model = new Dashboard_m();
            $Enquiry_model = new Enquiry_m();
            $final_save_flag = 0;
            date_default_timezone_set('Asia/Kolkata');
            $updated_time = date('Y-m-d H:i:s');
            $sdate = date('Y-m-d');
            $system_id = session('system_id');
            $user_id = session('user_id');
            $is_edit = $this->request->getPost('is_edit');
            $version_count = $this->request->getPost('version_count');
            $edit_id = $this->request->getPost('edit_id');
            $object_id = $this->request->getPost('object_id');
            $tour_plan_ref_id = $this->request->getPost('tour_plan_ref_id');
            $extension_ref_id_temp = $this->request->getPost('extension_ref_id_temp');
            $submit_type = $this->request->getPost('submit_type');
            $enquiry_header_id = $this->request->getPost('enquiry_header_id');
            $enquiry_details_id = $this->request->getPost('enquiry_details_id');
            $no_of_double_room = $this->request->getPost('no_of_double_room');
            $no_of_single_room = $this->request->getPost('no_of_single_room');
            $is_quick_quote = $this->request->getPost('is_quick_quote');
            $hotel_additi = $this->request->getPost('hotel_additi');
            $h_no_of_night = $this->request->getPost('h_no_of_night');
            
            if($is_edit == 1){
                $version_count_all = $Enquiry_model->get_all_itinerary_version_count($enquiry_header_id);
            }
            else{
                $version_count_all = 0;
            }
            if(!empty($hotel_additi)){
                foreach ($hotel_additi as $hkey => $hval) {
                    $hotel_names =  $Enquiry_model->get_hotel_name_byid($hval['hotelid']);
                    if(!empty($hotel_names)){
                        $add_hotel_name = $hotel_names[0]['object_name'];
                    }
                    else{
                        $add_hotel_name = '';
                    }
                    $rc_names =  $Enquiry_model->get_rc_name_byid($hval['roomcat']);
                    if(!empty($rc_names)){
                        $add_rc_name = $rc_names[0]['room_category_name'];
                    }
                    else{
                        $add_rc_name = '';
                    }
                    $json_hdata[] = [
                        "id" => $hval['id'],
                        "sequence" => $hval['sequence'],
                        "idvalue" => $hval['idvalue'],
                        "own_arrange" => $hval['own_arrange'],
                        "tour_date" => $hval['tour_date'],
                        "tour_location_id" => $hval['tour_location_id'],
                        "meal_plan_id" => $hval['meal_plan_id'],
                        "no_of_ch" => $hval['no_of_ch'],
                        "no_of_cw" => $hval['no_of_cw'],
                        "no_of_extra" => $hval['no_of_extra'],
                        "hotelid" => $hval['hotelid'],
                        "hotel_name" => $add_hotel_name,
                        "room_category_name" => $add_rc_name,
                        "roomcat" => $hval['roomcat'],
                        "hotfac" => $hval['hotfac'],
                        "fac_rate" => $hval['fac_rate'],
                        "total" => $hval['acc_total'],
                        "double" => $hval['double'],
                        "d_adult_rate" => $hval['d_adult_rate'],
                        "d_child_rate" => $hval['d_child_rate'],
                        "d_child_wb_rate" => $hval['d_child_wb_rate'],
                        "d_extra_bed_rate" => $hval['d_extra_bed_rate'],
                        "single" => $hval['single'],
                        "s_adult_rate" => $hval['s_adult_rate'],
                        "s_child_rate" => $hval['s_child_rate'],
                        "s_child_wb_rate" => $hval['s_child_wb_rate'],
                        "s_extra_bed_rate" => $hval['s_extra_bed_rate'],
                        "remarks" => $hval['remarks'] ?? ""
                    ];
                }
                $json_hotels = json_encode($json_hdata, JSON_PRETTY_PRINT);
            }
            else{
                $json_hotels = json_encode([]);
            }
          
            $additi = $this->request->getPost('additi'); //print_r($additi);exit;
   
                if(!empty($additi)){

                   $temp_rows       = [];          
                   $vehicle_totals  = []; 

                    if($submit_type == "draft"){
                        
                        if($is_edit == 1){
                            $sURL = site_url('Enquiry/itinerary/'.$object_id.'/'.$final_save_flag.'/'.$edit_id.'/'.$version_count);
                        }
                        else{
                            $sURL = site_url('Enquiry/itinerary/'.$object_id.'/'.$final_save_flag);
                        }

                        foreach ($additi as $key =>$item) {
                           $tour_exist = $Enquiry_model->check_tour_date_exist($enquiry_header_id,$enquiry_details_id,$item['tour_details_id'],$item['tour_date']);
                           if($tour_exist > 0){
                                $json_data = [];
                                $rt_data = [];
                                if (!empty(array_filter($item['veh_model'] ?? []))) {
                                    foreach ($item['veh_model'] as $index => $model_raw) {

                                        $veh_type_id      = $item['veh_type_id'][$index];
                                        $model_name       = trim($model_raw);
                                        $max_km_day       = (float) ($item['max_km_day'][$index] ?? 0);
                                        $travel_distance  = (float) ($item['travel_distance'][$index] ?? 0);
                                        $extra_km_rate    = (float) ($item['extra_km_rate'][$index] ?? 0);
                                        $extra_kilometer  = $travel_distance > $max_km_day
                                                        ? $travel_distance - $max_km_day
                                                        : 0;

                                        $extra_cost       = $extra_kilometer * $extra_km_rate;
                                       
                                        if (!isset($vehicle_totals[$veh_type_id])) {
                                            $vehicle_totals[$veh_type_id] = [
                                                'total_max_km_day'      => 0,
                                                'total_travel_distance' => 0,
                                                'total_extra_kilometer' => 0,
                                                'total_extra_cost'      => 0,
                                            ];
                                        }

                                        $vehicle_totals[$veh_type_id]['total_max_km_day']      += $max_km_day;
                                        $vehicle_totals[$veh_type_id]['total_travel_distance'] += $travel_distance;
                                        $vehicle_totals[$veh_type_id]['total_extra_kilometer'] += $extra_kilometer;
                                        $vehicle_totals[$veh_type_id]['total_extra_cost']      += $extra_cost;

                                        $temp_rows[] = [
                                            "vehicle_model" => $model_name,
                                            "veh_type_id" => $item['veh_type_id'][$index],
                                            "tour_date" => $item['v_tour_date'][$index],
                                            "day_rent" => $item['day_rent'][$index],
                                            "max_km_day" => $item['max_km_day'][$index],
                                            "extra_km_rate" => $item['extra_km_rate_hidden'][$index],
                                            "travel_distance" => $item['travel_distance'][$index],
                                            "extra_kilometer" => $item['extra_kilometer'][$index],
                                            "veh_total" => $item['veh_total'][$index],
                                            'veh_header' => $item['veh_header'],
                                            'chk_vehicle' => $item['chk_vehicle_value'][$index],
                                            'chk_vehicle_status' => $item['chk_vehicle_hidden'][$index]
                                        ];
                                    }
                                }
                                foreach ($temp_rows as $row) {
                                    $id = $row['veh_type_id'];
                                    $totals = $vehicle_totals[$id];

                                    $total_max_km_day      = $totals['total_max_km_day'];
                                    $total_travel_distance = round($totals['total_travel_distance'], 2);
                                    $total_extra_kilometer = max(0, $total_travel_distance - $total_max_km_day);
                                    $total_extra_cost      = round($total_extra_kilometer * $row['extra_km_rate'], 2);

                                    $row['total_max_km_day']      = $total_max_km_day;
                                    $row['total_travel_distance'] = $total_travel_distance;
                                    $row['total_extra_kilometer'] = round($total_extra_kilometer, 2);
                                    $row['total_extra_cost']      = $total_extra_cost;

                                    $json_data[] = $row;
                                }
                                $json_output = json_encode($json_data, JSON_PRETTY_PRINT);

                                $rt_data[] = [
                                    "double" => $no_of_double_room,
                                    "single" => $no_of_single_room
                                ];
                                $rt_json = json_encode($rt_data, JSON_PRETTY_PRINT);
                            
                                $iti_data_update = array(
                                    'hotel_id' => $item['hotelid'],
                                    'room_category_id' => $item['roomcat'],
                                    'child_with_bed' => $item['no_of_ch'],
                                    'child_without_bed' => $item['no_of_cw'],
                                    'extra_bed' => $item['no_of_extra'],
                                    'double_room' => $item['double'],
                                    'single_room' => $item['single'],
                                    'vehicle_details' => $json_output,
                                    'hotel_details' => $json_hotels,
                                    'special_event_name' => $item['spcl_event'],
                                    'remarks' => $item['remarks'],
                                    'updated_time' => $updated_time,
                                    'edit_version' => 1
                                );
                                $iti_updated = $Enquiry_model->update_iti_details($iti_data_update,$enquiry_header_id,$enquiry_details_id,$item['tour_details_id'],$item['tour_date']);
                                $iti_details_ids = $Enquiry_model->get_itinerary_details_id($enquiry_header_id,$enquiry_details_id,$item['tour_details_id'],$item['tour_date']);
                                $itinerary_details_id = $iti_details_ids[0]['itinerary_details_id'];
                                if($iti_updated){
                                    //if($is_quick_quote == 1){
                                        $d_room_rate = array(
                                            'tariff' => $item['d_adult_rate']
                                        );
                                        $iti_update = $Enquiry_model->update_iti_cost_details($d_room_rate,$itinerary_details_id,6,2);   
                                        $s_room_rate = array(
                                            'tariff' => $item['s_adult_rate']
                                        );
                                        $iti_update = $Enquiry_model->update_iti_cost_details($s_room_rate,$itinerary_details_id,6,1);   
                                        $d_c_rate = array(
                                            'tariff' => $item['d_child_rate']
                                        );
                                        $iti_update = $Enquiry_model->update_iti_cost_details($d_c_rate,$itinerary_details_id,12,2);   
                                        $s_c_rate = array(
                                            'tariff' => $item['s_child_rate']
                                        );
                                        $iti_update = $Enquiry_model->update_iti_cost_details($s_c_rate,$itinerary_details_id,12,1);   
                                        $d_cw_rate = array(
                                            'tariff' => $item['d_child_wb_rate']
                                        );
                                        $iti_update = $Enquiry_model->update_iti_cost_details($d_cw_rate,$itinerary_details_id,15,2);   
                                        $s_cw_rate = array(
                                            'tariff' => $item['s_child_wb_rate']
                                        );
                                        $iti_update = $Enquiry_model->update_iti_cost_details($s_cw_rate,$itinerary_details_id,15,1);   

                                        $d_e_rate = array(
                                            'tariff' => $item['d_extra_bed_rate']
                                        );
                                        $iti_update = $Enquiry_model->update_iti_cost_details($d_e_rate,$itinerary_details_id,9,2);   
                                        $s_e_rate = array(  
                                            'tariff' => $item['s_extra_bed_rate']
                                        );
                                        $iti_update = $Enquiry_model->update_iti_cost_details($s_e_rate,$itinerary_details_id,9,1);   

                                        $spcl_tariff = array(  
                                            'tariff' => $item['spcl_tariff']
                                        );
                                        $iti_update = $Enquiry_model->update_iti_cost_details($spcl_tariff,$itinerary_details_id,17,1);  
                                        
                                        $hot_fac_id = array(  
                                            'tariff' => $item['hotfac']
                                        );
                                        $iti_update = $Enquiry_model->update_iti_cost_details($hot_fac_id,$itinerary_details_id,18,1);  
                                        $hot_fac_tariff = array(  
                                            'tariff' => $item['fac_rate']
                                        );
                                        $iti_update = $Enquiry_model->update_iti_cost_details($hot_fac_tariff,$itinerary_details_id,19,1);
                                        
                                        $ss_id = array(  
                                            'tariff' => $item['sight']
                                        );
                                        $iti_update = $Enquiry_model->update_iti_cost_details($ss_id,$itinerary_details_id,21,1);
                                        $ss_distance = array(  
                                            'tariff' => $item['ss_distance']
                                        );
                                        $iti_update = $Enquiry_model->update_iti_cost_details($ss_distance,$itinerary_details_id,22,1);
                                        
                                        $daily_addon = array(  
                                            'tariff' => $item['daily_addon']
                                        );
                                        $iti_update = $Enquiry_model->update_iti_cost_details($daily_addon,$itinerary_details_id,23,1);
                                    //}
                                }
                           }
                           else{
                                $json_data = [];
                                $rt_data = [];
                              
                                if (!empty(array_filter($item['veh_model'] ?? []))) {
                                    foreach ($item['veh_model'] as $index => $model_raw) {

                                        $veh_type_id      = $item['veh_type_id'][$index];
                                        $model_name       = trim($model_raw);
                                        $max_km_day       = (float) ($item['max_km_day'][$index] ?? 0);
                                        $travel_distance  = (float) ($item['travel_distance'][$index] ?? 0);
                                        $extra_km_rate    = (float) ($item['extra_km_rate'][$index] ?? 0);
                                        $extra_kilometer  = $travel_distance > $max_km_day
                                                        ? $travel_distance - $max_km_day
                                                        : 0;

                                        $extra_cost       = $extra_kilometer * $extra_km_rate;
                                       
                                        if (!isset($vehicle_totals[$veh_type_id])) {
                                            $vehicle_totals[$veh_type_id] = [
                                                'total_max_km_day'      => 0,
                                                'total_travel_distance' => 0,
                                                'total_extra_kilometer' => 0,
                                                'total_extra_cost'      => 0,
                                            ];
                                        }

                                        $vehicle_totals[$veh_type_id]['total_max_km_day']      += $max_km_day;
                                        $vehicle_totals[$veh_type_id]['total_travel_distance'] += $travel_distance;
                                        $vehicle_totals[$veh_type_id]['total_extra_kilometer'] += $extra_kilometer;
                                        $vehicle_totals[$veh_type_id]['total_extra_cost']      += $extra_cost;

                                        $temp_rows[] = [
                                            "vehicle_model" => $model_name,
                                            "veh_type_id" => $item['veh_type_id'][$index],
                                            "tour_date" => $item['v_tour_date'][$index],
                                            "day_rent" => $item['day_rent'][$index],
                                            "max_km_day" => $item['max_km_day'][$index],
                                            "extra_km_rate" => $item['extra_km_rate_hidden'][$index],
                                            "travel_distance" => $item['travel_distance'][$index],
                                            "extra_kilometer" => $item['extra_kilometer'][$index],
                                            "veh_total" => $item['veh_total'][$index],
                                            'veh_header' => $item['veh_header'],
                                            'chk_vehicle' => $item['chk_vehicle_value'][$index],
                                            'chk_vehicle_status' => $item['chk_vehicle_hidden'][$index]
                                        ];
                                    }
                                }
                                foreach ($temp_rows as $row) {
                                    $id = $row['veh_type_id'];
                                    $totals = $vehicle_totals[$id];

                                    $total_max_km_day      = $totals['total_max_km_day'];
                                    $total_travel_distance = round($totals['total_travel_distance'], 2);
                                    $total_extra_kilometer = max(0, $total_travel_distance - $total_max_km_day);
                                    $total_extra_cost      = round($total_extra_kilometer * $row['extra_km_rate'], 2);

                                    $row['total_max_km_day']      = $total_max_km_day;
                                    $row['total_travel_distance'] = $total_travel_distance;
                                    $row['total_extra_kilometer'] = round($total_extra_kilometer, 2);
                                    $row['total_extra_cost']      = $total_extra_cost;

                                    $json_data[] = $row;
                                }
                                $json_output = json_encode($json_data, JSON_PRETTY_PRINT);

                                $rt_data[] = [
                                    "double" => $no_of_double_room,
                                    "single" => $no_of_single_room
                                ];
                                $rt_json = json_encode($rt_data, JSON_PRETTY_PRINT);
                                
                                $iti_data_insert = array(
                                    'enquiry_header_id' => $enquiry_header_id,
                                    'enquiry_details_id' => $enquiry_details_id,
                                    'tour_date' => $item['tour_date'],
                                    'tour_details_id' => $item['tour_details_id'],
                                    'hotel_id' => $item['hotelid'],
                                    'room_category_id' => $item['roomcat'],
                                    'child_with_bed' => $item['no_of_ch'],
                                    'child_without_bed' => $item['no_of_cw'],
                                    'extra_bed' => $item['no_of_extra'],
                                    'double_room' => $item['double'],
                                    'single_room' => $item['single'],
                                    'vehicle_details' => $json_output,
                                    'hotel_details' => $json_hotels,
                                    'special_event_name' => $item['spcl_event'],
                                    'remarks' => $item['remarks'],
                                    'is_active' => 1,
                                    'is_draft' => 0,
                                    'updated_time' => $updated_time,
                                    'edit_version' => 1,
                                    'tour_plan_ref_id' => $tour_plan_ref_id,
                                    'extension_ref_id' => 0,
                                    'enterprise_id' => 1
                                );
                                $itinerary_details_id = $Enquiry_model->insert_iti_details($iti_data_insert);  
                                //if($is_quick_quote == 1){
                                    if($itinerary_details_id){
                                        $d_room_rate = array(
                                            'itinerary_details_id' => $itinerary_details_id,
                                            'cost_component_id' => 6,
                                            'room_type_id' => 2,
                                            'tariff' => $item['d_adult_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $iti_insert = $Enquiry_model->insert_iti_cost_details($d_room_rate);   
                                        $s_room_rate = array(
                                            'itinerary_details_id' => $itinerary_details_id,
                                            'cost_component_id' => 6,
                                            'room_type_id' => 1,
                                            'tariff' => $item['s_adult_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $iti_insert = $Enquiry_model->insert_iti_cost_details($s_room_rate);   

                                        $d_c_rate = array(
                                            'itinerary_details_id' => $itinerary_details_id,
                                            'cost_component_id' => 12,
                                            'room_type_id' => 2,
                                            'tariff' => $item['d_child_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $iti_insert = $Enquiry_model->insert_iti_cost_details($d_c_rate);   
                                        $s_c_rate = array(
                                            'itinerary_details_id' => $itinerary_details_id,
                                            'cost_component_id' => 12,
                                            'room_type_id' => 1,
                                            'tariff' => $item['s_child_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $iti_insert = $Enquiry_model->insert_iti_cost_details($s_c_rate);   

                                        $d_cw_rate = array(
                                            'itinerary_details_id' => $itinerary_details_id,
                                            'cost_component_id' => 15,
                                            'room_type_id' => 2,
                                            'tariff' => $item['d_child_wb_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $iti_insert = $Enquiry_model->insert_iti_cost_details($d_cw_rate);   
                                        $s_cw_rate = array(
                                            'itinerary_details_id' => $itinerary_details_id,
                                            'cost_component_id' => 15,
                                            'room_type_id' => 1,
                                            'tariff' => $item['s_child_wb_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $iti_insert = $Enquiry_model->insert_iti_cost_details($s_cw_rate);   

                                        $d_e_rate = array(
                                            'itinerary_details_id' => $itinerary_details_id,
                                            'cost_component_id' => 9,
                                            'room_type_id' => 2,
                                            'tariff' => $item['d_extra_bed_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $iti_insert = $Enquiry_model->insert_iti_cost_details($d_e_rate);   
                                        $s_e_rate = array(
                                            'itinerary_details_id' => $itinerary_details_id,
                                            'cost_component_id' => 9,
                                            'room_type_id' => 1,
                                            'tariff' => $item['s_extra_bed_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $iti_insert = $Enquiry_model->insert_iti_cost_details($s_e_rate);   



                                        $spcl_tariff = array(
                                            'itinerary_details_id' => $itinerary_details_id,
                                            'cost_component_id' => 17,
                                            'room_type_id' => 1,
                                            'tariff' => $item['spcl_tariff'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $iti_insert = $Enquiry_model->insert_iti_cost_details($spcl_tariff);   
                                        $hotfac = array(
                                            'itinerary_details_id' => $itinerary_details_id,
                                            'cost_component_id' => 18,
                                            'room_type_id' => 1,
                                            'tariff' => $item['hotfac'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $iti_insert = $Enquiry_model->insert_iti_cost_details($hotfac);   
                                        $fac_rate = array(
                                            'itinerary_details_id' => $itinerary_details_id,
                                            'cost_component_id' => 19,
                                            'room_type_id' => 1,
                                            'tariff' => $item['fac_rate'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $iti_insert = $Enquiry_model->insert_iti_cost_details($fac_rate);   
                                        $sight = array(
                                            'itinerary_details_id' => $itinerary_details_id,
                                            'cost_component_id' => 21,
                                            'room_type_id' => 1,
                                            'tariff' => $item['sight'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $iti_insert = $Enquiry_model->insert_iti_cost_details($sight);   
                                        $ss_distance = array(
                                            'itinerary_details_id' => $itinerary_details_id,
                                            'cost_component_id' => 22,
                                            'room_type_id' => 1,
                                            'tariff' => $item['ss_distance'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $iti_insert = $Enquiry_model->insert_iti_cost_details($ss_distance);   
                                        $daily_addon = array(
                                            'itinerary_details_id' => $itinerary_details_id,
                                            'cost_component_id' => 23,
                                            'room_type_id' => 1,
                                            'tariff' => $item['daily_addon'],
                                            'is_active' => 1,
                                            'is_draft' => 0,
                                            'enterprise_id' => 1
                                        );
                                        $iti_insert = $Enquiry_model->insert_iti_cost_details($daily_addon);   
                                    }
                                //}
                           }
                        } 
                    
                    return redirect()->to($sURL);
                }


                if($submit_type == "final"){
                    $final_save_flag = 1;

                    if($is_edit == 1){
                        $sURL = site_url('Enquiry/itinerary/'.$object_id.'/'.$final_save_flag.'/'.$edit_id.'/'.$version_count);
                    }
                    else{
                        $sURL = site_url('Enquiry/itinerary/'.$object_id.'/'.$final_save_flag);
                    }

                    foreach ($additi as $key =>$item) {
                        $tour_exist = $Enquiry_model->check_tour_date_exist($enquiry_header_id,$enquiry_details_id,$item['tour_details_id'],$item['tour_date']);
                       if($tour_exist > 0){
                            $json_data = [];
                            $rt_data = [];
                            if (!empty(array_filter($item['veh_model'] ?? []))) {
                                foreach ($item['veh_model'] as $index => $model_raw) {
                                    $veh_type_id      = $item['veh_type_id'][$index];
                                        $model_name       = trim($model_raw);
                                        $max_km_day       = (float) ($item['max_km_day'][$index] ?? 0);
                                        $travel_distance  = (float) ($item['travel_distance'][$index] ?? 0);
                                        $extra_km_rate    = (float) ($item['extra_km_rate'][$index] ?? 0);
                                        $extra_kilometer  = $travel_distance > $max_km_day
                                                        ? $travel_distance - $max_km_day
                                                        : 0;

                                        $extra_cost       = $extra_kilometer * $extra_km_rate;
                                       
                                        if (!isset($vehicle_totals[$veh_type_id])) {
                                            $vehicle_totals[$veh_type_id] = [
                                                'total_max_km_day'      => 0,
                                                'total_travel_distance' => 0,
                                                'total_extra_kilometer' => 0,
                                                'total_extra_cost'      => 0,
                                            ];
                                        }

                                        $vehicle_totals[$veh_type_id]['total_max_km_day']      += $max_km_day;
                                        $vehicle_totals[$veh_type_id]['total_travel_distance'] += $travel_distance;
                                        $vehicle_totals[$veh_type_id]['total_extra_kilometer'] += $extra_kilometer;
                                        $vehicle_totals[$veh_type_id]['total_extra_cost']      += $extra_cost;

                                    $temp_rows[] = [
                                        "vehicle_model" => $model_name,
                                        "veh_type_id" => $item['veh_type_id'][$index],
                                        "tour_date" => $item['v_tour_date'][$index],
                                        "day_rent" => $item['day_rent'][$index],
                                        "max_km_day" => $item['max_km_day'][$index],
                                        "extra_km_rate" => $item['extra_km_rate_hidden'][$index],
                                        "travel_distance" => $item['travel_distance'][$index],
                                        "extra_kilometer" => $item['extra_kilometer'][$index],
                                        "veh_total" => $item['veh_total'][$index],
                                        'veh_header' => $item['veh_header'],
                                        'chk_vehicle' => $item['chk_vehicle_value'][$index],
                                        'chk_vehicle_status' => $item['chk_vehicle_hidden'][$index]
                                    ];
                                }
                            }
                            foreach ($temp_rows as $row) {
                                    $id = $row['veh_type_id'];
                                    $totals = $vehicle_totals[$id];

                                    $total_max_km_day      = $totals['total_max_km_day'];
                                    $total_travel_distance = round($totals['total_travel_distance'], 2);
                                    $total_extra_kilometer = max(0, $total_travel_distance - $total_max_km_day);
                                    $total_extra_cost      = round($total_extra_kilometer * $row['extra_km_rate'], 2);

                                    $row['total_max_km_day']      = $total_max_km_day;
                                    $row['total_travel_distance'] = $total_travel_distance;
                                    $row['total_extra_kilometer'] = round($total_extra_kilometer, 2);
                                    $row['total_extra_cost']      = $total_extra_cost;

                                    $json_data[] = $row;
                                }
                            $json_output = json_encode($json_data, JSON_PRETTY_PRINT);

                            $rt_data[] = [
                                "double" => $no_of_double_room,
                                "single" => $no_of_single_room
                            ];
                            $rt_json = json_encode($rt_data, JSON_PRETTY_PRINT);
                        
                            $iti_data_update = array(
                                'hotel_id' => $item['hotelid'],
                                'room_category_id' => $item['roomcat'],
                                'child_with_bed' => $item['no_of_ch'],
                                'child_without_bed' => $item['no_of_cw'],
                                'extra_bed' => $item['no_of_extra'],
                                'double_room' => $item['double'],
                                'single_room' => $item['single'],
                                'vehicle_details' => $json_output,
                                'hotel_details' => $json_hotels,
                                'special_event_name' => $item['spcl_event'],
                                'remarks' => $item['remarks'],
                                'updated_time' => $updated_time,
                                'edit_version' => 1,
                                'is_draft' => 1
                            );
                            
                            $iti_updated = $Enquiry_model->update_iti_details($iti_data_update,$enquiry_header_id,$enquiry_details_id,$item['tour_details_id'],$item['tour_date']);
                            $iti_details_ids = $Enquiry_model->get_itinerary_details_id($enquiry_header_id,$enquiry_details_id,$item['tour_details_id'],$item['tour_date']);
                            $itinerary_details_id = $iti_details_ids[0]['itinerary_details_id'];
                            if($iti_updated){
                                //if($is_quick_quote == 1){
                                    $d_room_rate = array(
                                        'tariff' => $item['d_adult_rate'],
                                        'is_draft' => 1
                                    );
                                    $iti_update = $Enquiry_model->update_iti_cost_details($d_room_rate,$itinerary_details_id,6,2);   
                                    $s_room_rate = array(
                                        'tariff' => $item['s_adult_rate'],
                                        'is_draft' => 1
                                    );
                                    $iti_update = $Enquiry_model->update_iti_cost_details($s_room_rate,$itinerary_details_id,6,1);   
                                    $d_c_rate = array(
                                        'tariff' => $item['d_child_rate'],
                                        'is_draft' => 1
                                    );
                                    $iti_update = $Enquiry_model->update_iti_cost_details($d_c_rate,$itinerary_details_id,12,2);   
                                    $s_c_rate = array(
                                        'tariff' => $item['s_child_rate'],
                                        'is_draft' => 1
                                    );
                                    $iti_update = $Enquiry_model->update_iti_cost_details($s_c_rate,$itinerary_details_id,12,1);   
                                    $d_cw_rate = array(
                                        'tariff' => $item['d_child_wb_rate'],
                                        'is_draft' => 1
                                    );
                                    $iti_update = $Enquiry_model->update_iti_cost_details($d_cw_rate,$itinerary_details_id,15,2);   
                                    $s_cw_rate = array(
                                        'tariff' => $item['s_child_wb_rate'],
                                        'is_draft' => 1
                                    );
                                    $iti_update = $Enquiry_model->update_iti_cost_details($s_cw_rate,$itinerary_details_id,15,1);   

                                    $d_e_rate = array(
                                        'tariff' => $item['d_extra_bed_rate'],
                                        'is_draft' => 1
                                    );
                                    $iti_update = $Enquiry_model->update_iti_cost_details($d_e_rate,$itinerary_details_id,9,2);   
                                    $s_e_rate = array(  
                                        'tariff' => $item['s_extra_bed_rate'],
                                        'is_draft' => 1
                                    );
                                    $iti_update = $Enquiry_model->update_iti_cost_details($s_e_rate,$itinerary_details_id,9,1);   

                                    $spcl_tariff = array(  
                                        'tariff' => $item['spcl_tariff'],
                                        'is_draft' => 1
                                    );
                                    $iti_update = $Enquiry_model->update_iti_cost_details($spcl_tariff,$itinerary_details_id,17,1);  
                                    
                                    $hot_fac_id = array(  
                                        'tariff' => $item['hotfac'],
                                        'is_draft' => 1
                                    );
                                    $iti_update = $Enquiry_model->update_iti_cost_details($hot_fac_id,$itinerary_details_id,18,1);  
                                    $hot_fac_tariff = array(  
                                        'tariff' => $item['fac_rate'],
                                        'is_draft' => 1
                                    );
                                    $iti_update = $Enquiry_model->update_iti_cost_details($hot_fac_tariff,$itinerary_details_id,19,1);
                                    
                                    $ss_id = array(  
                                        'tariff' => $item['sight'],
                                        'is_draft' => 1
                                    );
                                    $iti_update = $Enquiry_model->update_iti_cost_details($ss_id,$itinerary_details_id,21,1);
                                    $ss_distance = array(  
                                        'tariff' => $item['ss_distance'],
                                        'is_draft' => 1
                                    );
                                    $iti_update = $Enquiry_model->update_iti_cost_details($ss_distance,$itinerary_details_id,22,1);
                                    
                                    $daily_addon = array(  
                                        'tariff' => $item['daily_addon'],
                                        'is_draft' => 1
                                    );
                                    $iti_update = $Enquiry_model->update_iti_cost_details($daily_addon,$itinerary_details_id,23,1);
                                //}
                            }
                       }
                       else{
                            
                            $json_data = [];
                            $rt_data = [];
                            if (!empty(array_filter($item['veh_model'] ?? []))) {
                                foreach ($item['veh_model'] as $index => $model_raw) {
                                    $veh_type_id      = $item['veh_type_id'][$index];
                                        $model_name       = trim($model_raw);
                                        $max_km_day       = (float) ($item['max_km_day'][$index] ?? 0);
                                        $travel_distance  = (float) ($item['travel_distance'][$index] ?? 0);
                                        $extra_km_rate    = (float) ($item['extra_km_rate'][$index] ?? 0);
                                        $extra_kilometer  = $travel_distance > $max_km_day
                                                        ? $travel_distance - $max_km_day
                                                        : 0;

                                        $extra_cost       = $extra_kilometer * $extra_km_rate;
                                       
                                        if (!isset($vehicle_totals[$veh_type_id])) {
                                            $vehicle_totals[$veh_type_id] = [
                                                'total_max_km_day'      => 0,
                                                'total_travel_distance' => 0,
                                                'total_extra_kilometer' => 0,
                                                'total_extra_cost'      => 0,
                                            ];
                                        }

                                        $vehicle_totals[$veh_type_id]['total_max_km_day']      += $max_km_day;
                                        $vehicle_totals[$veh_type_id]['total_travel_distance'] += $travel_distance;
                                        $vehicle_totals[$veh_type_id]['total_extra_kilometer'] += $extra_kilometer;
                                        $vehicle_totals[$veh_type_id]['total_extra_cost']      += $extra_cost;

                                    $temp_rows[] = [
                                        "vehicle_model" => $model_name,
                                        "veh_type_id" => $item['veh_type_id'][$index],
                                        "tour_date" => $item['v_tour_date'][$index],
                                        "day_rent" => $item['day_rent'][$index],
                                        "max_km_day" => $item['max_km_day'][$index],
                                        "extra_km_rate" => $item['extra_km_rate_hidden'][$index],
                                        "travel_distance" => $item['travel_distance'][$index],
                                        "extra_kilometer" => $item['extra_kilometer'][$index],
                                        "veh_total" => $item['veh_total'][$index],
                                        'veh_header' => $item['veh_header'],
                                        'chk_vehicle' => $item['chk_vehicle_value'][$index],
                                        'chk_vehicle_status' => $item['chk_vehicle_hidden'][$index]
                                    ];
                                }
                            }
                            foreach ($temp_rows as $row) {
                                    $id = $row['veh_type_id'];
                                    $totals = $vehicle_totals[$id];

                                    $total_max_km_day      = $totals['total_max_km_day'];
                                    $total_travel_distance = round($totals['total_travel_distance'], 2);
                                    $total_extra_kilometer = max(0, $total_travel_distance - $total_max_km_day);
                                    $total_extra_cost      = round($total_extra_kilometer * $row['extra_km_rate'], 2);

                                    $row['total_max_km_day']      = $total_max_km_day;
                                    $row['total_travel_distance'] = $total_travel_distance;
                                    $row['total_extra_kilometer'] = round($total_extra_kilometer, 2);
                                    $row['total_extra_cost']      = $total_extra_cost;

                                    $json_data[] = $row;
                                }
                            $json_output = json_encode($json_data, JSON_PRETTY_PRINT);

                            $rt_data[] = [
                                "double" => $no_of_double_room,
                                "single" => $no_of_single_room
                            ];
                            $rt_json = json_encode($rt_data, JSON_PRETTY_PRINT);
                            
                            $iti_data_insert = array(
                                'enquiry_header_id' => $enquiry_header_id,
                                'enquiry_details_id' => $enquiry_details_id,
                                'tour_date' => $item['tour_date'],
                                'tour_details_id' => $item['tour_details_id'],
                                'hotel_id' => $item['hotelid'],
                                'room_category_id' => $item['roomcat'],
                                'child_with_bed' => $item['no_of_ch'],
                                'child_without_bed' => $item['no_of_cw'],
                                'extra_bed' => $item['no_of_extra'],
                                'double_room' => $item['double'],
                                'single_room' => $item['single'],
                                'vehicle_details' => $json_output,
                                'hotel_details' => $json_hotels,
                                'special_event_name' => $item['spcl_event'],
                                'remarks' => $item['remarks'],
                                'is_active' => 1,
                                'is_draft' => 1,
                                'updated_time' => $updated_time,
                                'edit_version' => 1,
                                'tour_plan_ref_id' => $tour_plan_ref_id,
                                'extension_ref_id' => 0,
                                'enterprise_id' => 1
                            );
                            $itinerary_details_id = $Enquiry_model->insert_iti_details($iti_data_insert);   
                            //if($is_quick_quote == 1){
                                if($itinerary_details_id){
                                    $d_room_rate = array(
                                        'itinerary_details_id' => $itinerary_details_id,
                                        'cost_component_id' => 6,
                                        'room_type_id' => 2,
                                        'tariff' => $item['d_adult_rate'],
                                        'is_active' => 1,
                                        'is_draft' => 1,
                                        'enterprise_id' => 1
                                    );
                                    $iti_insert = $Enquiry_model->insert_iti_cost_details($d_room_rate);   
                                    $s_room_rate = array(
                                        'itinerary_details_id' => $itinerary_details_id,
                                        'cost_component_id' => 6,
                                        'room_type_id' => 1,
                                        'tariff' => $item['s_adult_rate'],
                                        'is_active' => 1,
                                        'is_draft' => 1,
                                        'enterprise_id' => 1
                                    );
                                    $iti_insert = $Enquiry_model->insert_iti_cost_details($s_room_rate);   

                                    $d_c_rate = array(
                                        'itinerary_details_id' => $itinerary_details_id,
                                        'cost_component_id' => 12,
                                        'room_type_id' => 2,
                                        'tariff' => $item['d_child_rate'],
                                        'is_active' => 1,
                                        'is_draft' => 1,
                                        'enterprise_id' => 1
                                    );
                                    $iti_insert = $Enquiry_model->insert_iti_cost_details($d_c_rate);   
                                    $s_c_rate = array(
                                        'itinerary_details_id' => $itinerary_details_id,
                                        'cost_component_id' => 12,
                                        'room_type_id' => 1,
                                        'tariff' => $item['s_child_rate'],
                                        'is_active' => 1,
                                        'is_draft' => 1,
                                        'enterprise_id' => 1
                                    );
                                    $iti_insert = $Enquiry_model->insert_iti_cost_details($s_c_rate);   

                                    $d_cw_rate = array(
                                        'itinerary_details_id' => $itinerary_details_id,
                                        'cost_component_id' => 15,
                                        'room_type_id' => 2,
                                        'tariff' => $item['d_child_wb_rate'],
                                        'is_active' => 1,
                                        'is_draft' => 1,
                                        'enterprise_id' => 1
                                    );
                                    $iti_insert = $Enquiry_model->insert_iti_cost_details($d_cw_rate);   
                                    $s_cw_rate = array(
                                        'itinerary_details_id' => $itinerary_details_id,
                                        'cost_component_id' => 15,
                                        'room_type_id' => 1,
                                        'tariff' => $item['s_child_wb_rate'],
                                        'is_active' => 1,
                                        'is_draft' => 1,
                                        'enterprise_id' => 1
                                    );
                                    $iti_insert = $Enquiry_model->insert_iti_cost_details($s_cw_rate);   

                                    $d_e_rate = array(
                                        'itinerary_details_id' => $itinerary_details_id,
                                        'cost_component_id' => 9,
                                        'room_type_id' => 2,
                                        'tariff' => $item['d_extra_bed_rate'],
                                        'is_active' => 1,
                                        'is_draft' => 1,
                                        'enterprise_id' => 1
                                    );
                                    $iti_insert = $Enquiry_model->insert_iti_cost_details($d_e_rate);   
                                    $s_e_rate = array(
                                        'itinerary_details_id' => $itinerary_details_id,
                                        'cost_component_id' => 9,
                                        'room_type_id' => 1,
                                        'tariff' => $item['s_extra_bed_rate'],
                                        'is_active' => 1,
                                        'is_draft' => 1,
                                        'enterprise_id' => 1
                                    );
                                    $iti_insert = $Enquiry_model->insert_iti_cost_details($s_e_rate);   



                                    $spcl_tariff = array(
                                        'itinerary_details_id' => $itinerary_details_id,
                                        'cost_component_id' => 17,
                                        'room_type_id' => 1,
                                        'tariff' => $item['spcl_tariff'],
                                        'is_active' => 1,
                                        'is_draft' => 1,
                                        'enterprise_id' => 1
                                    );
                                    $iti_insert = $Enquiry_model->insert_iti_cost_details($spcl_tariff);   
                                    $hotfac = array(
                                        'itinerary_details_id' => $itinerary_details_id,
                                        'cost_component_id' => 18,
                                        'room_type_id' => 1,
                                        'tariff' => $item['hotfac'],
                                        'is_active' => 1,
                                        'is_draft' => 1,
                                        'enterprise_id' => 1
                                    );
                                    $iti_insert = $Enquiry_model->insert_iti_cost_details($hotfac);   
                                    $fac_rate = array(
                                        'itinerary_details_id' => $itinerary_details_id,
                                        'cost_component_id' => 19,
                                        'room_type_id' => 1,
                                        'tariff' => $item['fac_rate'],
                                        'is_active' => 1,
                                        'is_draft' => 1,
                                        'enterprise_id' => 1
                                    );
                                    $iti_insert = $Enquiry_model->insert_iti_cost_details($fac_rate);   
                                    $sight = array(
                                        'itinerary_details_id' => $itinerary_details_id,
                                        'cost_component_id' => 21,
                                        'room_type_id' => 1,
                                        'tariff' => $item['sight'],
                                        'is_active' => 1,
                                        'is_draft' => 1,
                                        'enterprise_id' => 1
                                    );
                                    $iti_insert = $Enquiry_model->insert_iti_cost_details($sight);   
                                    $ss_distance = array(
                                        'itinerary_details_id' => $itinerary_details_id,
                                        'cost_component_id' => 22,
                                        'room_type_id' => 1,
                                        'tariff' => $item['ss_distance'],
                                        'is_active' => 1,
                                        'is_draft' => 1,
                                        'enterprise_id' => 1
                                    );
                                    $iti_insert = $Enquiry_model->insert_iti_cost_details($ss_distance);   
                                    $daily_addon = array(
                                        'itinerary_details_id' => $itinerary_details_id,
                                        'cost_component_id' => 23,
                                        'room_type_id' => 1,
                                        'tariff' => $item['daily_addon'],
                                        'is_active' => 1,
                                        'is_draft' => 1,
                                        'enterprise_id' => 1
                                    );
                                    $iti_insert = $Enquiry_model->insert_iti_cost_details($daily_addon);   
                                }
                            //}
                       }
                    }
                    //if($is_edit == 1){
                        $iti_data_pre = array(
                            'is_active' => 0,
                            'is_draft' => 0,
                        );
                        $iti_updated_pre = $Enquiry_model->update_iti_detailsforedit($iti_data_pre,$enquiry_header_id,$extension_ref_id_temp);
                    //}

                return redirect()->to($sURL);
            }

            }
       
        }
        else{
            return redirect()->to('Login');
        }
    }

    public function getTourTariffDetailsbydate()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            
            $hotel_id = $this->request->getPost('hotel_id');
            $room_cat_id = $this->request->getPost('room_cat_id');
            $mealplan = $this->request->getPost('mealplan');
            $tour_date = $this->request->getPost('tour_date');
            $double = $this->request->getPost('double');
            $single = $this->request->getPost('single');
            $id = $this->request->getPost('id');
            $tour_location_id = $this->request->getPost('tour_location_id');
            $tariff_det = [];
            $object_ids = $Enquiry_model->getObjectidByhotel($hotel_id);
            $object_id = $object_ids[0]['object_id'];

            $d_room_tariff = 0;
            $d_child_tariff = 0;
            $d_child_wb_tariff = 0;
            $d_extra_tariff = 0;

            $s_room_tariff = 0;
            $s_child_tariff = 0;
            $s_child_wb_tariff = 0;
            $s_extra_tariff = 0;

            if($double > 0){
                $room_type = 2;
                    $weekend_tariff = $Enquiry_model->checkWeekendExist($tour_date,$object_id);
                    $season_tariff = $Enquiry_model->checkSeasonExist($tour_date,$object_id);
                    if(!empty($weekend_tariff)){ 
                        $room_tariffs = $Enquiry_model->getTourTariffDetails(7,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan);
                        if(!empty($room_tariffs)){
                            $d_room_tariff = $room_tariffs[0]['tariff'];
                        }
                        else{
                            $d_room_tariff = 0;
                        } 

                        $child_tariffs = $Enquiry_model->getTourTariffDetailsChild(13,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan,1);
                        if(!empty($child_tariffs)){
                            $d_child_tariff = $child_tariffs[0]['tariff'];
                        }
                        else{
                            $d_child_tariff = 0;
                        }

                        $child_wb_tariffs = $Enquiry_model->getTourTariffDetailsChild(16,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan,2);
                        if(!empty($child_wb_tariffs)){
                            $d_child_wb_tariff = $child_wb_tariffs[0]['tariff'];
                        }
                        else{
                            $d_child_wb_tariff = 0;
                        }

                        $extra_tariffs = $Enquiry_model->getTourTariffDetailsChild(10,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan,3);
                        if(!empty($extra_tariffs)){
                            $d_extra_tariff = $extra_tariffs[0]['tariff'];
                        }
                        else{
                            $d_extra_tariff = 0;
                        }
                    }
                    else if(!empty($season_tariff)){  
                        $room_tariffs = $Enquiry_model->getTourTariffDetails(6,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan);
                        if(!empty($room_tariffs)){
                            $d_room_tariff = $room_tariffs[0]['tariff'];
                        }
                        else{
                            $d_room_tariff = 0;
                        }

                        $child_tariffs = $Enquiry_model->getTourTariffDetailsChild(12,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan,1);
                        if(!empty($child_tariffs)){
                            $d_child_tariff = $child_tariffs[0]['tariff'];
                        }
                        else{
                            $d_child_tariff = 0;
                        }

                        $child_wb_tariffs = $Enquiry_model->getTourTariffDetailsChild(15,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan,2);
                        if(!empty($child_wb_tariffs)){
                            $d_child_wb_tariff = $child_wb_tariffs[0]['tariff'];
                        }
                        else{
                            $d_child_wb_tariff = 0;
                        }

                        $extra_tariffs = $Enquiry_model->getTourTariffDetailsChild(9,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan,3);
                        if(!empty($extra_tariffs)){
                            $d_extra_tariff = $extra_tariffs[0]['tariff'];
                        }
                        else{
                            $d_extra_tariff = 0;
                        }
                    }
                    else{
                        $room_tariffs = $Enquiry_model->getTourTariffDetailsBasic(5,$room_cat_id,$room_type,$object_id,$mealplan);
                        if(!empty($room_tariffs)){
                            $d_room_tariff = $d_room_tariff + $room_tariffs[0]['tariff'];
                        }
                        else{
                            $d_room_tariff = 0;
                        }

                        $child_tariffs = $Enquiry_model->getTourTariffDetailsChildBasic(11,$room_cat_id,$room_type,$object_id,$mealplan,1);
                        if(!empty($child_tariffs)){
                            $d_child_tariff = $d_child_tariff + $child_tariffs[0]['exclusive_tariff'];
                        }
                        else{
                            $d_child_tariff = 0;
                        }

                        $child_wb_tariffs = $Enquiry_model->getTourTariffDetailsChildBasic(11,$room_cat_id,$room_type,$object_id,$mealplan,2);
                        if(!empty($child_wb_tariffs)){
                            $d_child_wb_tariff = $d_child_wb_tariff + $child_wb_tariffs[0]['exclusive_tariff'];
                        }
                        else{
                            $d_child_wb_tariff = 0;
                        }

                        $extra_tariffs = $Enquiry_model->getTourTariffDetailsChildBasic(11,$room_cat_id,$room_type,$object_id,$mealplan,3);
                        if(!empty($extra_tariffs)){
                            $d_extra_tariff = $d_extra_tariff + $extra_tariffs[0]['exclusive_tariff'];
                        }
                        else{
                            $d_extra_tariff = 0;
                        }
                    }
            }

            if($single > 0){    
                $room_type = 1;
                    $weekend_tariff = $Enquiry_model->checkWeekendExist($tour_date,$object_id);
                    $season_tariff = $Enquiry_model->checkSeasonExist($tour_date,$object_id);
                    if(!empty($weekend_tariff)){
                        $s_room_tariffs = $Enquiry_model->getTourTariffDetails(7,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan);
                        if(!empty($s_room_tariffs)){
                            $s_room_tariff = $s_room_tariffs[0]['tariff'];
                        }
                        else{
                            $s_room_tariff = 0;
                        }

                        $s_child_tariffs = $Enquiry_model->getTourTariffDetailsChild(13,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan,1);
                        if(!empty($s_child_tariffs)){
                            $s_child_tariff = $s_child_tariffs[0]['tariff'];
                        }
                        else{
                            $s_child_tariff = 0;
                        }

                        $s_child_wb_tariffs = $Enquiry_model->getTourTariffDetailsChild(16,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan,2);
                        if(!empty($s_child_wb_tariffs)){
                            $s_child_wb_tariff = $s_child_wb_tariffs[0]['tariff'];
                        }
                        else{
                            $s_child_wb_tariff = 0;
                        }

                        $s_extra_tariffs = $Enquiry_model->getTourTariffDetailsChild(10,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan,3);
                        if(!empty($s_extra_tariffs)){
                            $s_extra_tariff = $s_extra_tariffs[0]['tariff'];
                        }
                        else{
                            $s_extra_tariff = 0;
                        }
                    }
                    else if(!empty($season_tariff)){
                        $s_room_tariffs = $Enquiry_model->getTourTariffDetails(6,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan);
                        if(!empty($s_room_tariffs)){
                            $s_room_tariff = $s_room_tariffs[0]['tariff'];
                        }
                        else{
                            $s_room_tariff = 0;
                        }

                        $s_child_tariffs = $Enquiry_model->getTourTariffDetailsChild(12,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan,1);
                        if(!empty($s_child_tariffs)){
                            $s_child_tariff = $s_child_tariffs[0]['tariff'];
                        }
                        else{
                            $s_child_tariff = 0;
                        }

                        $s_child_wb_tariffs = $Enquiry_model->getTourTariffDetailsChild(15,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan,2);
                        if(!empty($s_child_wb_tariffs)){
                            $s_child_wb_tariff = $s_child_wb_tariffs[0]['tariff'];
                        }
                        else{
                            $s_child_wb_tariff = 0;
                        }

                        $s_extra_tariffs = $Enquiry_model->getTourTariffDetailsChild(9,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan,3);
                        if(!empty($s_extra_tariffs)){
                            $s_extra_tariff = $s_extra_tariffs[0]['tariff'];
                        }
                        else{
                            $s_extra_tariff = 0;
                        }

                    }
                    else{

                        $room_tariffs = $Enquiry_model->getTourTariffDetailsBasic(5,$room_cat_id,$room_type,$object_id,$mealplan);
                        if(!empty($room_tariffs)){
                            $s_room_tariff = $s_room_tariff + $room_tariffs[0]['tariff'];
                        }
                        else{
                            $s_room_tariff = 0;
                        }

                        $child_tariffs = $Enquiry_model->getTourTariffDetailsChildBasic(11,$room_cat_id,$room_type,$object_id,$mealplan,1);
                        if(!empty($child_tariffs)){
                            $s_child_tariff = $s_child_tariff + $child_tariffs[0]['exclusive_tariff'];
                        }
                        else{
                            $s_child_tariff = 0;
                        }

                        $child_wb_tariffs = $Enquiry_model->getTourTariffDetailsChildBasic(11,$room_cat_id,$room_type,$object_id,$mealplan,2);
                        if(!empty($child_wb_tariffs)){
                            $s_child_wb_tariff = $s_child_wb_tariff + $child_wb_tariffs[0]['exclusive_tariff'];
                        }
                        else{
                            $s_child_wb_tariff = 0;
                        }

                        $extra_tariffs = $Enquiry_model->getTourTariffDetailsChildBasic(11,$room_cat_id,$room_type,$object_id,$mealplan,3);
                        if(!empty($extra_tariffs)){
                            $s_extra_tariff = $s_extra_tariff + $extra_tariffs[0]['exclusive_tariff'];
                        }
                        else{
                            $s_extra_tariff = 0;
                        }
                    }
                
            }
            $tariff_det['d_room_tariff']=$d_room_tariff;
            $tariff_det['d_child_tariff']=$d_child_tariff;
            $tariff_det['d_child_wb_tariff']=$d_child_wb_tariff;
            $tariff_det['d_extra_tariff']=$d_extra_tariff;

            $tariff_det['s_room_tariff']=$s_room_tariff;
            $tariff_det['s_child_tariff']=$s_child_tariff;
            $tariff_det['s_child_wb_tariff']=$s_child_wb_tariff;
            $tariff_det['s_extra_tariff']=$s_extra_tariff;
            echo json_encode($tariff_det);
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function generateCostingSheet()
    {
        $Enquiry_model = new Enquiry_m();
        date_default_timezone_set('Asia/Kolkata');
        $sdate = date('Y-m-d H:i:s');
        $enquiry_header_id = $this->request->getPost('enquiry_header_id_t');
        $extension_ref_id = $this->request->getPost('extension_ref_id');
        $enquiry_details_id = $this->request->getPost('enquiry_details_id_t');
        $no_of_night = $this->request->getPost('no_of_night_hidden');

        $itinerary_details_save = [];
        $tour_plan_det = $Enquiry_model->get_tour_plan_details($enquiry_header_id,$enquiry_details_id);
        $ext_ref_id_tour_plan = $tour_plan_det[0]['tour_details_id'];
        /*foreach($tour_plan_det as $keys => $vals){
            $result2 = $Enquiry_model->get_all_itinerary_save_details($enquiry_header_id,$enquiry_details_id,$vals['tour_details_id']);
            if (!empty($result2)) {
                $itinerary_details_save = [...$itinerary_details_save, ...$result2];
            }
        } 
        $version_count = count($itinerary_details_save)/$no_of_night;*/
        $version_count = $Enquiry_model->get_all_itinerary_version_count($enquiry_header_id);
        $object_id = $this->request->getPost('object_id_t');
        $user_id = session('user_id');
        $er_det = $Enquiry_model->getEditRequestDetails($enquiry_header_id);
        $status_exist = $Enquiry_model->checkStatusExist($enquiry_header_id,7);
        if($status_exist == 0){
            $status_det = $Enquiry_model->getstatusDetails($enquiry_header_id,1);
            $status_data = array(
                'object_id' => $object_id,
                'enquiry_header_id' => $enquiry_header_id,
                'current_status_id' => 7,
                'updated_time' => $sdate,
                'assigned_to' => $status_det[0]['assigned_to'],
                'assigned_status' => 1,
                'edit_request_id' => $er_det[0]['enquiry_edit_request_id'],
                'updated_by' => $user_id,
                'enterprise_id' => 1                            
            );
            $status_data_insert = $Enquiry_model->insertEnquirystatus($status_data);
        }

        $object_det = $Enquiry_model->get_object_details($object_id);
        $data_cs_status = array(
            'is_active' => 0
        );
        $update_status = $Enquiry_model->update_cs_active($data_cs_status,$enquiry_header_id,$enquiry_details_id);

        $margin_value = $this->request->getPost('margin_value');
		$margin_total = $this->request->getPost('margin_total');
		$tour_addon_value = $this->request->getPost('tour_addon_value');
		$total_final = $this->request->getPost('total_final');
		$gst_value = $this->request->getPost('gst_value');
		$gst_final = $this->request->getPost('gst_final');
		$tpc = $this->request->getPost('tpc');

        $tac_hidden = $this->request->getPost('tac_hidden');
        $ttc_hidden = $this->request->getPost('ttc_hidden');
        $spcl_hidden = $this->request->getPost('spcl_hidden');
        $daily_hidden = $this->request->getPost('daily_hidden');
        $tnr_hidden = $this->request->getPost('tnr_hidden');
        

        $data_cs = array(
            'object_id' => $object_id,
            'enquiry_header_id' => $enquiry_header_id,
            'enquiry_details_id' => $enquiry_details_id,

            'tac' => $tac_hidden,
            'ttc' => $ttc_hidden,
            'special_total_cost' => $spcl_hidden,
            'daily_total_cost' => $daily_hidden,
            'tnr' => $tnr_hidden,

            'margin_per' => $margin_value,
            'margin_value' => $margin_total,
            'tour_addon' => $tour_addon_value,
            'total_rate' => $total_final,
            'gst_per' => $gst_value,
            'gst_value' => $gst_final,
            'tpc' => $tpc,
            'created_date' => $sdate,
            'is_active' => 1,
            'is_edit' => 1,
            'version_count' => $version_count,
            'enterprise_id' => 1
        );
        $enquiry_detail_details_id = $Enquiry_model->insert_iti_costing($data_cs);   
        if($enquiry_detail_details_id){
                $vc_data = array(
                    'version_count' => $version_count
                );
                $vc_data_update = $Enquiry_model->update_all_version_count($vc_data,$enquiry_header_id);   

                $ext_iti_data = array(
                    'extension_ref_id' => $enquiry_detail_details_id
                );
                $ext_tp_data = array(
                    'extension_ref_id' => $ext_ref_id_tour_plan
                );
              
                $ext_tp_refdata = array(
                    'tour_plan_ref_id' => $ext_ref_id_tour_plan
                );
                $ext_enq_refdata = array(
                    'enquiry_ref_id' => $enquiry_details_id
                );
                if($extension_ref_id > 0){
                    $ext_iti_data_temp = array(
                        'extension_ref_id' => $extension_ref_id
                    );
                    $ext_updated = $Enquiry_model->set_extension_ref_id($ext_iti_data_temp,$enquiry_detail_details_id); 
                    $tp_updated = $Enquiry_model->set_tourplan_ref_id($ext_tp_refdata,$enquiry_detail_details_id); 
                    $enq_updated = $Enquiry_model->set_enquiry_ref_id($ext_enq_refdata,$enquiry_detail_details_id);
                }
                else{
                    $ext_updated = $Enquiry_model->set_extension_ref_id($ext_iti_data,$enquiry_detail_details_id); 
                    $tp_updated = $Enquiry_model->set_tourplan_ref_id($ext_tp_refdata,$enquiry_detail_details_id); 
                    $enq_updated = $Enquiry_model->set_enquiry_ref_id($ext_enq_refdata,$enquiry_detail_details_id);
                    $ext_iti_updated = $Enquiry_model->linkItinearywithExtension($ext_iti_data,$enquiry_header_id,$enquiry_details_id);
                    $ext_tp_updated = $Enquiry_model->linkItinearywithTourplan($ext_tp_data,$enquiry_header_id,$enquiry_details_id); 
                  
                }
            return redirect()->to('Enquiry/enquiry_list_view/10');
        }else{
            return redirect()->to('Login');
        }
    }
    
    public function viewCostingSheet()
    {
        $Enquiry_model = new Enquiry_m();
        $itinerary_details_save = [];
        $result2 = [];
        $object_det = [];
        $tour_plan_det = [];
        $final_cs_data = [];
        $id = $this->request->getPost('id');
        $extension_ref_id = $this->request->getPost('extension_ref_id');
        $tourplan_ref_id = $this->request->getPost('tourplan_ref_id');
        $enq_ref_id = $this->request->getPost('enq_ref_id');
        $iti_cost_datas = $Enquiry_model->get_iti_cost($id); 
        if($iti_cost_datas[0]['cs_confirmed_id'] > 0){
            $final_cs_datas = $Enquiry_model->get_final_costing_sheet($iti_cost_datas[0]['cs_confirmed_id']);
            $final_cs_data = $final_cs_datas[0]['costing_sheet'];
        }

        $object_det = $Enquiry_model->get_object_details_forcs($iti_cost_datas[0]['object_id'],$enq_ref_id);
       
        $tour_plan_det = $Enquiry_model->get_tour_plan_details_foredit($tourplan_ref_id);

        foreach($tour_plan_det as $keys => $vals){
            $result2 = $Enquiry_model->get_itinerary_save_details_for_cs($id,$extension_ref_id,$enq_ref_id,$vals['tour_details_id']);
            if (!empty($result2)) {
                $itinerary_details_save = [...$itinerary_details_save, ...$result2];
            }
        } 
      
        $response['iti_cost_datas'] = $iti_cost_datas;
        $response['iti_data'] = $itinerary_details_save;
        $response['object_det'] = $object_det;
        $response['tour_plan_det'] = $tour_plan_det; 

        $response['tac_hidden'] = $iti_cost_datas[0]['tac']; 
        $response['ttc_hidden'] = $iti_cost_datas[0]['ttc']; 
        $response['spcl_hidden'] = $iti_cost_datas[0]['special_total_cost']; 
        $response['daily_hidden'] = $iti_cost_datas[0]['daily_total_cost']; 
        $response['tnr_hidden'] = $iti_cost_datas[0]['tnr']; 
        $response['final_cs_data'] = $final_cs_data;
        
        echo view('enquiry/costing_sheet_view', $response);
    }


    public function viewItinerarySheet()
    {
        $Enquiry_model = new Enquiry_m();
        $itinerary_details_save = [];
        $result2 = [];
        $object_det = [];
        $tour_plan_det = [];
        $final_iti_data = [];
        $id = $this->request->getPost('id');
        $extension_ref_id = $this->request->getPost('extension_ref_id');
        $tourplan_ref_id = $this->request->getPost('tourplan_ref_id');
        $enq_ref_id = $this->request->getPost('enq_ref_id');
        $iti_cost_datas = $Enquiry_model->get_iti_cost($id); 
        if($iti_cost_datas[0]['cs_confirmed_id'] > 0){
            $final_iti_datas = $Enquiry_model->get_final_costing_sheet($iti_cost_datas[0]['cs_confirmed_id']);
            $final_iti_data = $final_iti_datas[0]['itinerary'];
        }
       
        $object_det = $Enquiry_model->get_object_details_forcs($iti_cost_datas[0]['object_id'],$enq_ref_id);
        
        $tour_plan_det = $Enquiry_model->get_tour_plan_details_foredit($tourplan_ref_id);
    
        foreach($tour_plan_det as $keys => $vals){
            $result2 = $Enquiry_model->get_itinerary_save_details_for_cs($id,$extension_ref_id,$enq_ref_id,$vals['tour_details_id']);
            if (!empty($result2)) {
                $itinerary_details_save = [...$itinerary_details_save, ...$result2];
            }
        } 
        $response['iti_cost_datas'] = $iti_cost_datas;
        $response['iti_data'] = $itinerary_details_save;
        $response['object_det'] = $object_det;
        $response['tour_plan_det'] = $tour_plan_det; 

        $response['tac_hidden'] = $iti_cost_datas[0]['tac']; 
        $response['ttc_hidden'] = $iti_cost_datas[0]['ttc']; 
        $response['spcl_hidden'] = $iti_cost_datas[0]['special_total_cost']; 
        $response['daily_hidden'] = $iti_cost_datas[0]['daily_total_cost']; 
        $response['tnr_hidden'] = $iti_cost_datas[0]['tnr']; 
        $response['final_iti_data'] = $final_iti_data;
        
        echo view('enquiry/itinerary_sheet_view', $response);
    }
    public function viewMultipleItinerarySheet()
    {
        $Enquiry_model = new Enquiry_m();
        
        $selectedIDs = $this->request->getPost('selectedIDs') ?? [];
        foreach($selectedIDs as $key => $id){
            $itinerary_details_save = [];
            $result2 = [];
            $object_det = [];
            $tour_plan_det = [];
            $ext_det = $Enquiry_model->getExtensionDetailsbyid($id);
            $extension_ref_id = $ext_det[0]['extension_ref_id'];
            $tourplan_ref_id = $ext_det[0]['tour_plan_ref_id'];
            $enq_ref_id = $ext_det[0]['enquiry_ref_id'];
            $iti_cost_datas = $Enquiry_model->get_iti_cost($id); 
            $object_det = $Enquiry_model->get_object_details_forcs($iti_cost_datas[0]['object_id'],$enq_ref_id);
            $tour_plan_det = $Enquiry_model->get_tour_plan_details_foredit($tourplan_ref_id);
            foreach($tour_plan_det as $keys => $vals){
                $result2 = $Enquiry_model->get_itinerary_save_details_for_cs($id,$extension_ref_id,$enq_ref_id,$vals['tour_details_id']);
                if (!empty($result2)) {
                    $itinerary_details_save = [...$itinerary_details_save, ...$result2];
                }
            } 
            $response[$key]['iti_cost_datas'] = $iti_cost_datas;
            $response[$key]['iti_data'] = $itinerary_details_save;
            $response[$key]['object_det'] = $object_det;
            $response[$key]['tour_plan_det'] = $tour_plan_det; 
        }
      
        echo view('enquiry/multiple_itinerary_sheet_view', ['response' => $response]);
    }


    public function getTourTariffDetailsbyTourDetails($tour_date,$hotel_id,$room_cat_id,$mealplan,$double,$single)
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $tariff_det = [];
            $object_ids = $Enquiry_model->getObjectidByhotel($hotel_id);
            $object_id = $object_ids[0]['object_id'];

            $d_room_tariff = 0;
            $d_child_tariff = 0;
            $d_child_wb_tariff = 0;
            $d_extra_tariff = 0;

            $s_room_tariff = 0;
            $s_child_tariff = 0;
            $s_child_wb_tariff = 0;
            $s_extra_tariff = 0;

            if($double > 0){    
                $room_type = 2;
                    $weekend_tariff = $Enquiry_model->checkWeekendExist($tour_date,$object_id);
                    $season_tariff = $Enquiry_model->checkSeasonExist($tour_date,$object_id);
                    $d_room_tariff = 0;
                    $d_child_tariff = 0;
                    $d_child_wb_tariff = 0;
                    $d_extra_tariff = 0;
                    if(!empty($weekend_tariff)){ 
                        $room_tariffs = $Enquiry_model->getTourTariffDetails(7,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan);
                        if(!empty($room_tariffs)){
                            $d_room_tariff = $room_tariffs[0]['tariff'];
                        }
                        else{
                            $d_room_tariff = 0;
                        } 

                        $child_tariffs = $Enquiry_model->getTourTariffDetailsChild(13,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan,1);
                        if(!empty($child_tariffs)){
                            $d_child_tariff = $child_tariffs[0]['tariff'];
                        }
                        else{
                            $d_child_tariff = 0;
                        }
                      
                        $child_wb_tariffs = $Enquiry_model->getTourTariffDetailsChild(16,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan,2);
                        if(!empty($child_wb_tariffs)){
                            $d_child_wb_tariff = $child_wb_tariffs[0]['tariff'];
                        }
                        else{
                            $d_child_wb_tariff = 0;
                        }

                        $extra_tariffs = $Enquiry_model->getTourTariffDetailsChild(10,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan,3);
                        if(!empty($extra_tariffs)){
                            $d_extra_tariff = $extra_tariffs[0]['tariff'];
                        }
                        else{
                            $d_extra_tariff = 0;
                        }
                    }
                    else if(!empty($season_tariff)){ 
                        
                            $room_tariffs = $Enquiry_model->getTourTariffDetails(6,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan);
                            if(!empty($room_tariffs)){
                                $d_room_tariff = $room_tariffs[0]['tariff'];
                            }
                            else{
                                $d_room_tariff = 0;
                            }

                            $child_tariffs = $Enquiry_model->getTourTariffDetailsChild(12,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan,1);
                            if(!empty($child_tariffs)){
                                $d_child_tariff = $child_tariffs[0]['tariff'];
                            }
                            else{
                                $d_child_tariff = 0;
                            }

                            $child_wb_tariffs = $Enquiry_model->getTourTariffDetailsChild(15,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan,2);
                            if(!empty($child_wb_tariffs)){
                                $d_child_wb_tariff = $child_wb_tariffs[0]['tariff'];
                            }
                            else{
                                $d_child_wb_tariff = 0;
                            }

                            $extra_tariffs = $Enquiry_model->getTourTariffDetailsChild(9,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan,3);
                            if(!empty($extra_tariffs)){
                                $d_extra_tariff = $extra_tariffs[0]['tariff'];
                            }
                            else{
                                $d_extra_tariff = 0;
                            }
                    }
                    else{
                        $room_tariffs = $Enquiry_model->getTourTariffDetailsBasic(5,$room_cat_id,$room_type,$object_id,$mealplan);
                        if(!empty($room_tariffs)){
                            $d_room_tariff = $d_room_tariff + $room_tariffs[0]['tariff'];
                        }
                        else{
                            $d_room_tariff = 0;
                        }

                        $child_tariffs = $Enquiry_model->getTourTariffDetailsChildBasic(11,$room_cat_id,$room_type,$object_id,$mealplan,1);
                        if(!empty($child_tariffs)){
                            $d_child_tariff = $d_child_tariff + $child_tariffs[0]['exclusive_tariff'];
                        }
                        else{
                            $d_child_tariff = 0;
                        }

                        $child_wb_tariffs = $Enquiry_model->getTourTariffDetailsChildBasic(11,$room_cat_id,$room_type,$object_id,$mealplan,2);
                        if(!empty($child_wb_tariffs)){
                            $d_child_wb_tariff = $d_child_wb_tariff + $child_wb_tariffs[0]['exclusive_tariff'];
                        }
                        else{
                            $d_child_wb_tariff = 0;
                        }

                        $extra_tariffs = $Enquiry_model->getTourTariffDetailsChildBasic(11,$room_cat_id,$room_type,$object_id,$mealplan,3);
                        if(!empty($extra_tariffs)){
                            $d_extra_tariff = $d_extra_tariff + $extra_tariffs[0]['exclusive_tariff'];
                        }
                        else{
                            $d_extra_tariff = 0;
                        }
                    }
            }

            if($single > 0){    
                $room_type = 1;
                    $weekend_tariff = $Enquiry_model->checkWeekendExist($tour_date,$object_id);
                    $season_tariff = $Enquiry_model->checkSeasonExist($tour_date,$object_id);
                    $s_room_tariff = 0;
                    $s_child_tariff = 0;
                    $s_child_wb_tariff = 0;
                    $s_extra_tariff = 0;
                    if(!empty($weekend_tariff)){
                        $s_room_tariffs = $Enquiry_model->getTourTariffDetails(7,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan);
                        if(!empty($s_room_tariffs)){
                            $s_room_tariff = $s_room_tariffs[0]['tariff'];
                        }
                        else{
                            $s_room_tariff = 0;
                        }

                        $s_child_tariffs = $Enquiry_model->getTourTariffDetailsChild(13,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan,1);
                        if(!empty($s_child_tariffs)){
                            $s_child_tariff = $s_child_tariffs[0]['tariff'];
                        }
                        else{
                            $s_child_tariff = 0;
                        }

                        $s_child_wb_tariffs = $Enquiry_model->getTourTariffDetailsChild(16,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan,2);
                        if(!empty($s_child_wb_tariffs)){
                            $s_child_wb_tariff = $s_child_wb_tariffs[0]['tariff'];
                        }
                        else{
                            $s_child_wb_tariff = 0;
                        }

                        $s_extra_tariffs = $Enquiry_model->getTourTariffDetailsChild(10,$room_cat_id,$room_type,$weekend_tariff[0]['weekend_id'],$object_id,$mealplan,3);
                        if(!empty($s_extra_tariffs)){
                            $s_extra_tariff = $s_extra_tariffs[0]['tariff'];
                        }
                        else{
                            $s_extra_tariff = 0;
                        }
                    }
                    else if(!empty($season_tariff)){
                        $s_room_tariffs = $Enquiry_model->getTourTariffDetails(6,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan);
                        if(!empty($s_room_tariffs)){
                            $s_room_tariff = $s_room_tariffs[0]['tariff'];
                        }
                        else{
                            $s_room_tariff = 0;
                        }

                        $s_child_tariffs = $Enquiry_model->getTourTariffDetailsChild(12,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan,1);
                        if(!empty($s_child_tariffs)){
                            $s_child_tariff = $s_child_tariffs[0]['tariff'];
                        }
                        else{
                            $s_child_tariff = 0;
                        }

                        $s_child_wb_tariffs = $Enquiry_model->getTourTariffDetailsChild(15,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan,2);
                        if(!empty($s_child_wb_tariffs)){
                            $s_child_wb_tariff = $s_child_wb_tariffs[0]['tariff'];
                        }
                        else{
                            $s_child_wb_tariff = 0;
                        }

                        $s_extra_tariffs = $Enquiry_model->getTourTariffDetailsChild(9,$room_cat_id,$room_type,$season_tariff[0]['season_id'],$object_id,$mealplan,3);
                        if(!empty($s_extra_tariffs)){
                            $s_extra_tariff = $s_extra_tariffs[0]['tariff'];
                        }
                        else{
                            $s_extra_tariff = 0;
                        }

                    }
                    else{

                        $room_tariffs = $Enquiry_model->getTourTariffDetailsBasic(5,$room_cat_id,$room_type,$object_id,$mealplan);
                        if(!empty($room_tariffs)){
                            $s_room_tariff = $s_room_tariff + $room_tariffs[0]['tariff'];
                        }
                        else{
                            $s_room_tariff = 0;
                        }

                        $child_tariffs = $Enquiry_model->getTourTariffDetailsChildBasic(11,$room_cat_id,$room_type,$object_id,$mealplan,1);
                        if(!empty($child_tariffs)){
                            $s_child_tariff = $s_child_tariff + $child_tariffs[0]['exclusive_tariff'];
                        }
                        else{
                            $s_child_tariff = 0;
                        }

                        $child_wb_tariffs = $Enquiry_model->getTourTariffDetailsChildBasic(11,$room_cat_id,$room_type,$object_id,$mealplan,2);
                        if(!empty($child_wb_tariffs)){
                            $s_child_wb_tariff = $s_child_wb_tariff + $child_wb_tariffs[0]['exclusive_tariff'];
                        }
                        else{
                            $s_child_wb_tariff = 0;
                        }

                        $extra_tariffs = $Enquiry_model->getTourTariffDetailsChildBasic(11,$room_cat_id,$room_type,$object_id,$mealplan,3);
                        if(!empty($extra_tariffs)){
                            $s_extra_tariff = $s_extra_tariff + $extra_tariffs[0]['exclusive_tariff'];
                        }
                        else{
                            $s_extra_tariff = 0;
                        }
                    }
                
            }
            $tariff_det['tour_date']=$tour_date;
            $tariff_det['d_room_tariff']=$d_room_tariff;
            $tariff_det['d_child_tariff']=$d_child_tariff;
            $tariff_det['d_child_wb_tariff']=$d_child_wb_tariff;
            $tariff_det['d_extra_tariff']=$d_extra_tariff;

            $tariff_det['s_room_tariff']=$s_room_tariff;
            $tariff_det['s_child_tariff']=$s_child_tariff;
            $tariff_det['s_child_wb_tariff']=$s_child_wb_tariff;
            $tariff_det['s_extra_tariff']=$s_extra_tariff;
            return $tariff_det;
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function cost_list_view()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $data = $Enquiry_model->cost_list_view($this->request->getPost());
            echo json_encode($data);
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function get_sales_report_data()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $data = $Enquiry_model->get_sales_report_data($this->request->getPost());
            echo json_encode($data);
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function get_payment_tracker_data()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $data = $Enquiry_model->get_payment_tracker_data($this->request->getPost());
            echo json_encode($data);
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function get_sales_report_new_data()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $data = $Enquiry_model->get_sales_report_new_data($this->request->getPost());
            echo json_encode($data);
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function payment_list_view()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $data = $Enquiry_model->payment_list_view($this->request->getPost());
            echo json_encode($data);
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function payment_history_view()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            $data = $Enquiry_model->payment_history_view($this->request->getPost());
            echo json_encode($data);
        }
        else{
            return redirect()->to('Login');
        }
    }
    public function get_all_enquiry_foredit()
    {
        if (!empty(session()->get('user_id'))) {
            $Enquiry_model = new Enquiry_m();
            
            $object_id = $this->request->getPost('object_id');
            $object_class_id = $this->request->getPost('object_class_id');
            $guest_name = $this->request->getPost('guest_name');
            //$enq_det['enq_det'] = $Enquiry_model->get_all_enquiry_foredit($object_id);
            $enq_header_ids = $Enquiry_model->get_enquiry_header_id($object_id);
            $enq_header_id = $enq_header_ids[0]['enquiry_header_id'];
            $enq_det['enquiry_details'] = $Enquiry_model->get_all_enquiry_details($enq_header_id);
            $enq_det['enquiry_header_details'] = $Enquiry_model->get_all_enquiry_header_details($object_id);
            $enq_det['object_id'] = $object_id;
            $enq_det['object_class_id'] = $object_class_id;
            $enq_det['guest_name'] = $guest_name;
           

            echo view('enquiry/enquiry_edit_view', $enq_det);
        }
        else{
            return redirect()->to('Login');
        }
    }

    public function ajax_get_tourplans()
    {
        $enquiry_details_id = $this->request->getPost('enquiry_details_id');
        $object_id = $this->request->getPost('object_id');
        $status_id = $this->request->getPost('sid');
        $Enquiry_model = new Enquiry_m();
        $tour_plans = $Enquiry_model->get_all_tourplan_byid($enquiry_details_id);
        if (!empty($tour_plans)) {
            if($status_id == 1){
                $first = array_shift($tour_plans);
                $active = $first['is_active'] == 1;
                $created_date = date("d-m-Y h:i A", strtotime($first['updated_time']));
                echo '<div class="item-block">';
                echo '<a href="#" class="tour-item" data-sid="1" data-id="'.$first['extension_ref_id'].'" style="color:'.($active ? '#003300' : '#339966').'">';
                echo $active ? 'Current '.$created_date : 'Previous '.$created_date;
                echo '</a>';
                if ($active) {
                    echo '<a href="'.site_url("Enquiry/tour_plan/{$object_id}/{$enquiry_details_id}").'" title="Tour Plan Edit"><i style="color:#003300;" class="fa fa-edit edit-icon"></i></a>';
                    echo '<div class="item-block">';
                        echo '<h6 style="font-weight: bold;font-style: italic;color:#cc0099;">View <a class="tour_view_edit" data-id-ext="'.$first['extension_ref_id'].'" data-id-object="'.$object_id.'" data-id-head="'.$first['enquiry_header_id'].'" data-id-det="'.$first['enquiry_details_id'].'" data-toggle="tooltip" data-original-title="Tour Plan View" href="#"><i class="fa fa-eye" style="color:#006600"></i></a></h6>';
                    echo '</div>';
                }
                echo '</div>';

                // Show More / Show Less Toggle if there are more
                if (count($tour_plans) > 0) {
                    echo '<div id="tour-toggle-wrapper">';
                    echo '<div id="toggle-tour-buttons" style="margin-top:5px;">';
                    echo '<a href="#" id="show-more-tour" style="font-size: 13px; font-weight:bold;">+ Show Previous Tour Plans</a>';
                    echo '<a href="#" id="show-less-tour" style="font-size: 13px; font-weight:bold; display:none;">– Hide Previous Tour Plans</a>';
                    echo '</div>';
                    echo '</div>';

                    echo '<div id="more-tour-plans" style="display:none;">';
                    foreach ($tour_plans as $tour) {
                        $cr_date = date("d-m-Y h:i A", strtotime($tour['updated_time']));
                        echo '<div class="item-block">';
                        echo '<a href="#" class="tour-item" data-sid="0" data-id="'.$tour['extension_ref_id'].'" style="color:#003366">Previous '.$cr_date.'</a>';
                            echo '<div class="item-block">';
                                echo '<h6 style="font-weight: bold;font-style: italic;color:#cc0099;">View <a class="tour_view_edit" data-id-ext="'.$tour['extension_ref_id'].'" data-id-object="'.$object_id.'" data-id-head="'.$tour['enquiry_header_id'].'" data-id-det="'.$tour['enquiry_details_id'].'" data-toggle="tooltip" data-original-title="Tour Plan View" href="#"><i class="fa fa-eye" style="color:#006600"></i></a></h6>';
                            echo '</div>';
                        echo '</div>';
                    }
                    echo '</div>';
                }
            }
            else{
                echo '<div>';
                    foreach ($tour_plans as $tour) {
                        $cr_date = date("d-m-Y h:i A", strtotime($tour['updated_time']));
                        echo '<div class="item-block">';
                        echo '<a href="#" class="tour-item" data-sid="0" data-id="'.$tour['extension_ref_id'].'" style="color:#003366">Previous '.$cr_date.'</a>';
                            echo '<div class="item-block">';
                                echo '<h6 style="font-weight: bold;font-style: italic;color:#cc0099;">View <a class="tour_view_edit" data-id-ext="'.$tour['extension_ref_id'].'" data-id-object="'.$object_id.'" data-id-head="'.$tour['enquiry_header_id'].'" data-id-det="'.$tour['enquiry_details_id'].'" data-toggle="tooltip" data-original-title="Tour Plan View" href="#"><i class="fa fa-eye" style="color:#006600"></i></a></h6>';
                            echo '</div>';
                        echo '</div>';
                    }
                echo '</div>';
            }
        }
        else{
            echo '<div class="item-block">';
                echo '<h6 style="font-size: 13px; font-weight:bold;font-style: italic;color:#ff3399">Tour plan not created yet</h6>';
            echo '</div>';
        }
    }

    public function ajax_get_itineraries()
    {
        $tour_id = $this->request->getPost('tour_id');
        $status_id = $this->request->getPost('sid');
        $object_id = $this->request->getPost('object_id');
        $Enquiry_model = new Enquiry_m();
        $itineraries = $Enquiry_model->get_all_itinerary_byid($tour_id);
        if (!empty($itineraries)) {
            if($status_id == 1){
                $first = array_shift($itineraries);
                $is_active = $first['is_active'] == 1;
                $is_draft = $first['is_draft'] == 1;
                $created_date = date("d-m-Y h:i A", strtotime($first['updated_time']));
                $ext = $Enquiry_model->getExtensionDetailsforItinerary($first['extension_ref_id']);
                $ext_all = $Enquiry_model->get_all_extensions_byid($first['extension_ref_id']);
                if(count($ext_all) > 1){
                $cs_status = 2;
                }
                else if(count($ext_all) == 1){
                    $cs_status = 1;
                }
                else{
                    $cs_status = 0;
                }
                echo '<div class="item-block">';
                echo '<a href="#" class="iti-item" data-sid="1" data-id="'.$first['extension_ref_id'].'" style="color:'.($is_active&&$is_draft ? '#003300' : '#339966').'">';
                echo $is_active&&$is_draft ? $created_date : $created_date;
               
                echo '</a>';
                if ($is_active&&$is_draft) {
                    if(!empty($ext)){
                        echo '&nbsp;<a href="'.site_url("Enquiry/itinerary/{$ext[0]['object_id']}/0/{$ext[0]['enquiry_detail_details_id']}/{$ext[0]['version_count']}").'" title="Itinerary Edit"><i style="color:#003300;" class="fa fa-edit edit-icon"></i></a>';
                        echo '&nbsp;&nbsp;<a href="'.site_url("Enquiry/itinerary/{$object_id}/0").'" target="_blank" title="Itinerary View"><i style="color:#003300;" class="fa fa-eye"></i></a>';
                        if($cs_status == 1){
                            echo '<div class="item-block">';
                                echo '<h6 style="font-weight: bold;font-style: italic;color:#cc0099;">Total Cost : '.$ext[0]['tpc'].' <a href="" class="view_cost_sheet_edit" data-did="'.$ext[0]['enquiry_ref_id'].'" data-tid="'.$ext[0]['tour_plan_ref_id'].'" data-eid="'.$ext[0]['extension_ref_id'].'" data-id="'.$ext[0]['enquiry_detail_details_id'].'"><i class="fa fa-eye" style="color:rgb(7, 138, 2); padding-right:10px;" type="button" title="Costing Sheet"></i></a></h6>';
                            echo '</div>';
                        }
                    }
                    else{
                        $ext_temp = $Enquiry_model->getExtensionDetailsforItinerarynext($first['extension_ref_id']);
                        echo '<div class="item-block">';
                            echo '<h6 style="font-size: 13px; font-weight:bold;font-style: italic;color:#ff3399">Current Itinerary Not Completed</h6>';
                            echo '<a style="font-size: 13px; font-weight:bold;font-style: italic;" href="'.site_url("Enquiry/itinerary/{$ext_temp[0]['object_id']}/0/{$ext_temp[0]['enquiry_detail_details_id']}/{$ext_temp[0]['version_count']}").'" title="Itinerary Edit">Go to Itinerary <i class="fa fa-arrow-right"></i></a>';
                        echo '</div>';
                    }
                }
                else{
                    if(!empty($ext)){
                        echo '<h6 style="font-weight: bold;font-style: italic;color:#cc0099;">Total Cost : '.$ext[0]['tpc'].' <a href="" class="view_cost_sheet_edit" data-did="'.$ext[0]['enquiry_ref_id'].'" data-tid="'.$ext[0]['tour_plan_ref_id'].'" data-eid="'.$ext[0]['extension_ref_id'].'" data-id="'.$ext[0]['enquiry_detail_details_id'].'"><i class="fa fa-eye" style="color:rgb(7, 138, 2); padding-right:10px;" type="button" title="Costing Sheet"></i></a></h6>';
                    }
                }
                echo '</div>';

                if (!empty($itineraries)) {
                    echo '<div id="iti-toggle-wrapper">';
                    echo '<div id="toggle-iti-buttons" style="margin-top:5px;">';
                    echo '<a href="#" id="show-more-iti" style="font-size: 13px; font-weight:bold;">+ Show Previous Itineraries</a>';
                    echo '<a href="#" id="show-less-iti" style="font-size: 13px; font-weight:bold; display:none;">– Hide Previous Itineraries</a>';
                    echo '</div>';
                    echo '</div>';

                    echo '<div id="more-itineraries" style="display:none;">';
                    foreach ($itineraries as $iti) {
                        $ext1 = $Enquiry_model->getExtensionDetailsforItinerarynext($iti['extension_ref_id']);
                        $ext_all1 = $Enquiry_model->get_all_extensions_byid($iti['extension_ref_id']);
                        if(count($ext_all1) > 1){
                            $cs_status1 = 2;
                        }
                        else if(count($ext_all1) == 1){
                            $cs_status1 = 1;
                        }
                        else{
                            $cs_status1 = 0;
                        }
                        $cr_date = date("d-m-Y h:i A", strtotime($iti['updated_time']));
                        echo '<div class="item-block">';
                        echo '<a href="#" class="iti-item" data-sid="0" data-id="'.$iti['extension_ref_id'].'" style="color:#003366;">'.$cr_date.'</a>';
                        if(!empty($ext1)){
                            echo '<a href="'.site_url("Enquiry/itinerary/{$ext1[0]['object_id']}/0/{$ext1[0]['enquiry_detail_details_id']}/{$ext1[0]['version_count']}/0").'" title="Itinerary Edit" onclick="return confirm(\'If you edit this itinerary, it will become the current itinerary. Are you sure you want to continue?\')"><i style="color:#003300;" class="fa fa-edit edit-icon"></i></a>';
                            echo '&nbsp;&nbsp;<a href="'.site_url("Enquiry/itinerary/{$object_id}/0").'" target="_blank" title="Itinerary View"><i style="color:#003300;" class="fa fa-eye"></i></a>';
                        }
                        echo '</div>';
                        if($cs_status1 == 1){
                            echo '<div class="item-block">';
                            if(!empty($ext1)){
                                echo '<h6 style="font-weight: bold;font-style: italic;color:#cc0099;">Total Cost : '.$ext1[0]['tpc'].' <a href="" class="view_cost_sheet_edit" data-did="'.$ext1[0]['enquiry_ref_id'].'" data-tid="'.$ext1[0]['tour_plan_ref_id'].'" data-eid="'.$ext1[0]['extension_ref_id'].'" data-id="'.$ext1[0]['enquiry_detail_details_id'].'"><i class="fa fa-eye" style="color:rgb(7, 138, 2); padding-right:10px;" type="button" title="Costing Sheet"></i></a></h6>';
                            }
                            echo '</div>';
                        }
                    }
                    echo '</div>';
                }
            }
            else{
                echo '<div>';
                    foreach ($itineraries as $iti) {
                        $ext1 = $Enquiry_model->getExtensionDetailsforItinerarynext($iti['extension_ref_id']);
                        $ext_all1 = $Enquiry_model->get_all_extensions_byid($iti['extension_ref_id']);
                        if(count($ext_all1) > 1){
                            $cs_status1 = 2;
                        }
                        else if(count($ext_all1) == 1){
                            $cs_status1 = 1;
                        }
                        else{
                            $cs_status1 = 0;
                        }
                        $cr_date = date("d-m-Y h:i A", strtotime($iti['updated_time']));
                        echo '<div class="item-block">';
                        echo '<a href="#" class="iti-item" data-sid="0" data-id="'.$iti['extension_ref_id'].'" style="color:#003366;">Previous '.$cr_date.'</a>';
                        if(!empty($ext1)){
                            echo '<a href="'.site_url("Enquiry/itinerary/{$ext1[0]['object_id']}/0/{$ext1[0]['enquiry_detail_details_id']}/{$ext1[0]['version_count']}/0").'" title="Itinerary Edit" onclick="return confirm(\'If you edit this itinerary, it will become the current itinerary. Are you sure you want to continue?\')"><i style="color:#003300;" class="fa fa-edit edit-icon"></i></a>';
                            echo '&nbsp;&nbsp;<a href="'.site_url("Enquiry/itinerary/{$object_id}/0").'" target="_blank" title="Itinerary View"><i style="color:#003300;" class="fa fa-eye"></i></a>';
                        }
                        echo '</div>';
                        if($cs_status1 == 1){
                            echo '<div class="item-block">';
                            if(!empty($ext1)){
                                echo '<h6 style="font-weight: bold;font-style: italic;color:#cc0099;">Total Cost : '.$ext1[0]['tpc'].' <a href="" class="view_cost_sheet_edit" data-did="'.$ext1[0]['enquiry_ref_id'].'" data-tid="'.$ext1[0]['tour_plan_ref_id'].'" data-eid="'.$ext1[0]['extension_ref_id'].'" data-id="'.$ext1[0]['enquiry_detail_details_id'].'"><i class="fa fa-eye" style="color:rgb(7, 138, 2); padding-right:10px;" type="button" title="Costing Sheet"></i></a></h6>';
                            }
                            echo '</div>';
                        }
                    }
                echo '</div>';
            }
        }
        else{
            echo '<div class="item-block">';
                echo '<h6 style="font-size: 13px; font-weight:bold;font-style: italic;color:#ff3399">Itinerary not created yet</h6>';
            echo '</div>';
        }
    }

    public function ajax_get_extensions()
    {
        $extension_ref_id = $this->request->getPost('iti_id');
        $Enquiry_model = new Enquiry_m();
        $ext = $Enquiry_model->get_all_extensions_byid($extension_ref_id);
        if(count($ext) > 1){
            $cs_status = 2;
          }
          else if(count($ext) == 1){
              $cs_status = 1;
          }
          else{
              $cs_status = 0;
          }
        if($cs_status == 1){
            if($ext[0]['is_active'] == 1){
                echo '<a href="'.site_url("Enquiry/itinerary/{$ext[0]['object_id']}/0/{$ext[0]['enquiry_detail_details_id']}/0/{$ext[0]['extension_ref_id']}").'" title="Extension Edit"><i style="color:#003300;" class="fa fa-edit edit-icon"></i></a>';
            }
        }
        else if ($cs_status == 2) {
            // Output the first (current or latest) tour plan
            $first = array_shift($ext);
            $active = $first['is_active'] == 1;
            $created_date = date("d-m-Y h:i A", strtotime($first['created_date']));
            echo '<div class="item-block">';
            echo '<a href="#" class="ext-item" data-id="'.$first['enquiry_detail_details_id'].'" style="color:'.($active ? '#003300' : '#339966').'">';
            echo $active ? 'Current '.$created_date : 'Previous '.$created_date;
            echo '</a>';
            if ($active) {
                echo '<a href="'.site_url("Enquiry/itinerary/{$first['object_id']}/0/{$first['enquiry_detail_details_id']}/0/{$first['extension_ref_id']}").'" title="Extension Edit"><i style="color:#003300;" class="fa fa-edit edit-icon"></i></a>';
                
            }
            echo '</div>';
            echo '<div class="item-block">';
                echo '<h6 style="font-weight: bold;font-style: italic;color:#cc0099;">Total Cost : '.$first['tpc'].' <a href="" class="view_cost_sheet" data-did="'.$first['enquiry_ref_id'].'" data-tid="'.$first['tour_plan_ref_id'].'" data-eid="'.$first['extension_ref_id'].'" data-id="'.$first['enquiry_detail_details_id'].'"><i class="fa fa-eye" style="color:rgb(7, 138, 2); padding-right:10px;" type="button" title="Costing Sheet"></i></a></h6>';
            echo '</div>';
            // Show More / Show Less Toggle if there are more
            if (count($ext) > 0) {
                echo '<div id="tour-toggle-wrapper">';
                echo '<div id="toggle-tour-buttons" style="margin-top:5px;">';
                echo '<a href="#" id="show-more-tour" style="font-size: 13px; font-weight:bold;">+ Show Previous Extensions</a>';
                echo '<a href="#" id="show-less-tour" style="font-size: 13px; font-weight:bold; display:none;">– Hide Previous Extensions</a>';
                echo '</div>';
                echo '</div>';

                echo '<div id="more-tour-plans" style="display:none;">';
                foreach ($ext as $exts) {
                    $cr_date = date("d-m-Y h:i A", strtotime($exts['created_date']));
                    echo '<div class="item-block">';
                    echo '<a href="#" class="ext-item" data-id="'.$exts['enquiry_detail_details_id'].'" style="color:#003366">Previous '.$cr_date.'</a>';
                    echo '</div>';
                    echo '<div class="item-block">';
                        echo '<h6 style="font-weight: bold;font-style: italic;color:#cc0099;">Total Cost : '.$exts['tpc'].' <a href="" class="view_cost_sheet" data-did="'.$exts['enquiry_ref_id'].'" data-tid="'.$exts['tour_plan_ref_id'].'" data-eid="'.$exts['extension_ref_id'].'" data-id="'.$exts['enquiry_detail_details_id'].'"><i class="fa fa-eye" style="color:rgb(7, 138, 2); padding-right:10px;" type="button" title="Costing Sheet"></i></a></h6>';
                    echo '</div>';
                }
                echo '</div>';
            }
        }
    }

    public function ajax_get_enquiry_details()
    {
        $enquiry_header_id = $this->request->getPost('enquiry_header_id');
        $object_class_id = $this->request->getPost('object_class_id');
        $object_id = $this->request->getPost('object_id');
   
        $Enquiry_model = new Enquiry_m();
        $itinerary_details = $Enquiry_model->get_all_enquiry_details($enquiry_header_id);

        if (!empty($itinerary_details)) {
            // Output the first enquiry detail
            $first = array_shift($itinerary_details);
            $active = $first['is_active'] == 1;
            $created_date = date("d-m-Y h:i A", strtotime($first['created_date']));
            echo '<div class="item-block">';
            echo '<a href="#" class="enquiry-item" data-sid="1" data-id="'.$first['extension_ref_id'].'" style="color:'.($active ? '#003300' : '#339966').'">';
            echo $active ? 'Current '.$created_date : 'Previous '.$created_date;
            echo '</a>';
            if ($active) {
                echo '<a href="'.site_url("Enquiry/add_object_enquiry/{$object_class_id}/{$object_id}").'" title="Enquiry Details Edit"><i style="color:#003300;" class="fa fa-edit edit-icon"></i></a>';
                echo '<div class="item-block">';
                    echo '<h6 style="font-weight: bold;font-style: italic;color:#cc0099;">View <a class="enquiry_view_edit" data-id-object="'.$object_id.'" data-id-det="'.$first['enquiry_details_id'].'" data-toggle="tooltip" data-original-title="Enquiry View" href=""><i class="fa fa-eye" style="color:#006600"></i></a></h6>';
                echo '</div>';
            }
            echo '</div>';

            // Add show more toggle button
            if (count($itinerary_details) > 0) {
                echo '<div id="show-more-wrapper">';
                    echo '<div id="toggle-ed-buttons" style="margin-top:5px;">';
                    echo '<a href="#" id="show-more-ed" style="font-size: 13px; font-weight:bold;display:inline-block;">+ Show Previous Enquiry Details</a>';
                    echo '<a href="#" id="show-less-ed" style="font-size: 13px; font-weight:bold;display:none;">– Hide Previous Enquiry Details</a>';
                    echo '</div>';
                echo '</div>';
                
                // Wrap the rest in a hidden container
                echo '<div id="more-enquiry-details" style="display:none;">';
                foreach ($itinerary_details as $itinerary_detail) {
                    $cr_date = date("d-m-Y h:i A", strtotime($itinerary_detail['created_date']));
                    echo '<div class="item-block">';
                    echo '<a href="#" class="enquiry-item" data-sid="0" data-id="'.$itinerary_detail['extension_ref_id'].'" style="color:#003366">Previous '.$cr_date.'</a>';
                        echo '<div class="item-block">';
                            echo '<h6 style="font-weight: bold;font-style: italic;color:#cc0099;">View <a class="enquiry_view_edit" data-id-object="'.$object_id.'" data-id-det="'.$itinerary_detail['enquiry_details_id'].'" data-toggle="tooltip" data-original-title="Enquiry View" href=""><i class="fa fa-eye" style="color:#006600"></i></a></h6>';
                        echo '</div>';
                    echo '</div>';
                }
                echo '</div>';
            }
        }
        else{
            echo '<div class="item-block">';
                echo '<h6 style="font-size: 13px; font-weight:bold;font-style: italic;color:#ff3399">Enquiry Details not created yet</h6>';
            echo '</div>';
        }
        
    }

    public function updateConfirmHotelFinal()
    {
        $Enquiry_model = new Enquiry_m();
        $user_id = session('user_id');
        date_default_timezone_set('Asia/Kolkata');
        $updated_time = date('Y-m-d H:i:s');
        $enquiry_header_id = $this->request->getPost('enquiry_header_id');
        $er_det = $Enquiry_model->getEditRequestDetails($enquiry_header_id);
        $cut_off_date = $this->request->getPost('cut_off_date');
        $confirm_cs_id = $this->request->getPost('confirm_cs_id');
        $ext_det = $Enquiry_model->getExtensionDetailsbyid($confirm_cs_id);   
            $c_data = array(
                'cut_off_date' => $cut_off_date
            );
            $c_update = $Enquiry_model->update_cut_off_date($c_data,$enquiry_header_id);  
            if($c_update){
                $is_exist = $Enquiry_model->is_status_check_exist($enquiry_header_id,16);
                if(empty($is_exist)){
                    $status_det = $Enquiry_model->getstatusDetails($enquiry_header_id,13);                
                    $status_data = array(
                        'object_id' => $ext_det[0]['object_id'],
                        'enquiry_header_id' => $enquiry_header_id,
                        'current_status_id' => 16,
                        'updated_time' => $updated_time,
                        'assigned_to' => $status_det[0]['assigned_to'],
                        'assigned_status' => 1,
                        'edit_request_id' => $er_det[0]['enquiry_edit_request_id'],
                        'updated_by' => $user_id,
                        'enterprise_id' => 1                            
                    );
                    $status_insert = $Enquiry_model->insertEnquirystatus($status_data);

                    $is_top_confirmed = $Enquiry_model->is_status_check_exist($enquiry_header_id,15);
                    if(!empty($is_top_confirmed)){
                        $booked_status_data = array(
                            'object_id' => $ext_det[0]['object_id'],
                            'enquiry_header_id' => $enquiry_header_id,
                            'current_status_id' => 17,
                            'updated_time' => $updated_time,
                            'assigned_to' => $status_det[0]['assigned_to'],
                            'assigned_status' => 1,
                            'edit_request_id' => $er_det[0]['enquiry_edit_request_id'],
                            'updated_by' => $user_id,
                            'enterprise_id' => 1                            
                        );
                        $booked_status_insert = $Enquiry_model->insertEnquirystatus($booked_status_data);
                    }
                    echo 1;
                }
                else{
                    echo 0;
                }
            }
    }
    public function finalTransportConfirm()
    {
        $Enquiry_model = new Enquiry_m();
        $user_id = session('user_id');
        date_default_timezone_set('Asia/Kolkata');
        $updated_time = date('Y-m-d H:i:s');
        $enquiry_header_id = $this->request->getPost('enquiry_header_id');
        $er_det = $Enquiry_model->getEditRequestDetails($enquiry_header_id);
        $confirm_cs_id = $this->request->getPost('confirm_cs_id');
        $ext_det = $Enquiry_model->getExtensionDetailsbyid($confirm_cs_id);   
            
                $is_exist = $Enquiry_model->is_status_check_exist($enquiry_header_id,15);
                if(empty($is_exist)){
                    $status_det = $Enquiry_model->getstatusDetails($enquiry_header_id,14);                
                    $status_data = array(
                        'object_id' => $ext_det[0]['object_id'],
                        'enquiry_header_id' => $enquiry_header_id,
                        'current_status_id' => 15,
                        'updated_time' => $updated_time,
                        'assigned_to' => $status_det[0]['assigned_to'],
                        'assigned_status' => 1,
                        'edit_request_id' => $er_det[0]['enquiry_edit_request_id'],
                        'updated_by' => $user_id,
                        'enterprise_id' => 1                            
                    );
                    $status_insert = $Enquiry_model->insertEnquirystatus($status_data);

                    $is_sop_confirmed = $Enquiry_model->is_status_check_exist($enquiry_header_id,16);
                    if(!empty($is_sop_confirmed)){
                        $booked_status_data = array(
                            'object_id' => $ext_det[0]['object_id'],
                            'enquiry_header_id' => $enquiry_header_id,
                            'current_status_id' => 17,
                            'updated_time' => $updated_time,
                            'assigned_to' => $status_det[0]['assigned_to'],
                            'assigned_status' => 1,
                            'edit_request_id' => $er_det[0]['enquiry_edit_request_id'],
                            'updated_by' => $user_id,
                            'enterprise_id' => 1                            
                        );
                        $booked_status_insert = $Enquiry_model->insertEnquirystatus($booked_status_data);
                    }
                    echo 1;
                }
                else{
                    echo 0;
                }
    }
    public function get_vehicle_types_by_hub()
    {
        $Enquiry_model = new Enquiry_m();
        $hub_location_id = $this->request->getPost('hub_location_id');
        echo $Enquiry_model->getVehicleTypes($hub_location_id);
    }
}
