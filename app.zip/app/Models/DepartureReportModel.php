<?php

namespace App\Models;

use CodeIgniter\Model;

class DepartureReportModel extends Model
{
    protected $table = 'khm_obj_departure_follow_up';
    protected $primaryKey = 'departure_follow_up_id';
    protected $returnType = 'array';
    protected $allowedFields = [

        'followup_type_id',
        'enquiry_header_id',
        'call_date',
        'mode_of_departure',
        'city',
        'flight_train_no',
        'departure_date',
        'comments',
        'deleted',
        'enterprise_id',
    ];


    protected function baseQuery()
    {
        // 1) latest “departure” row per enquiry
        $latestDepartureSubquery = $this->db
            ->table('khm_obj_departure_follow_up')
            ->select('enquiry_header_id, MAX(departure_follow_up_id) AS latest_departure_id')
            ->where('deleted', 0)
            ->groupBy('enquiry_header_id');

        // 2) latest “call” row per enquiry, from the all_call_follow_up table, using call_time
        $latestCallSubquery = $this->db
            ->table('khm_obj_all_call_follow_up')
            ->select('enquiry_header_id, MAX(call_time) AS latest_call_time')
            ->where('followup_type_id', 10)
            ->groupBy('enquiry_header_id');

        return $this->db
            ->table('khm_obj_departure_follow_up AS dr')
            ->distinct()
            ->select([
                'dr.departure_follow_up_id',
                'dr.followup_type_id',
                'dr.enquiry_header_id',
                'dr.call_date',
                'dr.mode_of_departure',
                'dr.city',
                'dr.flight_train_no',
                'dr.departure_date',
                'dr.comments',
                'dr.deleted',
                'dr.enterprise_id',
                'eh.object_id',
                'om.object_name',
                'cf.call_time',
                'e11.entity_name',
                'e11.entity_id',
                'oeh.ref_no',
                'oeh.enq_type_id',
                'tf.driver_name  AS drivername',
                'tf.phone_number AS driverphone',


            ])
            // only the latest departure per enquiry
            ->join(
                "({$latestDepartureSubquery->getCompiledSelect()}) AS last_dep",
                'dr.departure_follow_up_id = last_dep.latest_departure_id',
                'inner'
            )
            ->join(
                'khm_obj_enquiry_header AS oeh',
                'oeh.enquiry_header_id=dr.enquiry_header_id',
                'left'
            )
            //trsansport
            ->join(
                'khm_obj_transport_follow_up AS tf',
                'tf.enquiry_header_id=oeh.enquiry_header_id',
                'left'
            )
            ->join(
                'khm_entity_mst AS em4',
                'em4.entity_id=tf.transporter_id',
                'left'
            )
            // ->where('tf.is_active', 1)
            // join header → object
            ->join(
                'khm_obj_enquiry_edit_request AS eer',
                'eer.enquiry_header_id=dr.enquiry_header_id',
                'left'
            )
            ->where('eer.is_active', 1)
            ->join(
                'khm_obj_enquiry_status AS s',
                's.edit_request_id=eer.enquiry_edit_request_id',
                'left'
            )
            ->where('s.current_status_id', 1)
            ->join(
                'khm_entity_mst AS e11',
                'e11.entity_id=s.assigned_to',
                'left'
            )

            ->join(
                'khm_obj_enquiry_header AS eh',
                'eh.enquiry_header_id = dr.enquiry_header_id',
                'left'
            )
            ->join(
                'khm_obj_mst AS om',
                'om.object_id = eh.object_id',
                'left'
            )
            // join latest call
            ->join(
                "({$latestCallSubquery->getCompiledSelect()}) AS last_call",
                'last_call.enquiry_header_id = dr.enquiry_header_id',
                'left'
            )
            ->join(
                'khm_obj_all_call_follow_up AS cf',
                'cf.enquiry_header_id    = last_call.enquiry_header_id
               AND cf.call_time         = last_call.latest_call_time
               AND cf.followup_type_id  = 10',
                'left'
            )

            //
            // ----- joins for vehicles & drivers -----
            //
            ->join(
                'khm_obj_enquiry_details AS ed',
                'ed.enquiry_header_id = dr.enquiry_header_id',
                'left'
            )

            //
            // ----- joins for “executive” -----
            //
            // pick only the “open” status row


            // only non-deleted departures
            ->where('dr.deleted', 0)

            // aggregate per departure row
            // ->groupBy('dr.departure_follow_up_id')

            ->orderBy('dr.departure_follow_up_id', 'DESC');
    }



    public function getByDateRange(string $fromYmd, string $toYmd, ?int $system = null): array
    {
        // 1) Start from your baseQuery()
        $qb = $this->baseQuery();

        // 2) If $system was passed (i.e. not null), add that WHERE clause first
        if ($system !== null && $system !== 0) {
            $qb->where('oeh.enq_type_id', $system);
        }

        // 3) Now add the date‐range filters on dr.departure_date
        $qb->where('dr.departure_date >=', $fromYmd)
            ->where('dr.departure_date <',  $toYmd);

        // 4) Finally, execute and return
        return $qb
            ->get()
            ->getResultArray();
    }



    public function getDepartureReport(): array
    {
        // simply returns everything (no date filter)
        return $this->baseQuery()
            ->get()
            ->getResultArray();
    }
}
