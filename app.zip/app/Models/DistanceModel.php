<?php

namespace App\Models;

use CodeIgniter\Model;

class DistanceModel extends Model
{
    protected $table      = 'khm_loc_mst_geography_distance';
    protected $primaryKey = 'geog_dist_id';
    protected $allowedFields = ['geog_from_id', 'geog_to_id', 'geog_km_distance'];
}
