<?php 

namespace App\Models;

use CodeIgniter\Model;

class ExecutiveFollowUpModel extends Model{
 
    protected $table ='khm_obj_executive_follow_up';
    protected $primaryKey='executive_follow_up_id';
    protected $allowedFields = [
        'followup_type_id',
        'enquiry_header_id',
        'contacted_person',
        'follow_up_time',
        'next_follow_up_time',
        'follow_up_type',
        'disposition',
        'remarks',
        'deleted',
        'enterprise_id'

    ];


    public function getExecutiveFollowUp($followupTypeId, $enquiryHeaderId){
        return $this->where('followup_type_id',$followupTypeId)
                    ->where('enquiry_header_id',$enquiryHeaderId)
                    ->where('deleted',0)
                    ->orderBy('executive_follow_up_id','DESC')

                    ->findAll();
    }

    public function saveExecutiveFollowUp($data)
    {
        return $this-> save($data);
    }

    public function sodtDelete($id)
    {
        return $this->update($id,['deleted'=> 1]);
    }



}


















?>