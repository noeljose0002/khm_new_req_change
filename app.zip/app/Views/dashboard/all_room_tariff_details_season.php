<?php
$tariff_datas = [];
foreach ($tariff_data as $item) {
    $roomId = $item['room_id'];
    if (!isset($tariff_datas[$roomId])) {
        $tariff_datas[$roomId] = [
            "room_category_name" => $item["room_category_name"],
            "room_category_id" => $item["room_category_id"],
            "room_type_name" => $item["room_type_name"],
            "room_id" => $item["room_id"],
            'max_occupancy'      => (int) $item['max_occupancy'],
            "enterprise_id" => $item["enterprise_id"]
        ];
    }
    $tariff_datas[$roomId]["meal_tariff"][] = [
        "hotel_room_meal_id" => $item["hotel_room_meal_id"],
        "meal_plan_id" => $item["meal_plan_id"],
        "meal_plan_name" => $item["meal_plan_name"],
        "tariff" => $item["tariff"]
    ];
}
$tariff_datas = array_values($tariff_datas);
?>
<style>
    .table td {
    padding: 0.2rem;
    vertical-align: top;
    border-top: 0;
}
input[type="date"],
		input[type="text"],
		label,
		select,
		option {
			font-size: 11px;
		}
</style>
<table class="table table-bordered table-responsive-md table-striped mb-0 text-nowrap">
	<tr>
		<td colspan ="2" style="background-color: #c2d6d6;text-align:center;font-weight: bold;">ROOM TYPE / TARIFFS</td>
		<td colspan ="2" style="background-color: #c2c2d6;text-align:center;font-weight: bold;">Dinner<input type="text" id="dinner1" class="form-control input-sm" value="0"></td>
        <td colspan ="2" style="background-color: #c2c2d6;text-align:center;font-weight: bold;">Lunch<input type="text" id="lunch1" class="form-control input-sm" value="0"></td>
        <td colspan ="2" style="background-color: #cccccc;text-align:center;font-weight: bold;">Dinner<input type="text" id="dinner2" class="form-control input-sm" value="0"></td>
        <td colspan ="2" style="background-color: #cccccc;text-align:center;font-weight: bold;">Lunch<input type="text" id="lunch2" class="form-control input-sm" value="0"></td>
        <td colspan ="2" style="background-color: #c2c2d6;text-align:center;font-weight: bold;">Dinner<input type="text" id="dinner3" class="form-control input-sm" value="0"></td>
        <td colspan ="2" style="background-color: #c2c2d6;text-align:center;font-weight: bold;">Lunch<input type="text" id="lunch3" class="form-control input-sm" value="0"></td>
        <td colspan ="2" style="background-color: #cccccc;text-align:center;font-weight: bold;">Dinner<input type="text" id="dinner4" class="form-control input-sm" value="0"></td>
    	<td colspan ="2" style="background-color: #cccccc;text-align:center;font-weight: bold;">Lunch<input type="text" id="lunch4" class="form-control input-sm" value="0"></td>
	</tr>
	<tr>
        <td rowspan ="2" style="background-color: #c2d6d6;text-align:center;font-weight: bold;">Room Category</td>
        <td rowspan ="2" style="background-color: #c2d6d6;text-align:center;font-weight: bold;">Room Type</td>
        <td colspan ="4" style="background-color: #c2c2d6;text-align:center;font-weight: bold;">Adult tariff</td>
        <td colspan ="4" style="background-color: #cccccc;text-align:center;font-weight: bold;">Child tariff with bed</td>
        <td colspan ="4" style="background-color: #c2c2d6;text-align:center;font-weight: bold;">Child tariff without bed</td>
    	<td colspan ="4" style="background-color: #cccccc;text-align:center;font-weight: bold;">Extra bed tariff</td>
    </tr>
    <tr>        
        <td style="background-color: #c2c2d6;text-align:center;font-weight: bold;">EP</td>
        <td style="background-color: #c2c2d6;text-align:center;font-weight: bold;">CP</td>
    	<td style="background-color: #c2c2d6;text-align:center;font-weight: bold;">MAP</td>
        <td style="background-color: #c2c2d6;text-align:center;font-weight: bold;">AP</td>

        <td style="background-color: #cccccc;text-align:center;font-weight: bold;">EP</td>
        <td style="background-color: #cccccc;text-align:center;font-weight: bold;">CP</td>
        <td style="background-color: #cccccc;text-align:center;font-weight: bold;">MAP</td>
    	<td style="background-color: #cccccc;text-align:center;font-weight: bold;">AP</td>

        <td style="background-color: #c2c2d6;text-align:center;font-weight: bold;">EP</td>
        <td style="background-color: #c2c2d6;text-align:center;font-weight: bold;">CP</td>
        <td style="background-color: #c2c2d6;text-align:center;font-weight: bold;">MAP</td>
        <td style="background-color: #c2c2d6;text-align:center;font-weight: bold;">AP</td>

        <td style="background-color: #cccccc;text-align:center;font-weight: bold;">EP</td>
        <td style="background-color: #cccccc;text-align:center;font-weight: bold;">CP</td>
        <td style="background-color: #cccccc;text-align:center;font-weight: bold;">MAP</td>
        <td style="background-color: #cccccc;text-align:center;font-weight: bold;">AP</td>
    </tr>
    <?php 
if (!empty($tariff_datas)) {
    foreach ($tariff_datas as $key => $val) { ?>
        <tr>
            <td><input type="checkbox" class="chk_room" value="<?php echo $val['room_id']; ?>"> <?php echo $val['room_category_name']; ?></td>
             <td>
                    <input
                        type="hidden"
                        id="rt<?= $val['room_id'] ?>"
                        value="<?= $val['room_type_name'] ?>">
                    <?= $val['room_type_name'] ?>
                    (max<?= isset($val['max_occupancy']) ? $val['max_occupancy'] : '–' ?>)
                </td>

            <?php 
                $index = 1;
                foreach ($val['meal_tariff'] as $key1 => $val1) { 
                    $id = "{$val1['meal_plan_name']}_{$index}_{$val['room_id']}";
                ?>
                    <td>
                        <input type="text" id="<?php echo $id; ?>" class="form-control input-sm meal_class mc<?php echo $val['room_id']; ?> ml<?php echo $val1['hotel_room_meal_id']; ?>" data-id="<?php echo $id; ?>" value="0" readonly>
                    </td>
                <?php 
                } 

                $index = 2;
                foreach ($val['meal_tariff'] as $key1 => $val1) { 
                    $id = "{$val1['meal_plan_name']}_{$index}_{$val['room_id']}";
                ?>
                    <td>
                        <input type="text" id="<?php echo $id; ?>" class="form-control input-sm meal_class mc<?php echo $val['room_id']; ?> ml<?php echo $val1['hotel_room_meal_id']; ?>" data-id="<?php echo $id; ?>" value="0" readonly>
                    </td>
                <?php 
                } 

                $index = 3;
                foreach ($val['meal_tariff'] as $key1 => $val1) { 
                    $id = "{$val1['meal_plan_name']}_{$index}_{$val['room_id']}";
                ?>
                    <td>
                        <input type="text" id="<?php echo $id; ?>" class="form-control input-sm meal_class mc<?php echo $val['room_id']; ?> ml<?php echo $val1['hotel_room_meal_id']; ?>" data-id="<?php echo $id; ?>" value="0" readonly>
                    </td>
                <?php 
                } 

                $index = 4;
                foreach ($val['meal_tariff'] as $key1 => $val1) { 
                    $id = "{$val1['meal_plan_name']}_{$index}_{$val['room_id']}";
                ?>
                    <td>
                        <input type="text" id="<?php echo $id; ?>" class="form-control input-sm meal_class mc<?php echo $val['room_id']; ?> ml<?php echo $val1['hotel_room_meal_id']; ?>" data-id="<?php echo $id; ?>" value="0" readonly>
                    </td>
                <?php 
                } 
                
            ?>
        </tr> 
<?php 
    } 
} 
?>
</table>
<br>
<button type="button" id="btn_save_all_tariff" class="btn btn-success" style="float:right;">Save All</button>
<span id="tariff-alert"></span>
<script>
    //nj//
$(document).ready(function () {
    $(document).on("input", '#dinner1', function () {
        var tariff_datas = <?php echo json_encode($tariff_datas); ?>;
        var dinnerValue = parseInt($(this).val()) || 0;
        //var lunchValue = parseInt($('#lunch1').val()) || 0;
        $.each(tariff_datas, function (index, data) {
            var room_id = data.room_id;
            var meal_id = data.meal_tariff[2]['hotel_room_meal_id'];
            var element_id = "MAP_1_"+room_id;
            var cp_id = "CP_1_"+room_id;
            var cpval = parseInt($('#'+cp_id).val()) || 0;
            var maxOcc     = parseInt(data.max_occupancy, 10) || 1;
            if(data.room_type_name == "Double"){
                $('#'+element_id).val((dinnerValue*maxOcc)+cpval);
            }
            else{
                $('#'+element_id).val(dinnerValue+cpval);
            }
        });   
    });
});
//nj//

$(document).ready(function () {
    $(document).on("input", '#dinner2', function () {
        var tariff_datas = <?php echo json_encode($tariff_datas); ?>;
        var dinnerValue = parseInt($(this).val()) || 0;
        //var lunchValue = parseInt($('#lunch2').val()) || 0;
        $.each(tariff_datas, function (index, data) {
            var room_id = data.room_id;
            var meal_id = data.meal_tariff[2]['hotel_room_meal_id'];
            var element_id = "MAP_2_"+room_id;
            var cp_id = "CP_2_"+room_id;
            var cpval = parseInt($('#'+cp_id).val()) || 0;
            if(data.room_type_name == "Double"){
                $('#'+element_id).val(dinnerValue+cpval);
            }
        });   
    });
});

$(document).ready(function () {
    $(document).on("input", '#dinner3', function () {
        var tariff_datas = <?php echo json_encode($tariff_datas); ?>;
        var dinnerValue = parseInt($(this).val()) || 0;
        //var lunchValue = parseInt($('#lunch3').val()) || 0;
        $.each(tariff_datas, function (index, data) {
            var room_id = data.room_id;
            var meal_id = data.meal_tariff[2]['hotel_room_meal_id'];
            var element_id = "MAP_3_"+room_id;
            var cp_id = "CP_3_"+room_id;
            var cpval = parseInt($('#'+cp_id).val()) || 0;
            if(data.room_type_name == "Double"){
                $('#'+element_id).val(dinnerValue+cpval);
            }
        });   
    });
});

$(document).ready(function () {
    $(document).on("input", '#dinner4', function () {
        var tariff_datas = <?php echo json_encode($tariff_datas); ?>;
        var dinnerValue = parseInt($(this).val()) || 0;
        //var lunchValue = parseInt($('#lunch4').val()) || 0;
        $.each(tariff_datas, function (index, data) {
            var room_id = data.room_id;
            var meal_id = data.meal_tariff[2]['hotel_room_meal_id'];
            var element_id = "MAP_4_"+room_id;
            var cp_id = "CP_4_"+room_id;
            var cpval = parseInt($('#'+cp_id).val()) || 0;
            if(data.room_type_name == "Double"){
                $('#'+element_id).val(dinnerValue+cpval);
            }
        });   
    });
});
</script>


<script>
$(document).ready(function () {
    $(document).on("input", '#lunch1', function () {
        var tariff_datas = <?php echo json_encode($tariff_datas); ?>;
        var lunchValue = parseInt($(this).val()) || 0;
        var dinnerValue = parseInt($('#dinner1').val()) || 0;
        $.each(tariff_datas, function (index, data) {
            var room_id = data.room_id;
            var meal_id = data.meal_tariff[3]['hotel_room_meal_id'];
            var element_id = "AP_1_"+room_id;
            var cp_id = "CP_1_"+room_id;
            var cpval = parseInt($('#'+cp_id).val()) || 0;
             var maxOcc     = parseInt(data.max_occupancy, 10) || 1;
            if(data.room_type_name == "Double"){
                var vals = (dinnerValue+lunchValue)*maxOcc;
                $('#'+element_id).val(vals+cpval);
            }
            else{
                $('#'+element_id).val(dinnerValue+lunchValue+cpval);
            }
        });   
    });
});

$(document).ready(function () {
    $(document).on("input", '#lunch2', function () {
        var tariff_datas = <?php echo json_encode($tariff_datas); ?>;
        var lunchValue = parseInt($(this).val()) || 0;
        var dinnerValue = parseInt($('#dinner2').val()) || 0;
        $.each(tariff_datas, function (index, data) {
            var room_id = data.room_id;
            var meal_id = data.meal_tariff[3]['hotel_room_meal_id'];
            var element_id = "AP_2_"+room_id;
            var cp_id = "CP_2_"+room_id;
            var cpval = parseInt($('#'+cp_id).val()) || 0;
            if(data.room_type_name == "Double"){
                $('#'+element_id).val(dinnerValue+lunchValue+cpval);
            }
        });   
    });
});

$(document).ready(function () {
    $(document).on("input", '#lunch3', function () {
        var tariff_datas = <?php echo json_encode($tariff_datas); ?>;
        var lunchValue = parseInt($(this).val()) || 0;
        var dinnerValue = parseInt($('#dinner3').val()) || 0;
        $.each(tariff_datas, function (index, data) {
            var room_id = data.room_id;
            var meal_id = data.meal_tariff[3]['hotel_room_meal_id'];
            var element_id = "AP_3_"+room_id;
            var cp_id = "CP_3_"+room_id;
            var cpval = parseInt($('#'+cp_id).val()) || 0;
            if(data.room_type_name == "Double"){
                $('#'+element_id).val(dinnerValue+lunchValue+cpval);
            }
        });   
    });
});

$(document).ready(function () {
    $(document).on("input", '#lunch4', function () {
        var tariff_datas = <?php echo json_encode($tariff_datas); ?>;
        var lunchValue = parseInt($(this).val()) || 0;
        var dinnerValue = parseInt($('#dinner4').val()) || 0;
        $.each(tariff_datas, function (index, data) {
            var room_id = data.room_id;
            var meal_id = data.meal_tariff[3]['hotel_room_meal_id'];
            var element_id = "AP_4_"+room_id;
            var cp_id = "CP_4_"+room_id;
            var cpval = parseInt($('#'+cp_id).val()) || 0;
            if(data.room_type_name == "Double"){
                $('#'+element_id).val(dinnerValue+lunchValue+cpval);
            }
        });   
    });
});
</script>
<script>
$(document).ready(function() {
  $(document).on("input", ".meal_class", function() {
    // 1) Load the data array
    var tariff_datas = <?php echo json_encode($tariff_datas, JSON_HEX_TAG); ?>;
    // 2) Parse this input’s ID
    var id    = $(this).data("id");        // e.g. "CP_1_8347"
    var parts = id.split("_");             // ["CP","1","8347"]
    if (parts[0] !== "CP") return;         // only handle CP inputs

    var part        = parts[1];            // "1", "2", etc.
    var room_id     = parts[2];            // the room’s ID
    var cpvalue     = parseInt($("#"+id).val(), 10)       || 0;
    var dinnerValue = parseInt($("#dinner"+part).val(), 10) || 0;
    var lunchValue  = parseInt($("#lunch" +part).val(), 10) || 0;

    // 3) Find this room’s object to get its max occupancy
    var roomData = tariff_datas.find(function(d) {
      return d.room_id.toString() === room_id.toString();
    }) || {};

    var occ    = parseInt(roomData.max_occupancy, 10);
    var maxOcc = (isNaN(occ) || occ < 1) ? 1 : occ;

<<<<<<< .mine
    // 4) Build your target IDs
    var map_id = "MAP_" + part + "_" + room_id;
    var ap_id  = "AP_"  + part + "_" + room_id;
    var cp_id  = "CP_"  + part + "_" + room_id;

    // 5) Calculate using maxOcc
    if (part == 1) {
      // adult rows
      var totalMAP = (dinnerValue * maxOcc) + cpvalue;
      var totalAP  = ((dinnerValue + lunchValue) * maxOcc) + cpvalue;

      $("#" + map_id).val(totalMAP);
      $("#" + ap_id).val(totalAP);
      $("#" + cp_id).val(cpvalue);
    } else {
      // other parts: update only checked “Double” rooms
      tariff_datas.forEach(function(data) {
        if (data.room_type_name === "Double" &&
            $(".chk_room[value='" + data.room_id + "']").is(":checked")) {

          var occ2    = parseInt(data.max_occupancy, 10);
          var maxOcc2 = (isNaN(occ2) || occ2 < 1) ? 1 : occ2;

          var map_ids = "MAP_" + part + "_" + data.room_id;
          var ap_ids  = "AP_"  + part + "_" + data.room_id;
          var cp_ids  = "CP_"  + part + "_" + data.room_id;

          $("#" + map_ids).val((dinnerValue * maxOcc2) + cpvalue);
          $("#" + ap_ids).val(((dinnerValue + lunchValue) * maxOcc2) + cpvalue);
          $("#" + cp_ids).val(cpvalue);
||||||| .r1102
                        $('#' + map_ids).val(dinnerValue + cpvalue);
                        $('#' + ap_ids).val(dinnerValue + lunchValue + cpvalue);
                        $('#' + cp_ids).val(cpvalue);
                    }
                }
            });
=======
    // 4) Build your target IDs
    var map_id = "MAP_" + part + "_" + room_id;
    var ap_id  = "AP_"  + part + "_" + room_id;
    var cp_id  = "CP_"  + part + "_" + room_id;

    // 5) Calculate using maxOcc
    if (part == 1) {
      // adult rows
      var totalMAP = (dinnerValue * maxOcc) + cpvalue;
      var totalAP  = ((dinnerValue + lunchValue) * maxOcc) + cpvalue;

      $("#" + map_id).val(totalMAP);
      $("#" + ap_id).val(totalAP);
      $("#" + cp_id).val(cpvalue);
    } else {
      // other parts: update only checked “Double” rooms
      tariff_datas.forEach(function(data) {
        if (data.room_type_name === "Double" &&
            $(".chk_room[value='" + data.room_id + "']").is(":checked")) {

          var occ2    = parseInt(data.max_occupancy, 10);
          var maxOcc2 = (isNaN(occ2) || occ2 < 1) ? 1 : occ2;

          var map_ids = "MAP_" + part + "_" + data.room_id;
          var ap_ids  = "AP_"  + part + "_" + data.room_id;
          var cp_ids  = "CP_"  + part + "_" + data.room_id;

          $("#" + map_ids).val((dinnerValue * maxOcc2) + cpvalue);
          $("#" + ap_ids).val(((dinnerValue + lunchValue) * maxOcc2) + cpvalue);
          $("#" + cp_ids).val(cpvalue);
                }
            });
>>>>>>> .r1119
        
      });
    }
  });
});
</script>

</script>
<script>
<<<<<<< .mine
   // $(document).ready(function() {

    //     $('.chk_room').on('change', function() {
    //         var roomId = $(this).val();
    //         var isChecked = $(this).is(':checked'); // Check if the checkbox is checked
    //         $('.mc' + roomId).prop('readonly', !isChecked);
    //         $('.wmc' + roomId).prop('readonly', !isChecked);
    //     });
    // });

    //NJ//
    $(document).ready(function () {
    var tariff_datas = <?php echo json_encode($tariff_datas); ?>;

    $('.chk_room').on('change', function () {
||||||| .r1102
    $(document).ready(function() {
        
    $('.chk_room').on('change', function() {
=======
   // $(document).ready(function() {
        
    //     $('.chk_room').on('change', function() {
    //         var roomId = $(this).val();
    //         var isChecked = $(this).is(':checked'); // Check if the checkbox is checked
    //         $('.mc' + roomId).prop('readonly', !isChecked);
    //         $('.wmc' + roomId).prop('readonly', !isChecked);
    //     });
    // });

    //NJ//
    $(document).ready(function () {
    var tariff_datas = <?php echo json_encode($tariff_datas); ?>;

    $('.chk_room').on('change', function () {
>>>>>>> .r1119
        var roomId = $(this).val(); 
        var isChecked = $(this).is(':checked');

        // Find the room's data
        var roomData = tariff_datas.find(function (d) {
            return d.room_id.toString() === roomId.toString();
        });

        // Weekday fields (normal)
        $('.mc' + roomId).each(function () {
            var id = $(this).attr('id');  // e.g., CP_2_8833
            var parts = id.split('_');
            var part = parseInt(parts[1]); // 1=Adult, 2=Child with bed, 3=Child without bed, 4=Extra bed

            let makeReadonly = !isChecked || (roomData.room_type_name === 'Single' && part !== 1);
            $(this).prop('readonly', makeReadonly);
        });

        // Weekend fields
        $('.wmc' + roomId).each(function () {
            var id = $(this).attr('id');  // e.g., WCP_2_8833
            var parts = id.split('_');
            var part = parseInt(parts[1]); // 1=Adult, 2=Child with bed, 3=Child without bed, 4=Extra bed

            let makeReadonly = !isChecked || (roomData.room_type_name === 'Single' && part !== 1);
            $(this).prop('readonly', makeReadonly);
        });
    });
});

    ///
</script>
<script>
$(document).ready(function () {
    $(document).on("click", '#btn_save_all_tariff', function () {
        var object_id = "<?php echo $object_id; ?>";
        var tariff_datas = <?php echo json_encode($tariff_datas); ?>;
        var season_id = $('#season_id').val();
        var room_id;
        var ep_adult;
        var ep_child;
        var ep_child_wb;
        var ep_extra;
        var tariff = 0;
        var child_tariff =0;
        var child_wb_tariff=0;
        var extra_tariff =0;
        var flag = 0;
        var dinner_adult = $('#dinner1').val();
        var lunch_adult = $('#lunch1').val();
        var dinner_child = $('#dinner2').val();
        var lunch_child = $('#lunch2').val();
        var dinner_child_wb = $('#dinner3').val();
        var lunch_child_wb = $('#lunch3').val();
        var dinner_extra = $('#dinner4').val();
        var lunch_extra = $('#lunch4').val();
		if(season_id == '' || season_id == null || season_id == 'undefined'){
			alert("Please select Season");
		}
        else{
            $.each(tariff_datas, function (index, data) {
                room_id = data.room_id;

                for(var i = 0; i < 4; i++){
                    var hotel_room_meal_id = data.meal_tariff[i]['hotel_room_meal_id'];
                    if(i == 0){
                        ep_adult = "EP_1_"+room_id;
                        ep_child = "EP_2_"+room_id;
                        ep_child_wb = "EP_3_"+room_id;
                        ep_extra = "EP_4_"+room_id;
                    }
                    if(i == 1){
                        ep_adult = "CP_1_"+room_id;
                        ep_child = "CP_2_"+room_id;
                        ep_child_wb = "CP_3_"+room_id;
                        ep_extra = "CP_4_"+room_id;
                    }
                    if(i == 2){
                        ep_adult = "MAP_1_"+room_id;
                        ep_child = "MAP_2_"+room_id;
                        ep_child_wb = "MAP_3_"+room_id;
                        ep_extra = "MAP_4_"+room_id;
                    }
                    if(i == 3){
                        ep_adult = "AP_1_"+room_id;
                        ep_child = "AP_2_"+room_id;
                        ep_child_wb = "AP_3_"+room_id;
                        ep_extra = "AP_4_"+room_id;
                    }

                    tariff = $('#'+ep_adult).val();
                    child_tariff = $('#'+ep_child).val();
                    child_wb_tariff = $('#'+ep_child_wb).val();
                    extra_tariff = $('#'+ep_extra).val();

                    $.ajax({
                            url: '<?=site_url('Dashboard/saveRoomfunctionSeason');?>',
                            method: 'POST',
                            data: {
                                object_id:object_id,
                                hotel_room_meal_id:hotel_room_meal_id,
                                tariff:tariff,
                                season_id:season_id,
                                child_tariff:child_tariff,
                                child_wb_tariff:child_wb_tariff,
                                extra_tariff:extra_tariff,
                                dinner_adult:dinner_adult,
                                lunch_adult:lunch_adult,
                                dinner_child:dinner_child,
                                lunch_child:lunch_child,
                                dinner_child_wb:dinner_child_wb,
                                lunch_child_wb:lunch_child_wb,
                                dinner_extra:dinner_extra,
                                lunch_extra:lunch_extra
                            },
                            dataType: 'json',
                            success: function (response) {
                                if(response.status === 1){
                                    var alerttHTML = `<div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <span class="alert-inner--icon"><i class="fe fe-info"></i></span>
                                        <span class="alert-inner--text">Tariff Updated</span>
                                        <button type="button" class="close text-white" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>`;

                                    $('#tariff-alert').html(alerttHTML);
                                    setTimeout(function () {
                                        $(".alert").fadeOut("slow", function () {
                                            $(this).remove();
                                        });
                                    }, 2000);
                                }
                                else{
                                    alert("Tariff not saved. Please try again.");
                                }
                            },
                            error: function (xhr, status, error) {
                                console.error('Error adding node:', error);
                            }
                    });
                }
            });  
          
         } 
    });
});
</script>