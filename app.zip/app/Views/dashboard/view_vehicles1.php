<!doctype html>
<html lang="en" dir="ltr">
	<head>

		<!-- Meta data -->
		<meta charset="UTF-8">
		<meta http-equiv="x-ua-compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta content="Dashlot - Bootstrap Responsive Admin panel Dashboard Template Ui Kit & Premium Dashboard Design Modern Flat HTML Template. This Template Includes 100 HTML Pages & 40+ Plugins. No Need to do hard work for this template customization." name="description">
		<meta content="Spruko Technologies Private Limited" name="author">
		<meta name="keywords" content="admin,dashboard,dashboard template,bootstrap dashboard template,bootstrap admin template,admin panel template,admin dashboard template,admin template,admin dashboard,bootstrap 4 admin template,bootstrap dashboard,bootstrap simple dashboard,bootstrap 4 dashboard template,modern admin,bootstrap admin panel,best admin templates,bootstrap admin dashboard template,simple admin panel template,html admin template,simple bootstrap admin template,bootstrap admin dashboard,adminlte template,html dashboard template,responsive admin template,admin dashboard bootstrap 4,admin panel design,bootstrap admin,web dashboard,user dashboard,bootstrap 4 dashboard,bootstrap admin panel template,simple dashboard html template">

		<!-- Favicon-->
		<link rel="icon" href="<?php echo base_url('assets/images/brand/favicon.png'); ?>" type="image/x-icon"/>

		<!-- Title -->
		<title>KHM Dashboard</title>

		<!-- Bootstrap css -->
		<link href="<?php echo base_url('assets/plugins/bootstrap-4.1.3/css/bootstrap.min.css'); ?>" rel="stylesheet" />

		<!-- Style css -->
		<link  href="<?php echo base_url('assets/css/style.css'); ?>" rel="stylesheet" />

		<!-- Default css -->
		<link href="<?php echo base_url('assets/css/default.css'); ?>" rel="stylesheet">

		<!-- Sidemenu css-->
		<link rel="stylesheet" href="<?php echo base_url('assets/plugins/sidemenu/icon-sidemenu.css'); ?>">

		<!-- Owl-carousel css-->
		<link href="<?php echo base_url('assets/plugins/owl-carousel/owl.carousel.css'); ?>" rel="stylesheet" />

		<!-- Bootstrap-daterangepicker css -->
		<link rel="stylesheet" href="<?php echo base_url('assets/plugins/bootstrap-daterangepicker/daterangepicker.css'); ?>">

		<!-- Bootstrap-datepicker css -->
		<link rel="stylesheet" href="<?php echo base_url('assets/plugins/bootstrap-datepicker/bootstrap-datepicker.css'); ?>">

		<!-- Custom scroll bar css -->
		<link href="<?php echo base_url('assets/plugins/scroll-bar/jquery.mCustomScrollbar.css'); ?>" rel="stylesheet"/>

		<!-- P-scroll css -->
		<link href="<?php echo base_url('assets/plugins/p-scroll/p-scroll.css'); ?>" rel="stylesheet" type="text/css">

		<link href="<?php echo base_url('assets/plugins/datatable/dataTables.bootstrap4.min.css'); ?>" rel="stylesheet" />


		<!-- Font-icons css -->
		<link  href="<?php echo base_url('assets/css/icons.css'); ?>" rel="stylesheet">

		<!-- Rightsidebar css -->
		<link href="<?php echo base_url('assets/plugins/sidebar/sidebar.css'); ?>" rel="stylesheet">

		<!-- Nice-select css  -->
		<link href="<?php echo base_url('assets/plugins/jquery-nice-select/css/nice-select.css'); ?>" rel="stylesheet"/>

		<!-- Color-palette css-->
		<link rel="stylesheet" href="<?php echo base_url('assets/css/skins.css'); ?>"/>
	<style>
		.modal-dialog-custom {
    max-width: 90%;
    width: 1200px; /* Adjust as needed */
    margin: auto;
}

.modal-content {
    overflow: hidden; /* Prevents overflow of content */
    max-width: 100%; /* Ensures the content does not exceed the modal width */
    box-sizing: border-box; /* Ensures padding and border are included in the width */
}

.modal-footer {
    display: flex;
    justify-content: flex-end; /* Align buttons to the right */
    padding: 15px; /* Add appropriate padding */
    border-top: 1px solid #dee2e6; /* Optional: Add a top border for separation */
    width: 100%; /* Ensure the footer fits within the modal */
    box-sizing: border-box; /* Prevents overflow due to padding */
}

	
	</style>
	</head>

	<body class="app sidebar-mini">	

		<!-- Loader -->
		<div id="loading">
			<img src="<?php echo base_url('assets/images/other/loader.svg'); ?>" class="loader-img" alt="Loader">
		</div>
		
		<!-- PAGE -->
		<div class="page">
			<div class="page-main">

				<!-- Top-header opened -->
				<div class="header-main header sticky">
					<div class="app-header header top-header navbar-collapse ">
						<div class="container-fluid">
							<div class="d-flex">
								<a class="header-brand" href="index.html">
									<img src="<?php echo base_url('assets/images/brand/logo.png'); ?>" class="header-brand-img desktop-logo " alt="Dashlot logo">
									<img src="<?php echo base_url('assets/images/brand/logo1.png'); ?>" class="header-brand-img desktop-logo-1 " alt="Dashlot logo">
									<img src="<?php echo base_url('assets/images/brand/favicon.png'); ?>" class="mobile-logo" alt="Dashlot logo">
									<img src="<?php echo base_url('assets/images/brand/favicon1.png'); ?>" class="mobile-logo-1" alt="Dashlot logo">
								</a>
								<a href="#" data-toggle="sidebar" class="nav-link icon toggle"><i class="fe fe-align-justify fs-20"></i></a>
								<div class="d-flex header-left left-header">
									<div class="d-none d-lg-block horizontal">
										<ul class="nav">
											<li class="">
												<div class="dropdown d-none d-md-flex">
													<a href="#" class="d-flex nav-link pr-0  pt-2 mt-3 country-flag1" data-toggle="dropdown">
														<!--<span class="d-flex"><img src="<?php echo base_url('assets/images/us_flag.jpg'); ?>" alt="img" class="avatar country-Flag mr-2 align-self-center"></span>-->
														<div>
															<span class="d-flex fs-14 mr-3 mt-0">System<span><i class="mdi mdi-chevron-down"></i></span></span>
														</div>
													</a>
													<div class="dropdown-menu dropdown-menu-left dropdown-menu-arrow">
														<a href="#" class="dropdown-item d-flex align-items-center mt-2">
															<!--<img src="<?php echo base_url('assets/images/french_flag.jpg'); ?>" alt="flag-img" class="w-6 flag-sm mr-3 align-self-center">-->
															<div>
																<span>B2B</span>
															</div>
														</a>
														<a href="#" class="dropdown-item d-flex align-items-center">
															<!--<img src="<?php echo base_url('assets/images/germany_flag.jpg'); ?>" alt="flag-img" class="w-6 flag-sm mr-3 align-self-center">-->
															<div>
																<span>B2C</span>
															</div>
														</a>
													</div>
												</div>
											</li>
										</ul>
									</div>
								</div>
								<div class="d-flex header-right ml-auto">
									<div class="dropdown header-fullscreen">
										<a class="nav-link icon full-screen-link" id="fullscreen-button">
											<i class="mdi mdi-arrow-collapse fs-20"></i>
										</a>
									</div>

									<div class="dropdown drop-profile">
										<a class="nav-link pr-0 leading-none" href="#" data-toggle="dropdown" aria-expanded="false">
											<div class="profile-details mt-1">
												<span class="mr-3 mb-0  fs-15 font-weight-semibold"><?php echo session('user_name'); ?></span>
												<!--<small class="text-muted mr-3">appdeveloper</small>-->
											</div>
											<img class="avatar avatar-md brround" src="<?php echo base_url('assets/images/users/user.png'); ?>" alt="image">
										 </a>
										<div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow animated bounceInDown w-250">
											<div class="user-profile bg-header-image border-bottom p-3">
												<div class="user-image text-center">
													<img class="user-images" src="<?php echo base_url('assets/images/users/user.png'); ?>" alt="image">
												</div>
												<div class="user-details text-center">
													<h4 class="mb-0"><?php echo session('user_name'); ?></h4>
													<!--<p class="mb-1 fs-13 text-white-50">Jonathan@gmail.com</p>-->
												</div>
											</div>
											<a class="dropdown-item" href="#">
												<i class="dropdown-icon mdi mdi-account-outline "></i> Profile
											</a>
											<a class="dropdown-item" href="#">
												<i class="dropdown-icon  mdi mdi-settings"></i> Settings
											</a>
											<a class="dropdown-item" href="#">
												<span class="float-right"><span class="badge badge-success">6</span></span>
												<i class="dropdown-icon mdi  mdi-message-outline"></i> Inbox
											</a>
											<a class="dropdown-item" href="#">
												<i class="dropdown-icon mdi mdi-comment-check-outline"></i> Message
											</a>
											<div class="dropdown-divider"></div>
											<a class="dropdown-item" href="#">
												<i class="dropdown-icon mdi mdi-compass"></i> Need help?
											</a>
											<a class="dropdown-item mb-1" href="<?=site_url('Login/logout');?>">
												<i class="dropdown-icon mdi  mdi-logout-variant"></i> Sign out
											</a>
										</div>
									</div><!-- Profile -->
									<!--<div class="sidebar-link">
										<a href="#" class="nav-link icon" data-toggle="sidebar-right" data-target=".sidebar-right">
											<i class="fe fe-align-right" ></i>
										</a>
									</div>-->
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Top-header closed -->

				<!-- Sidebar menu-->
				<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
				<aside class="app-sidebar toggle-sidebar">
					<div class="app-sidebar__user">
						<div class="user-body">
							<img src="<?php echo base_url('assets/images/users/user.png'); ?>" alt="profile-img" class="rounded-circle w-25">
						</div>
						<div class="user-info">
							<a href="#" class=""><span class="app-sidebar__user-name font-weight-semibold"><?php echo session('user_name'); ?></span><br>
							<!--span class="text-muted app-sidebar__user-designation text-sm">App Developer</span>-->
							</a>
						</div>
					</div>
					<ul class="side-menu toggle-menu">
						<?php foreach($parent_menu as $key1 => $val1){ 
							$img_tmp = $val1['entity_trans_id'].".svg";
							?>
							<li class="slide">
								<a class="side-menu__item"  data-toggle="slide" href=""><span class="icon-menu-img"><img src="<?php echo base_url('assets/images/svgs/'.$img_tmp); ?>" class="side_menu_img svg-1" alt="image"></span><span class="side-menu__label"><?php echo $val1['entity_trans_name']; ?></span><i class="angle fa fa-angle-right"></i></a>
								<ul class="slide-menu">
									<?php foreach($sub_menu as $key2 => $val2){ 
										if($val1['entity_trans_id'] == $val2['prs_parent_id']){
											foreach($all_menus as $key3 => $val3){
												if($val3['entity_trans_id'] == $val2['entity_trans_id']){
										?>
											<li><a class="slide-item" href="<?=site_url($val2['menu_link']);?>"><span><?php echo $val2['entity_trans_name']; ?></span></a></li>
									<?php } } } } ?>
								</ul>
							</li>
						<?php } ?>
					</ul>
				</aside>
				<!-- Sidemenu closed -->

				<!-- App-content opened -->
				<div class="app-content icon-content">
					<div class="section">

						<!-- Page-header opened -->
						<div class="page-header">
							<div class="page-leftheader">
								<h4 class="page-title mb-0"><?php echo $object_class_name; ?></h4>
								<small class="text-muted mt-0 fs-14">View / Add / Edit <?php echo $object_class_name; ?> Details</small>
							</div>

                            

							<div class="page-rightheader">
								<div class="ml-3 ml-auto d-flex">
									<!--<div class="mt-3 mt-md-0">
										<div class="border-right pr-4 mt-1 d-xl-block">
											<p class="text-muted mb-2">Category</p>
											<h6 class="font-weight-semibold mb-0">All Categories</h6>
										</div>
									</div>
									<div class="mt-3 mt-md-0">
										<div class="border-right pl-0 pl-md-4 pr-4 mt-1 d-xl-block">
											<p class="text-muted mb-1">Customer Rating</p>
											<div class="wideget-user-rating">
												<a href="#">
													<i class="fa fa-star text-warning"></i>
												</a>
												<a href="#">
													<i class="fa fa-star text-warning"></i>
												</a>
												<a href="#">
													<i class="fa fa-star text-warning"></i>
												</a>
												<a href="#">
													<i class="fa fa-star text-warning"></i>
												</a>
												<a href="#">
													<i class="fa fa-star-o text-warning mr-1"></i>
												</a>
												<span class="">(4.5/5)</span>
											</div>
										</div>
									</div>-->
									<span class="mt-3 mt-md-0 pg-header">
										<a href="<?=site_url('Dashboard/add_object/'.$object_class_id);?>" class="btn btn-success ml-0 ml-md-4 mt-1 "><i class="typcn typcn-plus mr-1"></i>Create New</a>
									</span>
								</div>
							</div>
						</div>
						<!-- Page-header closed -->

						<div class="row">
							<div class="col-md-12 col-lg-12">
								<div class="card">
									
									<div class="card-body">
										<div class="table-responsive product-datatable">
											<table id="example" class="table table-striped table-bordered " >
												<thead>
													<tr>
														<th class="w-15p"><?php echo $object_class_name; ?> Name</th>
													
														<th class="wd-10p">Action</th>
													</tr>
												</thead>
												<tbody>
													<?php foreach($vehicle_list as $key => $val) { ?>
														<tr>
															<td><?php echo $val['object_name']; ?></td>
														
															<!--<td><span class="badge badge-danger-light badge-md">Stock</span></td>-->
															<td>
																
																
																<?php if(!empty($all_permissions)){ 
																	foreach($all_permissions as $key1 => $val1){
																		if($val1['pro_permission_id'] == 2){
																	?>
																	<a class="btn btn-info btn-sm mb-2 mb-xl-0 text-white" data-toggle="tooltip" data-original-title="Edit" href="<?=site_url('Dashboard/add_object/'.$object_class_id.'/'.$val['object_id']);?>"><i class="fa fa-edit"></i></a>
																	<?php } 
																	if($val1['pro_permission_id'] == 5){
																	?>
																	<a class="btn btn-danger btn-sm mb-2 mb-xl-0 text-white" data-toggle="tooltip" data-original-title="Delete"><i class="fa fa-trash-o"></i></a>
																	<?php } 
																	if($val1['pro_permission_id'] == 3){
																	?>
																	<a class="btn btn-info btn-sm mb-2 mb-xl-0 text-white" data-toggle="tooltip" data-original-title="View"><i class="fa fa-eye"></i></a>
																	<?php } 
																	if($val1['pro_permission_id'] == 4){
																	?>
																	<a class="btn btn-info btn-sm mb-2 mb-xl-0 text-white" data-toggle="tooltip" data-original-title="Print"><i class="fa fa-print"></i></a>
																	<?php } ?>

																<?php } } ?>	
															</td>
														</tr>
													<?php } ?>
												</tbody>
											</table>
										</div>
									</div>
									<!-- table-wrapper -->
								</div>
								<!-- section-wrapper -->
							</div>
						</div>
					</div>
				</div>
				<!-- App-content closed -->
			</div>

			<!-- Right-sidebar-->
			
			<!-- Right-sidebar-closed -->

			<!-- Footer opened -->
			<footer class="footer-main icon-footer">
				<div class="container">
					<div class="  mt-2 mb-2 text-center">
						Copyright © 2025 <a href="#" class="fs-14 text-primary">KHM</a>. Designed by <a href="https://megatrendkms.co.in" class="fs-14 text-primary" target="_blank">Megatrend Knowledge Management Systems Pvt Ltd</a> All rights reserved.
					</div>
				</div>
			</footer>
			<!-- Footer closed -->
		</div>

		<!-- Back-to-top -->
		<a href="#top" id="back-to-top"><i class="fa fa-angle-double-up"></i></a>

		<!-- Jquery-scripts -->
		<script src="<?php echo base_url('assets/js/vendors/jquery-3.2.1.min.js'); ?>"></script>

		<!-- Moment js-->
        <script src="<?php echo base_url('assets/plugins/moment/moment.min.js'); ?>"></script>

		<!-- Bootstrap-scripts js -->
		<script src="<?php echo base_url('assets/js/vendors/bootstrap.bundle.min.js'); ?>"></script>

		<!-- Sparkline JS-->
		<script src="<?php echo base_url('assets/js/vendors/jquery.sparkline.min.js'); ?>"></script>

		<!-- Bootstrap-daterangepicker js -->
		<script src="<?php echo base_url('assets/plugins/bootstrap-daterangepicker/daterangepicker.js'); ?>"></script>

		<!-- Bootstrap-datepicker js -->
		<script src="<?php echo base_url('assets/plugins/bootstrap-datepicker/bootstrap-datepicker.js'); ?>"></script>

		<!-- Chart-circle js -->
		<script src="<?php echo base_url('assets/js/vendors/circle-progress.min.js'); ?>"></script>

		<!-- Rating-star js -->
		<script src="<?php echo base_url('assets/plugins/rating/jquery.rating-stars.js'); ?>"></script>

		<!-- Clipboard js -->
		<script src="<?php echo base_url('assets/plugins/clipboard/clipboard.min.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/clipboard/clipboard.js'); ?>"></script>

		<!-- Prism js -->
		<script src="<?php echo base_url('assets/plugins/prism/prism.js'); ?>"></script>

		<!-- Custom scroll bar js-->
		<script src="<?php echo base_url('assets/plugins/scroll-bar/jquery.mCustomScrollbar.concat.min.js'); ?>"></script>

		<!-- Nice-select js-->
		<script src="<?php echo base_url('assets/plugins/jquery-nice-select/js/jquery.nice-select.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/jquery-nice-select/js/nice-select.js'); ?>"></script>

        <!-- P-scroll js -->
		<script src="<?php echo base_url('assets/plugins/p-scroll/p-scroll.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/p-scroll/p-scroll-1.js'); ?>"></script>

		<!-- Sidemenu js-->
		<script src="<?php echo base_url('assets/plugins/sidemenu/icon-sidemenu.js'); ?>"></script>

		<!-- JQVMap -->
		<script src="<?php echo base_url('assets/plugins/jqvmap/jquery.vmap.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/jqvmap/maps/jquery.vmap.world.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/jqvmap/jquery.vmap.sampledata.js'); ?>"></script>

		<!-- Apexchart js-->
		<script src="<?php echo base_url('assets/js/apexcharts.js'); ?>"></script>

		<!-- Chart js-->
		<script src="<?php echo base_url('assets/plugins/chart/chart.min.js'); ?>"></script>

		<!-- Index js -->
		<script src="<?php echo base_url('assets/js/index.js'); ?>"></script>
		<script src="<?php echo base_url('assets/js/index-map.js'); ?>"></script>

		<!-- Rightsidebar js -->
		<script src="<?php echo base_url('assets/plugins/sidebar/sidebar.js'); ?>"></script>

		<!-- Custom js -->
		<script src="<?php echo base_url('assets/js/custom.js'); ?>"></script>

	

		

		<!-- Bootstrap-colorpicker js -->
		<script src="<?php echo base_url('assets/plugins/bootstrap-colorpicker/bootstrap-colorpicker.min.js'); ?>"></script>

		<!-- Bootstrap-timepicker js -->
		<script src="<?php echo base_url('assets/plugins/bootstrap-timepicker/bootstrap-timepicker.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/select2/select2.full.min.js'); ?>"></script>
		<script src="<?php echo base_url('assets/js/select2.js'); ?>"></script>



		<script src="<?php echo base_url('assets/plugins/datatable/jquery.dataTables.min.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/datatable/dataTables.bootstrap4.min.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/datatable/datatable.js'); ?>"></script>

	</body>
</html>
<script type="text/javascript">
    $(document).on('click', '.room_category', function(e) {
        e.preventDefault();
        var hotel_id = $(this).attr('data-id');
		var hotel_name = $(this).attr('data-id-name');
		var object_id = $(this).attr('data-id-object');
		room_category_datatable(hotel_id);
    });

	$(document).on('click', '#btn_room_cat', function (e) {
        e.preventDefault();
		var hotel_id = $('#hd_hotel_id').val();
		var room_category_id = $('#hd_room_category_id').val();
		if(room_category_id == '' || room_category_id == null || room_category_id == 'undefined'){
            alert("Please select Room Category");
		}
		else{
				$.ajax({
					url: '<?=site_url('Dashboard/addnewRoomCategory');?>',
					method: 'POST',
					data: {
						hotel_id:hotel_id,
                		room_category_id: room_category_id
					},
					dataType: 'json',
					success: function (response) {
						if(response > 0){
							alert("Room Category Added");
							room_category_datatable(hotel_id);
						}
						else{
							alert("Room Category Already Exist");
						}
					},
					error: function (xhr, status, error) {
						console.error('Error adding node:', error);
					}
				});
			}
    	});

	function room_category_datatable(hotel_id){
		if ($.fn.DataTable.isDataTable('#table_room_category')) {
            $('#table_room_category').DataTable().destroy();
        }
        var table = $('#table_room_category').DataTable({
            'processing': true,
            'serverSide': true,
            'serverMethod': 'post',
            'ajax': {
                'url': '<?=site_url('Dashboard/room_category_modal');?>',
                'data': {
                    'hotel_id': hotel_id
                }
            },
            'columns': [
            
            {
                data: 'room_category_name'
            },
            {
                data: 'room_category_id',
                render: function (data, type, row, meta) {
                    if (data) {
                		return '<i class="fa fa-edit" style="color: #1760de; padding-right:10px;" type="button" onclick="fetchData(' + data + ');clear_or_cancel(); " title="Role Edit"></i>';
                    } else {
                        return '';
                    }
                }
            }
            ],
			paging: true, // Ensure paging is enabled
    		pageLength: 10, // Number of rows per page
    		lengthMenu: [5, 10, 25, 50], // Options for rows per page
    		order: [[0, 'asc']] // Default sorting
        });
        /*$('#refreshButton').on('click', function() {
            table.ajax.reload();
        });*/
        $('#hd_hotel_id').val(hotel_id);
        $('#roomcatmodal').modal('show');
	}
</script>