																				<table class="table table-bordered table-responsive-md table-striped mb-0 text-nowrap">
																					<tr style="background-color:#c8ead9;">
																						<th class="">Category</th>
																						<th class="">Room type</th>
																						<th class="">Occupancy</th>
																						<th class="">EP</th>
																						<th class="">CP</th>
																						<th class="">MAP</th>
																						<th class="">AP</th>
																						<th class="">Action</th>
																					</tr>
																					<?php 
																					if(!empty($tariff_data)){
																					
																					foreach($tariff_data as $key => $val){ ?>
																						<tr>
																							<td class="pt-3-half"><?php echo $val['room_category_name']; ?></td>
																							<td class="pt-3-half"><?php echo $val['room_type_name']; ?></td>
																							<td class="pt-3-half"><?php echo $val['occupancy_name']; ?></td>
																							<?php if(!empty($tariff_exist)){ 
																								$ep_temp = 0;
																								$cp_temp = 0;
																								$map_temp = 0;
																								$ap_temp = 0;
																								foreach($tariff_exist as $key1 => $val1){ 
																									if($val['room_id'] == $val1['room_id']){
																										if($val1['meal_plan_id'] == 1){
																											$ep_temp = $val1['tariff'];
																										}
																										if($val1['meal_plan_id'] == 2){
																											$cp_temp = $val1['tariff'];
																										}
																										if($val1['meal_plan_id'] == 3){
																											$map_temp = $val1['tariff'];
																										}
																										if($val1['meal_plan_id'] == 4){
																											$ap_temp = $val1['tariff'];
																										}												
																									}
																								}	
																									?>
																									
																								<td class="pt-3-half"><input type="text" class="form-control input-sm" id="ep<?php echo $val['room_id']; ?>" value="<?php echo $ep_temp; ?>" style="width:90px;" inputmode="numeric" pattern="[0-9]*" maxlength="6" oninput="this.value = this.value.replace(/\D/g, '')"></td>
																								
																								
																								<td class="pt-3-half"><input type="text" class="form-control input-sm" id="cp<?php echo $val['room_id']; ?>" value="<?php echo $cp_temp; ?>" style="width:90px;" inputmode="numeric" pattern="[0-9]*" maxlength="6" oninput="this.value = this.value.replace(/\D/g, '')"></td>
																								
																								
																								<td class="pt-3-half"><input type="text" class="form-control input-sm" id="map<?php echo $val['room_id']; ?>" value="<?php echo $map_temp; ?>" style="width:90px;" inputmode="numeric" pattern="[0-9]*" maxlength="6" oninput="this.value = this.value.replace(/\D/g, '')"></td>
																							
																									
																									<td class="pt-3-half"><input type="text" class="form-control input-sm" id="ap<?php echo $val['room_id']; ?>" value="<?php echo $ap_temp; ?>" style="width:90px;" inputmode="numeric" pattern="[0-9]*" maxlength="6" oninput="this.value = this.value.replace(/\D/g, '')"></td>
																							<?php   }else { ?>
																								<td class="pt-3-half"><input type="text" class="form-control input-sm" id="ep<?php echo $val['room_id']; ?>" value="" style="width:90px;" inputmode="numeric" pattern="[0-9]*" maxlength="6" oninput="this.value = this.value.replace(/\D/g, '')"></td>
																								<td class="pt-3-half"><input type="text" class="form-control input-sm" id="cp<?php echo $val['room_id']; ?>" value="" style="width:90px;" inputmode="numeric" pattern="[0-9]*" maxlength="6" oninput="this.value = this.value.replace(/\D/g, '')"></td>
																								<td class="pt-3-half"><input type="text" class="form-control input-sm" id="map<?php echo $val['room_id']; ?>" value="" style="width:90px;" inputmode="numeric" pattern="[0-9]*" maxlength="6" oninput="this.value = this.value.replace(/\D/g, '')"></td>
																								<td class="pt-3-half"><input type="text" class="form-control input-sm" id="ap<?php echo $val['room_id']; ?>" value="" style="width:90px;" inputmode="numeric" pattern="[0-9]*" maxlength="6" oninput="this.value = this.value.replace(/\D/g, '')"></td>
																							<?php } ?>
																								
																							<td>
																								<button type="button" class="btn btn-dark btn-rounded btn-sm my-0" onclick="save_room(<?php echo $val['room_id']; ?>)" data-bs-toggle="tooltip" data-bs-placement="top" title="Update"><i class="fa fa-save"></i></button>
																								<button type="button" class="btn btn-danger btn-rounded btn-sm my-0" onclick="delete_room(<?php echo $val['room_id']; ?>)" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"><i class="fa fa-trash"></i></button>
																							</td>
																						</tr>
																					<?php } } else { ?>
																						<tr>
																							<td colspan="8" style="text-align:center;">No rooms added yet</td>
																						</tr>
																					<?php } ?>
																				</table>
																				