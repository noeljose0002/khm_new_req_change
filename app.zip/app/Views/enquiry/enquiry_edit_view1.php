<?php 
$first = false;
$second = false;
$third = false;
$fourth = false;
foreach ($enq_det as $enq) { 
    $object_name = $enq['object_name'] ?? '';
    $enquiry_header_id = $enq['enquiry_header_id'] ?? '';
	if($enquiry_header_id){
    	$first = true;
	}

    if (!empty($enq['enq_details'])) {
        foreach ($enq['enq_details'] as $enq_detail) {
            $enquiry_details_id = $enq_detail['enquiry_details_id'] ?? '';
			if($enquiry_details_id){
            	$second = true;
			}

            if (!empty($enq_detail['tour_details'])) {
                foreach ($enq_detail['tour_details'] as $tour_detail) {
                    $tour_details_id = $tour_detail['tour_details_id'] ?? '';
					if($tour_details_id){
                    	$third = true;
					}

                    if (!empty($tour_detail['iti_details'])) {
                        

                        foreach ($tour_detail['iti_details'] as $iti) {
							
                            $itinerary_details_id = $iti['itinerary_details_id'] ?? '';
							if($itinerary_details_id){
								$fourth = true;
							}
                            $is_draft = $iti['is_draft'];
                            $is_active = $iti['is_active'];
                            $updated_time = $iti['updated_time'];
?>
<tr>
    <td><?php echo $first ? $enquiry_header_id : ''; ?></td>
	<?php if($second){ ?>
    	<td><a href="<?=site_url('Enquiry/add_object_enquiry/'); ?><?php echo $object_class_id; ?>/<?php echo $object_id; ?>" data-toggle="tooltip" data-original-title="Enquiry Edit"><i class="fa fa-edit" aria-hidden="true" style="color:#339966"></i></a></td>
	<?php } else { ?>
		<td></td>
	<?php } ?>
    <td><?php echo $third ? $tour_details_id : ''; ?></td>
    <td><?php echo $fourth ? $itinerary_details_id : ''; ?></td>
   
</tr>
<?php
                            $first = false;
                            $second = false;
                            $third = false;
                            $fourth = false;
                        }
                    }
					$first = false;
                    $second = false;
                    $third = false;
                    $fourth = false;
                }
            }
			$first = false;
            $second = false;
            $third = false;
            $fourth = false;
        }
    }
	$first = false;
    $second = false;
    $third = false;
    $fourth = false;
}
?>