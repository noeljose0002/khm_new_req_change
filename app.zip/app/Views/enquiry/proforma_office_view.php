<?php
    $vehicle_list = '';
    if($cdata[0]['is_vehicle_required'] == 1){
        $vehicles = json_decode($cdata[0]['vehicle_type_id'], true);
        foreach($vehicles as $vehicle){
            $vehicle_list.=$vehicle['vehicle_model_name']." ";
        }
    }
?>
    <textarea name="proforma_office_template" id="proforma_office_template" style="width:100%; height:1000px;"> 
        <div class="container" id="printcontent" style="border: 1px solid black; padding: 10px;">

                    <table style="width:100%;border-collapse: collapse;">  
                         
                                 <tr>
                                    <td style="text-align:center;" colspan="2"><b>Proforma Invoice - (Office Copy)</b></td>
                                </tr>
                          
                          
                                <tr>
                                    <td style="width:50%;"><b>Order No: </b><?php echo $cdata[0]['ref_no']; ?></td>
                                    <td rowspan="3" style="text-align:right;width:50%;"><img src="<?php echo base_url('assets/images/photos/logo_touracle.png');?>"></td>
                                </tr>
                                <tr>
                                    <td><b>Date : </b><?php echo date("d-m-y"); ?></td>
                                </tr>
                                <tr>    
                                    <td>GSTIN Reg No: 32AADCK1388D1ZV</td>
                                </tr>
                                <tr>
                                    <td><b>Executive: </b><?php echo $cdata[0]['executive_name']; ?></td>
                                </tr>
                                <tr>
                                    <td><b>Sales Operation Executive : </b><?php echo $cdata[0]['sop_name']; ?></td>
                                </tr>
                                <tr>
                                    <td><b>Check In : </b><?php echo $cdata[0]['date_of_tour_start']; ?></td>
                                </tr>
                                <tr>
                                    <td><b>Check Out : </b><?php echo $cdata[0]['date_of_tour_completion']; ?></td>
                                </tr>
                            
                    </table>
                
                    <table style="width:100%;border-collapse: collapse;border: 1px solid black;">  
                         
                                 <tr>
                                    <td style="text-align:left;border: 1px solid black;width:50%;">
                                        <b><i>To, </i></b><br>
                                            <?php 
                                            if($cdata[0]['enq_type_id'] == 3){
                                                $a_addresses = json_decode($cdata[0]['agent_address'], true);
	                                            $a_address = is_array($a_addresses) && count($a_addresses) > 0 ? $a_addresses[0] : '';
                                                $a_emails = json_decode($cdata[0]['agent_email'], true);
	                                            $a_email = is_array($a_emails) && count($a_emails) > 0 ? $a_emails[0] : '';
                                                echo $cdata[0]['agent_name'];
                                                echo $a_address;
                                                echo $a_email;
                                                echo $cdata[0]['gstin'];
                                            }
                                            else{
                                                $g_addresses = json_decode($cdata[0]['guest_address'], true);
	                                            $g_address = is_array($g_addresses) && count($g_addresses) > 0 ? $g_addresses[0] : '';
                                                echo $cdata[0]['guest_name'];
                                                echo $g_address;
                                            } 
                                        ?>
                                    
                                    </td>
                                    <td style="text-align:left;border: 1px solid black;width:50%;">
                                        <b><i>Guest Name: </i></b>
                                        <?php 
                                            if($cdata[0]['enq_type_id'] == 3){
                                                $g_addresses = json_decode($cdata[0]['guest_address'], true);
	                                            $g_address = is_array($g_addresses) && count($g_addresses) > 0 ? $g_addresses[0] : '';
                                                echo $cdata[0]['guest_name'];
                                                echo $g_address;
                                            }
                                            else{
                                            } 
                                        ?>
                                        </p>
                                    </td>
                                </tr>
                           
                    </table>

                    <table style="width:100%;border-collapse: collapse;border: 1px solid black;">  
                           
                                <tr>
                                    <td style="background-color:#4baf58;color:#fff;border:1px solid black;"><b>Si No</b></td>
                                    <td style="background-color:#4baf58;color:#fff;border:1px solid black;"><b>Particulars</b></td>
                                    <td style="background-color:#4baf58;color:#fff;border:1px solid black;"><b>Amount</b></td>
                                </tr>
                           
                          
                                <tr>
                                    <td style="border:1px solid black;"><b><i>1</i><b></td>
                                    <td style="border:1px solid black;"><b><i>Package</i><b></td>
                                    <td style="border:1px solid black;"><b><i>Rs.<?php echo $cdata[0]['tpc']; ?></i><b></td>
                                </tr>
                                <tr>
                                    <td rowspan="8" style="border:1px solid black;"></td>
                                    <td style="border:1px solid black;">&nbsp;No of Adults : </td>
                                    <td style="border:1px solid black;">&nbsp;<?php echo $cdata[0]['no_of_adult']; ?></td>
                                </tr>
                                <tr>  
                                    <td style="border:1px solid black;">&nbsp;No of Child with bed : </td>
                                    <td style="border:1px solid black;">&nbsp;<?php echo $cdata[0]['no_of_child_with_bed']; ?></td>
                                </tr>
                                <tr>
                                    <td style="border:1px solid black;">&nbsp;No of Child without bed  : </td> 
                                    <td style="border:1px solid black;">&nbsp;<?php echo $cdata[0]['no_of_child_without_bed']; ?></td>
                                </tr>
                            
                                <tr>
                                    <td style="border:1px solid black;">&nbsp;No of Double Rooms  : </td>   
                                    <td style="border:1px solid black;">&nbsp;<?php echo $cdata[0]['no_of_double_room']; ?></td>
                                </tr>
                                <tr>
                                    <td style="border:1px solid black;">&nbsp;No of Single Rooms : </td>
                                    <td style="border:1px solid black;">&nbsp;<?php echo $cdata[0]['no_of_single_room']; ?></td>
                                </tr>
                                <tr>
                                    <td style="border:1px solid black;">&nbsp;No of Extra Rooms : </td>
                                    <td style="border:1px solid black;">&nbsp;<?php echo $cdata[0]['no_of_extra_bed']; ?></td>
                                </tr>
                                <?php if($cdata[0]['is_vehicle_required'] == 1) { ?>
                                    <tr>
                                        <td style="border:1px solid black;">&nbsp;Vehicle : </td>
                                        <td style="border:1px solid black;">&nbsp;<?php echo $vehicle_list; ?></td>
                                    </tr>
                                <?php } ?>
                            
                    </table>
                    <?php 
                      $nop = 0;
                      if($cdata[0]['no_of_adult'] > 0){
                        $nop = $nop  + 1;
                      }
                      if($cdata[0]['no_of_child_with_bed'] > 0){
                        $nop = $nop  + 1;
                      }
                      if($cdata[0]['no_of_child_without_bed'] > 0){
                        $nop = $nop  + 1;
                      }
                      if($cdata[0]['no_of_extra_bed'] > 0){
                        $nop = $nop  + 1;
                      }
                    ?>
                    <table style="width:100%;border-collapse: collapse;border: 1px solid black;">  
                            <thead>
                                 <tr>
                                    <td style="text-align:center;background-color:#4baf58;color:#fff;border:1px solid black;" colspan="19"><b>Accomodation</b></td>
                                </tr>
                                <tr>
                                    <td rowspan="9" style="border:1px solid black;"><b>Day</b></td>
                                    <td rowspan="9" style="border:1px solid black;"><b>Check In</b></td>
                                    <td rowspan="9" style="border:1px solid black;"><b>Check Out</b></td>
                                    <td rowspan="9" style="border:1px solid black;"><b>Place</b></td>
                                    <td rowspan="9" style="border:1px solid black;"><b>Hotel</b></td>
                                    <td rowspan="9" style="border:1px solid black;"><b>Category</b></td>
                                    <td rowspan="9" style="border:1px solid black;"><b>Food Plan</b></td>
                                    <td rowspan="9" style="border:1px solid black;"><b>No:Of Rooms</b></td>
                                    <td rowspan="9" style="border:1px solid black;"><b>Room Type</b></td>
                                    <td colspan="<?php echo $nop; ?>" style="text-align:center;"><b>No Of Pax</b></td>
                                    <td colspan="<?php echo $nop; ?>" style="text-align:center;"><b>Rate</b></td>
                                    <td rowspan="2" style="border:1px solid black;"><b>Total</b></td>
                                    <td rowspan="2" style="border:1px solid black;"><b>ITC</b></td>
                                </tr>
                                <tr>
                                    <?php if($cdata[0]['no_of_adult'] > 0){ ?>
                                        <td style="border:1px solid black;"><b>Adult</b></td>
                                    <?php } ?>
                                    <?php if($cdata[0]['no_of_child_with_bed'] > 0){ ?>
                                        <td style="border:1px solid black;"><b>Child</b></td>
                                    <?php } ?>
                                    <?php if($cdata[0]['no_of_child_without_bed'] > 0){ ?>
                                        <td style="border:1px solid black;"><b>Child WB</b></td>
                                    <?php } ?>
                                    <?php if($cdata[0]['no_of_extra_bed'] > 0){ ?>
                                        <td style="border:1px solid black;"><b>Extra</b></td>
                                    <?php } ?>
                                    
                                    <?php if($cdata[0]['no_of_adult'] > 0){ ?>
                                        <td style="border:1px solid black;"><b>Adult</b></td>
                                    <?php } ?>
                                    <?php if($cdata[0]['no_of_child_with_bed'] > 0){ ?>
                                        <td style="border:1px solid black;"><b>Child</b></td>
                                    <?php } ?>
                                    <?php if($cdata[0]['no_of_child_without_bed'] > 0){ ?>
                                        <td style="border:1px solid black;"><b>Child WB</b></td>
                                    <?php } ?>
                                    <?php if($cdata[0]['no_of_extra_bed'] > 0){ ?>
                                        <td style="border:1px solid black;"><b>Extra</b></td>
                                    <?php } ?>
                                </tr>
                               
                            </thead>
                           <tbody>
                            <?php 
                            $k = 1;
                            $sum = 0;
                        
                            foreach($tour_plan as $key => $val) { 
                                foreach($val['cost'] as $tkey => $tval){
                                    if($tval['cost_component_id'] == 6 && $tval['room_type_id'] == 2){
                                        $d_adult = $tval['quick_quote_tariff'];
                                    }
                                    if($tval['cost_component_id'] == 12 && $tval['room_type_id'] == 2){
                                        $d_child = $tval['quick_quote_tariff'];
                                    }
                                    if($tval['cost_component_id'] == 15 && $tval['room_type_id'] == 2){
                                        $d_child_wb = $tval['quick_quote_tariff'];
                                    }
                                    if($tval['cost_component_id'] == 9 && $tval['room_type_id'] == 2){
                                        $d_extra = $tval['quick_quote_tariff'];
                                    }

                                    if($tval['cost_component_id'] == 6 && $tval['room_type_id'] == 1){
                                        $s_adult = $tval['quick_quote_tariff'];
                                    }
                                    if($tval['cost_component_id'] == 12 && $tval['room_type_id'] == 1){
                                        $s_child = $tval['quick_quote_tariff'];
                                    }
                                    if($tval['cost_component_id'] == 15 && $tval['room_type_id'] == 1){
                                        $s_child_wb = $tval['quick_quote_tariff'];
                                    }
                                    if($tval['cost_component_id'] == 9 && $tval['room_type_id'] == 1){
                                        $s_extra = $tval['quick_quote_tariff'];
                                    }
                                }

                                $rlen = 0;
                                if($val['no_of_double_room'] > 0){
                                    $rlen = $rlen + 1;
                                }
                                if($val['no_of_single_room'] > 0){
                                    $rlen = $rlen + 1;
                                }
                                if($val['is_own_arrangement'] == 1) { ?>
                                    <tr><td style="border:1px solid black;"><?php echo $k++; ?></td>
                                    <td style="border:1px solid black;"><?php echo date("d-m-Y", strtotime($val['check_in_date'])); ?></td>
                                    <td style="border:1px solid black;">Own Arrangements</td></tr> <?php
                                }
                                else {
                                    $sdate = $val['check_in_date'];
                                    $edate = $val['check_out_date'];
                                    $hname = $val['object_name'];
                                    $cat = $val['room_category_name'];
                                    $meals = $val['meal_plan_name'];
                                    ?>
                                        <tr>
                                            <td rowspan="<?php echo $rlen; ?>" style="border:1px solid black;"><?php echo $k++; ?></td>
                                            <td rowspan="<?php echo $rlen; ?>" style="border:1px solid black;"><?php echo date("d-m-Y", strtotime($sdate)); ?></td>
                                            <td rowspan="<?php echo $rlen; ?>" style="border:1px solid black;"><?php echo date("d-m-Y", strtotime($edate)); ?></td>
                                            <td rowspan="<?php echo $rlen; ?>" style="border:1px solid black;"><?php echo $val['geog_name']; ?></td>
                                            <td rowspan="<?php echo $rlen; ?>" style="border:1px solid black;"><?php echo $hname; ?></td>
                                            <td rowspan="<?php echo $rlen; ?>" style="border:1px solid black;"><?php echo $cat; ?></td>
                                            <td rowspan="<?php echo $rlen; ?>" style="border:1px solid black;"><?php echo $meals; ?></td>
                                            <?php
                                            if($val['no_of_double_room'] > 0) {  
                                            ?>   
                                                <td style="border:1px solid black;"><?php echo $val['no_of_double_room']; ?></td>
                                                <td style="border:1px solid black;">Double</td>
                                                <?php if($val['no_of_adult'] > 0){ ?>
                                                    <td style="border:1px solid black;"><?php echo $val['no_of_adult']; ?></td>
                                                <?php } ?>
                                                <?php if($val['no_of_child_with_bed'] > 0){ ?>
                                                    <td style="border:1px solid black;"><?php echo $val['no_of_child_with_bed']; ?></td>
                                                <?php } ?>
                                                <?php if($val['no_of_child_without_bed'] > 0){ ?>
                                                    <td style="border:1px solid black;"><?php echo $val['no_of_child_without_bed']; ?></td>
                                                <?php } ?>
                                                <?php if($val['no_of_extra_bed'] > 0){ ?>
                                                    <td style="border:1px solid black;"><?php echo $val['no_of_extra_bed']; ?></td>
                                                <?php } ?>

                                                <?php if($cdata[0]['no_of_adult'] > 0){ ?>
                                                    <td style="border:1px solid black;"><?php echo $d_adult; ?></td>
                                                <?php } ?>
                                                <?php if($cdata[0]['no_of_child_with_bed'] > 0){ ?>
                                                    <td style="border:1px solid black;"><?php echo $d_child; ?></td>
                                                <?php } ?>
                                                <?php if($cdata[0]['no_of_child_without_bed'] > 0){ ?>
                                                    <td style="border:1px solid black;"><?php echo $d_child_wb; ?></td>
                                                <?php } ?>
                                                <?php if($cdata[0]['no_of_extra_bed'] > 0){ ?>
                                                    <td style="border:1px solid black;"><?php echo $d_extra; ?></td>
                                                <?php } ?>
                                               
                                                    <td rowspan="2" style="border:1px solid black;">0</td>
                                                    <td rowspan="2" style="border:1px solid black;">0</td>
                                                </tr>
                                            <?php 
                                            } 
                                            if($val['no_of_single_room'] > 0) {
                                            ?>
                                            <tr>
                                             <td style="border:1px solid black;"><?php echo $val['no_of_single_room']; ?></td>
                                                <td style="border:1px solid black;">Single</td>
                                                <?php if($val['no_of_adult'] > 0){ ?>
                                                    <td style="border:1px solid black;"><?php echo $val['no_of_adult']; ?></td>
                                                <?php } ?>
                                                <?php if($val['no_of_child_with_bed'] > 0){ ?>
                                                    <td style="border:1px solid black;"><?php echo $val['no_of_child_with_bed']; ?></td>
                                                <?php } ?>
                                                <?php if($val['no_of_child_without_bed'] > 0){ ?>
                                                    <td style="border:1px solid black;"><?php echo $val['no_of_child_without_bed']; ?></td>
                                                <?php } ?>
                                                <?php if($val['no_of_extra_bed'] > 0){ ?>
                                                    <td style="border:1px solid black;"><?php echo $val['no_of_extra_bed']; ?></td>
                                                <?php } ?>

                                                <?php if($cdata[0]['no_of_adult'] > 0){ ?>
                                                    <td style="border:1px solid black;"><?php echo $s_adult; ?></td>
                                                <?php } ?>
                                                <?php if($cdata[0]['no_of_child_with_bed'] > 0){ ?>
                                                    <td style="border:1px solid black;"><?php echo $s_child; ?></td>
                                                <?php } ?>
                                                <?php if($cdata[0]['no_of_child_without_bed'] > 0){ ?>
                                                    <td style="border:1px solid black;"><?php echo $s_child_wb; ?></td>
                                                <?php } ?>
                                                <?php if($cdata[0]['no_of_extra_bed'] > 0){ ?>
                                                    <td style="border:1px solid black;"><?php echo $s_extra; ?></td>
                                                <?php } ?>
                                               
                                                    
                                        </tr> <?php
                                } 
                            } } ?>
                           </tbody>
                        </table>
                        
                       
                        <?php if($cdata[0]['is_vehicle_required'] == 1) { ?>
                        <table style="width:100%;border-collapse: collapse;border: 1px solid black;">  
                          
                                 <tr>
                                    <td style="text-align:center;background-color:#4baf58;color:#fff;border:1px solid black;" colspan="14"><b>Transportation</b></td>
                                </tr>
                                <tr>
                                    <td style="border:1px solid black;"><b>Si No</b></td>
                                    <td style="border:1px solid black;"><b>Check In</b></td>
                                    <td style="border:1px solid black;"><b>Check Out</b></td>
                                    <td style="border:1px solid black;"><b>No Of Days</b></td>
                                    <td style="border:1px solid black;"><b>Vehicle</b></td>
                                    <td style="border:1px solid black;"><b>Transporter</b></td>
                                    <td style="border:1px solid black;"><b>Max KM</b></td>
                                    <td style="border:1px solid black;"><b>Total KM</b></td>
                                    <td style="border:1px solid black;"><b>Extra KM</b></td>
                                    <td style="border:1px solid black;"><b>Extra KM Rate</b></td>
                                    <td style="border:1px solid black;"><b>Extra Km Cost</b></td>
                                    <td style="border:1px solid black;"><b>Others</b></td>
                                    <td style="border:1px solid black;"><b>Cost</b></td>
                                    <td style="border:1px solid black;"><b>Total</b></td>
                                </tr>
                           
                          
                                <?php 
                                $vehs = json_decode($cdata[0]['vehicle_details'], true);
                                foreach($vehs as $vkey => $vval) { ?>
                                    <tr>
                                        <td style="border:1px solid black;"><?php echo $vkey+1; ?></td>
                                        <td style="border:1px solid black;"><?php echo date("d-m-Y", strtotime($cdata[0]['date_of_tour_start'])); ?></td>
                                        <td style="border:1px solid black;"><?php echo date("d-m-Y", strtotime($cdata[0]['date_of_tour_completion'])); ?></td>
                                        <td style="border:1px solid black;"><?php echo $cdata[0]['no_of_night']; ?></td>
                                        <td style="border:1px solid black;"><?php echo $vval['vehicle_model']; ?></td>
                                        <td style="border:1px solid black;"></td>
                                        <td style="border:1px solid black;"><?php echo $vval['max_km_day']; ?></td>
                                        <td style="border:1px solid black;"><?php echo $vval['travel_distance']; ?></td>
                                        <td style="border:1px solid black;"><?php echo $vval['extra_kilometer']; ?></td>
                                        <td style="border:1px solid black;"><?php echo $vval['extra_km_rate']; ?></td>
                                        <td style="border:1px solid black;">0</td>
                                        <td style="border:1px solid black;">0</td>
                                        <td style="border:1px solid black;"><?php echo $vval['veh_total']; ?></td>
                                        <td style="border:1px solid black;"><?php echo $vval['veh_total']; ?></td>
                                    </tr>
                                <?php } ?>
                           
                        </table>
                        <?php } ?>
                       
                     


                        <table style="width:100%;border-collapse: collapse;border: 1px solid black;">  
                                <tr>
                                    <b></i>Narration</i></b>
                                </tr>
                                <tr>
                                    <td style="border: 1px solid black;"colspan="2"><p></p></td>
                                </tr>
                                <tr>
                                    <td style="text-align:center;border: 1px solid black;background-color:#4baf58;color:#fff;"><b>Summary</b></td>
                                    <td style="text-align:center;border: 1px solid black;background-color:#4baf58;color:#fff;"><b>Amount</b></td>
                                </tr>
                                <tr>
                                    <td style="text-align:left;border: 1px solid black;">Accommodation</td>
                                    <td style="text-align:right;border: 1px solid black;"><?php echo $cdata[0]['tac']; ?></td>
                                </tr>
                                <tr>
                                    <td style="text-align:left;border: 1px solid black;">Transportation</td>
                                    <td style="text-align:right;border: 1px solid black;"><?php echo $cdata[0]['ttc']; ?></td>
                                </tr>
                             
                                <tr>
                                    <td style="text-align:left;border: 1px solid black;">Total Net Rate (Cost of Sales)</td>
                                    <td style="text-align:right;border: 1px solid black;"><?php echo $cdata[0]['tnr']; ?></td>
                                </tr>
                              
                                <tr>
                                    <td style="text-align:left;border: 1px solid black;">Total (Taxable Sales Total)</td>
                                    <td style="text-align:right;border: 1px solid black;"><?php echo $cdata[0]['total_rate']; ?></td>
                                </tr>
                                <tr>
                                    <td style="text-align:left;border: 1px solid black;">GST (Tax)</td>
                                    <td style="text-align:right;border: 1px solid black;"><?php echo $cdata[0]['gst_value']; ?></td>
                                </tr>
                                <tr>
                                    <td style="text-align:left;border: 1px solid black;">Grand Total (Sale Value)</td>
                                    <td style="text-align:right;border: 1px solid black;"><?php echo round($cdata[0]['tpc'],2); ?></td>
                                </tr>
                                <tr>
                                    <td style="text-align:right;border: 1px solid black;" colspan="2"><b> Gross Amount (Sale Value): <?php echo $cdata[0]['tpc']; ?></b></td>
                                </tr>
                           
                        </table>

                       
                        </div>
                    
    </textarea>
<script>
$(document).ready(function() {
    tinyMCE.init({
        mode: "exact",
        elements: "proforma_office_template",  // The ID of your textarea element
        readonly : true,
        setup: function(ed) {
            ed.onInit.add(function(ed) {
                // TinyMCE has been initialized
               
            });
        }
    });
});
</script> 