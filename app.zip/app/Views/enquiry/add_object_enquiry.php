<?php 
$edit_id = $edit_id?$edit_id:0;
$agent_state_id = $agent_state_id?$agent_state_id:0;
$agentid = $agentid?$agentid:0;
if($edit_id > 0){
	$read_only = "readonly";
	$dis_abled = 'style="pointer-events: none; background-color: #eee;"';

	if($enquiry_source == 1){
		$email_sel = "selected";
		$ref_sel = "";
		$phone_sel = "";
		$oth_sel = "";
	}
	if($enquiry_source == 2){
		$email_sel = "";
		$ref_sel = "selected";
		$phone_sel = "";
		$oth_sel = "";
	}
	if($enquiry_source == 3){
		$email_sel = "";
		$ref_sel = "";
		$phone_sel = "selected";
		$oth_sel = "";
	}
	if($enquiry_source == 4){
		$email_sel = "";
		$ref_sel = "";
		$phone_sel = "";
		$oth_sel = "selected";
	}
	if($is_vehicle_required == 1){
		$vyes_sel = "selected";
		$vno_sel = "";
	}
	if($is_vehicle_required == 0){
		$vyes_sel = "";
		$vno_sel = "selected";
	}
	if($is_sight_seeing_required == 1){
		$syes_sel = "selected";
		$sno_sel = "";
	}
	if($is_sight_seeing_required == 0){
		$syes_sel = "";
		$sno_sel = "selected";
	}
	if($is_quick_quote == 1){
		$qyes_sel = "selected";
		$qno_sel = "";
	}
	if($is_quick_quote == 0){
		$qyes_sel = "";
		$qno_sel = "selected";
	}
}
else{
	$read_only = "";
	$dis_abled = "";
	$email_sel = "";
	$ref_sel = "";
	$phone_sel = "";
	$oth_sel = "";
	$vyes_sel = "";
	$vno_sel = "";
	$syes_sel = "";
	$sno_sel = "";
	$qyes_sel = "";
	$qno_sel = "";
}

$js_arrival_options = '';
foreach ($arrival_locations as $aloc) {
    $geog_id = htmlspecialchars($aloc['geog_id'], ENT_QUOTES);
    $geog_name = htmlspecialchars($aloc['geog_name'], ENT_QUOTES);
    $js_arrival_options .= "<option value='{$geog_id}'>{$geog_name}</option>";
}
$js_departure_options = '';
foreach ($departure_locations as $dloc) {
    $geog_id = htmlspecialchars($dloc['geog_id'], ENT_QUOTES);
    $geog_name = htmlspecialchars($dloc['geog_name'], ENT_QUOTES);
    $js_departure_options .= "<option value='{$geog_id}'>{$geog_name}</option>";
}
?>
<!doctype html>
<html lang="en" dir="ltr">
	<head>

		<!-- Meta data -->
		<meta charset="UTF-8">
		<meta http-equiv="x-ua-compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta content="KHM-Touracle" name="description">
		<meta content="Megatrend Knowledge Management Systems Pvt Ltd" name="author">
		<meta name="keywords" content="KHM">
		<!-- Favicon-->
		<link rel="icon" href="<?php echo base_url('assets/images/brand/favicon.png'); ?>" type="image/x-icon"/>

		<!-- Title -->
		<title>KHM - Enquiry</title>

		<!-- Bootstrap css -->
		<link href="<?php echo base_url('assets/plugins/bootstrap-4.1.3/css/bootstrap.min.css'); ?>" rel="stylesheet" />

		<!-- Style css -->
		<link href="<?php echo base_url('assets/css/style.css'); ?>" rel="stylesheet" />

		<!-- Default css -->
		<link href="<?php echo base_url('assets/css/default.css'); ?>" rel="stylesheet">

		<!-- Sidemenu css-->
		<link rel="stylesheet" href="<?php echo base_url('assets/plugins/sidemenu/icon-sidemenu.css'); ?>">

		<!-- Owl-carousel css-->
		<link href="<?php echo base_url('assets/plugins/owl-carousel/owl.carousel.css'); ?>" rel="stylesheet" />

		<!-- Bootstrap-daterangepicker css -->
		<link rel="stylesheet" href="<?php echo base_url('assets/plugins/bootstrap-daterangepicker/daterangepicker.css'); ?>">

		<!-- Bootstrap-datepicker css -->
		<link rel="stylesheet" href="<?php echo base_url('assets/plugins/bootstrap-datepicker/bootstrap-datepicker.css'); ?>">

		<!-- Custom scroll bar css -->
		<link href="<?php echo base_url('assets/plugins/scroll-bar/jquery.mCustomScrollbar.css'); ?>" rel="stylesheet"/>

		<!-- Sidemenu-repsonsive-tabs  css -->
		<link href="<?php echo base_url('assets/plugins/sidemenu-responsive-tabs/css/sidemenu-responsive-tabs.css'); ?>" rel="stylesheet">

		<!-- P-scroll css -->
		<link href="<?php echo base_url('assets/plugins/p-scroll/p-scroll.css'); ?>" rel="stylesheet" type="text/css">

		<!-- Font-icons css -->
		<link  href="<?php echo base_url('assets/css/icons.css'); ?>" rel="stylesheet">

		<!-- Rightsidebar css -->
		<link href="<?php echo base_url('assets/plugins/sidebar/sidebar.css'); ?>" rel="stylesheet">

		<!-- Data table css -->
		<link href="<?php echo base_url('assets/plugins/datatable1/css/dataTables.bootstrap4.min.css'); ?>" rel="stylesheet"/>
		<link href="<?php echo base_url('assets/plugins/datatable1/css/buttons.bootstrap4.min.css'); ?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/plugins/datatable1/responsive.bootstrap4.min.css'); ?>" rel="stylesheet"/>

		<!-- Nice-select css  -->
		<link href="<?php echo base_url('assets/plugins/jquery-nice-select/css/nice-select.css'); ?>" rel="stylesheet"/>

		<!-- Color-palette css-->
		<link rel="stylesheet" href="<?php echo base_url('assets/css/skins.css'); ?>"/>
    <style>
		.table th, .text-wrap table th {
			color:#009933 !important;
		}
		.nice-select{
			border: 1px solid #045511 !important;
		}

		.custom-modal-width {
			max-width: 90%; /* Adjust as needed */
			width: 90%;
		}
		.nice-select .list {
			max-height: 400px !important; /* Adjust height as needed */
			overflow-y: auto !important; /* Enable scrolling */
		}
		select.form-control {
			border: 1px solid #339966; /* Default border */
			border-radius: 4px;
		}

		/* On focus (when the dropdown is clicked) */
		.form-control:focus {
			border-color: #006600; /* Green border when selected/focused */
			outline: none;
			box-shadow: 0 0 0 5px rgba(21, 236, 68, 0.2); /* Optional subtle shadow */
		}
		.form-control {
			border-radius: 10px !important;
		}
		body {
			cursor: pointer;
		}
		.stylish-cursor {
			position: fixed;
			top: 0;
			left: 0;
			width: 16px;
			height: 16px;
			background: rgba(40, 167, 69, 0.6); /* Bootstrap green */
			border-radius: 50%;
			pointer-events: none;
			z-index: 9999;
			box-shadow: 0 0 10px rgba(40, 167, 69, 0.8),
						0 0 20px rgba(40, 167, 69, 0.5);
			transform: translate(-50%, -50%);
			transition: transform 0.05s ease-out;
		}
		#btn_next, #btn_back, #btn_save_entity, #btn_enq_list_view {
			background: #339966;
			color: white;
			border: 1px solid #006600;
			border-radius: 12px;
			backdrop-filter: blur(8px);
			-webkit-backdrop-filter: blur(8px);
			padding: 6px 14px;
			font-size: 16px;
			font-weight: 600;
			float: right;
			cursor: pointer;
			transition: all 0.3s ease-in-out;
		}

		#btn_next:hover, #btn_back:hover, #btn_save_entity:hover,#btn_enq_list_view:hover {
			background: #006600;
			transform: scale(1.05);
		}
		/*.header-main.header.sticky {
			background-color: #003300;
		}

		.app-header.header.top-header.navbar-collapse {
  			background-color: #003300; 
		}*/

		.arrival-box {
			border: 2px solid #28a745; /* green border */
			border-radius: 8px;
			padding: 16px;
			margin-top: 20px;
			background-color: #bcd5bf; /* light green tint */
		}

		.arrival-heading {
			font-weight: bold;
			font-size: 16px;
			margin-bottom: 15px;
			color: #066d38; /* darker green */
		}

		.arrival-box .row {
			margin-bottom: 12px;
		}

		.arrival-box select,
		.arrival-box input[type="date"] {
			padding: 5px;
			font-size: 14px;
		}
		.card {
    		border: 1px solid #fff !important;
		}
		</style>
	</head>
	<body class="app sidebar-mini">	

		<!-- Loader -->
		<div id="loading">
			<img src="<?php echo base_url('assets/images/other/loader.svg'); ?>" class="loader-img" alt="Loader">
		</div>


		<div class="modal fade" id="seasonsmodal" tabindex="-1" role="dialog"  aria-hidden="true">
				<div class="modal-dialog custom-modal-width" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="example-Modal3"><span id="ssn_header"></span> - Season</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body">
						
									<div class="row">
										<div class="col-lg-3">
											<input type="hidden" name="hd_hotel_id_ssn" id="hd_hotel_id_ssn" value="">
											<input type="hidden" name="hd_object_id_ssn" id="hd_object_id_ssn" value="">
											<label class="form-control-label">Start Date</label>
											<input class="form-control" type="date" id="ssn_start_date">
										</div>
										<div class="col-lg-3">
											<label class="form-control-label">End Date</label>
											<input class="form-control" type="date" id="ssn_end_date">
										</div>
										<div class="col-lg-3">
											<label class="form-control-label">Season Name</label>
											<input class="form-control" type="text" id="season_name">
										</div>
										<div class="col-lg-3">
											
											<button type="button" id="btn_seasons" class="btn btn-success" style="float:right;">Add New Season</button>
										</div>
									</div>
								
							
							
								<div class="row" style="padding-top:5px;">
									<div class="col-lg-12">
										<table class="table" id="table_seasons" style="width: 100%;">
											<thead style="background-color:#c6ecd9;"> 
												<tr>
													<th scope="col">Start Date</th>
													<th scope="col">End Date</th>
													<th scope="col">Season Name</th>
													<th scope="col">Tariff</th>
												</tr>
											</thead>
											<tbody>

											</tbody>
										</table>
									</div>
								</div>
							
						
						</div>
						
					</div>
				</div>
			</div>



		<!-- PAGE -->
		<div class="page">
			<div class="page-main">

				<!-- Top-header opened -->
				<div class="header-main header sticky">
					<div class="app-header header top-header navbar-collapse ">
						<div class="container-fluid">
							<div class="d-flex">
								<a class="header-brand" href="<?=site_url('Dashboard');?>">
									<img src="<?php echo base_url('assets/images/brand/logo.png'); ?>" class="header-brand-img desktop-logo " alt="Dashlot logo">
									<img src="<?php echo base_url('assets/images/brand/logo1.png'); ?>" class="header-brand-img desktop-logo-1 " alt="Dashlot logo">
									<img src="<?php echo base_url('assets/images/brand/favicon.png'); ?>" class="mobile-logo" alt="Dashlot logo">
									<img src="<?php echo base_url('assets/images/brand/favicon1.png'); ?>" class="mobile-logo-1" alt="Dashlot logo">
								</a>
								<a href="#" data-toggle="sidebar" class="nav-link icon toggle"><i class="fe fe-align-justify fs-20"></i></a>
								<div class="d-flex header-left left-header">
									<div class="d-none d-lg-block horizontal">
										<ul class="nav">
											<li class="">
												<div class="dropdown d-none d-md-flex">
													<a href="#" class="d-flex nav-link pr-0  pt-2 mt-3 country-flag1" data-toggle="dropdown">
														<span class="d-flex"><img src="<?php echo base_url('assets/images/roles.jpg'); ?>" alt="img" class="avatar country-Flag mr-2 align-self-center"></span>
														<div>
															<span class="d-flex fs-14 mr-3 mt-0"><?php echo session('active_role_name'); ?><span><i class="mdi mdi-chevron-down"></i></span></span>
														</div>
													</a>
													<div class="dropdown-menu dropdown-menu-left dropdown-menu-arrow">
													<?php foreach ($all_roles_assn as $data) : ?>
														<a href="#" onclick="switchroles(<?php echo $data['role_id']; ?>,'<?php echo $data['role_name']; ?>');" class="dropdown-item d-flex align-items-center mt-2">
															<div>
																<span><?php echo $data['role_name']; ?></span>
															</div>
														</a>
													<?php endforeach; ?>
														
													</div>
												</div>
											</li>
										</ul>
									</div>
								</div>
								<div class="d-flex header-left left-header">
									<div class="d-none d-lg-block horizontal">
										<ul class="nav">
											<li class="">
												<div class="dropdown d-none d-md-flex">
													<a href="#" class="d-flex nav-link pr-0  pt-2 mt-3 country-flag1" data-toggle="dropdown">
														<span class="d-flex"><img src="<?php echo base_url('assets/images/system.jpg'); ?>" alt="img" class="avatar country-Flag mr-2 align-self-center"></span>
														<div>
															<span class="d-flex fs-14 mr-3 mt-0"><?php echo session('system_name'); ?><span><i class="mdi mdi-chevron-down"></i></span></span>
														</div>
													</a>
													<div class="dropdown-menu dropdown-menu-left dropdown-menu-arrow">
														<?php foreach ($all_systems as $datas) : ?>
															<a href="#" onclick="switchsystems(<?php echo $datas['entity_boolean_id']; ?>,'<?php echo $datas['boolean_name']; ?>');" class="dropdown-item d-flex align-items-center mt-2">
																<div>
																	<span><?php echo $datas['boolean_name']; ?></span>
																</div>
															</a>
														<?php endforeach; ?>
													</div>
												</div>
											</li>
										</ul>
									</div>
								</div>
								<div class="d-flex header-right ml-auto">
									<div class="dropdown header-fullscreen">
										<a class="nav-link icon full-screen-link" id="fullscreen-button">
											<i class="mdi mdi-arrow-collapse fs-20"></i>
										</a>
									</div><!-- Fullscreen -->
									
									<div class="dropdown drop-profile">
										<a class="nav-link pr-0 leading-none" href="#" data-toggle="dropdown" aria-expanded="false">
											<div class="profile-details mt-1">
												<span class="mr-3 mb-0  fs-15 font-weight-semibold"><?php echo session('user_name'); ?></span>
												<!--<small class="text-muted mr-3">appdeveloper</small>-->
											</div>
											<img class="avatar avatar-md brround" src="<?php echo base_url('assets/images/users/user.png'); ?>" alt="image">
										 </a>
										<div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow animated bounceInDown w-250">
											<div class="user-profile bg-header-image border-bottom p-3">
												<div class="user-image text-center">
													<img class="user-images" src="<?php echo base_url('assets/images/users/user.png'); ?>" alt="image">
												</div>
												<div class="user-details text-center">
													<h4 class="mb-0"><?php echo session('user_name'); ?></h4>
													<!--<p class="mb-1 fs-13 text-white-50">Jonathan@gmail.com</p>-->
												</div>
											</div>
											<a class="dropdown-item" href="#">
												<i class="dropdown-icon mdi mdi-account-outline "></i> Profile
											</a>
											<a class="dropdown-item" href="#">
												<i class="dropdown-icon  mdi mdi-settings"></i> Settings
											</a>
											<a class="dropdown-item" href="#">
												<span class="float-right"><span class="badge badge-success">6</span></span>
												<i class="dropdown-icon mdi  mdi-message-outline"></i> Inbox
											</a>
											<a class="dropdown-item" href="#">
												<i class="dropdown-icon mdi mdi-comment-check-outline"></i> Message
											</a>
											<div class="dropdown-divider"></div>
											<a class="dropdown-item" href="#">
												<i class="dropdown-icon mdi mdi-compass"></i> Need help?
											</a>
											<a class="dropdown-item mb-1" href="<?=site_url('Login/logout');?>">
												<i class="dropdown-icon mdi  mdi-logout-variant"></i> Sign out
											</a>
										</div>
									</div><!-- Profile -->
								
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Top-header closed -->

				<!-- Sidebar menu-->
				<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
				<aside class="app-sidebar toggle-sidebar">
					<div class="app-sidebar__user">
						<div class="user-body">
							<img src="<?php echo base_url('assets/images/users/user.png'); ?>" alt="profile-img" class="rounded-circle w-25">
						</div>
						<div class="user-info">
							<a href="#" class=""><span class="app-sidebar__user-name font-weight-semibold"><?php echo session('user_name'); ?></span><br>
							<!--span class="text-muted app-sidebar__user-designation text-sm">App Developer</span>-->
							</a>
						</div>
					</div>
					<ul class="side-menu toggle-menu">
						<?php foreach($parent_menu as $key1 => $val1){ 
							$img_tmp = $val1['entity_trans_id'].".svg";
							?>
							<li class="slide">
								<a class="side-menu__item"  data-toggle="slide" href=""><span class="icon-menu-img"><img src="<?php echo base_url('assets/images/svgs/'.$img_tmp); ?>" class="side_menu_img svg-1" alt="image"></span><span class="side-menu__label"><?php echo $val1['entity_trans_name']; ?></span><i class="angle fa fa-angle-right"></i></a>
								<ul class="slide-menu">
									<?php foreach($sub_menu as $key2 => $val2){ 
										if($val1['entity_trans_id'] == $val2['prs_parent_id']){
											foreach($all_menus as $key3 => $val3){
												if($val3['entity_trans_id'] == $val2['entity_trans_id']){
										?>
											<li><a class="slide-item" href="<?=site_url($val2['menu_link']);?>"><span><?php echo $val2['entity_trans_name']; ?></span></a></li>
									<?php } } } } ?>
								</ul>
							</li>
						<?php } ?>
					</ul>
				</aside>
				<!-- Sidemenu closed -->

				<!-- App-content opened -->
				<div class="app-content icon-content">
					<div class="section">

						<!-- Page-header opened -->
						<div class="page-header">
							<div class="page-leftheader">
								<h4 class="page-title mb-0"><?php echo $object_class_name; ?></h4>
								<small class="text-muted mt-0">Create / Edit <?php echo $object_class_name; ?></small>
							</div>
							<div class="page-rightheader">
								<div class="ml-3 ml-auto d-flex">
								
									<div class="mt-4 mt-xl-0 mt-lg-4 mt-md-4 mt-md-0">
										<a href="<?=site_url('Enquiry/enquiry_list_view/'.$object_class_id); ?>" class="btn btn-success ml-0 ml-md-4 mt-1 " id="btn_enq_list_view"><i class="typcn typcn-eye mr-1"></i>Enquiry List View</a>
									</div>
								</div>
							
							</div>
						</div>
						<!-- Page-header closed -->

						<!-- row opened -->
						<div class="row">
							<div class="col-lg-12">
								<div class="wideget-user-tab wideget-user-tab3 border-bottom">
									<div class="tab-menu-heading">
										<div class="tabs-menu1">
											<ul class="nav">
												<?php if($edit_id > 0){ ?>
													<li class=""><a href="#tab-5" class="h5" data-toggle="tab"><b>Enquiry Header</b></a></li>
													<li><a href="#tab-6" data-toggle="tab" class="h5 active"><b>Enquiry Details</b></a></li>
												<?php } else { ?>
													<li class=""><a href="#tab-5" class="h5 active" data-toggle="tab"><b>Enquiry Header</b></a></li>
													<li><a href="#tab-6" data-toggle="tab" class="h5"><b>Enquiry Details</b></a></li>
												<?php } ?>
											</ul>
										</div>
									</div>
								</div>
								<form id="myEnquiryForm" method="POST" action="<?=site_url('Enquiry/saveEnquiry');?>">
								<div class="bg-white widget-user mb-0">
									<div class="card-body">
										<div class="border-0">
											<div class="tab-content">
											<?php if($edit_id > 0){ ?>
												<div class="tab-pane" id="tab-5">
											<?php } else { ?>
												<div class="tab-pane active" id="tab-5">
											<?php } ?>
													<div class="profile-log-switch">
														<!-- Row-->
														<div class="row">
															<div class="col-xl-12 ">
																<div class="">
																	<div class="card mb-0 box-shadow-0">
																		
																		<?php if(session('system_id') == "3"){ ?>
																			
																			<div class="row">
																				<div class="col-xl-3">
																				<input type="hidden" id="object_class_id" name="object_class_id" value="<?php echo $object_class_id; ?>">
																				<input type="hidden" id="object_type_id" name="object_type_id" value="<?php echo $object_type_id; ?>">
																				<input type="hidden" id="enterprise_id" name="enterprise_id" value="1">
																				<input type="hidden" id="edit_id" name="edit_id" value="<?php echo $edit_id; ?>">
																				<input type="hidden" name="hd_guest_exist" id="hd_guest_exist" value="0">
																					<label class="form-label" style="color:#039623;">Agent State <span style="color: red;">*</span></label>
																					<?php if(!empty($agent_details)){ ?>
																						<select class="form-control input-sm" name="agent_state" id="agent_state" onchange="selectagent()" required <?php echo $dis_abled; ?>>
																							<option value="">Select</option>
																							<?php foreach ($states as $state) { 
																								if($state['geog_id'] == $agent_state_id){
																								?>
																								<option value="<?php echo $state['geog_id'] ?>" selected><?php echo $state['geog_name'] ?></option>
																							<?php } else { ?>
																								<option value="<?php echo $state['geog_id'] ?>"><?php echo $state['geog_name'] ?></option>
																						<?php }
																						} ?>
																						</select>
																					<?php } else { ?>
																						<select class="form-control input-sm" name="agent_state" id="agent_state" onchange="selectagent()" required <?php echo $dis_abled; ?>>
																							<option value="">Select</option>
																							<?php foreach ($states as $state) { ?>
																								<option value="<?php echo $state['geog_id'] ?>">
																									<?php echo $state['geog_name'] ?>
																								</option>
																							<?php } ?>
																						</select>
																					<?php } ?>
																					<span id="state-alert"></span>
																				</div>
																				<div class="col-xl-3">
																					<label class="form-label" style="color:#039623;">Agent Name <span style="color: red;">*</span></label>
																					<select class="form-control input-sm" name="agent_id" id="agent_id" onchange="selectagentdet()" required <?php echo $dis_abled; ?>>
																						<option value="">Select</option>
																						
																					</select>
																					<span id="agent-alert"></span>
																				</div>
																				<div class="col-xl-6"> 
																					<label class="form-label" style="color:#039623;">Agent Address</label>
																					<textarea id="agent_address" name="agent_address"class="form-control input-sm" rows="1" readonly></textarea>
																				</div>
																			
																			</div>
																		


																	
																		<div class="row" style="padding-top:15px;">
																			<div class="col-xl-3" class="form-label" style="color:#039623;">
																				<label class="form-control-label">Guest Name<span style="color: red;">*</span></label>
																				<input type="text" class="form-control input-sm" id="guest_name" name="guest_name" value="<?php echo $obj_name; ?>" autocomplete="off" maxlength="40" pattern="^[A-Za-z]+(?: [A-Za-z]+)*$" oninput="this.value = this.value.replace(/[^A-Za-z ]/g, '').replace(/^ /g, '')" required <?php echo $read_only; ?>>
																				<span id="gname-alert"></span>
																			</div>
																			<div class="col-xl-2" class="form-label" style="color:#039623;">
																				<label class="form-control-label">Mobile<span style="color: red;">*</span></label>
																				<input type="text" class="form-control input-sm" id="guest_mobile" value="<?php echo $obj_mobile; ?>" name="guest_mobile" maxlength="10" autocomplete="off" required <?php echo $read_only; ?>>
																				<span id="gmobile-alert"></span>
																				<span id="mobile_error" style="color: red; display: none;">Enter a valid 10-digit mobile number</span>
																			</div>
																			<div class="col-xl-2" class="form-label" style="color:#039623;">
																				<label class="form-control-label">Email<span style="color: red;">*</span></label>
																				<input type="text" class="form-control input-sm" name="guest_email" id="guest_email" value="<?php echo $obj_email; ?>" maxlength="30" autocomplete="off" required <?php echo $read_only; ?>>
																				<span id="gemail-alert"></span>
																				<span id="email_error" style="color: red; display: none;">Invalid email format</span>
																			</div>
																			<div class="col-xl-3" class="form-label" style="color:#039623;">
																				<label class="form-control-label">Address<span style="color: red;">*</span></label>
																				<textarea class="form-control input-sm" name="guest_address" id="guest_address" rows="1" autocomplete="new-password" required <?php echo $read_only; ?>><?php echo $obj_address; ?></textarea>
																				<span id="gaddress-alert"></span>
																			</div>
																			<div class="col-xl-2" style="color:#039623;">
																				<label class="form-control-label">Multiple Arrivals</label>
																				<select class="form-control input-sm" name="no_of_arrivals" id="no_of_arrivals">
																					<option value="1">No</option>
																					<option value="2">2</option>
																					<option value="3">3</option>	
																				</select>
																			</div>
																		
																		</div>

																		<!---------------Multiple Arrival start------------------->
																		<div id="multi_dyn_wrapper" class="arrival-box" style="display: none;">
																			<h5 class="arrival-heading">Enter details for multiple arrivals.</h5>
																			<div id="multi_dyn"></div>
																		</div>
																		<!---------------Multiple Arrival End--------------------->

																		<div class="row">
																			<div class="col-xl-3">

																			</div>
																			<div class="col-xl-3">

																			</div>
																			<div class="col-xl-3">

																			</div>
																			<div class="col-xl-3" style="padding-top:20px;">
																				<button type="button" id="btn_next" class="btn btn-success" style="float:right;">Next >></button>
																			</div>
																		</div>
																	<?php } else { ?>
																		
																		<div class="row">
																			<div class="col-xl-3">

																				<input type="hidden" id="object_class_id" name="object_class_id" value="<?php echo $object_class_id; ?>">
																				<input type="hidden" id="object_type_id" name="object_type_id" value="<?php echo $object_type_id; ?>">
																				<input type="hidden" id="enterprise_id" name="enterprise_id" value="1">
																				<input type="hidden" id="edit_id" name="edit_id" value="<?php echo $edit_id; ?>">
																				<input type="hidden" name="agent_state" id="agent_state" value="">
																				<input type="hidden" name="agent_id" id="agent_id" value="">
																				<input type="hidden" name="agent_address" id="agent_address" value="">
																				<input type="hidden" name="hd_guest_exist" id="hd_guest_exist" value="0">

																				<label class="form-label" style="color:#039623;">Guest Name<span style="color: red;">*</span></label>
																				<input type="text" class="form-control input-sm" id="guest_name" name="guest_name" value="<?php echo $obj_name; ?>" autocomplete="off" maxlength="25" pattern="^[A-Za-z]+(?: [A-Za-z]+)*$" oninput="this.value = this.value.replace(/[^A-Za-z ]/g, '').replace(/^ /g, '')" required <?php echo $read_only; ?>>
																				<span id="gname-alert"></span>
																			</div>
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">Mobile<span style="color: red;">*</span></label>
																				<input type="text" class="form-control input-sm" id="guest_mobile" name="guest_mobile" value="<?php echo $obj_mobile; ?>" autocomplete="off" maxlength="10" required <?php echo $read_only; ?>>
																				<span id="gmobile-alert"></span>
																				<span id="mobile_error" style="color: red; display: none;">Enter a valid 10-digit mobile number</span>
																			</div>
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">Email<span style="color: red;">*</span></label>
																				<input type="email" class="form-control input-sm" name="guest_email" id="guest_email" value="<?php echo $obj_email; ?>" autocomplete="off" maxlength="30" required <?php echo $read_only; ?>>
																				<span id="gemail-alert"></span>
																				<span id="email_error" style="color: red; display: none;">Invalid email format</span>
																			</div>
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">Address<span style="color: red;">*</span></label>
																				<textarea class="form-control input-sm" name="guest_address" id="guest_address" rows="1" autocomplete="new-password" required <?php echo $read_only; ?>><?php echo $obj_address; ?></textarea>
																				<span id="gaddress-alert"></span>
																			</div>
																		
																		</div>

																		
																		<div class="row">
																			<div class="col-xl-3">

																			</div>
																			<div class="col-xl-3">

																			</div>
																			<div class="col-xl-3">

																			</div>
																			<div class="col-xl-3" style="padding-top:20px;">
																				<button type="button" id="btn_next" class="btn btn-success" style="float:right;">Next >></button>
																			</div>
																		</div>
																	<?php } ?>
																	</div>
																</div>
															</div>
														</div>
														<!-- End Row -->
													</div>
												</div>
												<?php if($edit_id > 0){ ?>
													<div class="tab-pane active" id="tab-6">
												<?php } else { ?>
													<div class="tab-pane" id="tab-6">
												<?php } ?>
													<!-- Row-->
													<div class="row">
														<div class="col-xl-12 ">
															<div class="">
																<div class="card mb-0 box-shadow-0">
																	<div class="">
																		<div class="row">
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">Tour start date<span style="color: red;">*</span></label>
																				<input type="date" class="form-control input-sm" id="tour_start_date" name="tour_start_date" value="<?php echo $date_of_tour_start; ?>" required>
																				<span id="startdate-alert"></span>
																			</div>
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">No Of Night<span style="color: red;">*</span></label>
																				<input type="text" class="form-control input-sm" id="no_of_days" name="no_of_days" value="<?php echo $no_of_night; ?>" inputmode="numeric" pattern="[0-9]*" maxlength="2" oninput="this.value = this.value.replace(/\D/g, '')" required>
																				<span id="nodays-alert"></span>
																			</div>
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">Tour end date<span style="color: red;">*</span></label>
																				<input type="date" class="form-control input-sm" id="tour_end_date" name="tour_end_date" value="<?php echo $date_of_tour_completion; ?>" readonly>
																			</div>
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">Enquiry Source<span style="color: red;">*</span></label>
																				<select class="form-control input-sm" name="enq_source" id="enq_source" required>
																					<option value="">Select</option>
																					<option value="1" <?php echo $email_sel; ?>>Email</option>
																					<option value="2" <?php echo $ref_sel; ?>>Reference</option>
																					<option value="3" <?php echo $phone_sel; ?>>Phone</option>
																					<option value="4" <?php echo $oth_sel; ?>>Others</option>
																				</select>
																			</div>
																		</div>

																		<div class="row" style="padding-top:15px;">
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">No: Of Adult<span style="color: red;">*</span></label>
																				<input type="text" class="form-control input-sm" id="no_of_adult" name="no_of_adult" value="<?php echo $no_of_adult; ?>" inputmode="numeric" pattern="[0-9]*" maxlength="2" oninput="this.value = this.value.replace(/\D/g, '')" required>
																				<span id="nodays-alert"></span>
																			</div>
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">Child with bed</label>
																				<input type="text" class="form-control input-sm" id="no_of_child_with_bed" value="<?php echo $no_of_child_with_bed; ?>" name="no_of_child_with_bed" inputmode="numeric" pattern="[0-9]*" maxlength="2" oninput="this.value = this.value.replace(/\D/g, '')">
																				<span id="nodays-alert"></span>
																			</div>
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">Child without bed</label>
																				<input type="text" class="form-control input-sm" id="no_of_child_without_bed" value="<?php echo $no_of_child_without_bed; ?>" name="no_of_child_without_bed" inputmode="numeric" pattern="[0-9]*" maxlength="2" oninput="this.value = this.value.replace(/\D/g, '')">
																				<span id="nodays-alert"></span>
																			</div>
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">Total No: Of Pax</label>
																				<input type="text" class="form-control input-sm" id="total_no_of_pax" name="total_no_of_pax" value="<?php echo $total_no_of_pax; ?>" inputmode="numeric" pattern="[0-9]*" maxlength="2" oninput="this.value = this.value.replace(/\D/g, '')" readonly>
																				<span id="nodays-alert"></span>
																			</div>
																		</div>

																		<div class="row" style="padding-top:15px;">
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">No: Of Double Room<span style="color: red;">*</span></label>
																				<input type="text" class="form-control input-sm" id="no_of_double_room" name="no_of_double_room" value="<?php echo $no_of_double_room; ?>" inputmode="numeric" pattern="[0-9]*" maxlength="2" oninput="this.value = this.value.replace(/\D/g, '')" required>
																				<span id="nodays-alert"></span>
																			</div>
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">No: Of Single Room</label>
																				<input type="text" class="form-control input-sm" id="no_of_single_room" value="<?php echo $no_of_single_room; ?>" name="no_of_single_room" inputmode="numeric" pattern="[0-9]*" maxlength="2" oninput="this.value = this.value.replace(/\D/g, '')">
																				<span id="nodays-alert"></span>
																			</div>
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">No: Of Extra bed</label>
																				<input type="text" class="form-control input-sm" id="no_of_extra_bed" value="<?php echo $no_of_extra_bed; ?>" name="no_of_extra_bed" inputmode="numeric" pattern="[0-9]*" maxlength="2" oninput="this.value = this.value.replace(/\D/g, '')">
																				<span id="nodays-alert"></span>
																			</div>
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">GSTIN</label>
																				<input type="text" class="form-control input-sm" id="gstin" value="" name="gstin" maxlength="20" oninput="this.value = this.value.replace(/[^a-zA-Z0-9]/g, '')">
																				<span id="nodays-alert"></span>
																			</div>
																		</div>

																		<div class="row" style="padding-top:15px;">
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">Arrival Location<span style="color: red;">*</span></label>
																					<select class="form-control input-sm" name="arrival_location" id="arrival_location" required>
																						<option value="">Select</option>
																						<?php foreach ($arrival_locations as $aloc) { 
																							if($aloc['geog_id'] == $arrival_location){
																							?>
																							<option value="<?php echo $aloc['geog_id'] ?>" selected><?php echo $aloc['geog_name'] ?></option>
																						<?php } else { ?>
																							<option value="<?php echo $aloc['geog_id'] ?>"><?php echo $aloc['geog_name'] ?></option>
																					   <?php }
																					} ?>
																					</select>
																			</div>
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">Departure Location<span style="color: red;">*</span></label>
																					<select class="form-control input-sm" name="departure_location" id="departure_location" required>
																						<option value="">Select</option>
																						<?php foreach ($departure_locations as $dloc) { 
																							if($dloc['geog_id'] == $departure_location){
																							?>
																							<option value="<?php echo $dloc['geog_id'] ?>" selected><?php echo $dloc['geog_name'] ?></option>
																						<?php } else { ?>
																							<option value="<?php echo $dloc['geog_id'] ?>"><?php echo $dloc['geog_name'] ?></option>
																						<?php }
																						} ?>
																					</select>
																			</div>
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">Hotel Category<span style="color: red;">*</span></label>
																				<select class="form-control input-sm" name="hotel_category" id="hotel_category" required>
																					<option value="">Select</option>
																						<?php
																						foreach ($hotel_categories as $hkeys => $hvals) {
																							if($hvals['hotel_category_id'] == $hotel_category){
																								echo '<option value="' . $hvals['hotel_category_id'] . '" selected>' . $hvals['hotel_category_name'] . '</option>';
																							}
																							else{
																								echo '<option value="' . $hvals['hotel_category_id'] . '">' . $hvals['hotel_category_name'] . '</option>';
																							}
																						}
																						?>
																				</select>
																			</div>
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">Meal Plan<span style="color: red;">*</span></label>
																				<select class="form-control input-sm" name="meal_plan" id="meal_plan" required>
																					<option value="">Select</option>
																						<?php
																						foreach ($meal_plans as $mkeys => $mvals) {
																							if($mvals['meal_plan_id'] == $meal_plan){
																								echo '<option value="' . $mvals['meal_plan_id'] . '" selected>' . $mvals['meal_plan_name'] . '</option>';
																							}
																							else{
																								echo '<option value="' . $mvals['meal_plan_id'] . '">' . $mvals['meal_plan_name'] . '</option>';
																							}
																						}
																						?>
																				</select>
																			</div>
																		</div>

																		<div class="row" style="padding-top:15px;">
																			<div class="col-xl-3">
																				
																				<label class="form-label" style="color:#039623;">Vehicle Required <span style="color: red;">*</span></label>
																				<select class="form-control input-sm" name="is_vehicle_req" id="is_vehicle_req" required>
																					<option value="">Select</option>
																					<option value="1" <?php echo $vyes_sel; ?>>Yes</option>
																					<option value="0" <?php echo $vno_sel; ?>>No</option>	
																				</select>
																			</div>
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">Hub Location</label>
																				<select class="form-control input-sm" name="hub_location" id="hub_location" onchange="select_vehicle()">
																					<option value="">Select</option>
																						<?php
																						foreach ($hub_loc as $mkeys => $hubs) {
																							if($hubs['hub_location_id'] == $vehicle_from_location){
																								echo '<option value="' . $hubs['hub_location_id'] . '" selected>' . $hubs['hub_location_name'] . '</option>';
																							}
																							else{
																								echo '<option value="' . $hubs['hub_location_id'] . '">' . $hubs['hub_location_name'] . '</option>';
																							}
																						}
																						?>
																				</select>
																			</div>
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">Add Vehicle types from here</label>
																				<select class="form-control input-sm" name="vehicle_type" id="vehicle_type">
																					<option value="">Select</option>
																						
																				</select>
																				
																			</div>
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">Sightseeing Required <span style="color: red;">*</span></label>
																				<?php if($edit_id > 0){ ?>
																					<select class="form-control input-sm" name="is_ss_req" id="is_ss_req" required <?php echo $dis_abled; ?>>
																						<option value="">Select</option>
																						<option value="1" <?php echo $syes_sel; ?>>Yes</option>
																						<option value="0" <?php echo $sno_sel; ?>>No</option>	
																					</select>
																				<?php } else { ?>
																					<select class="form-control input-sm" name="is_ss_req" id="is_ss_req" required>
																						<option value="">Select</option>
																						<option value="1" selected>Yes</option>
																						<option value="0">No</option>	
																					</select>
																				<?php } ?>
																			</div>
																		</div>

																		<div class="row">
																			<div class="col-xl-12">
																			        
																					<table id="vehicle_dynamic_field" class="table table-bordered table-responsive-md table-striped mb-0 text-nowrap">
																						<thead id="vehicle_dynamic_head"></thead>
																					</table>
																				    <span id="veh_info"></span>
																			</div>
																		</div>
																		<div class="row" style="padding-top:15px;">
																			<div class="col-xl-3">
																				<label class="form-label" style="color:#039623;">Is Quick Quote <span style="color: red;">*</span></label>
																				<?php if($edit_id > 0){ ?>
																					<select class="form-control input-sm" name="is_qq_req" id="is_qq_req" required>
																						<option value="">Select</option>
																						<option value="1" <?php echo $qyes_sel; ?>>Yes</option>
																						<option value="0" <?php echo $qno_sel; ?>>No</option>	
																					</select>
																				<?php } else { ?>
																					<select class="form-control input-sm" name="is_qq_req" id="is_qq_req" required>
																						<option value="">Select</option>
																						<option value="1">Yes</option>
																						<option value="0" selected>No</option>	
																					</select>
																				<?php } ?>
																			</div>
																			<div class="col-xl-9">
																				<label class="form-label" style="color:#039623;">Description</label>
																				<textarea rows="1" class="form-control input-sm" name="enq_description" id="enq_description" placeholder="Description"><?php echo $enq_description; ?></textarea>
																			</div>
																		</div>
																		<div class="row" style="padding-top:15px;">
																			<div class="col-xl-3">
																			<button type="button" id="btn_back" class="btn btn-success" style="float:left;"><< Back</button>
																			</div>
																			<div class="col-xl-3">
																			</div>
																			<div class="col-xl-3">
																			
																			</div>
																			<div class="col-xl-3">
																				<button type="submit" id="btn_save_entity" class="btn btn-success" style="float:right;">Save >></button>
																			</div>	
									
																			</div>
																		</div>

																	</div>
																</div>
															</div>
														</div>
													</div>
													<!-- End Row -->
												</div>
												
											</div>
										</div>
									</div>
								</div>
								</form>
							</div>
						</div>
						<!-- row closed -->
					</div>
				</div>
				<!-- App-content closed -->
			</div>

			<!-- Right-sidebar-->
			<div class="sidebar sidebar-right sidebar-animate">
				<div class="p-3">
					<a href="#" class="text-right float-right" data-toggle="sidebar-right" data-target=".sidebar-right"><i class="fe fe-x"></i></a>
				</div>
				<div class="tab-menu-heading  siderbar-tabs border-0">
					<div class="tabs-menu ">
						<!-- Tabs -->
						<ul class="nav panel-tabs">
							<li class=""><a href="#tab" class="active show" data-toggle="tab">Profile</a></li>
							<li class=""><a href="#tab1" data-toggle="tab" class="">Friends</a></li>
							<li><a href="#tab2" data-toggle="tab" class="">Activity</a></li>
							<li><a href="#tab3" data-toggle="tab" class="">Todo</a></li>
						</ul>
					</div>
				</div>
				<div class="panel-body tabs-menu-body side-tab-body p-0 border-0 ">
					<div class="tab-content border-top">
						<div class="tab-pane active" id="tab">
							<div class="card-body p-0">
								<div class="header-user text-center mt-4 pb-4">
									<span class="avatar avatar-xxl brround"><img src="<?php echo base_url('assets/images/users/2.jpg'); ?>" alt="Profile-img" class="avatar avatar-xxl brround"></span>
									<div class="dropdown-item text-center font-weight-semibold user h3 mb-0">Jonathan Mills</div>
									<small>App Developer</small>
									<div class="card-body mb-6">
										<div class="form-group ">
											<label class="form-label  text-left">Offline/Online</label>
											<select class="form-control mb-4 nice-select " data-placeholder="Choose one">
												<option value="1">Online</option>
												<option value="2">Offline</option>
											</select>
										</div>
										<div class="form-group mt-3">
											<label class="form-label text-left">Website</label>
											<select class="form-control nice-select " data-placeholder="Choose one">
												<option value="1">Spruko.com</option>
												<option value="2">sprukosoft.com</option>
												<option value="3">sprukotechnologies.com</option>
												<option value="4">sprukoinfo.com</option>
												<option value="5">sprukotech.com</option>
											</select>
										</div>
									</div>
								</div>
								<a class="dropdown-item  border-top" href="#">
									<i class="dropdown-icon mdi mdi-account-edit"></i> Edit Profile
								</a>
								<a class="dropdown-item  border-top" href="#">
									<i class="dropdown-icon mdi mdi-account-outline"></i> Spruko technologies
								</a>
								<a class="dropdown-item border-top" href="#">
									<i class="dropdown-icon  mdi mdi-account-plus"></i> Add Another Account
								</a>
								<a class="dropdown-item  border-top" href="#">
									<i class="dropdown-icon mdi mdi-comment-check-outline"></i> Message
								</a>
								<a class="dropdown-item  border-top" href="#">
									<i class="dropdown-icon zmdi zmdi-pin-help"></i> Need Help?
								</a>
								<div class="card-body border-top">
									<h4>Gallery</h4>
									<div class="row mt-4">
										<div class="col-12">
											<div class="avatar-list">
												<ul>
													<li><a href="#" class="avatar avatar-lg cover-image"  data-image-src="<?php echo base_url('assets/images/users/5.jpg'); ?>"></a></li>
													<li><a href="#" class="avatar avatar-lg cover-image"  data-image-src="<?php echo base_url('assets/images/photos/2.jpg'); ?>"></a></li>
													<li><a href="#" class="avatar avatar-lg cover-image"  data-image-src="<?php echo base_url('assets/images/photos/3.jpg'); ?>"></a></li>
													<li><a href="#" class="avatar avatar-lg cover-image"  data-image-src="<?php echo base_url('assets/images/photos/5.jpg'); ?>"></a></li>
													<li><a href="#" class="avatar avatar-lg cover-image"  data-image-src="<?php echo base_url('assets/images/photos/3.jpg'); ?>"></a></li>
													<li><a href="#" class="avatar avatar-lg cover-image"  data-image-src="<?php echo base_url('assets/images/photos/15.jpg'); ?>"></a></li>
													<li><a href="#" class="avatar avatar-lg cover-image"  data-image-src="<?php echo base_url('assets/images/photos/16.jpg'); ?>"></a></li>
													<li><a href="#" class="avatar avatar-lg cover-image"  >+48</a></li>
												</ul>
											</div>
										</div>
									</div>
								</div>
								<div class="card-body border-top border-bottom">
									<div class="row">
										<div class="col-4 text-center">
											<a class="" href=""><i class="dropdown-icon mdi  mdi-message-outline fs-20 m-0 leading-tight"></i></a>
											<div>Inbox</div>
										</div>
										<div class="col-4 text-center">
											<a class="" href=""><i class="dropdown-icon mdi mdi-tune fs-20 m-0 leading-tight"></i></a>
											<div>Settings</div>
										</div>
										<div class="col-4 text-center">
											<a class="" href=""><i class="dropdown-icon mdi mdi-logout-variant fs-20 m-0 leading-tight"></i></a>
											<div>Sign out</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="tab-pane" id="tab1">
							<div class="chat">
								<div class="contacts_card">
									<div class="input-group mb-0 p-3">
										<input type="text" placeholder="Search..." class="form-control search">
										<div class="input-group-prepend mr-0">
											<span class="input-group-text  search_btn  btn-secondary"><i class="fa fa-search text-white"></i></span>
										</div>
									</div>
									<ul class="contacts mb-0">
										<li class="active">
											<div class="d-flex bd-highlight w-100">
												<div class="img_cont">
													<img src="<?php echo base_url('assets/images/users/12.jpg'); ?>" class="rounded-circle user_img" alt="img">
													<span class="online_icon"></span>
												</div>
												<div class="user_info">
													<h5 class="mt-1 mb-1">Maryam Naz</h5>
													<small class="text-muted">is online</small>
												</div>
												<div class="float-right text-right ml-auto mt-auto mb-auto"><small>01-02-2019</small></div>
											</div>
										</li>
										<li>
											<div class="d-flex bd-highlight w-100">
												<div class="img_cont">
													<img src="<?php echo base_url('assets/images/users/2.jpg'); ?>" class="rounded-circle user_img" alt="img">
													<span class=" online_icon"></span>
												</div>
												<div class="user_info">
													<h5 class="mt-1 mb-1">Sahar Darya</h5>
													<small class="text-muted">left 7 mins ago</small>
												</div>
												<div class="float-right text-right ml-auto mt-auto mb-auto"><small>01-02-2019</small></div>
											</div>
										</li>
										<li>
											<div class="d-flex bd-highlight w-100">
												<div class="img_cont">
													<img src="<?php echo base_url('assets/images/users/5.jpg'); ?>" class="rounded-circle user_img" alt="img">
													<span class="online_icon"></span>
												</div>
												<div class="user_info">
													<h5 class="mt-1 mb-1">Maryam Naz</h5>
													<small class="text-muted">online</small>
												</div>
												<div class="float-right text-right ml-auto mt-auto mb-auto"><small>01-02-2019</small></div>
											</div>
										</li>
										<li>
											<div class="d-flex bd-highlight w-100">
												<div class="img_cont">
													<img src="<?php echo base_url('assets/images/users/7.jpg'); ?>" class="rounded-circle user_img" alt="img">
													<span class="online_icon"></span>
												</div>
												<div class="user_info">
													<h5 class="mt-1 mb-1">Yolduz Rafi</h5>
													<small class="text-muted">online</small>
												</div>
												<div class="float-right text-right ml-auto mt-auto mb-auto"><small>02-02-2019</small></div>
											</div>
										</li>
										<li>
											<div class="d-flex bd-highlight w-100">
												<div class="img_cont">
													<img src="<?php echo base_url('assets/images/users/8.jpg'); ?>" class="rounded-circle user_img" alt="img">
													<span class="online_icon"></span>
												</div>
												<div class="user_info">
													<h5 class="mt-1 mb-1">Nargis Hawa</h5>
													<small class="text-muted">30 mins ago</small>
												</div>
												<div class="float-right text-right ml-auto mt-auto mb-auto"><small>02-02-2019</small></div>
											</div>
										</li>
										<li>
											<div class="d-flex bd-highlight w-100">
												<div class="img_cont">
													<img src="<?php echo base_url('assets/images/users/3.jpg'); ?>" class="rounded-circle user_img" alt="img">
													<span class="online_icon"></span>
												</div>
												<div class="user_info">
													<h5 class="mt-1 mb-1">Khadija Mehr</h5>
													<small class="text-muted">50 mins ago</small>
												</div>
												<div class="float-right text-right ml-auto mt-auto mb-auto"><small>03-02-2019</small></div>
											</div>
										</li>
										<li>
											<div class="d-flex bd-highlight w-100">
												<div class="img_cont">
													<img src="<?php echo base_url('assets/images/users/14.jpg'); ?>" class="rounded-circle user_img" alt="img">
													<span class="online_icon"></span>
												</div>
												<div class="user_info">
													<h5 class="mt-1 mb-1">Petey Cruiser</h5>
													<small class="text-muted">1hr ago</small>
												</div>
												<div class="float-right text-right ml-auto mt-auto mb-auto"><small>03-02-2019</small></div>
											</div>
										</li>
										<li>
											<div class="d-flex bd-highlight w-100">
												<div class="img_cont">
													<img src="<?php echo base_url('assets/images/users/11.jpg'); ?>" class="rounded-circle user_img" alt="img">
												</div>
												<div class="user_info">
													<h5 class="mt-1 mb-1">Khadija Mehr</h5>
													<small class="text-muted">2hr ago</small>
												</div>
												<div class="float-right text-right ml-auto mt-auto mb-auto"><small>03-02-2019</small></div>
											</div>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="tab-pane" id="tab2">
							<div class="list d-flex align-items-center border-bottom p-4">
								<div class="">
									<span class="avatar bg-primary brround avatar-md">CH</span>
								</div>
								<div class="wrapper w-100 ml-3">
									<p class="mb-0 d-flex">
										<b>New Websites is Created</b>
									</p>
									<div class="d-flex justify-content-between align-items-center">
										<div class="d-flex align-items-center">
											<i class="mdi mdi-clock text-muted mr-1"></i>
											<small class="text-muted ml-auto">30 mins ago</small>
											<p class="mb-0"></p>
										</div>
									</div>
								</div>
							</div>
							<div class="list d-flex align-items-center border-bottom p-4">
								<div class="">
									<span class="avatar bg-danger brround avatar-md">N</span>
								</div>
								<div class="wrapper w-100 ml-3">
									<p class="mb-0 d-flex">
										<b>Prepare For the Next Project</b>
									</p>
									<div class="d-flex justify-content-between align-items-center">
										<div class="d-flex align-items-center">
											<i class="mdi mdi-clock text-muted mr-1"></i>
											<small class="text-muted ml-auto">2 hours ago</small>
											<p class="mb-0"></p>
										</div>
									</div>
								</div>
							</div>
							<div class="list d-flex align-items-center border-bottom p-4">
								<div class="">
									<span class="avatar bg-info brround avatar-md">S</span>
								</div>
								<div class="wrapper w-100 ml-3">
									<p class="mb-0 d-flex">
										<b>Decide the live Discussion Time</b>
									</p>
									<div class="d-flex justify-content-between align-items-center">
										<div class="d-flex align-items-center">
											<i class="mdi mdi-clock text-muted mr-1"></i>
											<small class="text-muted ml-auto">3 hours ago</small>
											<p class="mb-0"></p>
										</div>
									</div>
								</div>
							</div>
							<div class="list d-flex align-items-center border-bottom p-4">
								<div class="">
									<span class="avatar bg-warning brround avatar-md">K</span>
								</div>
								<div class="wrapper w-100 ml-3">
									<p class="mb-0 d-flex">
										<b>Team Review meeting</b>
									</p>
									<div class="d-flex justify-content-between align-items-center">
										<div class="d-flex align-items-center">
											<i class="mdi mdi-clock text-muted mr-1"></i>
											<small class="text-muted ml-auto">4 hours ago</small>
											<p class="mb-0"></p>
										</div>
									</div>
								</div>
							</div>
							<div class="list d-flex align-items-center border-bottom p-4">
								<div class="">
									<span class="avatar bg-success brround avatar-md">R</span>
								</div>
								<div class="wrapper w-100 ml-3">
									<p class="mb-0 d-flex">
										<b>Prepare for Presentation</b>
									</p>
									<div class="d-flex justify-content-between align-items-center">
										<div class="d-flex align-items-center">
											<i class="mdi mdi-clock text-muted mr-1"></i>
											<small class="text-muted ml-auto">1 days ago</small>
											<p class="mb-0"></p>
										</div>
									</div>
								</div>
							</div>
							<div class="list d-flex align-items-center  border-bottom p-4">
								<div class="">
									<span class="avatar bg-pink brround avatar-md">MS</span>
								</div>
								<div class="wrapper w-100 ml-3">
									<p class="mb-0 d-flex">
										<b>Prepare for Presentation</b>
									</p>
									<div class="d-flex justify-content-between align-items-center">
										<div class="d-flex align-items-center">
											<i class="mdi mdi-clock text-muted mr-1"></i>
											<small class="text-muted ml-auto">1 days ago</small>
											<p class="mb-0"></p>
										</div>
									</div>
								</div>
							</div>
							<div class="list d-flex align-items-center border-bottom p-4">
								<div class="">
									<span class="avatar bg-purple brround avatar-md">L</span>
								</div>
								<div class="wrapper w-100 ml-3">
									<p class="mb-0 d-flex">
										<b>Prepare for Presentation</b>
									</p>
									<div class="d-flex justify-content-between align-items-center">
										<div class="d-flex align-items-center">
											<i class="mdi mdi-clock text-muted mr-1"></i>
											<small class="text-muted ml-auto">45 mintues ago</small>
											<p class="mb-0"></p>
										</div>
									</div>
								</div>
							</div>
							<div class="list d-flex align-items-center border-bottom p-4">
								<div class="">
									<span class="avatar bg-primary brround avatar-md">CH</span>
								</div>
								<div class="wrapper w-100 ml-3">
									<p class="mb-0 d-flex">
										<b>New Websites is Created</b>
									</p>
									<div class="d-flex justify-content-between align-items-center">
										<div class="d-flex align-items-center">
											<i class="mdi mdi-clock text-muted mr-1"></i>
											<small class="text-muted ml-auto">30 mins ago</small>
											<p class="mb-0"></p>
										</div>
									</div>
								</div>
							</div>
							<div class="list d-flex align-items-center p-4">
								<div class="">
									<span class="avatar bg-blue brround avatar-md">U</span>
								</div>
								<div class="wrapper w-100 ml-3">
									<p class="mb-0 d-flex">
										<b>Prepare for Presentation</b>
									</p>
									<div class="d-flex justify-content-between align-items-center">
										<div class="d-flex align-items-center">
											<i class="mdi mdi-clock text-muted mr-1"></i>
											<small class="text-muted ml-auto">2 days ago</small>
											<p class="mb-0"></p>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="tab-pane" id="tab3">
							<div class="">
								<div class="d-flex p-3">
									<label class="custom-control custom-checkbox mb-0">
										<input type="checkbox" class="custom-control-input" name="example-checkbox1" value="option1" checked="">
										<span class="custom-control-label">Do Even More..</span>
									</label>
									<span class="ml-auto">
										<a href="#"><i class="si si-pencil text-primary mr-2" data-toggle="tooltip" title="" data-placement="top" data-original-title="Edit"></i></a>
										<a href="#"><i class="si si-trash text-danger mr-2" data-toggle="tooltip" title="" data-placement="top" data-original-title="Delete"></i></a>
									</span>
								</div>
								<div class="d-flex p-3 border-top">
									<label class="custom-control custom-checkbox mb-0">
										<input type="checkbox" class="custom-control-input" name="example-checkbox2" value="option2" checked="">
										<span class="custom-control-label">Find an idea.</span>
									</label>
									<span class="ml-auto">
										<a href="#"><i class="si si-pencil text-primary mr-2" data-toggle="tooltip" title="" data-placement="top" data-original-title="Edit"></i></a>
										<a href="#"><i class="si si-trash text-danger mr-2" data-toggle="tooltip" title="" data-placement="top" data-original-title="Delete"></i></a>
									</span>
								</div>
								<div class="d-flex p-3 border-top">
									<label class="custom-control custom-checkbox mb-0">
										<input type="checkbox" class="custom-control-input" name="example-checkbox3" value="option3" checked="">
										<span class="custom-control-label">Hangout with friends</span>
									</label>
									<span class="ml-auto">
										<a href="#"><i class="si si-pencil text-primary mr-2" data-toggle="tooltip" title="" data-placement="top" data-original-title="Edit"></i></a>
										<a href="#"><i class="si si-trash text-danger mr-2" data-toggle="tooltip" title="" data-placement="top" data-original-title="Delete"></i></a>
									</span>
								</div>
								<div class="d-flex p-3 border-top">
									<label class="custom-control custom-checkbox mb-0">
										<input type="checkbox" class="custom-control-input" name="example-checkbox4" value="option4">
										<span class="custom-control-label">Do Something else</span>
									</label>
									<span class="ml-auto">
										<a href="#"><i class="si si-pencil text-primary mr-2" data-toggle="tooltip" title="" data-placement="top" data-original-title="Edit"></i></a>
										<a href="#"><i class="si si-trash text-danger mr-2" data-toggle="tooltip" title="" data-placement="top" data-original-title="Delete"></i></a>
									</span>
								</div>
								<div class="d-flex p-3 border-top">
									<label class="custom-control custom-checkbox mb-0">
										<input type="checkbox" class="custom-control-input" name="example-checkbox5" value="option5">
										<span class="custom-control-label">Eat healthy, Eat Fresh..</span>
									</label>
									<span class="ml-auto">
										<a href="#"><i class="si si-pencil text-primary mr-2" data-toggle="tooltip" title="" data-placement="top" data-original-title="Edit"></i></a>
										<a href="#"><i class="si si-trash text-danger mr-2" data-toggle="tooltip" title="" data-placement="top" data-original-title="Delete"></i></a>
									</span>
								</div>
								<div class="d-flex p-3 border-top">
									<label class="custom-control custom-checkbox mb-0">
										<input type="checkbox" class="custom-control-input" name="example-checkbox6" value="option6" checked="">
										<span class="custom-control-label">Finsh something more..</span>
									</label>
									<span class="ml-auto">
										<a href="#"><i class="si si-pencil text-primary mr-2" data-toggle="tooltip" title="" data-placement="top" data-original-title="Edit"></i></a>
										<a href="#"><i class="si si-trash text-danger mr-2" data-toggle="tooltip" title="" data-placement="top" data-original-title="Delete"></i></a>
									</span>
								</div>
								<div class="d-flex p-3 border-top">
									<label class="custom-control custom-checkbox mb-0">
										<input type="checkbox" class="custom-control-input" name="example-checkbox7" value="option7" checked="">
										<span class="custom-control-label">Do something more</span>
									</label>
									<span class="ml-auto">
										<a href="#"><i class="si si-pencil text-primary mr-2" data-toggle="tooltip" title="" data-placement="top" data-original-title="Edit"></i></a>
										<a href="#"><i class="si si-trash text-danger mr-2" data-toggle="tooltip" title="" data-placement="top" data-original-title="Delete"></i></a>
									</span>
								</div>
								<div class="d-flex p-3 border-top">
									<label class="custom-control custom-checkbox mb-0">
										<input type="checkbox" class="custom-control-input" name="example-checkbox8" value="option8">
										<span class="custom-control-label">Updated more files</span>
									</label>
									<span class="ml-auto">
										<a href="#"><i class="si si-pencil text-primary mr-2" data-toggle="tooltip" title="" data-placement="top" data-original-title="Edit"></i></a>
										<a href="#"><i class="si si-trash text-danger mr-2" data-toggle="tooltip" title="" data-placement="top" data-original-title="Delete"></i></a>
									</span>
								</div>
								<div class="d-flex p-3 border-top">
									<label class="custom-control custom-checkbox mb-0">
										<input type="checkbox" class="custom-control-input" name="example-checkbox9" value="option9">
										<span class="custom-control-label">System updated</span>
									</label>
									<span class="ml-auto">
										<a href="#"><i class="si si-pencil text-primary mr-2" data-toggle="tooltip" title="" data-placement="top" data-original-title="Edit"></i></a>
										<a href="#"><i class="si si-trash text-danger mr-2" data-toggle="tooltip" title="" data-placement="top" data-original-title="Delete"></i></a>
									</span>
								</div>
								<div class="d-flex p-3 border-top border-bottom">
									<label class="custom-control custom-checkbox mb-0">
										<input type="checkbox" class="custom-control-input" name="example-checkbox10" value="option10">
										<span class="custom-control-label">Settings Changings...</span>
									</label>
									<span class="ml-auto">
										<a href="#"><i class="si si-pencil text-primary mr-2" data-toggle="tooltip" title="" data-placement="top" data-original-title="Edit"></i></a>
										<a href="#"><i class="si si-trash text-danger mr-2" data-toggle="tooltip" title="" data-placement="top" data-original-title="Delete"></i></a>
									</span>
								</div>
								<div class="text-center pt-5">
									<a href="#" class="btn btn-primary">Add more</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- Right-sidebar-closed -->

			<!-- Footer opened -->
			<footer class="footer-main icon-footer">
				<div class="container">
					<div class="  mt-2 mb-2 text-center">
					Copyright © 2025 <a href="#" class="fs-14 text-primary">KHM</a>. Designed by <a href="https://megatrendkms.co.in" class="fs-14 text-primary" target="_blank">Megatrend Knowledge Management Systems Pvt Ltd</a> All rights reserved.
					</div>
				</div>
			</footer>
			<!-- Footer closed -->
		</div>

		<!-- Back to top -->
		<a href="#top" id="back-to-top"><i class="fa fa-angle-double-up"></i></a>

		<!-- Jquery-scripts -->
		<script src="<?php echo base_url('assets/js/vendors/jquery-3.2.1.min.js'); ?>"></script>

		<!-- Moment js-->
        <script src="<?php echo base_url('assets/plugins/moment/moment.min.js'); ?>"></script>

		<!-- Bootstrap-scripts js -->
		<script src="<?php echo base_url('assets/js/vendors/bootstrap.bundle.min.js'); ?>"></script>

		<!-- Sparkline JS-->
		<script src="<?php echo base_url('assets/js/vendors/jquery.sparkline.min.js'); ?>"></script>

		<!-- Bootstrap-daterangepicker js -->
		<script src="<?php echo base_url('assets/plugins/bootstrap-daterangepicker/daterangepicker.js'); ?>"></script>

		<!-- Bootstrap-datepicker js -->
		<script src="<?php echo base_url('assets/plugins/bootstrap-datepicker/bootstrap-datepicker.js'); ?>"></script>

		<!-- Chart-circle js -->
		<script src="<?php echo base_url('assets/js/vendors/circle-progress.min.js'); ?>"></script>

		<!-- Rating-star js -->
		<script src="<?php echo base_url('assets/plugins/rating/jquery.rating-stars.js'); ?>"></script>

		<!-- Custom scroll bar js-->
		<script src="<?php echo base_url('assets/plugins/scroll-bar/jquery.mCustomScrollbar.concat.min.js'); ?>"></script>

		<!-- Nice-select js-->
		<script src="<?php echo base_url('assets/plugins/jquery-nice-select/js/jquery.nice-select.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/jquery-nice-select/js/nice-select.js'); ?>"></script>

        <!-- P-scroll js -->
		<script src="<?php echo base_url('assets/plugins/p-scroll/p-scroll.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/p-scroll/p-scroll-1.js'); ?>"></script>

		<!-- Sidemenu js-->
		<script src="<?php echo base_url('assets/plugins/sidemenu/icon-sidemenu.js'); ?>"></script>

		<!-- Sidemenu-respoansive-tabs js -->
		<script src="<?php echo base_url('assets/plugins/sidemenu-responsive-tabs/js/sidemenu-responsive-tabs.js'); ?>"></script>

		<!-- Leftmenu js -->
		<script src="<?php echo base_url('assets/js/left-menu.js'); ?>"></script>

		<!-- Data tables -->
		<script src="<?php echo base_url('assets/plugins/datatable1/js/jquery.dataTables.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/datatable1/js/dataTables.bootstrap4.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/datatable1/js/dataTables.buttons.min.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/datatable1/js/buttons.bootstrap4.min.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/datatable1/dataTables.responsive.min.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/datatable1/responsive.bootstrap4.min.js'); ?>"></script>
		<script src="<?php echo base_url('assets/js/editable.js'); ?>"></script>

		<!-- Rightsidebar js -->
		<script src="<?php echo base_url('assets/plugins/sidebar/sidebar.js'); ?>"></script>

		<!-- Custom js -->
		<script src="<?php echo base_url('assets/js/custom.js'); ?>"></script>

	</body>
</html>
<script>
    function selectagent() {
        var change_value = $('#agent_state').val();
        if (change_value == "") {
            alert('Select a state!');
        } else {
            $.ajax({
                url: "<?=site_url('Enquiry/getAgents');?>",
                method: "POST",
                data: {
                    location_id: change_value
                },
                success: function (data) {
                    $('#agent_id').html(data);
                }
            });
        }
    } 
</script>

<script>
    function select_vehicle() {
        var change_value = $('#hub_location').val();
        if (hub_location == "") {
            alert('Select Hub Location!');
        } else {
            $.ajax({
                url: "<?=site_url('Enquiry/getVehicleTypes');?>",
                method: "POST",
                data: {
                    location_id: change_value
                },
                success: function (data) {
                    $('#vehicle_type').html(data);
                }
            });
        }
    } 
</script>

<script>
function selectagentdet() {
        var agent_id = $('#agent_id').val();
        if (agent_id == "") {
            alert('Select Agent');
        } else {
            $.ajax({
                url: '<?=site_url('Enquiry/getAgentDetails');?>',
                type: 'POST',
                data: {
                    agent_id: agent_id
                },
                dataType: 'json',
                success: function (data) {
					var address_temp = data[0].entity_address;
                    $('#agent_address').text(address_temp);
					$('#gstin').val(data[0].entity_attr_value);
                },
                error: function (xhr, status, error) {
                    console.error(error);
                }
            });
        }
    }
	</script>
	<script>
      function switchroles(role_id,role_name) {
        const newUrl = '<?php echo site_url('Dashboard'); ?>'
        $.ajax({
          url: '<?php echo site_url('Dashboard/system_role_change'); ?>',
          type: 'POST',
          data: {role_id:role_id,role_name:role_name},
          success: function(response) {
			location.reload();

          },
          error: function(xhr, status, error) {
            // Handle any errors
            console.error(error);
          }
        });
      }
</script>
<script>
      function switchsystems(system_id,system_name) {
        const newUrl = '<?php echo site_url('Enquiry/add_object_enquiry/10'); ?>'
        $.ajax({
          url: '<?php echo site_url('Dashboard/khm_system_change'); ?>',
          type: 'POST',
          data: {system_id:system_id,system_name:system_name},
          success: function(response) {
            location.reload();

          },
          error: function(xhr, status, error) {
            // Handle any errors
            console.error(error);
          }
        });
      }
</script>

<script>
$(document).ready(function () {
	var edit_id = <?php echo $edit_id; ?>;
    function validateFields() {
		var system_id = <?php echo session('system_id'); ?>;
        var agent_state = $('#agent_state').val();
        var agent_id = $('#agent_id').val();
        var guest_name = $('#guest_name').val();
        var guest_mobile = $('#guest_mobile').val();
        var guest_email = $('#guest_email').val();
        var guest_address = $('#guest_address').val();
        var isValid = true; // Assume valid unless an error is found

        function showAlert(element, message) {
            var alertHTML = `<div class="alert alert-success alert-dismissible fade show" role="alert">
                <span class="alert-inner--icon"><i class="fe fe-info"></i></span>
                <span class="alert-inner--text">${message}</span>
                <button type="button" class="close text-white" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>`;

            $(element).html(alertHTML);
            setTimeout(function () {
                $(".alert").fadeOut("slow", function () {
                    $(this).remove();
                });
            }, 2000);
            isValid = false;
        }

        if (system_id == 3 && !agent_state) {
            showAlert('#state-alert', 'State is required');
        }
        if (system_id == 3 && !agent_id) {
            showAlert('#agent-alert', 'Agent ID is required');
        }
        if (!guest_name) {
            showAlert('#gname-alert', 'Guest name is required');
        }
        if (!guest_mobile) {
            showAlert('#gmobile-alert', 'Guest mobile is required');
        }
        if (!guest_email) {
            showAlert('#gemail-alert', 'Guest email is required');
        }
        if (!guest_address) {
            showAlert('#gaddress-alert', 'Guest address is required');
        }

        return isValid;
    }

    $("#btn_next").click(function () {
		
		if(edit_id == 0){
			if (validateFields()) {
				var guest_name = $('#guest_name').val();
				var guest_mobile = $('#guest_mobile').val();
				var guest_email = $('#guest_email').val();
				
				
					$.ajax({
						type: "POST",
						url: '<?php echo site_url('Enquiry/check_guest_exist'); ?>',
						data: {
							guest_name: guest_name,
							guest_mobile: guest_mobile,
							guest_email: guest_email
						},
						dataType: 'json',
						success: function (response) {
						if(response == 0){
								$('.nav a[href="#tab-6"]').tab('show');
						}
						else{
							var confirmDisable = confirm(guest_name + " Already exist with mobile "+guest_mobile+" and email "+guest_email+". Do you want to continue ?");
								if (confirmDisable) {
									$('#hd_guest_exist').val(1);
									$('.nav a[href="#tab-6"]').tab('show');
								} else {
									
								}
						}
						}
					});
				
				//$('.nav a[href="#tab-6"]').tab('show');
			}
		}
		else{
			$('.nav a[href="#tab-6"]').tab('show');
		}
    });
	if(edit_id == 0){
		$('a[href="#tab-6"]').on('show.bs.tab', function (e) {
			if (!validateFields()) {
				e.preventDefault(); // Prevents switching to tab-6 if validation fails
			}
		});
	}
});
</script>
<script>
	$(document).ready(function () {
    function calculateTotalPax() {
        var noOfAdult = parseInt($('#no_of_adult').val()) || 0;
        var noOfChildWithBed = parseInt($('#no_of_child_with_bed').val()) || 0;
        var noOfChildWithoutBed = parseInt($('#no_of_child_without_bed').val()) || 0;

        var totalPax = noOfAdult + noOfChildWithBed + noOfChildWithoutBed;
        $('#total_no_of_pax').val(totalPax);
    }

    $('#no_of_adult, #no_of_child_with_bed, #no_of_child_without_bed').on('input', calculateTotalPax);
});
</script>
<script type="text/javascript">
    $(document).ready(function () {
        var i = 0;
        $('#vehicle_type').on('change', function () {
            var v_id = $("#vehicle_type").val();
			var inffo = '<p style="color:#ff66cc;"><b><i>* You can add multiple vehicles by selecting vehicle types from above</i></b></p>';
			$('#veh_info').html(inffo);
            $('#vehicle_dynamic_head').html('<tr><th>Vehicle Type</th><th>Count</th><th>Remove</th></tr>');
            $.ajax({
                type: "POST",
				url: '<?php echo site_url('Enquiry/get_vehicle_name'); ?>',
                data: {
                    v_id: v_id
                },
                dataType: 'json',
                success: function (response) {
                    i++;
                    $('#vehicle_dynamic_field').append('<tr id="row' + i + '" class="dynamic-added"><td><input type="hidden" name="addmore[' + i + '][v_id]" value="' + response[0].vehicle_type_id + '"/><input type="text" name="addmore[' + i + '][v_name]" value="' + response[0].vehicle_model_name + '" class="form-control input-sm"></td><td><select class="form-control input-sm" id="vtype' + response[0].vehicle_type_id + '" name="addmore[' + i + '][v_count]" aria-label="Default select example"><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option></select></td><td><button type="button" name="remove" id="' + i + '" class="btn btn-danger btn-sm btn_agency_remove">X</button></td></tr>');
                }
            });
			
        });
        $(document).on('click', '.btn_agency_remove', function () {
            var button_id = $(this).attr("id");
            $('#row' + button_id + '').remove();
        });
    });
</script>
<script>
	$(document).ready(function () {
		$("#btn_back").click(function () {
            $('.nav a[href="#tab-5"]').tab('show');
    	});
	});
</script>
<script>
    $(document).ready(function () {
        function toggleVehicleFields() {
            var isVehicleRequired = $("#is_vehicle_req").val();
            if (isVehicleRequired === "1") {
                $("#hub_location, #vehicle_type").prop("disabled", false);
            } else {
                $("#hub_location, #vehicle_type").prop("disabled", true).val(""); // Clear selection when disabled
				$("#vehicle_dynamic_field").html('');
            }
        }

        // Call on page load (in case of pre-selected value)
        toggleVehicleFields();

        // Attach change event
        $("#is_vehicle_req").change(function () {
            toggleVehicleFields();
        });
    });
</script>
<script>
$(document).ready(function () {
    $('#no_of_days, #tour_start_date').on('input change', function () {
        var startDate = $('#tour_start_date').val();
        var noOfDays = parseInt($('#no_of_days').val());

        if (startDate && noOfDays > 0) {
            var startDateObj = new Date(startDate);
            startDateObj.setDate(startDateObj.getDate() + noOfDays);

            var yyyy = startDateObj.getFullYear();
            var mm = String(startDateObj.getMonth() + 1).padStart(2, '0');
            var dd = String(startDateObj.getDate()).padStart(2, '0');
            var endDate = yyyy + '-' + mm + '-' + dd;

            $('#tour_end_date').val(endDate);
        } else {
			if(startDate == null || startDate == '' || startDate == 'undefined'){
				var alerttHTML = `<div class="alert alert-warning alert-dismissible fade show" role="alert">
					<span class="alert-inner--icon"><i class="fe fe-info"></i></span>
					<span class="alert-inner--text">Required</span>
					<button type="button" class="close text-white" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>`;

				$('#startdate-alert').html(alerttHTML);
				setTimeout(function () {
					$(".alert").fadeOut("slow", function () {
						$(this).remove();
					});
				}, 2000);
			}
            $('#tour_end_date').val('');
        }
    });
});
</script>
<script>
$(document).ready(function(){
    var emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z]+(\.[a-zA-Z]+)+$/;

    $("#guest_email").on("input keyup", function() {
        var email = $(this).val();

        if (emailPattern.test(email)) {
            $("#email_error").hide();
            $(this).css("border", "2px solid green");
        } else {
            $("#email_error").show();
            $(this).css("border", "2px solid red");
        }
    });

    // Clear field when clicking outside if invalid
    $("#guest_email").on("blur", function() {
        var email = $(this).val();

        if (!emailPattern.test(email)) {
            $(this).val("");  // Clear input
            $(this).css("border", "");  // Reset border color
            $("#email_error").hide();  // Hide error message
        }
    });
});
</script>

<script>
$(document).ready(function(){
    $("#guest_mobile").on("keyup", function() {
        var mobile = $(this).val();
        
        // Remove non-numeric characters
        mobile = mobile.replace(/\D/g, '');
        $(this).val(mobile); // Set cleaned value back

        // Check if exactly 10 digits
        if (mobile.length === 10) {
            $("#mobile_error").hide();
            $(this).css("border", "2px solid green");
        } else {
            $("#mobile_error").show();
            $(this).css("border", "2px solid red");
        }
    });

    // Clear field if invalid when clicking outside
    $("#guest_mobile").on("blur", function() {
        var mobile = $(this).val();

        if (mobile.length !== 10) {
            $(this).val("");  // Clear input
            $(this).css("border", "");  // Reset border color
            $("#mobile_error").hide();  // Hide error message
        }
    });
});
</script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        let today = new Date().toISOString().split('T')[0]; // Get today's date in YYYY-MM-DD format
        document.getElementById("tour_start_date").setAttribute("min", today);
    });
</script>
<script>
    $(document).ready(function () {
        function toggleRequiredFields() {
            if ($("#is_vehicle_req").val() === "1") { // If "Yes" is selected
                $("#hub_location, #vehicle_type").attr("required", "required");
            } else { // If "No" is selected
                $("#hub_location, #vehicle_type").removeAttr("required");
            }
        }

        // Run function on change event
        $("#is_vehicle_req").change(toggleRequiredFields);

        // Run function on page load (in case form is prefilled)
        toggleRequiredFields();
    });
</script>
<script>
$(document).ready(function () {
  $('#myEnquiryForm').on('submit', function (e) {

	var btn = $('#btn_save_entity');
    btn.prop('disabled', true);
    btn.html('<i class="fa fa-spinner fa-spin"></i> Saving...');
    // Check if form is valid
    if (!this.checkValidity()) {
      e.preventDefault();

      // Find the first invalid input
      const $firstInvalid = $(this).find(':invalid').first();

      // If it's inside a tab, show that tab
      const $tabPane = $firstInvalid.closest('.tab-pane');
      if ($tabPane.length && !$tabPane.hasClass('active')) {
        const tabId = $tabPane.attr('id');
        // Activate tab (assuming you’re using Bootstrap-style tabs)
        $(`a[href="#${tabId}"]`).tab('show');

        // Small timeout to let tab show before focusing
        setTimeout(() => $firstInvalid.focus(), 200);
      } else {
        $firstInvalid.focus();
      }
    }
  });
});
</script>
<script>
document.addEventListener("DOMContentLoaded", function() {
    const cursor = document.createElement("div");
    cursor.classList.add("stylish-cursor");
    document.body.appendChild(cursor);

    document.addEventListener("mousemove", function(e) {
        cursor.style.top = `${e.clientY}px`;
        cursor.style.left = `${e.clientX}px`;
    });
});
</script>
<script>
	$(document).ready(function () {
		var edit_id = <?php echo $edit_id; ?>;
		var agent_state_id = <?php echo $agent_state_id; ?>;
		var agentid = <?php echo $agentid; ?>;
		var is_vehicle_required = <?php echo $is_vehicle_required?1:0; ?>;
		if(edit_id > 0 && agent_state_id > 0){
			setTimeout(() => {
				$('#agent_state').trigger('change');
				setTimeout(() => {
					$('#agent_id').val(agentid).trigger('change');
				}, 300);
			}, 500);
		}
		if(edit_id > 0 && is_vehicle_required == 1){
			setTimeout(() => {
				$('#hub_location').trigger('change');
			}, 500);
		}
	});
</script>
<script>
$(document).ready(function () {
var edit_id = <?php echo $edit_id; ?>;
if(edit_id > 0) {
	var vehicles = <?php echo json_encode($vehicle_type_id); ?>;
	if (Array.isArray(vehicles) && vehicles.length > 0) {
		setTimeout(() => {
			$.each(vehicles, function (index, item) {
				var vehicle_type_id = item.vehicle_type_id;
				var vehicle_count = item.vehicle_count;
				setTimeout(() => {
					$('#vehicle_type').val(vehicle_type_id).trigger('change');
					setTimeout(() => {
						$('#vtype'+vehicle_type_id).val(vehicle_count).trigger('change');
					}, 100);
				}, 300);
			});
		}, 500);
	}
}
});
</script>
<script>
	$('#guest_name').on('blur', function () {
		this.value = this.value.trim().replace(/\s+/g, ' ');
	});
</script>

<script>
$(document).ready(function () {
    const arrivalOptions = `<?php echo $js_arrival_options; ?>`;
    const departureOptions = `<?php echo $js_departure_options; ?>`;
    const hubOptions = `<?php foreach ($hub_loc as $hub) {
        echo '<option value="'.$hub['hub_location_id'].'">'.$hub['hub_location_name'].'</option>';
    } ?>`;

    let vehicleIndex = 100;

    function generateRows(num) {
        $('#multi_dyn').empty();

        // Arrival 1 notice
        const firstRow = `
            <div class="row mb-2">
                <div class="col-xl-2"><h4 style="font-weight: bold;font-style: italic;">Arrival 1</h4></div>
                <div class="col-xl-10"><h4 style="font-weight: bold;font-style: italic;">You need to configure the Starting Arrival details in the next tab.</h4></div>
            </div>
        `;
        $('#multi_dyn').append(firstRow);

        if (num > 1) {
            for (let i = 2; i <= num; i++) {
                const sectionId = `multi_arrival_${i}`;
                const vehTableId = `vehicle_dynamic_field_${i}`;
                const vehInfoId = `veh_info_${i}`;

                const row = `
                    <div id="${sectionId}" class="border p-2 mb-3" style="border:1px dashed #999;">
                        <div class="row mb-2">
                            <div class="col-xl-1"><label><b>Arrival ${i}</b></label></div>
                            <div class="col-xl-2">
								<label><b>Start Date</b></label>
								<input type="date" name="arrival[${i}][start_date]" class="form-control input-sm">
							</div>
                            <div class="col-xl-1">
								<label><b>Days</b></label>
								<input type="text" name="arrival[${i}][ndays]" class="form-control input-sm">
							</div>
							<div class="col-xl-2">
								<label><b>End Date</b></label>
								<input type="date" name="arrival[${i}][end_date]" class="form-control input-sm">
							</div>
                            <div class="col-xl-3">
								<label><b>Arrival</b></label>
                                <select name="arrival[${i}][arrival_place]" class="form-control input-sm">
                                    <option value="">Select</option>${arrivalOptions}
                                </select>
                            </div>
                            <div class="col-xl-3">
								<label><b>Departure</b></label>
                                <select name="arrival[${i}][departure_place]" class="form-control input-sm">
                                    <option value="">Select</option>${departureOptions}
                                </select>
                            </div>
                        </div>

                        <div class="row mb-2">
                            <div class="col-xl-3">
								<label>Hub Location</label>
								<select name="arrival[${i}][hub_location]" class="form-control input-sm hub_location_dyn" data-index="${i}">
									<option value="">Select</option>
									${hubOptions}
								</select>
								</div>
								<div class="col-xl-3">
								<label>Vehicle Type</label>
								<select class="form-control input-sm vehicle_type_dyn" data-index="${i}">
									<option value="">Select</option>
								</select>
								</div>
                            <div class="col-xl-6">
                                <label>Vehicle Details</label>
                                <table id="${vehTableId}" class="table table-bordered table-striped mb-0 text-nowrap">
                                    <thead><tr><th>Vehicle Type</th><th>Count</th><th>Remove</th></tr></thead>
                                    <tbody></tbody>
                                </table>
                                <div id="${vehInfoId}" class="text-info small mt-1"></div>
                            </div>
                        </div>
                    </div>
                `;
                $('#multi_dyn').append(row);
            }
        }
    }

    $('#no_of_arrivals').change(function () {
        const value = parseInt($(this).val());
        if (value === 1) {
            $('#multi_dyn_wrapper').hide();
        } else {
            $('#multi_dyn_wrapper').show();
            generateRows(value);
        }
    });

    // Get vehicle types when hub location changes
    $(document).on('change', '.hub_location_dyn', function () {
		const index = $(this).data('index');
		const hub_id = $(this).val();

		const $vehicleDropdown = $(`.vehicle_type_dyn[data-index="${index}"]`);

		if (!hub_id) {
			$vehicleDropdown.html('<option value="">Select</option>');
			return;
		}

		$.ajax({
			type: "POST",
			url: "<?= site_url('Enquiry/get_vehicle_types_by_hub'); ?>",
			data: { hub_location_id: hub_id },
			success: function (response) {
			
				$vehicleDropdown.html(response);
			},
			error: function (xhr, status, error) {
				console.error("AJAX Error:", status, error);
				console.log("Response:", xhr.responseText);
			}
		});
	});

    // Add vehicle on vehicle type change
    $(document).on('change', '.vehicle_type_dyn', function () {
        const index = $(this).data('index');
        const vehicle_type_id = $(this).val();
        const vehTableBody = $(`#vehicle_dynamic_field_${index} tbody`);
        const vehInfo = $(`#veh_info_${index}`);

        if (!vehicle_type_id) return;

        $.ajax({
            type: "POST",
            url: "<?= site_url('Enquiry/get_vehicle_name'); ?>",
            data: { v_id: vehicle_type_id },
            dataType: 'json',
            success: function (response) {
                if (response.length > 0) {
                    const vehicle = response[0];
                    const uniqueRowId = `row_${vehicleIndex++}`;

                    const rowHtml = `
                        <tr id="${uniqueRowId}">
                            <td>
                                <input type="hidden" name="arrival[${index}][vehicles][${vehicleIndex}][vehicle_type_id]" value="${vehicle.vehicle_type_id}">
                                <input type="text" name="arrival[${index}][vehicles][${vehicleIndex}][vehicle_model_name]" value="${vehicle.vehicle_model_name}" class="form-control input-sm" readonly>
                            </td>
                            <td>
                                <select name="arrival[${index}][vehicles][${vehicleIndex}][vehicle_count]" class="form-control input-sm">
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                </select>
                            </td>
                            <td><button type="button" class="btn btn-danger btn-sm btn_arrival_vehicle_remove" data-row="${uniqueRowId}">X</button></td>
                        </tr>
                    `;
                    vehTableBody.append(rowHtml);
                    vehInfo.html('<i>* You can add multiple vehicles by selecting vehicle types above</i>');
                }
            }
        });
    });

    // Remove vehicle row
    $(document).on('click', '.btn_arrival_vehicle_remove', function () {
        const rowId = $(this).data('row');
        $(`#${rowId}`).remove();
    });
});
</script>
<script>
$(document).on('input', 'input[name^="arrival"][name$="[ndays]"]', function () {
    const $daysInput = $(this);
    const index = $daysInput.attr('name').match(/\[(\d+)\]/)[1]; // extract index from name
    const $startDateInput = $(`input[name="arrival[${index}][start_date]"]`);
    const $endDateInput = $(`input[name="arrival[${index}][end_date]"]`);

    const startDateStr = $startDateInput.val();
    const days = parseInt($daysInput.val());

    if (!startDateStr) {
        alert('Please select the Start Date before entering the number of days.');
        $daysInput.val(''); // optional: clear the ndays input
        $startDateInput.focus();
        return;
    }

    if (!isNaN(days) && days > 0) {
        const startDate = new Date(startDateStr);
        startDate.setDate(startDate.getDate() + days); // Include last day

        const year = startDate.getFullYear();
        const month = ('0' + (startDate.getMonth() + 1)).slice(-2);
        const day = ('0' + startDate.getDate()).slice(-2);
        const formattedEndDate = `${year}-${month}-${day}`;

        $endDateInput.val(formattedEndDate);
    }
});
</script>