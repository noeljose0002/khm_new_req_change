<?php 
$first = false;
$second = false;
$third = false;
$fourth = false;
$checked = "";
$edit_flag_iti = 0;
$edit_flag_enq = 0;
$edit_flag_tour = 0;
foreach ($enq_det as $enq) { 
    $object_name = $enq['object_name'] ?? '';
    $enquiry_header_id = $enq['enquiry_header_id'] ?? '';
	if($enquiry_header_id){
    	$first = true;
	}

    if (!empty($enq['enq_details'])) {
        foreach ($enq['enq_details'] as $enq_detail) {
            $enquiry_details_id = $enq_detail['enquiry_details_id'] ?? '';
			if($enquiry_details_id){
            	$second = true;
			}
            if($enq_detail['is_active'] == 1){
            	$edit_flag_enq = 1;
			}

            if (!empty($enq_detail['tour_details'])) {
                foreach ($enq_detail['tour_details'] as $tour_detail) {
                    $tour_details_id = $tour_detail['tour_details_id'] ?? '';
					if($tour_details_id){
                    	$third = true;
					}
                    if($tour_detail['is_active'] == 1){
                    	$edit_flag_tour = 1;
					}

                    if (!empty($tour_detail['iti_details'])) {
                        

                        foreach ($tour_detail['iti_details'] as $iti) {
                            $itinerary_details_id = $iti['itinerary_details_id'] ?? '';
                            $tpc = $iti['tpc'] ?? '';
                            $enquiry_detail_details_id = $iti['enquiry_detail_details_id'];
                            $enquiry_header_id = $iti['enquiry_header_id'];
                            $enquiry_details_id = $iti['enquiry_details_id'];
                            $version_count = $iti['version_count'];
                            $extension_ref_id = $iti['extension_ref_id'] ?? 0;
                            if($iti['is_draft'] == 1 && $iti['is_active'] == 1){
                                $checked = "checked";
                                $edit_flag_iti = 1;
                            }
							if($itinerary_details_id){
								$fourth = true;
							}
                            $is_draft = $iti['is_draft'];
                            $is_active = $iti['is_active'];
                            $updated_time = $iti['updated_time'];
?>
<tr>
 
	<?php if($second && $edit_flag_enq == 1){ ?>
    	<td style="background-color:#d9f2e6;"><a href="<?=site_url('Enquiry/add_object_enquiry/'); ?><?php echo $object_class_id; ?>/<?php echo $object_id; ?>" data-toggle="tooltip" data-original-title="Enquiry Edit"><i class="fa fa-edit" aria-hidden="true" style="color:#339966"></i></a></td>
	<?php } else { ?>
		<td></td>
	<?php } ?>
    <?php if($third && $edit_flag_tour == 1){ ?>
        <td style="background-color:#d9f2e6;"><a href="<?=site_url('Enquiry/tour_plan/'); ?><?php echo $object_id; ?>/1" data-toggle="tooltip" data-original-title="Tour Plan Edit"><i class="fa fa-edit" aria-hidden="true" style="color:#339966"></i></a></td>
    <?php } else { ?>
		<td></td>
	<?php } ?>

    <?php if($fourth && $edit_flag_iti == 1){ ?>
        <td style="background-color:#d9f2e6;">
            <a href="<?=site_url('Enquiry/itinerary/'); ?><?php echo $object_id; ?>/0/<?php echo $enquiry_detail_details_id; ?>/<?php echo $version_count; ?>" data-toggle="tooltip" data-original-title="Itinerary Edit"><i class="fa fa-edit" aria-hidden="true" style="color:#339966"></i></a>
        </td>
    <?php } else { ?>
		<td></td>
	<?php } ?>

    <?php if($fourth && $edit_flag_iti == 1){ ?>
        <td style="background-color:#d9f2e6;">
            <a href="<?=site_url('Enquiry/itinerary/'); ?><?php echo $object_id; ?>/0/<?php echo $enquiry_detail_details_id; ?>/0/<?php echo $extension_ref_id; ?>" data-toggle="tooltip" data-original-title="Extension Edit"><i class="fa fa-edit" aria-hidden="true" style="color:#339966"></i></a>
        </td>
    <?php } else { ?>
		<td></td>
	<?php } ?>


    <?php if($fourth){ ?>
        <td><input type="radio" name="itinerary_select" class="itinerary-radio" <?php echo $checked; ?>></td>
    <?php } else { ?>
		<td></td>
	<?php } ?>

    <?php if($fourth){ ?>
        <td><?php echo $tpc; ?></td>
    <?php } else { ?>
		<td></td>
	<?php } ?>
  
</tr>
<?php
                            $first = false;
                            $second = false;
                            $third = false;
                            $fourth = false;
                            $checked = "";
                            $edit_flag_iti = 0;
                        }
                    }
					$first = false;
                    $second = false;
                    $third = false;
                    $fourth = false;
                    $edit_flag_tour = 0;
                }
            }
			$first = false;
            $second = false;
            $third = false;
            $fourth = false;
            $edit_flag_enq = 0;
        }
    }
	$first = false;
    $second = false;
    $third = false;
    $fourth = false;
}
?>