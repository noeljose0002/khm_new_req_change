<?php
use App\Models\Enquiry_m;
$Enquiry_model = new Enquiry_m();
$vehicle_data = json_decode($object_det[0]['vehicle_type_id'], true); // Decode JSON from DB
$d_room_tariff = 0;
$s_room_tariff = 0;

$d_child_tariff = 0;
$s_child_tariff = 0;

$d_child_wb_tariff = 0;
$s_child_wb_tariff = 0;

$d_extra_tariff = 0;
$s_extra_tariff = 0;

if($iti_edit_id == 1 || $final_save_flag == 1){
	/*$read_only = "readonly";
	$dis_abled = 'style="pointer-events: none; background-color: #eee;"';
	$dis_abled_temp = 'style="pointer-events: none; background-color: #eee;background-color:#c6ecd9;font-weight:bold;"';*/
	$read_only = "";
	$dis_abled = "";
	$dis_abled_temp = 'style="background-color:#c6ecd9;font-weight:bold;"';
}
else{
	$read_only = "";
	$dis_abled = "";
	$dis_abled_temp = 'style="background-color:#c6ecd9;font-weight:bold;"';
}

if($extension_disable == 1){
	$read_only_ext = "readonly";
	$dis_abled_ext = 'style="pointer-events: none; background-color: #eee;"';
}
else{
	$read_only_ext = "";
	$dis_abled_ext = "";
}
$is_edit = $edit_id?1:0;
$extension_ref_id = $extension_ref_id?$extension_ref_id:0;
?>
<!doctype html>
<html lang="en" dir="ltr">
	<head>

		<!-- Meta data -->
		<meta charset="UTF-8">
		<meta http-equiv="x-ua-compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta content="KHM-Touracle" name="description">
		<meta content="Megatrend Knowledge Management Systems Pvt Ltd" name="author">
		<meta name="keywords" content="KHM">
		<!-- Favicon-->
		<link rel="icon" href="<?php echo base_url('assets/images/brand/favicon.png'); ?>" type="image/x-icon"/>

		<!-- Title -->
		<title>KHM - Itinerary View</title>

		<!-- Bootstrap css -->
		<link href="<?php echo base_url('assets/plugins/bootstrap-4.1.3/css/bootstrap.min.css'); ?>" rel="stylesheet" />

		<!-- Style css -->
		<link href="<?php echo base_url('assets/css/style.css'); ?>" rel="stylesheet" />

		<!-- Default css -->
		<link href="<?php echo base_url('assets/css/default.css'); ?>" rel="stylesheet">

		<!-- Sidemenu css-->
		<link rel="stylesheet" href="<?php echo base_url('assets/plugins/sidemenu/icon-sidemenu.css'); ?>">

		<!-- Owl-carousel css-->
		<link href="<?php echo base_url('assets/plugins/owl-carousel/owl.carousel.css'); ?>" rel="stylesheet" />

		<!-- Bootstrap-daterangepicker css -->
		<link rel="stylesheet" href="<?php echo base_url('assets/plugins/bootstrap-daterangepicker/daterangepicker.css'); ?>">

		<!-- Bootstrap-datepicker css -->
		<link rel="stylesheet" href="<?php echo base_url('assets/plugins/bootstrap-datepicker/bootstrap-datepicker.css'); ?>">

		<!-- Custom scroll bar css -->
		<link href="<?php echo base_url('assets/plugins/scroll-bar/jquery.mCustomScrollbar.css'); ?>" rel="stylesheet"/>

		<!-- Sidemenu-repsonsive-tabs  css -->
		<link href="<?php echo base_url('assets/plugins/sidemenu-responsive-tabs/css/sidemenu-responsive-tabs.css'); ?>" rel="stylesheet">

		<!-- P-scroll css -->
		<link href="<?php echo base_url('assets/plugins/p-scroll/p-scroll.css'); ?>" rel="stylesheet" type="text/css">

		<!-- Font-icons css -->
		<link  href="<?php echo base_url('assets/css/icons.css'); ?>" rel="stylesheet">

		<!-- Rightsidebar css -->
		<link href="<?php echo base_url('assets/plugins/sidebar/sidebar.css'); ?>" rel="stylesheet">

		<!-- Data table css -->
		<link href="<?php echo base_url('assets/plugins/datatable1/css/dataTables.bootstrap4.min.css'); ?>" rel="stylesheet"/>
		<link href="<?php echo base_url('assets/plugins/datatable1/css/buttons.bootstrap4.min.css'); ?>" rel="stylesheet">
		<link href="<?php echo base_url('assets/plugins/datatable1/responsive.bootstrap4.min.css'); ?>" rel="stylesheet"/>

		<!-- Nice-select css  -->
		<link href="<?php echo base_url('assets/plugins/jquery-nice-select/css/nice-select.css'); ?>" rel="stylesheet"/>

		<link href="<?php echo base_url('assets/plugins/select2/select2.min.css'); ?>" rel="stylesheet"/>

		<!-- Color-palette css-->
		<link rel="stylesheet" href="<?php echo base_url('assets/css/skins.css'); ?>"/>
		<script src="<?php echo base_url('assets/tiny_mce/tiny_mce.js');?>"></script>

	<style>
		
		.small-label {
			font-size: 0.7em;
			font-style: italic;
			font-weight:bold;
			color: #003300;
			padding: 0px 0px;
			margin-bottom: 0rem !important;
		}

		.costing-container {
			justify-content: center;
			align-items: center;
			flex-direction: column;
			padding: 5px;
			margin: 5px auto;
		}

		.costing-box {
			border: 2px solid green;
			border-radius: 8px;
			padding: 5px;
			background-color: #f9f9f9;
			width: 100%;
			box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
		}

		.costing-table {
			width: 100%;
			background-color: #ffffff;
			border-collapse: collapse;
			text-align: center;
		}

		.costing-table th,
		.costing-table td {
			border: 1px solid #ddd;
			padding: 5px;
		}

		.costing-table th {
			background-color: #f1f1f1;
			font-weight: bold;
		}
	</style>
    <style>
		.table th, .text-wrap table th {
			color:#004d00 !important;
		}
		.nice-select{
			border: 1px solid #004d00 !important;
		}

		.custom-modal-width {
			max-width: 90%; /* Adjust as needed */
			width: 90%;
		}
		.nice-select .list {
			max-height: 400px !important; /* Adjust height as needed */
			overflow-y: auto !important; /* Enable scrolling */
		}

		.card-header {
			min-height: 1rem !important;
		}
		.card-body {
			padding: .5rem .5rem !important;
		}
		.table-bordered th, .text-wrap table th, .table-bordered td, .text-wrap table td {
			border: 1px solid #004d00 !important;
			padding: 0.1rem !important;
			text-align: center;
    		vertical-align: middle;
		}
		.card {
			background-color:#d9f2e6 !important;
		}
		.card-options a:not(.btn) {
			color: #0b0b0b !important;
		}
		
		.header .nav-link .badge {
			
			width: 3rem !important;
			height: 1rem !important;
		
		}
		.separator {
			display: inline-block;
			width: 2px; /* Adjust thickness */
			height: 25px; /* Adjust height */
			background-color: #c2d6d6; /* Change color if needed */
			margin: 0 10px; /* Add spacing */
		}
		.line {
			height: 1px;
			background-color: #c2d6d6;
			width: 100%;
			margin: 0px 0;
		}
		.pulse-secondary {
    		background: #025f0d !important;
		}
		.nav-tabs .nav-link.active {
    		background: #047058 !important;
		}
		.card {
    		border: 1px solid #0ae921 !important;
		}

		select.form-control {
			border: 1px solid #339966; /* Default border */
			border-radius: 4px;
		}

		/* On focus (when the dropdown is clicked) */
		.form-control:focus {
			border-color: #006600; /* Green border when selected/focused */
			outline: none;
			box-shadow: 0 0 0 5px rgba(21, 236, 68, 0.2); /* Optional subtle shadow */
		}
		.form-control {
			border-radius: 10px !important;
		}
		body {
			cursor: pointer;
		}
		.stylish-cursor {
			position: fixed;
			top: 0;
			left: 0;
			width: 16px;
			height: 16px;
			background: rgba(40, 167, 69, 0.6); /* Bootstrap green */
			border-radius: 50%;
			pointer-events: none;
			z-index: 9999;
			box-shadow: 0 0 10px rgba(40, 167, 69, 0.8),
						0 0 20px rgba(40, 167, 69, 0.5);
			transform: translate(-50%, -50%);
			transition: transform 0.05s ease-out;
		}

		#btn_savedraft_iti_plan, #btn_save_iti_plan {
			background: #339966;
			color: white;
			border: 1px solid #006600;
			border-radius: 12px;
			backdrop-filter: blur(8px);
			-webkit-backdrop-filter: blur(8px);
			padding: 6px 14px;
			font-size: 16px;
			font-weight: 600;
			float: right;
			cursor: pointer;
			transition: all 0.3s ease-in-out;
		}

		#btn_savedraft_iti_plan:hover, #btn_save_iti_plan:hover {
			background: #006600;
			transform: scale(1.05);
		}
		
		.tab-menu-heading {
			padding: 0px 0px !important;
		}
		.p-3 {
			padding: 0rem !important;
		}
		.nav-tabs .nav-link.active {
			background: #003300 !important;
		}
		.tabs-menu1 ul li .active {
    		border-radius: 10px !important;
		}
		.nav-tabs .nav-link {
    		padding: .2rem .5rem !important;
		}
		.nav-tabs .nav-link:hover:not(.disabled) {
			background: #339966;
		}
		.card-header {
    		padding: 0rem 0rem !important;
			min-height: 0rem !important;
		}
	
		#view_cost_sheet_id, #gen_cost_sheet_id, #tour_view_id, #cancel_cost_sheet_id,#ac_btn_id {
			background: #339966;
			color: white;
			border: 1px solid #006600;
			border-radius: 12px;
			backdrop-filter: blur(8px);
			-webkit-backdrop-filter: blur(8px);
			padding: 6px 14px;
			font-size: 16px;
			font-weight: 600;
			float: right;
			cursor: pointer;
			transition: all 0.3s ease-in-out;
		}

		#view_cost_sheet_id:hover, #gen_cost_sheet_id:hover, #tour_view_id:hover, #cancel_cost_sheet_id:hover, #ac_btn_id:hover {
			background: #006600;
			transform: scale(1.05);
		}

		.breadcrumb-arrow li:first-child a {
			padding-left: 0px !important;
		}
		.breadcrumb-arrow li:first-child a {
			padding: 0 0px !important;
		}
		.breadcrumb-arrow li:first-child a {
		
			-webkit-border-radius: 0px 0 0 0px !important;
		
		}
		.breadcrumb-arrow li a {
			border: 1px solid #fafdfc !important;
		}
		.breadcrumb-arrow li a, .breadcrumb-arrow li:not(:first-child) span {
			height: 26px !important;
			padding: 0 3px 0 2px !important;
			line-height: 26px !important;
		}
		.breadcrumb-arrow {
			height: 0px !important;
			padding: 0 !important;
			line-height: 0px !important;
			font-size: 12px !important;
		}
		.breadcrumb-arrow li a:after, .breadcrumb-arrow li a:before {
			border-top: 0px solid transparent !important;
			border-bottom: 0px solid transparent !important;
		}
		.breadcrumb-arrow li span {
			padding: 0 3px;
		}
		/*input[type="date"],
		input[type="text"],
		label,
		select,
		option {
			font-size: 11px;
		}*/
		.fixed-save-buttons {
			position: sticky;
			bottom: 0;
			background: #f8f9fa; /* Light gray background */
			padding: 15px 20px;
			z-index: 1000;
			border-top: 1px solid #ccc;
			text-align: center;
		}
		.card
		{
    		border: 1px solid #fff !important;
			border-radius:10px !important;
		}
		.wideget-user-tab.wideget-user-tab3 .tabs-menu1 ul li .active {
			padding: 5px 5px 5px 5px;
			background: #004d00;
			font-weight:bold;
			font-size:20px;
			color:#fff;
			border: 0;
		}
		.card-body {
			padding: .0rem .0rem !important;
		}
		.nav-tabs {
    		margin: 0rem !important;
			justify-content: center !important;
		}
		.tab-menu-heading {
			padding: 20px 8px;
			border: 0px;
		}
		.col, .col-1, .col-10, .col-11, .col-12, .col-2, .col-3, .col-4, .col-5, .col-6, .col-7, .col-8, .col-9, .col-auto, .col-lg, .col-lg-1, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-lg-auto, .col-md, .col-md-1, .col-md-10, .col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-md-auto, .col-sm, .col-sm-1, .col-sm-10, .col-sm-11, .col-sm-12, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-sm-auto, .col-xl, .col-xl-1, .col-xl-10, .col-xl-11, .col-xl-12, .col-xl-2, .col-xl-3, .col-xl-4, .col-xl-5, .col-xl-6, .col-xl-7, .col-xl-8, .col-xl-9, .col-xl-auto
		{
			position: relative;
			width: 100%;
			min-height: 1px;
			padding-right: 15px;
			padding-left: 15px;
		}

	</style>
	</head>
	<body class="app sidebar-mini">	
	<?php
		$start_date = date('Y-m-d', strtotime($object_det[0]['start_date']));
		$meal_plan = date('Y-m-d', strtotime($object_det[0]['meal_plan']));
	?>
		<!-- Loader -->
		<div id="loading">
			<img src="<?php echo base_url('assets/images/other/loader.svg'); ?>" class="loader-img" alt="Loader">
		</div>
											<div class="modal fade overflow-hidden" id="modal_tour" tabindex="-1" role="dialog" aria-labelledby="modal-default" aria-hidden="true">
												<div class="modal-dialog custom-modal-width" role="document">
													<div class="modal-content">
														<div class="modal-header">
															<h5 class="modal-title" id="example-Modal3">Tour Plan View</h5>
															<button type="button" class="close" data-dismiss="modal" aria-label="Close">
																<span aria-hidden="true">&times;</span>
															</button>
														</div>
														
														<div class="modal-body tab_con">
														
														</div>
														
														<div class="modal-footer">
															
															<button type="button" class="btn btn-success  ml-auto" data-dismiss="modal">Close</button>
														</div>
													</div>
												</div>
											</div>

											<div class="modal fade overflow-hidden" id="modal_qq" tabindex="-1" role="dialog" aria-labelledby="modal-default" aria-hidden="true">
												<div class="modal-dialog custom-modal-width" role="document">
													<div class="modal-content">
														<div class="modal-header">
															<h5 class="modal-title" id="example-Modal3">Quick Quote View</h5>
															<button type="button" class="close" data-dismiss="modal" aria-label="Close">
																<span aria-hidden="true">&times;</span>
															</button>
														</div>
														
														<div class="modal-body tab_con_qq">
														
														</div>
														
														<div class="modal-footer">
															
															<button type="button" class="btn btn-success  ml-auto" data-dismiss="modal">Close</button>
														</div>
													</div>
												</div>
											</div>

											

		<!-- PAGE -->
		<div class="page">
			<div class="page-main">

				<!-- Top-header opened -->
				<div class="header-main header sticky">
					<div class="app-header header top-header navbar-collapse ">
						<div class="container-fluid">
							<div class="d-flex">
								<a class="header-brand" href="index.html">
									<img src="<?php echo base_url('assets/images/brand/logo.png'); ?>" class="header-brand-img desktop-logo " alt="Dashlot logo">
									<img src="<?php echo base_url('assets/images/brand/logo1.png'); ?>" class="header-brand-img desktop-logo-1 " alt="Dashlot logo">
									<img src="<?php echo base_url('assets/images/brand/favicon.png'); ?>" class="mobile-logo" alt="Dashlot logo">
									<img src="<?php echo base_url('assets/images/brand/favicon1.png'); ?>" class="mobile-logo-1" alt="Dashlot logo">
								</a>
								<a href="#" data-toggle="sidebar" class="nav-link icon toggle"><i class="fe fe-align-justify fs-20"></i></a>
								<div class="d-flex header-left left-header">
									<div class="d-none d-lg-block horizontal">
										<ul class="nav">
											<li class="">
												<div class="dropdown d-none d-md-flex">
													<a href="#" class="d-flex nav-link pr-0  pt-2 mt-3 country-flag1" data-toggle="dropdown">
														<span class="d-flex"><img src="<?php echo base_url('assets/images/roles.jpg'); ?>" alt="img" class="avatar country-Flag mr-2 align-self-center"></span>
														<div>
															<span class="d-flex fs-14 mr-3 mt-0"><?php echo session('active_role_name'); ?><span><i class="mdi mdi-chevron-down"></i></span></span>
														</div>
													</a>
													<div class="dropdown-menu dropdown-menu-left dropdown-menu-arrow">
													<?php foreach ($all_roles_assn as $data) : ?>
														<a href="#" onclick="switchroles(<?php echo $data['role_id']; ?>,'<?php echo $data['role_name']; ?>');" class="dropdown-item d-flex align-items-center mt-2">
															<div>
																<span><?php echo $data['role_name']; ?></span>
															</div>
														</a>
													<?php endforeach; ?>
														
													</div>
												</div>
											</li>
										</ul>
									</div>
								</div>
								<div class="d-flex header-left left-header">
									<div class="d-none d-lg-block horizontal">
										<ul class="nav">
											<li class="">
												<div class="dropdown d-none d-md-flex">
													<a href="#" class="d-flex nav-link pr-0  pt-2 mt-3 country-flag1" data-toggle="dropdown">
														<span class="d-flex"><img src="<?php echo base_url('assets/images/system.jpg'); ?>" alt="img" class="avatar country-Flag mr-2 align-self-center"></span>
														<div>
															<span class="d-flex fs-14 mr-3 mt-0"><?php echo session('system_name'); ?><span><i class="mdi mdi-chevron-down"></i></span></span>
														</div>
													</a>
													<div class="dropdown-menu dropdown-menu-left dropdown-menu-arrow">
														<?php foreach ($all_systems as $datas) : ?>
															<a href="#" onclick="switchsystems(<?php echo $datas['entity_boolean_id']; ?>,'<?php echo $datas['boolean_name']; ?>');" class="dropdown-item d-flex align-items-center mt-2">
																<div>
																	<span><?php echo $datas['boolean_name']; ?></span>
																</div>
															</a>
														<?php endforeach; ?>
													</div>
												</div>
											</li>
										</ul>
									</div>
								</div>
								
								<div class="d-flex header-right ml-auto">
									<div class="profile-details mt-1" style="padding-top:10px;">
										<span class="mr-3 mb-0  fs-15 font-weight-bold" style="color:#003300;font-weight:bold;">Tour Start Date : <?php echo $object_det[0]['start_date']; ?></span>
									</div>
									<div class="profile-details mt-1" style="padding-top:10px;">
										<span class="mr-3 mb-0  fs-15 font-weight-bold" style="color:#003300;">Nights : <span id="planned_night"></span><?php echo $object_det[0]['no_of_night']; ?></span>
									
									</div>
									<div class="profile-details mt-1" style="padding-top:10px;">
										<span class="mr-3 mb-0  fs-15 font-weight-bold" style="color:#003300;font-weight:bold;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tour End Date : <?php echo $object_det[0]['end_date']; ?></span>
									</div>
									<div class="dropdown header-fullscreen">
										<a class="nav-link icon full-screen-link" id="fullscreen-button">
											<i class="mdi mdi-arrow-collapse fs-20"></i>
										</a>
									</div>
									
									<div class="dropdown drop-profile">
										<a class="nav-link pr-0 leading-none" href="#" data-toggle="dropdown" aria-expanded="false">
											<div class="profile-details mt-1">
												<span class="mr-3 mb-0  fs-15 font-weight-semibold"><?php echo session('user_name'); ?></span>
												<!--<small class="text-muted mr-3">appdeveloper</small>-->
											</div>
											<img class="avatar avatar-md brround" src="<?php echo base_url('assets/images/users/user.png'); ?>" alt="image">
										 </a>
										<div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow animated bounceInDown w-250">
											<div class="user-profile bg-header-image border-bottom p-3">
												<div class="user-image text-center">
													<img class="user-images" src="<?php echo base_url('assets/images/users/user.png'); ?>" alt="image">
												</div>
												<div class="user-details text-center">
													<h4 class="mb-0"><?php echo session('user_name'); ?></h4>
													<!--<p class="mb-1 fs-13 text-white-50">Jonathan@gmail.com</p>-->
												</div>
											</div>
											<a class="dropdown-item" href="#">
												<i class="dropdown-icon mdi mdi-account-outline "></i> Profile
											</a>
											<a class="dropdown-item" href="#">
												<i class="dropdown-icon  mdi mdi-settings"></i> Settings
											</a>
											<a class="dropdown-item" href="#">
												<span class="float-right"><span class="badge badge-success">6</span></span>
												<i class="dropdown-icon mdi  mdi-message-outline"></i> Inbox
											</a>
											<a class="dropdown-item" href="#">
												<i class="dropdown-icon mdi mdi-comment-check-outline"></i> Message
											</a>
											<div class="dropdown-divider"></div>
											<a class="dropdown-item" href="#">
												<i class="dropdown-icon mdi mdi-compass"></i> Need help?
											</a>
											<a class="dropdown-item mb-1" href="<?=site_url('Login/logout');?>">
												<i class="dropdown-icon mdi  mdi-logout-variant"></i> Sign out
											</a>
										</div>
									</div><!-- Profile -->
								
								</div>
							</div>

							<div class="line"></div>
							<div class="d-flex">
								<a class="header-brand" href="<?=site_url('Dashboard');?>">
									
								</a>
								<a href="#" data-toggle="sidebar" class="nav-link icon toggle"></a>
								

								<div class="d-flex header-left left-header">
									<div class="d-none d-lg-block horizontal" style="padding-top:7px;">
						
										<button type="button" id="tour_view_id" class="btn btn-success tour_view">View Tour Plan</button>
									</div>
								</div>
								<div class="d-flex header-right ml-auto">
									<div class="dropdown d-md-flex message" style="padding-top:10px;">
										<span class="separator"></span>
											<p class="h5" style="color:#003300;font-weight:bold;"><?php echo $object_det[0]['object_name']; ?></p>
										<span class="separator"></span>
									</div>
									<?php if($object_det[0]['enq_type_id'] == "3"){ ?>
										<div class="dropdown d-md-flex message" style="padding-top:10px;">
											<p class="h5" style="color:#003300;font-weight:bold;"><?php echo $object_det[0]['agent_name']; ?></p>
											<span class="separator"></span>
										</div>
									<?php } ?>
									<div class="dropdown d-md-flex message" style="padding-top:10px;">
										<p class="h5" style="color:#003300;font-weight:bold;">Accom-Total : <span id="a_total"></span></p>
										<span class="separator"></span>
									</div>
									<div class="dropdown d-md-flex message" style="padding-top:10px;"> 
										<p class="h5" style="color:#003300;font-weight:bold;">Trans-Total : <span id="v_total"></span></p>
										<span class="separator"></span>
									</div>
									
									<div class="dropdown d-md-flex message" style="padding-top:10px;">
										<p class="h5" style="color:#003300;font-weight:bold;">Grand Total : <span id="g_total"></span></p>
										<span class="separator"></span>
									</div>
								</div>
							</div>
							<div class="line"></div>

							<div class="d-flex">
								<a class="header-brand" href="<?=site_url('Login/logout');?>">
								
								</a>
								<a href="#" data-toggle="sidebar" class="nav-link icon toggle"></a>
								<div class="d-flex header-left left-header">
									<div class="d-none d-lg-block horizontal" style="padding-top:5px;">
										
											<ol class="breadcrumb breadcrumb-arrow mt-3 bg-light">
												<?php 
												$bcount = 1;
												$tour_plan_det_count = count($tour_plan_det);
												foreach ($tour_plan_det as $ttkey => $ttval) { 
													$startDates = new DateTime($ttval['check_in_date']);
													$endDates = new DateTime($ttval['check_out_date']);
													while ($startDates < $endDates) {  
														$iti_id = $ttval['tour_details_id']."_".$startDates->format('d-m-Y');
														$iti_id_temp = $ttval['tour_details_id'];
													?>
												
													<li class="bc-card" data-index="<?php echo $iti_id; ?>">
														<a>
															<span class="bc-card-seq" style="color:#fff;font-weight:bold;"><?php echo $bcount; ?></span><span style="color:#fff;font-weight:bold;">. <?php echo $startDates->format('d-m-Y'); ?> - <span id="span_bread_id<?php echo $iti_id; ?>" style="color:#fff"></span></span>
														</a>
													</li>
												<?php 
													$startDates->modify('+1 day'); 
													$bcount ++;
												} 
												
												} 
												$iti_id = $iti_id_temp."_".$object_det[0]['end_date'];
												?>
													<li class="bc-card" data-index="<?php echo $iti_id; ?>">
														<a>
															<span class="bc-card-seq" style="color:#fff;font-weight:bold;"><?php echo $bcount; ?></span><span style="color:#fff;font-weight:bold;">. <?php echo $object_det[0]['end_date']; ?> - <span id="span_bread_id<?php echo $iti_id; ?>" style="color:#fff"></span></span>
														</a>
													</li>
											</ol>	
										 
											
									</div>
								</div>
							</div>

						</div>
					</div>
				</div>
				<!-- Top-header closed -->

				<!-- Sidebar menu-->
				<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
				<aside class="app-sidebar toggle-sidebar">
					<div class="app-sidebar__user">
						<div class="user-body">
							<img src="<?php echo base_url('assets/images/users/user.png'); ?>" alt="profile-img" class="rounded-circle w-25">
						</div>
						<div class="user-info">
							<a href="#" class=""><span class="app-sidebar__user-name font-weight-semibold"><?php echo session('user_name'); ?></span><br>
							<!--span class="text-muted app-sidebar__user-designation text-sm">App Developer</span>-->
							</a>
						</div>
					</div>
					<ul class="side-menu toggle-menu">
						<?php foreach($parent_menu as $key1 => $val1){ 
							$img_tmp = $val1['entity_trans_id'].".svg";
							?>
							<li class="slide">
								<a class="side-menu__item"  data-toggle="slide" href=""><span class="icon-menu-img"><img src="<?php echo base_url('assets/images/svgs/'.$img_tmp); ?>" class="side_menu_img svg-1" alt="image"></span><span class="side-menu__label"><?php echo $val1['entity_trans_name']; ?></span><i class="angle fa fa-angle-right"></i></a>
								<ul class="slide-menu">
									<?php foreach($sub_menu as $key2 => $val2){ 
										if($val1['entity_trans_id'] == $val2['prs_parent_id']){
											foreach($all_menus as $key3 => $val3){
												if($val3['entity_trans_id'] == $val2['entity_trans_id']){
										?>
											<li><a class="slide-item" href="<?=site_url($val2['menu_link']);?>"><span><?php echo $val2['entity_trans_name']; ?></span></a></li>
									<?php } } } } ?>
								</ul>
							</li>
						<?php } ?>
					</ul>
				</aside>
				<!-- Sidemenu closed -->

				<!-- App-content opened -->
				<div class="app-content icon-content">
				<div class="section business-management mt-5">

						<!-- Page-header opened -->
						<!--<div class="page-header">
							<div class="page-leftheader">
								<h4 class="page-title mb-0"><?php echo $object_class_name; ?></h4>
								<small class="text-muted mt-0">Create / Edit <?php echo $object_class_name; ?></small>
							</div>
							<div class="page-rightheader">
								<div class="ml-3 ml-auto d-flex">
								
									<div class="mt-4 mt-xl-0 mt-lg-4 mt-md-4 mt-md-0">
										<a href="<?=site_url('Enquiry/enquiry_list_view/'.$object_class_id); ?>" class="btn btn-success ml-0 ml-md-4 mt-1 "><i class="typcn typcn-eye mr-1"></i>Enquiry List View</a>
									</div>
								</div>
							
							</div>
						</div>-->

						
						<!-- Page-header closed -->

						<!-- row opened -->
						
						 
						<div class="row" style="padding-top:125px;">
							<div class="col-lg-12">
							
								<div class="wideget-user-tab wideget-user-tab3">
									<div class="tab-menu-heading">
										<div class="tabs-menu1">
											<ul class="nav nav-tabs" id="outer-location-tabs">
												
												<?php foreach ($tour_plan_det as $tkey => $tval) { 
													if($tkey == 0) {
													?>
													 <li class=""><a href="#tab-<?php echo $tval['tour_details_id']; ?>" class="nav-link <?php echo $tval['tour_details_id']; ?> active" data-toggle="tab"><b><?php echo $tval['geog_name']; ?></b></a></li>

												<?php } 
													else { ?>
													<li><a href="#tab-<?php echo $tval['tour_details_id']; ?>" data-toggle="tab" class="nav-link <?php echo $tval['tour_details_id']; ?>"><b><?php echo $tval['geog_name']; ?></b></a></li>
												<?php	
													}
												} ?>

											</ul>
										</div>
									</div>
								</div>
								
								<form id="myTourplanForm" method="POST" action="<?=site_url('Enquiry/saveItinerary');?>">
									<input type="hidden" name="hotel_additi" value="">
									<input type="hidden" name="enquiry_header_id" value="<?php echo $object_det[0]['enquiry_header_id']; ?>">
									<input type="hidden" name="enquiry_details_id" value="<?php echo $object_det[0]['enquiry_details_id']; ?>">
									<input type="hidden" name="is_quick_quote" value="<?php echo $object_det[0]['is_quick_quote']; ?>">
									<input type="hidden" name="h_no_of_night" value="<?php echo $object_det[0]['no_of_night']; ?>">
									<input type="hidden" name="object_id" value="<?php echo $object_id; ?>">
									<input type="hidden" name="edit_id" value="<?php echo $edit_id; ?>">
									<input type="hidden" name="is_edit" value="<?php echo $is_edit; ?>">
									<input type="hidden" name="tour_plan_ref_id" value="<?php echo $tour_plan_ref_id; ?>">
									<input type="hidden" name="extension_ref_id_temp" value="<?php echo $extension_ref_id_temp; ?>">
									<input type="hidden" name="version_count" value="<?php echo $version_count; ?>">
									<input type="hidden" name="no_of_double_room" value="<?php echo $object_det[0]['no_of_double_room']; ?>">
									<input type="hidden" name="no_of_single_room" value="<?php echo $object_det[0]['no_of_single_room']; ?>">
									<div class="bg-white widget-user mb-0">
										<div class="card-body">
											<div class="border-0">
												<div class="tab-content">
													
													
													<?php 
													$breadcrumb = '';
													$tpd_count = count($tour_plan_det) - 1;
													$day_count = 1;
													foreach ($tour_plan_det as $ttkey => $ttval) { 
														$vehicle_details = json_decode($ttval['vehicle_details']);
														$cnt = 0;
														?>
														<div class="tab-pane <?php echo ($ttkey == 0) ? 'show active' : ''; ?>" id="tab-<?php echo $ttval['tour_details_id']; ?>">
															<div class="row">
																<div class="col-xl-12">
																	<div class="">
																		<!--<div class="card mb-0 box-shadow-0">-->
																			<div class="tab-menu-heading">
																				<div class="tabs-menu1">
																					<!-- Horizontal Itinerary Tabs -->
																					<ul class="nav nav-tabs" role="tablist">
																						<?php 
																						$startDate = new DateTime($ttval['check_in_date']);
																						$endDate = new DateTime($ttval['check_out_date']);
																						if($ttkey == $tpd_count){
																							$endDate->modify('+1 day'); 
																						}
																						while ($startDate < $endDate) {  
																							$iti_id = $ttval['tour_details_id']."_".$startDate->format('d-m-Y');
																							$iti_id_last = $ttval['tour_details_id'];
																							?>
																							<li class="nav-item">
																								<a href="#tabi-<?php echo $iti_id; ?>" class="nav-link <?php echo ($cnt == 0) ? 'active' : ''; ?>" data-toggle="tab">
																									<b><?php echo $startDate->format('d-m-Y'); ?></b>
																								</a>
																							</li>
																							<?php 
																							$startDate->modify('+1 day'); 
																							$cnt++;
																						} 
																					
																						?>
																							
																					</ul>
																				</div>
																			</div>

																			<!-- Tab Content for Itinerary -->
																			<div class="tab-content">
																				<?php 
																				$startDate1 = new DateTime($ttval['check_in_date']);
																				$endDate1 = new DateTime($ttval['check_out_date']);

																				if($ttkey == $tpd_count){
																					//$endDate1->add(new DateInterval('P1D'));
																					$endDate1->modify('+1 day'); 
																				}
																				$cnt1 = 0;
																				while ($startDate1 < $endDate1) { 
																					$iti_id = $ttval['tour_details_id']."_".$startDate1->format('d-m-Y');
																					foreach($tariff_details_iti as $tppkey => $tppval){
																						if($tppval['tour_date'] == $startDate1->format('Y-m-d')){
																									$d_room_tariff = $tppval['d_room_tariff'];
																									$s_room_tariff = $tppval['s_room_tariff'];
																									$d_child_tariff = $tppval['d_child_tariff'];
																									$s_child_tariff = $tppval['s_child_tariff'];
																									$d_child_wb_tariff = $tppval['d_child_wb_tariff'];
																									$s_child_wb_tariff = $tppval['s_child_wb_tariff'];
																									$d_extra_tariff = $tppval['d_extra_tariff'];
																									$s_extra_tariff = $tppval['s_extra_tariff'];
																						}
																					}

																					foreach($tour_plan_tariff as $tppkey => $tppval){
																						if($ttval['tour_details_id'] == $tppkey){
																							foreach($tour_plan_tariff[$tppkey] as $tpkey => $tpval){
																								if($tpval['cost_component_id'] == 6 && $tpval['room_type_id'] == 2){
																									$d_room_tariff_t = $tpval['quick_quote_tariff'];
																								}
																								if($tpval['cost_component_id'] == 6 && $tpval['room_type_id'] == 1){
																									$s_room_tariff_t = $tpval['quick_quote_tariff'];
																								}
																							
																								if($tpval['cost_component_id'] == 12 && $tpval['room_type_id'] == 2){
																									$d_child_tariff_t = $tpval['quick_quote_tariff'];
																								}
																								if($tpval['cost_component_id'] == 12 && $tpval['room_type_id'] == 1){
																									$s_child_tariff_t = $tpval['quick_quote_tariff'];
																								}
																							
																								if($tpval['cost_component_id'] == 15 && $tpval['room_type_id'] == 2){
																									$d_child_wb_tariff_t = $tpval['quick_quote_tariff'];
																								}
																								if($tpval['cost_component_id'] == 15 && $tpval['room_type_id'] == 1){
																									$s_child_wb_tariff_t = $tpval['quick_quote_tariff'];
																								}
																							
																								if($tpval['cost_component_id'] == 9 && $tpval['room_type_id'] == 2){
																									$d_extra_tariff_t = $tpval['quick_quote_tariff'];
																								}
																								if($tpval['cost_component_id'] == 9 && $tpval['room_type_id'] == 1){
																									$s_extra_tariff_t = $tpval['quick_quote_tariff'];
																								}
																							}
																						}
																					}

																					/*if($d_room_tariff == 0){
																						$d_room_tariff = $d_room_tariff_t;
																					}
																					if($s_room_tariff == 0){
																						$s_room_tariff = $s_room_tariff_t;
																					}
																					if($d_child_tariff == 0){
																						$d_child_tariff = $d_child_tariff_t;
																					}
																					if($s_child_tariff == 0){
																						$s_child_tariff = $s_child_tariff_t;
																					}
																					if($d_child_wb_tariff == 0){
																						$d_child_wb_tariff = $d_child_wb_tariff_t;
																					}
																					if($s_child_wb_tariff == 0){
																						$s_child_wb_tariff = $s_child_wb_tariff_t;
																					}
																					if($d_extra_tariff == 0){
																						$d_extra_tariff = $d_extra_tariff_t;
																					}
																					if($s_extra_tariff == 0){
																						$s_extra_tariff = $s_extra_tariff_t;
																					}*/

																					if(!empty($tour_plan_tariff)){
																					
																							$d_room_tariff = $d_room_tariff_t;
																						
																							$s_room_tariff = $s_room_tariff_t;
																						
																							$d_child_tariff = $d_child_tariff_t;
																						
																							$s_child_tariff = $s_child_tariff_t;
																						
																							$d_child_wb_tariff = $d_child_wb_tariff_t;
																				
																							$s_child_wb_tariff = $s_child_wb_tariff_t;
																					
																							$d_extra_tariff = $d_extra_tariff_t;
																					
																							$s_extra_tariff = $s_extra_tariff_t;
																						
																					}


																					$tac_double = ($object_det[0]['no_of_double_room']*$d_room_tariff) + ($object_det[0]['no_of_child_with_bed']*$d_child_tariff) + ($object_det[0]['no_of_child_without_bed']*$d_child_wb_tariff) + ($object_det[0]['no_of_extra_bed']*$d_extra_tariff);
																					$tac_single = ($object_det[0]['no_of_single_room']*$s_room_tariff);
																					$tac = $tac_double + $tac_single;
																					$spcl_tariff = 0;
																					$hot_fac_id = 0;
																					$hot_fac_tariff = 0;
																					$sight_id = 0;
																					$sight_tariff = 0;
																					$daily_addon = 0;
																					$remarks ='';
																					$child_with_bed = $object_det[0]['no_of_child_with_bed'];
																					$child_without_bed = $object_det[0]['no_of_child_without_bed'];
																					$extra_bed = $object_det[0]['no_of_extra_bed'];
																					$double_room = $object_det[0]['no_of_double_room'];
																					$single_room = $object_det[0]['no_of_single_room'];
																					$d_vehicles = [];
																					$d_hotels = [];
																					$saved_vehicles = [];
																					$special_event_name ='';
																					$hotel_exist = $ttval['hotel_id'];
																					$room_cat_exist = $ttval['room_category_id'];
																					$room_cat_list_draft = $ttval['room_cat_list'];
																					if(!empty($itinerary_details_draft)){ 
																						foreach($itinerary_details_draft as $dkey => $dval){
																							if($startDate1->format('Y-m-d') == $dval['tour_date']){  
																								
																								$child_with_bed = $dval['child_with_bed'];
																								$child_without_bed = $dval['child_without_bed'];
																								$extra_bed = $dval['extra_bed'];
																								$double_room = $dval['double_room'];
																								$single_room = $dval['single_room'];

																								$remarks = $dval['remarks'];
																								$special_event_name = $dval['special_event_name'];
																								$d_vehicle_details = $dval['vehicle_details'];
																								$d_hotel_details = $dval['hotel_details'];
																								$hotel_exist = $dval['hotel_id'];
																								$room_cat_list_draft = $dval['room_cat_list_draft'];
																								$room_cat_exist = $dval['room_category_id'];
																								$d_vehicles = json_decode($d_vehicle_details);
																								$saved_vehicles = json_decode($d_vehicle_details,true);
																								
													
																								$d_hotels = json_decode($d_hotel_details);
																								
																								foreach($dval['cost'] as $costkey => $costval){
																									if($costval['cost_component_id'] == 6 && $costval['room_type_id'] == 2){
																										$d_room_tariff = $costval['tariff'];
																									}
																									if($costval['cost_component_id'] == 6 && $costval['room_type_id'] == 1){
																										$s_room_tariff = $costval['tariff'];
																									}
																									if($costval['cost_component_id'] == 12 && $costval['room_type_id'] == 2){
																										$d_child_tariff = $costval['tariff'];
																									}
																									if($costval['cost_component_id'] == 12 && $costval['room_type_id'] == 1){
																										$s_child_tariff = $costval['tariff'];
																									}
																									if($costval['cost_component_id'] == 15 && $costval['room_type_id'] == 2){
																										$d_child_wb_tariff = $costval['tariff'];
																									}
																									if($costval['cost_component_id'] == 15 && $costval['room_type_id'] == 1){
																										$s_child_wb_tariff = $costval['tariff'];
																									}
																									if($costval['cost_component_id'] == 9 && $costval['room_type_id'] == 2){
																										$d_extra_tariff = $costval['tariff'];
																									}
																									if($costval['cost_component_id'] == 9 && $costval['room_type_id'] == 1){
																										$s_extra_tariff = $costval['tariff'];
																									}
																									if($costval['cost_component_id'] == 17 && $costval['room_type_id'] == 1){
																										$spcl_tariff = $costval['tariff'];
																									}
																									if($costval['cost_component_id'] == 18 && $costval['room_type_id'] == 1){
																										$hot_fac_id = $costval['tariff'];
																									}
																									if($costval['cost_component_id'] == 19 && $costval['room_type_id'] == 1){
																										$hot_fac_tariff = $costval['tariff'];
																									}
																									if($costval['cost_component_id'] == 21 && $costval['room_type_id'] == 1){
																										$sight_id = $costval['tariff'];
																									}
																									if($costval['cost_component_id'] == 22 && $costval['room_type_id'] == 1){
																										$sight_tariff = $costval['tariff'];
																									}
																									if($costval['cost_component_id'] == 23 && $costval['room_type_id'] == 1){
																										$daily_addon = $costval['tariff'];
																									}

																									$tac_double1 = ($double_room*$d_room_tariff) + ($child_with_bed*$d_child_tariff) + ($child_without_bed*$d_child_wb_tariff) + ($extra_bed*$d_extra_tariff);
																									$tac_single1 = ($single_room*$s_room_tariff);
																									$tac = $tac_double1 + $tac_single1;
																								}
																							}
																						}
																					}
												
																					?>
																					<div class="tab-pane fade <?php echo ($cnt1 == 0) ? 'show active' : ''; ?>" id="tabi-<?php echo $iti_id; ?>">
																						<div class="p-3">
																						
																								

																								<div class="col-md-12 col-lg-12 col-xl-12 location-card" data-index="<?php echo $iti_id; ?>">
																								<div class="card">
																									<div class="card-header">
																										<input type="hidden" id="own_arrange<?php echo $iti_id; ?>" name="addloc[<?php echo $iti_id; ?>][own_arrange]" value="0">
																										<input type="hidden" id="tour_details_id<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][tour_details_id]" value="<?php echo $ttval['tour_details_id']; ?>">
																										<input type="hidden" id="iti_id<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][iti_id]" value="<?php echo $iti_id; ?>">
																										<input type="hidden" id="tour_date<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][tour_date]" value="<?php echo $startDate1->format('Y-m-d'); ?>">
																										<input type="hidden" id="tour_location_id<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][tour_location_id]" value="<?php echo $ttval['tour_location']; ?>">
																										<input type="hidden" id="tour_location_name<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][tour_location_name]" value="<?php echo $ttval['geog_name']; ?>">
																										<input type="hidden" id="meal_plan_id<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][meal_plan_id]" value="<?php echo $ttval['meal_plan_id']; ?>">
																									</div>
																									<div class="card-body">
																										<div class="ibox teams mb-30 bg-boxshadow">
																											<div class="ibox-content teams">
																											<div id="hotel_dynamic_field">
																											<div id="loading-spinner" style="
																												display: none;
																												position: fixed;
																												top: 50%;
																												left: 50%;
																												z-index: 9999;
																												transform: translate(-50%, -50%);
																											">
																												<div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;">
																													<span class="sr-only">Loading...</span>
																												</div>
																											</div>
																											
																												<?php if($startDate1->format('d-m-Y') == $object_det[0]['end_date']){ ?>
																														<select id="hotelid<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][hotelid]" data-id="<?php echo $iti_id; ?>" class="form-control input-sm hotel_change" style="display:none;">
																															<option value="">Select</option>
																																
																														</select>
																														<select id="roomcat<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][roomcat]" data-id="<?php echo $iti_id; ?>" data-sid="1" class="form-control input-sm room_cat_change" style="display:none;">
																															<option value="">Select</option>
																																
																														</select>
																														
																														<input type="hidden" id="no_of_adult<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][no_of_adult]" value="<?php echo $object_det[0]['no_of_adult']; ?>">
																														<input type="hidden" id="no_of_ch<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][no_of_ch]" value="<?php echo $child_with_bed; ?>">
																														<input type="hidden" id="no_of_cw<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][no_of_cw]" value="<?php echo $child_without_bed; ?>">
																														<input type="hidden" id="no_of_extra<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][no_of_extra]" value="<?php echo $extra_bed; ?>">

																														<input type="hidden" id="double<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][double]" value="<?php echo $double_room; ?>">
																														<input type="hidden" id="d_adult_rate<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][d_adult_rate]" value="0">
																														<input type="hidden" id="d_child_rate<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][d_child_rate]" value="0">
																														<input type="hidden" id="d_child_wb_rate<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][d_child_wb_rate]" value="0">
																														<input type="hidden" id="d_extra_bed_rate<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][d_extra_bed_rate]" value="0">

																														<input type="hidden" id="single<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>"name="additi[<?php echo $iti_id; ?>][single]" value="<?php echo $single_room; ?>">
																														<input type="hidden" id="s_adult_rate<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][s_adult_rate]" value="0">
																														<input type="hidden" id="s_child_rate<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][s_child_rate]" value="0">
																														<input type="hidden" id="s_child_wb_rate<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][s_child_wb_rate]" value="0">
																														<input type="hidden" id="s_extra_bed_rate<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][s_extra_bed_rate]" value="0">
																														
																														<select id="hotfac<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][hotfac]" class="form-control input-sm hotel_fac_change" data-id="<?php echo $iti_id; ?>" style="display:none;">
																															<option value="">Select</option>
																															
																														</select>
																														
																														<input type="hidden" id="fac_rate<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][fac_rate]" value="0">
																														<textarea id="remarks<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][remarks]" style="display:none;"></textarea>
																														<input type="hidden" id="acc_total<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][acc_total]" class="form-control input-sm" value="0">
																														<button type="button" class="btn btn-success btn-sm add_hotel" data-mp = "<?php echo $ttval['meal_plan_id']; ?>" data-tl = "<?php echo $ttval['tour_location']; ?>" data-td = "<?php echo $startDate1->format('Y-m-d'); ?>" data-id="<?php echo $iti_id; ?>" data-oid="<?php echo $iti_id; ?>" data-hid="<?= htmlspecialchars(json_encode($ttval['hotel_list']), ENT_QUOTES, 'UTF-8') ?>" <?php echo $dis_abled; ?> style="display:none">Add <i class="fa fa-plus ml-2"></i></button>
																														<div class="row" style="display:none;">
																															<div class="col-xl-12" id="hotel_dynamic_fields<?php echo $iti_id; ?>">
																																	
																																
																																
																															</div>
																														</div>
																												<?php } else { 
																														
																													?>	

																													<div class="row mt-2">
																													
																														<div class="col-xl-12 col-sm-12 col-md-12">
																															<h4 style="font-weight:bold;font-size:20px;color:#004d00;text-align:center;">Day <?php echo $day_count; ?> - <?php echo $ttval['geog_name']; ?></h4>
																														</div>
																																																										
																													</div>		
																												
																													<div class="row mt-2">
																													
																													
																														<div class="col-xl-2 col-sm-12 col-md-2">
																															<div class="teams-rank"><label class="small-label">Hotel</label></div>
																															<span class="text-muted">
																																<select id="hotelid<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][hotelid]" data-id="<?php echo $iti_id; ?>" class="form-control input-sm hotel_change" required <?php echo $dis_abled; ?>>
																																<option value="">Select</option>
																																<?php foreach($ttval['hotel_list'] as $key => $val) { 
																																	if($val['hotel_id'] == $hotel_exist){
																																	?>
																																	<option value="<?php echo $val['hotel_id']; ?>" selected><?php echo $val['object_name']; ?></option>
																																<?php } else{ ?>
																																	<option value="<?php echo $val['hotel_id']; ?>"><?php echo $val['object_name']; ?></option>
																																<?php }} ?>
																																</select>
																															</span>
																														</div>
																							

																												
																														<div class="col-xl-2 col-sm-12 col-md-2">
																															<div class="teams-rank"><label class="small-label">Room Category</label></div>
																																<select id="roomcat<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][roomcat]" data-id="<?php echo $iti_id; ?>" data-sid="1" class="form-control input-sm room_cat_change" required <?php echo $dis_abled; ?>>
																																<option value="">Select</option>
																																<?php foreach($room_cat_list_draft as $key => $val) { 
																																	if($val['room_category_id'] == $room_cat_exist){
																																	?>
																																	<option value="<?php echo $val['room_category_id']; ?>" selected><?php echo $val['room_category_name']; ?></option>
																																<?php } else{ ?>
																																	<option value="<?php echo $val['room_category_id']; ?>"><?php echo $val['room_category_name']; ?></option>
																																<?php }} ?>
																																</select>
																																
																														</div>
																													

																													<div class="col-xl-2 col-sm-12 col-md-2">
																														<div class="teams-rank"><label class="small-label">No Of Adult</label></div>
																														<input type="text" id="no_of_adult<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][no_of_adult]" value="<?php echo $object_det[0]['no_of_adult']; ?>" class="form-control input-sm" maxlength="2" readonly>
																													</div>
																													<div class="col-xl-2 col-sm-12 col-md-2">
																														<div class="teams-rank"><label class="small-label">C.With Bed Qty</label></div>
																														<input type="text" id="no_of_ch<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][no_of_ch]" value="<?php echo $child_with_bed; ?>" class="form-control input-sm" maxlength="2" required <?php echo $read_only; ?>>
																													</div>
																													<div class="col-xl-2 col-sm-12 col-md-2">
																														<div class="teams-rank"><label class="small-label">C.Without Bed Qty</label></div>
																														<input type="text" id="no_of_cw<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][no_of_cw]" value="<?php echo $child_without_bed; ?>" class="form-control input-sm" maxlength="2" required <?php echo $read_only; ?>>
																													</div>
																													<div class="col-xl-2 col-sm-12 col-md-2">
																														<div class="teams-rank"><label class="small-label">Extra Bed Qty</label></div>
																														<input type="text" id="no_of_extra<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][no_of_extra]" value="<?php echo $extra_bed; ?>" class="form-control input-sm" maxlength="2" required <?php echo $read_only; ?>>
																													</div>

																												</div>

																												<div class="row mt-2 double_row">
																														<div class="col-xl-2 col-sm-12 col-md-2">
																															<div class="teams-rank"><label class="small-label">Room Type</label></div>
																															
																														</div>
																														<div class="col-xl-2 col-sm-12 col-md-2">
																															<div class="teams-rank"><label class="small-label">No Of Rooms</label></div>
																															
																														</div>
																											
																														<div class="col-xl-2 col-sm-12 col-md-2">
																															<div class="teams-rank"><label class="small-label">Daily Room Rate</label></div>
																															
																														</div>
																														<div class="col-xl-2 col-sm-12 col-md-2">
																															<div class="teams-rank"><label class="small-label">C.With Bed Rate</label></div>
																															
																														</div>
																														<div class="col-xl-2 col-sm-12 col-md-2">
																															<div class="teams-rank"><label class="small-label">C.Without Bed Rate</label></div>
																															
																														</div>
																														<div class="col-xl-2 col-sm-12 col-md-2">
																															<div class="teams-rank"><label class="small-label">Extra Bed Rate</label></div>
																															
																														</div>
																								
																														
																													</div>
																
																												<?php 
																												if($object_det[0]['no_of_double_room'] > 0) { ?>
																												
																													<div class="row mt-2 double_row">
																														<div class="col-xl-2 col-sm-12 col-md-2">
																														
																															<input type="text" value="Double" class="form-control input-sm" maxlength="2" readonly>
																														</div>
																														<div class="col-xl-2 col-sm-12 col-md-2">
																														
																															<input type="text" id="double<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][double]" value="<?php echo $double_room; ?>" class="form-control input-sm" maxlength="2" required <?php echo $read_only; ?>>
																														</div>
																											
																														<div class="col-xl-2 col-sm-12 col-md-2">
																															
																															<input type="text" id="d_adult_rate<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][d_adult_rate]" class="form-control input-sm" maxlength="6" value="<?php echo $d_room_tariff; ?>" required <?php echo $read_only; ?>>
																														</div>
																														<div class="col-xl-2 col-sm-12 col-md-2">
																															
																															<input type="text" id="d_child_rate<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][d_child_rate]" class="form-control input-sm" maxlength="6" value="<?php echo $d_child_tariff; ?>" required <?php echo $read_only; ?>>
																														</div>
																														<div class="col-xl-2 col-sm-12 col-md-2">
																														
																															<input type="text" id="d_child_wb_rate<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][d_child_wb_rate]" class="form-control input-sm" maxlength="6" value="<?php echo $d_child_wb_tariff; ?>" required <?php echo $read_only; ?>>
																														</div>
																														<div class="col-xl-2 col-sm-12 col-md-2">
																														
																															<input type="text" id="d_extra_bed_rate<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][d_extra_bed_rate]" class="form-control input-sm" maxlength="6" value="<?php echo $d_extra_tariff; ?>" required <?php echo $read_only; ?>>
																														</div>
																								
																														
																													</div>
																												<?php 
																												}
																												else{ ?>
																																<input type="hidden" id="double<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][double]" value="0">
																																<input type="hidden" id="d_adult_rate<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][d_adult_rate]" value="0">
																																<input type="hidden" id="d_child_rate<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][d_child_rate]" value="0">
																																<input type="hidden" id="d_child_wb_rate<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][d_child_wb_rate]" value="0">
																																<input type="hidden" id="d_extra_bed_rate<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][d_extra_bed_rate]" value="0">
																																
																												<?php
																													}
																												if($object_det[0]['no_of_single_room'] > 0) { ?>
																												<div class="row mt-2 single_row">
																													<div class="col-xl-2 col-sm-12 col-md-2">
																													
																														<input type="text" value="Single" class="form-control input-sm" maxlength="2" oninput="validateNumericInput(this);" readonly>
																													</div>
																													<div class="col-xl-2 col-sm-12 col-md-2">
																													
																														<input type="text" id="single<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>"name="additi[<?php echo $iti_id; ?>][single]" value="<?php echo $single_room; ?>" class="form-control input-sm" maxlength="2" required <?php echo $read_only; ?>>
																													</div>
																										
																													<div class="col-xl-2 col-sm-12 col-md-2">
																														
																														<input type="text" id="s_adult_rate<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][s_adult_rate]" class="form-control input-sm" maxlength="6" value="<?php echo $s_room_tariff; ?>" required <?php echo $read_only; ?>>
																													</div>
																													<div class="col-xl-2 col-sm-12 col-md-2">
																														
																														<input type="text" id="s_child_rate<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][s_child_rate]" class="form-control input-sm" maxlength="6" value="0" readonly>
																													</div>
																													<div class="col-xl-2 col-sm-12 col-md-2">
																														
																														<input type="text" id="s_child_wb_rate<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][s_child_wb_rate]" class="form-control input-sm" maxlength="6" value="0" readonly>
																													</div>
																													<div class="col-xl-2 col-sm-12 col-md-2">
																														
																														<input type="text" id="s_extra_bed_rate<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][s_extra_bed_rate]" class="form-control input-sm" maxlength="6" value="0" readonly>
																													</div>
																												
																													
																												</div>
																								             
																												<?php
																												}
																												else{ ?>
																													<input type="hidden" id="single<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][single]" value="0">
																													<input type="hidden" id="s_adult_rate<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][s_adult_rate]" value="0">
																													<input type="hidden" id="s_child_rate<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][s_child_rate]" value="0">
																													<input type="hidden" id="s_child_wb_rate<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][s_child_wb_rate]" value="0">
																													<input type="hidden" id="s_extra_bed_rate<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][s_extra_bed_rate]" value="0">
																													
																												<?php
																												} ?>
																											</div>	
																												<?php
																													$cur_fac = $Enquiry_model->getHotelFacilitybyhotelid($hotel_exist);
																												?>
																												<div class="row mt-2 single_row" style="padding-bottom:10px;">
																												
																														<div class="col-xl-2 col-sm-12 col-md-2">
																															<div class="teams-rank"><label class="small-label">Hotel Facility</label></div>
																															<select id="hotfac<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][hotfac]" class="form-control input-sm hotel_fac_change" data-id="<?php echo $iti_id; ?>" <?php echo $dis_abled; ?>>
																																<option value="">Select</option>
																																	<?php foreach($cur_fac as $ckey => $cval) { 
																																		if($cval['hotel_facility_id'] == $hot_fac_id){
																																		?>
																																		<option value="<?php echo $cval['hotel_facility_id']; ?>" selected><?php echo $cval['facility_name']; ?></option>
																																	<?php } else { ?>
																																		<option value="<?php echo $cval['hotel_facility_id']; ?>"><?php echo $cval['facility_name']; ?></option>
																																	<?php }
																																}?>
																																</select>
																														</div>
																												
																										
																													<div class="col-xl-2 col-sm-12 col-md-2">
																														<div class="teams-rank"><label class="small-label">Facility Rate</label></div>
																														<input type="text" id="fac_rate<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][fac_rate]" class="form-control input-sm" maxlength="6" value="<?php echo $hot_fac_tariff; ?>" readonly>
																													</div>
																												
																														<div class="col-xl-6 col-sm-12 col-md-6">
																															<div class="teams-rank"><label class="small-label">Remarks</label></div>
																															<textarea id="remarks<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][remarks]" class="form-control input-sm" <?php echo $read_only; ?>><?php echo $remarks; ?></textarea>
																														</div>
																													
																													<div class="col-xl-1 col-sm-12 col-md-1">
																														<div class="teams-rank"><label class="small-label">Total</label></div>
																															<input type="text" id="acc_total<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][acc_total]" class="form-control input-sm" maxlength="6" value="<?php echo $tac; ?>" readonly>
																														</div>
																													<div class="col-xl-1 col-sm-12 col-md-1" style="padding-top:20px;">
																														<button type="button" class="btn btn-success btn-sm add_hotel" data-mp = "<?php echo $ttval['meal_plan_id']; ?>" data-tl = "<?php echo $ttval['tour_location']; ?>" data-td = "<?php echo $startDate1->format('Y-m-d'); ?>" data-id="<?php echo $iti_id; ?>" data-oid="<?php echo $iti_id; ?>" data-hid="<?= htmlspecialchars(json_encode($ttval['hotel_list']), ENT_QUOTES, 'UTF-8') ?>" <?php echo $dis_abled; ?>>Add <i class="fa fa-plus ml-2"></i></button>
																													</div>
																												</div>

																												<div class="row">
																													<div class="col-xl-12" id="hotel_dynamic_fields<?php echo $iti_id; ?>">
																															
																														
																														
																													</div>
																												</div>
																											<?php } ?>
																											
																											<?php	if($object_det[0]['is_vehicle_required'] == 1) { 

																												$newdateObj = DateTime::createFromFormat('d-m-Y', $object_det[0]['end_date']);
																												$newdateObj->modify('-1 day');
																												$newendDate = $newdateObj->format('d-m-Y');

																												$newdateObj1 = DateTime::createFromFormat('d-m-Y', $object_det[0]['start_date']);
																												$newendDate1 = $newdateObj1->format('d-m-Y');
																												
																												foreach($vehicle_details as $vindex => $vmodel) {
																													if($vindex == 0){
																														if($ttkey == $tpd_count){
																															if($cnt1 == 0){
																																	
																																if($startDate1->format('d-m-Y') == $object_det[0]['end_date']){
																																	$header_temp = " (Previous Location to Current Location - ".$vmodel->pre_to_cur. "KM, Location to Departure - ".$vmodel->cur_to_dep. "KM, Departure to Hub Location - ".$vmodel->dep_to_arr. "KM)";
																																	echo '<center><h5 style="padding-top:10px;">Vehicle Details'.$header_temp.'</h5></center>';
																																	echo '<input type="hidden" id="veh_header'.$iti_id.'" name="additi['.$iti_id.'][veh_header]" value="'.$header_temp.'">';
																																}
																																else if($startDate1->format('d-m-Y') == $newendDate1){
																																	$header_temp = " (Hub Location to Arrival - ".$vmodel->hub_to_arr. "KM, Arrival to Location - ".$vmodel->arr_to_loc."KM)";
																																	echo '<center><h5 style="padding-top:10px;">Vehicle Details'.$header_temp.'</h5></center>';
																																	echo '<input type="hidden" id="veh_header'.$iti_id.'" name="additi['.$iti_id.'][veh_header]" value="'.$vmodel->veh_header.'">';
																																}
																																else{
																																	$header_temp = " (Previous Location to Current Location - ".$vmodel->pre_to_cur. "KM)";
																																	echo '<center><h5 style="padding-top:10px;">Vehicle Details'.$header_temp.'</h5></center>';
																																	echo '<input type="hidden" id="veh_header'.$iti_id.'" name="additi['.$iti_id.'][veh_header]" value="'.$header_temp.'">';
																																}
																																
																															}
																															else{
																																if($startDate1->format('d-m-Y') == $object_det[0]['end_date']){
																																	$header_temp = " (Location to Departure - ".$vmodel->cur_to_dep. "KM, Departure to Hub Location - ".$vmodel->dep_to_arr. "KM)";
																																	echo '<center><h5 style="padding-top:10px;">Vehicle Details'.$header_temp.'</h5></center>';
																																	echo '<input type="hidden" id="veh_header'.$iti_id.'" name="additi['.$iti_id.'][veh_header]" value="'.$header_temp.'">';
																																}
																																else{
																																	$header_temp = " (Current location is same as previous location, Tour travel = 0 KM)";
																																	echo '<center><h5 style="padding-top:10px;">Vehicle Details'.$header_temp.'</h5></center>';
																																	echo '<input type="hidden" id="veh_header'.$iti_id.'" name="additi['.$iti_id.'][veh_header]" value="'.$header_temp.'">';
																																}
																															}
																														}
																														else{
																															if($cnt1 == 0){
																																echo '<center><h5 style="padding-top:10px;">Vehicle Details'.$vmodel->veh_header.'</h5></center>';
																																echo '<input type="hidden" id="veh_header'.$iti_id.'" name="additi['.$iti_id.'][veh_header]" value="'.$vmodel->veh_header.'">';
																															}
																															else{
																																echo '<center><h5 style="padding-top:10px;">Vehicle Details : Current location is same as previous location, Tour travel = 0 KM</h5></center>';
																																echo '<input type="hidden" id="veh_header'.$iti_id.'" name="additi['.$iti_id.'][veh_header]" value="Current location is same as previous location, Tour travel = 0 KM">';
																															}
																														}
																													}
																												}
																												?>
																								
																									
																													<input type="hidden" id="veh_header<?php echo $iti_id; ?>" name="addloc[<?php echo $iti_id; ?>][veh_header]" value="">
																													<div class="row mt-2 single_row">
																														<div class="col-xl-4 col-sm-12 col-md-4">
																															<div class="teams-rank"><label class="small-label">Vehicle Model</label></div>
																														</div>		
																														
																														<div class="col-xl-2 col-sm-12 col-md-2">
																															<div class="teams-rank"><label class="small-label">Daily Rent</label></div>
																														</div>
																														<div class="col-xl-1 col-sm-12 col-md-2">
																															<div class="teams-rank"><label class="small-label">Max KM/Day</label></div>
																														</div>
																														<div class="col-xl-1 col-sm-12 col-md-2">
																															<div class="teams-rank"><label class="small-label">Distance</label></div>
																														</div>
																														<div class="col-xl-1 col-sm-12 col-md-2">
																															<div class="teams-rank"><label class="small-label">Extra KM</label></div>
																														</div>
																														<div class="col-xl-1 col-sm-12 col-md-2">
																															<div class="teams-rank"><label class="small-label">Extra Rate</label></div>
																														</div>
																														<div class="col-xl-2 col-sm-12 col-md-2">
																															<div class="teams-rank"><label class="small-label">Total</label></div>
																														</div>
																													</div>
																													<?php 
																													$grand_veh_total = 0;
																													foreach($vehicle_details as $vindex => $vmodel) {
																														if($ttkey == $tpd_count){
																															if($cnt1 == 0){
																																if($startDate1->format('d-m-Y') == $object_det[0]['end_date']){
																																	$travel_distance_temp = $vmodel->travel_distance; 
																																	$extra_kilometer_temp = $vmodel->extra_kilometer;
																																	$veh_total = $vmodel->day_rent + ($vmodel->extra_kilometer*$vmodel->extra_km_rate);	
																																	$grand_veh_total = $grand_veh_total + ($veh_total*$vmodel->vehicle_count);
																																}
																																else if($startDate1->format('d-m-Y') == $newendDate1){
																																	//$travel_distance_temp = $vmodel->travel_distance; 
																																	$travel_distance_temp = (float)($vmodel->hub_to_arr ?? 0) + (float)($vmodel->arr_to_loc ?? 0);
																																	$max_km_day_temp = $vmodel->max_km_day;
																																	if($travel_distance_temp > $max_km_day_temp){
																																		$extra_kilometer_temp = $travel_distance_temp - $max_km_day_temp;
																																	}
																																	else{
																																		$extra_kilometer_temp = 0;
																																	}
																																	$veh_total = $vmodel->day_rent + ($vmodel->extra_kilometer*$vmodel->extra_km_rate);	
																																	$grand_veh_total = $grand_veh_total + ($veh_total*$vmodel->vehicle_count);
																																}
																																else{
																																	$travel_distance_temp = $vmodel->pre_to_cur; 
																																	$max_km_day_temp = $vmodel->max_km_day;
																																	if($travel_distance_temp > $max_km_day_temp){
																																		$extra_kilometer_temp = $travel_distance_temp - $max_km_day_temp;
																																	}
																																	else{
																																		$extra_kilometer_temp = 0;
																																	}
																																	//$extra_kilometer_temp = $vmodel->extra_kilometer;
																																	$veh_total = $vmodel->day_rent + ($vmodel->extra_kilometer*$vmodel->extra_km_rate);	
																																	$grand_veh_total = $grand_veh_total + ($veh_total*$vmodel->vehicle_count);
																																}
																															}
																															else{
																																if($startDate1->format('d-m-Y') == $object_det[0]['end_date']){
																																	//$travel_distance_temp = $vmodel->cur_to_dep + $vmodel->dep_to_arr; 
																																	$travel_distance_temp = (float)($vmodel->cur_to_dep ?? 0) + (float)($vmodel->dep_to_arr ?? 0);
																																	$max_km_day_temp = $vmodel->max_km_day;
																																	if($travel_distance_temp > $max_km_day_temp){
																																		$extra_kilometer_temp = $travel_distance_temp - $max_km_day_temp;
																																	}
																																	else{
																																		$extra_kilometer_temp = 0;
																																	}
																																	//$extra_kilometer_temp = $vmodel->extra_kilometer;
																																	$veh_total = $vmodel->day_rent + ($vmodel->extra_kilometer*$vmodel->extra_km_rate);	
																																	$grand_veh_total = $grand_veh_total + ($veh_total*$vmodel->vehicle_count);
																																}
																																else{
																																	$travel_distance_temp = 0;
																																	$extra_kilometer_temp = 0;
																																	$veh_total = $vmodel->day_rent;	
																																	$grand_veh_total = $grand_veh_total + ($veh_total*$vmodel->vehicle_count);
																																}
																															}
																														}
																														else{
																															if($cnt1 == 0){
																																$travel_distance_temp = $vmodel->travel_distance; 
																																$extra_kilometer_temp = $vmodel->extra_kilometer;
																																$veh_total = $vmodel->day_rent + ($vmodel->extra_kilometer*$vmodel->extra_km_rate);	
																																$grand_veh_total = $grand_veh_total + ($veh_total*$vmodel->vehicle_count);
																															}
																															else{
																																$travel_distance_temp = 0;
																																$extra_kilometer_temp = 0;
																																$veh_total = $vmodel->day_rent;	
																																$grand_veh_total = $grand_veh_total + ($veh_total*$vmodel->vehicle_count);
																															}
																														}

																														
																													//$veh_total = $vmodel->day_rent + ($vmodel->extra_kilometer*$vmodel->extra_km_rate);	
																													//$grand_veh_total = $grand_veh_total + ($veh_total*$vmodel->vehicle_count);
																													$si_nos = $vindex + 1;
																													//$vid = $iti_id.$vmodel['vehicle_type_id'];

																													
																													
																														
																													for($j = 0;$j<$vmodel->vehicle_count;$j++){
																														$checked = "checked";
																														$flag = 0;
																														$vid = $iti_id.$vmodel->veh_type_id."_".$j;
																														if(!empty($itinerary_details_draft)){ 
																															if(!empty($d_vehicles)){
																																foreach($d_vehicles as $drkey => $drval){
																																	if($vid == $drval->chk_vehicle){
																																		$flag = 1;
																																		
																																		$travel_distance_temp = $drval->travel_distance;	
																																	
																																	}
																																
																																}
																																if($flag == 0){
																																	$checked = "";
																																}
																															}
																															else{
																																$checked = "";
																															}
																														}
																														
																												    ?>
																													
																													<div class="row mt-2 single_row">
																														<div class="col-xl-1 col-sm-12 col-md-1">
																															<input type="hidden" name="additi[<?php echo $iti_id; ?>][chk_vehicle_value][<?php echo $vid; ?>]" value="<?php echo $vid; ?>">
																															<input type="hidden" name="additi[<?php echo $iti_id; ?>][chk_vehicle_hidden][<?php echo $vid; ?>]" value="1">
																														
																																<input type="checkbox" id="chk_vehicle<?php echo $vid; ?>" name="additi[<?php echo $iti_id; ?>][chk_vehicle][<?php echo $vid; ?>]" class="chk_vehicle" value="<?php echo $vid; ?>" data-id="<?php echo $iti_id; ?>" <?php echo $checked; ?> <?php echo $dis_abled; ?>>
																														
																															
																														</div>
																														<div class="col-xl-3 col-sm-12 col-md-3">
																															
																															<input type="text" id="veh_model<?php echo $vid; ?>" name="additi[<?php echo $iti_id; ?>][veh_model][<?php echo $vid; ?>]" value="<?php echo $vmodel->vehicle_model; ?>" class="form-control input-sm veh_model<?php echo $vindex; ?>" readonly>
																															<input type="hidden" id="veh_type_id<?php echo $vid; ?>" name="additi[<?php echo $iti_id; ?>][veh_type_id][<?php echo $vid; ?>]" value="<?php echo $vmodel->veh_type_id; ?>" class="form-control input-sm veh_type_id<?php echo $vindex; ?>">
																															<input type="hidden" id="v_tour_date<?php echo $vid; ?>" name="additi[<?php echo $iti_id; ?>][v_tour_date][<?php echo $vid; ?>]" value="<?php echo $startDate1->format('Y-m-d'); ?>">
																														</div>
																											
																													
																														<div class="col-xl-2 col-sm-12 col-md-2">
																															
																															<input type="text" id="day_rent<?php echo $vid; ?>" name="additi[<?php echo $iti_id; ?>][day_rent][<?php echo $vid; ?>]" value="<?php echo $vmodel->day_rent; ?>" class="form-control input-sm cls_daily day_rent<?php echo $vindex; ?>" data-id="" data-cid="" maxlength="5" readonly>
																														</div>
																														<div class="col-xl-1 col-sm-12 col-md-2">
																															
																															<input type="text" id="max_km_day<?php echo $vid; ?>" name="additi[<?php echo $iti_id; ?>][max_km_day][<?php echo $vid; ?>]" value="<?php echo $vmodel->max_km_day; ?>" class="form-control input-sm max_km_day<?php echo $vindex; ?>" maxlength="5" readonly>
																														</div>
																														<div class="col-xl-1 col-sm-12 col-md-2">
																															
																															<input type="text" id="travel_distance<?php echo $vid; ?>" name="additi[<?php echo $iti_id; ?>][travel_distance][<?php echo $vid; ?>]" value="<?php echo $travel_distance_temp; ?>" class="form-control input-sm cls_dist" data-base="<?php echo $travel_distance_temp; ?>" maxlength="5" readonly>
																														</div>
																														<div class="col-xl-1 col-sm-12 col-md-2">
																															
																															<input type="text" id="extra_kilometer<?php echo $vid; ?>" name="additi[<?php echo $iti_id; ?>][extra_kilometer][<?php echo $vid; ?>]" value="<?php echo $extra_kilometer_temp; ?>" class="form-control input-sm extra_kilometer<?php echo $vindex; ?>" maxlength="5" readonly>
																														</div>
																														<div class="col-xl-1 col-sm-12 col-md-2">
																															
																															<input type="text" id="extra_km_rate<?php echo $vid; ?>" name="additi[<?php echo $iti_id; ?>][extra_km_rate][<?php echo $vid; ?>]" value="0" class="form-control input-sm extra_km_rate<?php echo $vindex; ?>" maxlength="5" readonly>
																															<input type="hidden" id="extra_km_rate_hidden<?php echo $vid; ?>" name="additi[<?php echo $iti_id; ?>][extra_km_rate_hidden][<?php echo $vid; ?>]" value="<?php echo $vmodel->extra_km_rate; ?>">
																														</div>
																														<div class="col-xl-2 col-sm-12 col-md-2">
																															
																															<input type="text" id="veh_total<?php echo $vid; ?>" name="additi[<?php echo $iti_id; ?>][veh_total][<?php echo $vid; ?>]" value="<?php echo $veh_total; ?>" class="form-control input-sm veh_total<?php echo $vindex; ?>" maxlength="5" readonly>
																														</div>
																														
																													</div>
																													<?php  } } 
																												}
																												else { ?>
																														<input type="hidden" id="veh_model<?php echo $iti_id; ?>0" name="additi[<?php echo $iti_id; ?>][veh_model][0]" value="">
																														<input type="hidden" id="veh_type_id<?php echo $iti_id; ?>0" name="additi[<?php echo $iti_id; ?>][veh_type_id][0]" value="">
																														<input type="hidden" id="v_tour_date<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][v_tour_date][0]" value="">
																														<input type="hidden" id="veh_count<?php echo $iti_id; ?>0" name="additi[<?php echo $iti_id; ?>][veh_count][0]" value="0">
																														<input type="hidden" id="day_rent$<?php echo $iti_id; ?>0" name="additi[<?php echo $iti_id; ?>][day_rent][0]" value="0">
																														<input type="hidden" id="max_km_day<?php echo $iti_id; ?>0" name="additi[<?php echo $iti_id; ?>][max_km_day][0]" value="0">
																														<input type="hidden" id="extra_km_rate<?php echo $iti_id; ?>0" name="additi[<?php echo $iti_id; ?>][extra_km_rate][0]" value="0">
																														<input type="hidden" id="veh_total<?php echo $iti_id; ?>0" name="additi[<?php echo $iti_id; ?>][veh_total][0]" value="0">
																												<?php
																													}
																												?>


																												<div class="row mt-2 single_row">
																												
																														<div class="col-xl-2 col-sm-12 col-md-2">
																															<div class="teams-rank"><label class="small-label">Sight Seeing</label></div>
																															<?php 
																																$default_ss_distance = 0;
																																if($cnt1 == 0){ ?>
																																<select id="sight<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][sight]" class="form-control input-sm ss_change" data-id="<?php echo $iti_id; ?>" <?php echo $dis_abled; ?>>
																																	<option value="">Select</option>
																																	<?php foreach($ttval['ss'] as $skey => $sval) { 
																																		if($sval['sightseeing_id'] == $sight_id) {
																																		?>
																																		<option value="<?php echo $sval['sightseeing_id']; ?>" selected><?php echo $sval['object_name']; ?></option>
																																	<?php } else { ?>
																																		<option value="<?php echo $sval['sightseeing_id']; ?>"><?php echo $sval['object_name']; ?></option>
																																	<?php }
																																} ?>
																															
																																</select>
																															<?php } else if($cnt1 == 1){ ?>
																																<select id="sight<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][sight]" class="form-control input-sm ss_change" data-id="<?php echo $iti_id; ?>" <?php echo $dis_abled; ?>>
																																	<option value="">Select</option>
																																	<?php foreach($ttval['ss'] as $skey => $sval) { 
																																		if($sight_id > 0){
																																			if($sval['sightseeing_id'] == $sight_id) {
																																				?>
																																				<option value="<?php echo $sval['sightseeing_id']; ?>" selected><?php echo $sval['object_name']; ?></option>
																																			<?php } else { ?>
																																				<option value="<?php echo $sval['sightseeing_id']; ?>"><?php echo $sval['object_name']; ?></option>
																																			<?php }
																																		} 	
																																		else{
																																			if($sval['is_default_ss'] == 1) {
																																				$default_ss_distance = $sval['sightseeing_distance'];
																																			?>
																																			<option value="<?php echo $sval['sightseeing_id']; ?>" selected><?php echo $sval['object_name']; ?></option>
																																		<?php } else { ?>
																																			<option value="<?php echo $sval['sightseeing_id']; ?>"><?php echo $sval['object_name']; ?></option>
																																		<?php }
																																		}
																																} ?>
																															
																																</select>
																															<?php } else { ?>
																																<select id="sight<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][sight]" class="form-control input-sm ss_change" data-id="<?php echo $iti_id; ?>" <?php echo $dis_abled; ?>>
																																	<option value="">Select</option>
																																	<?php foreach($ttval['ss'] as $skey => $sval) { 
																																		if($sval['sightseeing_id'] == $sight_id) {
																																		?>
																																		<option value="<?php echo $sval['sightseeing_id']; ?>" selected><?php echo $sval['object_name']; ?></option>
																																	<?php } else { ?>
																																		<option value="<?php echo $sval['sightseeing_id']; ?>"><?php echo $sval['object_name']; ?></option>
																																	<?php }
																																} ?>
																															
																																</select>
																															<?php } ?>
																														</div>
																													
																													
																														<div class="col-xl-2 col-sm-12 col-md-2">
																															<div class="teams-rank"><label class="small-label">Distance</label></div>
																															<?php if($cnt1 == 0){ 
																																?>
																																<input type="text" id="ss_distance<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][ss_distance]" class="form-control input-sm cls_ss_distance" data-id="<?php echo $iti_id; ?>" maxlength="6" value="<?php echo $sight_tariff ? $sight_tariff: 0; ?>" readonly>
																															<?php } else if($cnt1 == 1){ 
																																 if($sight_id > 0){
																																?>
																																
																																<input type="text" id="ss_distance<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][ss_distance]" class="form-control input-sm cls_ss_distance" data-id="<?php echo $iti_id; ?>" maxlength="6" value="<?php echo $sight_tariff; ?>" readonly>
																															<?php } 
																														 		
																															    else{ ?>
																																<input type="text" id="ss_distance<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][ss_distance]" class="form-control input-sm cls_ss_distance" data-id="<?php echo $iti_id; ?>" maxlength="6" value="<?php echo $default_ss_distance; ?>" readonly>
																															<?php }
																														} else { ?>
																																<input type="text" id="ss_distance<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][ss_distance]" class="form-control input-sm cls_ss_distance" data-id="<?php echo $iti_id; ?>" maxlength="6" value="<?php echo $sight_tariff; ?>" readonly>
																															<?php } ?>
																														</div>
																													
																												
																														<div class="col-xl-2 col-sm-12 col-md-2">
																															<div class="teams-rank"><label class="small-label">Special Event Name</label></div>
																															<input type="text" id="spcl_event<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][spcl_event]" class="form-control input-sm" maxlength="30" value="<?php echo $special_event_name; ?>" <?php echo $read_only; ?>>
																														</div>
																														<div class="col-xl-2 col-sm-12 col-md-2">
																															<div class="teams-rank"><label class="small-label">Tariff</label></div>
																															<input type="text" id="spcl_tariff<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][spcl_tariff]" class="form-control input-sm" value="<?php echo $spcl_tariff; ?>" <?php echo $read_only; ?>>
																														</div>
																														<div class="col-xl-2 col-sm-12 col-md-2">
																															<div class="teams-rank"><label class="small-label">Extra Charges</label></div>
																															<input type="text" id="daily_addon<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][daily_addon]" class="form-control input-sm" maxlength="6" value="<?php echo $daily_addon; ?>" <?php echo $read_only; ?>>
																														</div>
																													
																													<div class="col-xl-2 col-sm-12 col-md-2">
																														<div class="teams-rank"><label class="small-label">Grand Total</label></div>
																														<?php
																															if($object_det[0]['is_vehicle_required'] == 0){
																																$grand_veh_total = 0;
																															}
																														?>
																														<input type="text" id="grand_total<?php echo $iti_id; ?>" name="additi[<?php echo $iti_id; ?>][grand_total]" class="form-control input-sm grand_total" value="<?php echo $tac+$grand_veh_total; ?>"readonly style="background-color: #004d00; color: white; font-weight: bold; font-style: italic;font-size: 20px;">
																													</div>
																													
																													
																												</div>
																												<?php if(!empty($edit_history)){ ?>
																													<div class="row mt-2">
																														<div class="col-xl-4 col-sm-12 col-md-4">
																															
																														</div>
																														
																														<div class="col-xl-4 col-sm-12 col-md-4">
																															<span class="text-muted">
																																<select id="make_current<?php echo $iti_id; ?>" data-id="<?php echo $iti_id; ?>" class="form-control input-sm select_make_current" <?php echo $dis_abled_temp; ?>>
																																<option value="">Select Edit History</option>
																																<?php foreach($edit_history as $keyh => $valh) { 
																																	if($valh['tour_date'] == $startDate1->format('Y-m-d')){
																																	
																																			if($valh['is_active'] == 1 && $valh['is_draft'] == 1){
																																				$history_name = date('d-m-Y h:i A', strtotime($valh['updated_time']))." - Current";
																																			}
																																			else{
																																				$history_name = date('d-m-Y h:i A', strtotime($valh['updated_time']))." - Previous ";
																																			}
																																	?>
																																	<option value="<?php echo $valh['itinerary_details_id']; ?>"><?php echo $history_name; ?></option>
																																<?php }} ?>
																																</select>
																															</span>
																														</div>
																														<div class="col-xl-4 col-sm-12 col-md-4">
																															
																														</div>
																													
																													</div>	
																												<?php } ?>	
																												
																											</div>
																										</div>
																									</div>
																								</div>
																								
																							</div>
                                                                                      
																						</div>
																					</div>
																					
																				<?php 
																				$startDate1->modify('+1 day'); 
																				$cnt1++;
																				$day_count++;
																			} ?>
																		
																			</div>
																			
																		<!--</div>-->
																	</div>
																</div>
															</div>
														</div>
												    <?php } ?>
												
													
				
												</div>
											</div>
										</div>
									</div>

									<?php if (empty($iti_edit_id)) { ?>
										<div class="fixed-save-buttons">
											<!--<button type="submit" id="btn_savedraft_iti_plan" class="btn btn-warning mr-2">Next>></button>-->
											<button type="button" id="btn_savedraft_iti_plan" class="btn btn-warning mr-2">Save & Next >></button>
											<button type="submit" id="btn_save_iti_plan" class="btn btn-success" style="display: none;">Final Save</button>
											<input type="hidden" name="submit_type" id="submit_type" value="">
										</div>
									<?php } ?>
								</form>	

								<!-------------------------------------------------------------------------------------------------------------->
								<hr/>
								<?php 
								$pax_count_exist = 0;
								if(!empty($itinerary_details_save)){ 
								$rt_count = 0;
										if($object_det[0]['no_of_double_room'] > 0){
											$rt_count = $rt_count + 1;
										}
										if($object_det[0]['no_of_single_room'] > 0){
											$rt_count = $rt_count + 1;
										}
								?>
								<div class="costing-container">
    							<h4 style="text-align:center; color: #004d00; font-weight: bold; font-style: italic;font-size: 20px;">Costing Sheet</h4>
    							<div class="table-responsive costing-box">
								<table class="table table-bordered costing-table">  
									
										<tr>
											<th>Day</th>
											<th>Date</th>
											<th>Destination</th>
											<th>Remarks</th>
											<th>Hotel</th>
											<th>Room Category</th>
											<th>Meal Plan</th>
										
											
											<th>No Of Adult</th>

											<th>Room Type</th>
											<th>No:Of Rooms</th>
										
											<th>Adult Rate</th>
												<?php if($object_det[0]['no_of_child_with_bed'] > 0){ 
													$pax_count_exist++;
													?>
													<th>No:Of Child with Bed</th>
													<th>Child with Bed Rate</th>
												<?php } ?>
										
												<?php if($object_det[0]['no_of_child_without_bed'] > 0){ 
													$pax_count_exist++;
													?>
													<th>No:Of Child without Bed</th>
													<th>Child without Bed Rate</th>
												<?php } ?>
									
												<?php if($object_det[0]['no_of_extra_bed'] > 0){ 
													$pax_count_exist++;
													?>
													<th>No:Of Extra Bed</th>
													<th>Extra Bed Rate</th>
												<?php } ?>
									
										
											<th>Total</th>
										</tr>
								
									<?php 
									$special_event_count = 0;
									$addon_count = 0;
									$k = 1;
									$sum = 0;
									$gtot = 0;
									$ss_name_temp = '';
									$cs_acc_total = 0;
									$itinerary_details_save_count = count($itinerary_details_save)-1;
									foreach($itinerary_details_save as $key => $val) { 
										if($key < $itinerary_details_save_count){
										$hot_det_count = json_decode($val['hotel_details']);
										if(!empty($val['special_event_name'])){
											$special_event_count = $special_event_count + 1;
										}
										foreach($val['cost'] as $ckey => $cval) { 
											if($cval['cost_component_id'] == "6" && $cval['room_type_id'] == "2"){
												$room_t_d = $cval['tariff'];
											}
											if($cval['cost_component_id'] == "12" && $cval['room_type_id'] == "2"){
												$child_t_d = $cval['tariff'];
											}
											if($cval['cost_component_id'] == "15" && $cval['room_type_id'] == "2"){
												$child_wb_t_d = $cval['tariff'];
											}
											if($cval['cost_component_id'] == "9" && $cval['room_type_id'] == "2"){
												$extra_t_d = $cval['tariff'];
											}

											if($cval['cost_component_id'] == "6" && $cval['room_type_id'] == "1"){
												$room_t_s = $cval['tariff'];
											}
											if($cval['cost_component_id'] == "12" && $cval['room_type_id'] == "1"){
												$child_t_s = $cval['tariff'];
											}
											if($cval['cost_component_id'] == "15" && $cval['room_type_id'] == "1"){
												$child_wb_t_s = $cval['tariff'];
											}
											if($cval['cost_component_id'] == "9" && $cval['room_type_id'] == "1"){
												$extra_t_s = $cval['tariff'];
											}
											if($cval['cost_component_id'] == "18" && $cval['room_type_id'] == "1"){
												$facility_id = $cval['tariff'];
												if(!empty($cval['tariff']) || !empty($hot_det_count)){
													$addon_count = $addon_count + 1;
												}
											}
											if($cval['cost_component_id'] == "19" && $cval['room_type_id'] == "1"){
												$facility_tafiff = $cval['tariff'];
											}
											if($cval['cost_component_id'] == "17" && $cval['room_type_id'] == "1"){
												$spcl_tariff = $cval['tariff'];
											}
											if($cval['cost_component_id'] == "21" && $cval['room_type_id'] == "1"){
												$sight_seeing_id = $cval['tariff'];
												$ss_name = $Enquiry_model->getSightName($sight_seeing_id);
												if(!empty($ss_name)){
													$ss_name_temp = $ss_name[0]['object_name'];
												}
												else{
													$ss_name_temp = "";
												}
											}
										}
										$dtotal = ($val['double_room']*$room_t_d) + ($val['child_with_bed']*$child_t_d) + ($val['child_without_bed']*$child_wb_t_d) + ($val['extra_bed']*$extra_t_d);
										$stotal = $val['single_room']*$room_t_s;
										
										?>
										<tr>
										<td rowspan="<?php echo $rt_count; ?>"><?php echo "Day ".$k; ?></td>
										<td rowspan="<?php echo $rt_count; ?>"><?php echo date("d-m-Y", strtotime($val['tour_date'])); ?></td>
										<td rowspan="<?php echo $rt_count; ?>"><?php echo $val['geog_name']; ?></td>
										
										<td rowspan="<?php echo $rt_count; ?>"><?php echo $val['remarks']; ?></td>
										<td rowspan="<?php echo $rt_count; ?>"><?php echo $val['object_name']; ?></td>
										<td rowspan="<?php echo $rt_count; ?>"><?php echo $val['room_category_name']; ?></td>
										<td rowspan="<?php echo $rt_count; ?>"><?php echo $val['meal_plan_name']; ?></td>
										
										<td rowspan="<?php echo $rt_count; ?>"><?php echo $object_det[0]['no_of_adult']; ?></td>
										<?php 
											if($object_det[0]['no_of_double_room'] > 0) { ?>
												<td>Double</td>
												<td><?php echo $val['double_room']; ?></td>
												
												<td><?php echo $room_t_d; ?></td>
											
												<?php if($object_det[0]['no_of_child_with_bed'] > 0){ ?>
													<td><?php echo $val['child_with_bed']; ?></td>
													<td><?php echo $child_t_d; ?></td>
												<?php } ?>
												<?php if($object_det[0]['no_of_child_without_bed'] > 0){ ?>
													<td><?php echo $val['child_without_bed']; ?></td>
													<td><?php echo $child_wb_t_d; ?></td>
												<?php } ?>
												<?php if($object_det[0]['no_of_extra_bed'] > 0){ ?>
													<td><?php echo $val['extra_bed']; ?></td>
													<td><?php echo $extra_t_d; ?></td>
												<?php } ?>
												<td><?php echo $dtotal; ?></td>
												</tr>
										<?php 
												$cs_acc_total = $cs_acc_total + $dtotal;
											} ?>
										<?php 
											if($object_det[0]['no_of_single_room'] > 0) { 
												if($object_det[0]['no_of_double_room'] > 0) {
												?>
												<tr>
												<?php } ?>
												<td>Single</td>
												<td><?php echo $val['single_room']; ?></td>
											
												<td><?php echo $room_t_s; ?></td>
											
												<?php if($object_det[0]['no_of_child_with_bed'] > 0){ ?>
													<td>0</td>
													<td><?php echo $child_t_s; ?></td>
												<?php } ?>
												<?php if($object_det[0]['no_of_child_without_bed'] > 0){ ?>
													<td>0</td>
													<td><?php echo $child_wb_t_s; ?></td>
												<?php } ?>
												<?php if($object_det[0]['no_of_extra_bed'] > 0){ ?>
													<td>0</td>
													<td><?php echo $extra_t_s; ?></td>
												<?php } ?>
												<td><?php echo $stotal; ?></td>
												</tr>
										<?php } 
										$cs_acc_total = $cs_acc_total + $stotal;
										$hot_details = json_decode($val['hotel_details']);
										if(!empty($hot_details)){ 
											foreach($hot_details as $key1 => $val1) { 
												if($val1->tour_date == $val['tour_date']){
													$dtotal1 = ($val1->double*$val1->d_adult_rate) + ($val1->no_of_ch*$val1->d_child_rate) + ($val1->no_of_cw*$val1->d_child_wb_rate) + ($val1->no_of_extra*$val1->d_extra_bed_rate);
													$stotal1 = $val1->single*$val1->s_adult_rate;
											?>
											<tr>
											<td rowspan="<?php echo $rt_count; ?>"><?php echo "Day ".$k; ?></td>
											<td rowspan="<?php echo $rt_count; ?>"><?php echo date("d-m-Y", strtotime($val['tour_date'])); ?></td>
											<td rowspan="<?php echo $rt_count; ?>"><?php echo $val['geog_name']; ?></td>
										
											<td rowspan="<?php echo $rt_count; ?>"><?php echo $val1->remarks; ?></td>
											<td rowspan="<?php echo $rt_count; ?>"><?php echo $val1->hotel_name; ?></td>
											<td rowspan="<?php echo $rt_count; ?>"><?php echo $val1->room_category_name; ?></td>
											<td rowspan="<?php echo $rt_count; ?>"><?php echo $val['meal_plan_name']; ?></td>
										
											<td rowspan="<?php echo $rt_count; ?>"><?php echo $object_det[0]['no_of_adult']; ?></td>
											<?php 
												if($object_det[0]['no_of_double_room'] > 0) { ?>
													<td>Doubles</td>
													<td><?php echo $val1->double; ?></td>
													
													<td><?php echo $val1->d_adult_rate; ?></td>
													<?php if($object_det[0]['no_of_child_with_bed'] > 0){ ?>
														<td><?php echo $val1->no_of_ch; ?></td>
														<td><?php echo $val1->d_child_rate; ?></td>
													<?php } ?>
													<?php if($object_det[0]['no_of_child_without_bed'] > 0){ ?>	
														<td><?php echo $val1->no_of_cw; ?></td>
														<td><?php echo $val1->d_child_wb_rate; ?></td>
													<?php } ?>
													<?php if($object_det[0]['no_of_extra_bed'] > 0){ ?>		
														<td><?php echo $val1->no_of_extra; ?></td>
														<td><?php echo $val1->d_extra_bed_rate; ?></td>
													<?php } ?>	
													<td><?php echo $dtotal1; ?></td>
													</tr>
											<?php 
												$cs_acc_total = $cs_acc_total + $dtotal1;
											} ?>
											<?php 
												if($object_det[0]['no_of_single_room'] > 0) { ?>
												<tr>
													<td>Single</td>
													<td><?php echo $val1->single; ?></td>
													
													<td><?php echo $val1->s_adult_rate; ?></td>
													<?php if($object_det[0]['no_of_child_with_bed'] > 0){ ?>
														<td>0</td>
														<td><?php echo $val1->s_child_rate; ?></td>
													<?php } ?>
													<?php if($object_det[0]['no_of_child_without_bed'] > 0){ ?>		
														<td>0</td>
														<td><?php echo $val1->s_child_wb_rate; ?></td>
													<?php } ?>
													<?php if($object_det[0]['no_of_extra_bed'] > 0){ ?>			
														<td>0</td>
														<td><?php echo $val1->s_extra_bed_rate; ?></td>
													<?php } ?>	
													<td><?php echo $stotal1; ?></td>
													</tr>
											<?php } 
													$cs_acc_total = $cs_acc_total + $stotal1;
												}
											}
										}
										$k = $k + 1;
										}
									}
										?>
									<tr>
										<?php $colspan_count = ($pax_count_exist*2) + 11; ?>
										<th colspan="<?php echo $colspan_count; ?>">Total Accommodation Cost</th>
										<th><?php echo $cs_acc_total; ?></th>
									</tr>
								</table> 
                                </div>
								</div>

								<?php 
									if($addon_count > 0){ 
										$fac_count = 1;
										?>
										<div class="costing-container">
    								
    									<div class="table-responsive costing-box">
										<table class="table table-bordered costing-table">  
											
											<tr>
												<th>Si No</th>
												<th>Date</th>
												<th>Hotel Facility</th>
												<th>Tariff</th>
											</tr>
											<?php
											$fac_name_temp = "";
											$cs_addon_total = 0;
												foreach($itinerary_details_save as $keyh => $valh) { 
													foreach($valh['cost'] as $chkey => $chval) { 
														if($chval['cost_component_id'] == "18" && $chval['room_type_id'] == "1"){
															$hotel_fac_id = $chval['tariff'];
															if(!empty($hotel_fac_id)){
																$fac_name = $Enquiry_model->getHotelFacilityName($hotel_fac_id);
																if(!empty($fac_name)){
																	$fac_name_temp = $fac_name[0]['facility_name'];
																}
															}
														}
														if($chval['cost_component_id'] == "19" && $chval['room_type_id'] == "1"){
															$hotel_fac_rate = $chval['tariff'];
														}
													}
													if(!empty($hotel_fac_id)){
														
												?>
												<tr>
													<td><?php echo $fac_count++; ?></td>
													<td><?php echo date("d-m-Y", strtotime($valh['tour_date'])); ?></td>
													<td><?php echo $fac_name_temp; ?></td>
													<td><?php echo $hotel_fac_rate; ?></td>
												</tr>
											<?php 
											$cs_addon_total = $cs_addon_total + $hotel_fac_rate;
											} 
												$dhot_details = json_decode($valh['hotel_details']);
												if(!empty($dhot_details)){ 
													foreach($dhot_details as $keyd => $vald) { 
														if($vald->tour_date == $valh['tour_date']){
															if(!empty($vald->hotfac)){
																$fac_name = $Enquiry_model->getHotelFacilityName($vald->hotfac);
																if(!empty($fac_name)){
																	$fac_name_temp = $fac_name[0]['facility_name'];
																}
															//}
														?>
												<tr>
													<td><?php echo $fac_count++; ?></td>
													<td><?php echo date("d-m-Y", strtotime($vald->tour_date)); ?></td>
													<td><?php echo $fac_name_temp; ?></td>
													<td><?php echo $vald->fac_rate; ?></td>
												</tr>

												<?php	
															}
														}	
														$cs_addon_total = $cs_addon_total + $vald->fac_rate;
													}
												}
										
										} ?>	

										<tr>
											<th colspan="3">Total Hotel Facility Cost</th>
											<th><?php echo $cs_addon_total; ?></th>
										</tr>
										</table>
										</div>
										</div>
								<?php
									}
								?>
							



								<?php if($object_det[0]['is_vehicle_required'] == 1){ ?>
									<div class="costing-container">
    								
    									<div class="table-responsive costing-box">
											<table class="table table-bordered costing-table">
												<tr>
													<th>Day</th>
													<th>Date</th>
													<th>Destination</th>
													
													<th>KM Used</th>
													<th>Vehicle Model</th>
													<th>Rate</th>
												</tr>

												<?php
												$cs_trans_total = 0;
												$total_extra_klm_cost = 0;
												$dayNo = 1;                                      
                                                $itinerary_details_save_cnt = count($itinerary_details_save)-1;
												foreach ($itinerary_details_save as $dkey => $day) {

													foreach($day['cost'] as $ckey => $cval) { 
														
														if($cval['cost_component_id'] == "21" && $cval['room_type_id'] == "1"){
															$sight_seeing_id = $cval['tariff'];
															$ss_name = $Enquiry_model->getSightName($sight_seeing_id);
															if(!empty($ss_name)){
																$ss_name_temp = $ss_name[0]['object_name'];
															}
															else{
																$ss_name_temp = "";
															}
														}
													}

													$tourDate    = $day['tour_date'];
													$vDetailsAll = json_decode($day['vehicle_details'] ?? '[]');

													
													$vehicles = array_filter(
														$vDetailsAll,
														fn($v) => $v->tour_date == $tourDate
													);

													if (!$vehicles) { continue; }

													$rowspan = count($vehicles);                
													$first   = true;                              

													foreach ($vehicles as $v) {
														echo '<tr>';

													
														if ($first) {
															echo '<td rowspan="'.$rowspan.'">'.$dayNo.'</td>';
															echo '<td rowspan="'.$rowspan.'">'.date('d-m-Y', strtotime($tourDate)).'</td>';
															echo '<td rowspan="'.$rowspan.'">'.$ss_name_temp.'</td>';
															$dayNo++;                          
															$first = false;
														}

													
														echo '<td>'.$v->travel_distance.'</td>';
														echo '<td>'.$v->vehicle_model.'</td>';
														echo '<td>'.$v->day_rent.'</td>';
														echo '</tr>';
														$cs_trans_total = $cs_trans_total + $v->day_rent;
													}
													if($dkey == $itinerary_details_save_cnt){
													
														$first1   = true;   
														foreach ($vehicles as $v) {
															echo '<tr>';

															if ($first1) {
																echo '<td rowspan="'.$rowspan.'" colspan="3">Extra Kilometer</td>';               
																$first1 = false;
															}

															echo '<td>'.$v->total_extra_kilometer.'</td>';
															echo '<td>'.$v->vehicle_model.'</td>';
															echo '<td>'.$v->total_extra_cost.'</td>';
															echo '</tr>';
															$cs_trans_total = $cs_trans_total + $v->total_extra_cost;
															$total_extra_klm_cost = $total_extra_klm_cost + $v->total_extra_cost;
														}
															
													}
												}
												?>
												<tr>
													<th colspan="5">Total Transportation Cost</th>
													<th><?php echo $cs_trans_total; ?></th>
												</tr>
												
											</table>
										</div>
									</div>
								<?php } } ?>
								<!-------------------------------------------------------------------------------------------------------------->	

								<form id="myTourplanForm1" method="POST" action="<?=site_url('Enquiry/generateCostingSheet');?>">
									<input type="hidden" id="no_of_night_hidden" name="no_of_night_hidden" value="<?php echo $object_det[0]['no_of_night']; ?>">	
									<input type="hidden" id="tac_hidden" name="tac_hidden" value="0">
									<input type="hidden" id="ttc_hidden" name="ttc_hidden" value="0">	
									<input type="hidden" id="extraklm_hidden" name="extraklm_hidden" value="<?php echo $total_extra_klm_cost; ?>">	
									<input type="hidden" id="spcl_hidden" name="spcl_hidden" value="0">
									<input type="hidden" id="daily_hidden" name="daily_hidden" value="0">
									<input type="hidden" id="extension_ref_id" name="extension_ref_id" value="<?php echo $extension_ref_id; ?>">
									<input type="hidden" id="tnr_hidden" name="tnr_hidden" value="0">
									<input type="hidden" name="enquiry_header_id_t" value="<?php echo $object_det[0]['enquiry_header_id']; ?>">
									<input type="hidden" name="enquiry_details_id_t" value="<?php echo $object_det[0]['enquiry_details_id']; ?>">
									<input type="hidden" name="object_id_t" value="<?php echo $object_id; ?>">
								
								<?php if(!empty($itinerary_details_save)){ 
										if(empty($iti_cost_datas)){ 
									?>
									<div class="costing-container" style="background-color:#003300;">
    								<div class="table-responsive costing-box">
									<table class="table">
										<tr>
											<th><h5 style="font-weight:bold;color:#003300;">Total Acc Cost : <sapn id="tac_span"></span></h5>
												
											</th>
											<th><h5 style="font-weight:bold;color:#003300;">Total Trans Cost : <sapn id="ttc_span"></span></h5>
												
											</th>
										
											<th><h5 style="font-weight:bold;color:#003300;">Special Event : <sapn id="spcl_span"></span></h5>
												
											</th>
											<th><h5 style="font-weight:bold;color:#003300;">Extra Charge : <sapn id="daily_span"></span></h5>
												
											</th>
											<th><h5 style="font-weight:bold;color:#003300;">Total Net Rate : <sapn id="tnr_span"></span></h5>
												
											</th>
										</tr>
									</table>
									<table class="table">
										<tr>
											<td><h5 style="font-weight:bold;color:#003300;">Markup(%)</h5></td>
											<td><input type="text" id="margin_value" name="margin_value" class="form-control input-sm" maxlength="6" value="<?php echo $mark_up; ?>" <?php echo $read_only_ext; ?>></td>
											<td><input type="text" id="margin_total" name="margin_total" class="form-control input-sm" maxlength="6" readonly></td>
										</tr>
										<tr>
											<td><h5 style="font-weight:bold;color:#003300;">Tour Addon</h5></td>
											<td><input type="text" id="tour_addon_value" name="tour_addon_value" class="form-control input-sm" maxlength="6" value="0" <?php echo $read_only_ext; ?>></td>
											<td><input type="text" id="tour_addon_total" name="tour_addon_total" class="form-control input-sm" maxlength="6" readonly></td>
										</tr>
										<tr>
											<td><h5 style="font-weight:bold;color:#003300;">Total</h5></td>
											<td></td>
											<td><input type="text" id="total_final" name="total_final" class="form-control input-sm" maxlength="6" readonly></td>
										</tr>
										<tr>
											<td><h5 style="font-weight:bold;color:#003300;">GST</h5></td>
											<td>
												
												<select id="gst_value" name="gst_value" class="form-control input-sm" <?php echo $dis_abled_ext; ?>>
													
													<option value="5">5%</option>
													<option value="0">18%</option>
												</select>
											</td>
											<td><input type="text" id="gst_final" name="gst_final" class="form-control input-sm" maxlength="6" readonly></td>
										</tr>
										<tr>
											<td><h5 style="font-weight:bold;color:#003300;">Total Package Cost</h5></td>
											<td></td>
											<td><input type="text" id="tpc" name="tpc" class="form-control input-sm" maxlength="6" readonly></td>
										</tr>
									</table>
<<<<<<< .mine
||||||| .r1102

									<table class="table">
										<tr>
											<th>
												
											</th>
											<th>
												
											</th>
										
											<th>
												
											</th>
											<th><h5 style="font-weight:bold;color:#003300;">Costing Sheet Name</h5>
												
											</th>
											<th><input type="text" id="cs_name" name="cs_name" class="form-control input-sm" maxlength="50" required>
												
											</th>
										</tr>
									</table>
=======

									<table class="table">
										<tr>
											<th>
												
											</th>
											<th>
												
											</th>
										
											<th>
												
											</th>
											<th><h5 style="font-weight:bold;color:#003300;">Costing Sheet Name</h5>
												
											</th>
											<th><input type="text" id="cs_name" name="cs_name" class="form-control input-sm" maxlength="50">
												
											</th>
										</tr>
									</table>
>>>>>>> .r1119
									
									<?php if($final_save_flag == 1){ ?>
										<button type="submit" id="gen_cost_sheet_id" class="btn btn-success" style="float:right;">Save Costing Sheet</button>
									<?php } ?>
								
							    <?php } else { ?>
									<table class="table">
										<tr>
											<th><h5 style="font-weight:bold;color:#003300;">Total Acc Cost : <sapn id="tac_span"></span></h5>
												
											</th>
											<th><h5 style="font-weight:bold;color:#003300;">Total Trans Cost : <sapn id="ttc_span"></h5></span>
												
											</th>
										
											<th><h5 style="font-weight:bold;color:#003300;">Special Event : <sapn id="spcl_span"></h5></span>
												
											</th>
											<th><h5 style="font-weight:bold;color:#003300;">Extra Charge : <sapn id="daily_span"></h5></span>
												
											</th>
											<th><h5 style="font-weight:bold;color:#003300;">Total Net Rate : <sapn id="tnr_span"></h5></span>
												
											</th>
										</tr>
									</table>
									<table class="table">
										<tr>
											<td><h5 style="font-weight:bold;color:#003300;">Markup(%)</h5></td>
											<td><input type="text" id="margin_value" name="margin_value" class="form-control input-sm" maxlength="6" value="<?php echo $iti_cost_datas[0]['margin_per']; ?>" <?php echo $read_only_ext; ?>></td>
											<td><input type="text" id="margin_total" name="margin_total" class="form-control input-sm" maxlength="6" value="<?php echo $iti_cost_datas[0]['margin_value']; ?>" readonly></td>
										</tr>
										<tr>
											<td><h5 style="font-weight:bold;color:#003300;">Tour Addon</h5></td>
											<td><input type="text" id="tour_addon_value" name="tour_addon_value" class="form-control input-sm" maxlength="6" value="<?php echo $iti_cost_datas[0]['tour_addon']; ?>" <?php echo $read_only_ext; ?>></td>
											<td><input type="text" id="tour_addon_total" name="tour_addon_total" class="form-control input-sm" maxlength="6" value="<?php echo $iti_cost_datas[0]['tour_addon']; ?>" readonly></td>
										</tr>
										<tr>
											<td><h5 style="font-weight:bold;color:#003300;">Total</h5></td>
											<td></td>
											<td><input type="text" id="total_final" name="total_final" class="form-control input-sm" maxlength="6" value="<?php echo $iti_cost_datas[0]['total_rate']; ?>" readonly></td>
										</tr>
										<tr>
											<td><h5 style="font-weight:bold;color:#003300;">GST</h5></td>
											<td>
												
												<select id="gst_value" name="gst_value" class="form-control input-sm" <?php echo $dis_abled_ext; ?>>
													<?php if($iti_cost_datas[0]['gst_per'] == "5"){ ?>
														<option value="5" selected>5%</option>
														<option value="0">18%</option>
													<?php } else { ?>
														<option value="5">5%</option>
														<option value="0" selected>18%</option>
													<?php } ?>
												</select>
											</td>
											<td><input type="text" id="gst_final" name="gst_final" class="form-control input-sm" maxlength="6" value="<?php echo $iti_cost_datas[0]['gst_value']; ?>" readonly></td>
										</tr>
										<tr>
											<td><h5 style="font-weight:bold;color:#003300;">Total Package Cost</h5></td>
											<td></td>
											<td><input type="text" id="tpc" name="tpc" class="form-control input-sm" maxlength="6" value="<?php echo $iti_cost_datas[0]['tpc']; ?>" readonly></td>
										</tr>
									</table>
								
								    <?php if($final_save_flag == 0){ ?>
										<a href="<?=site_url('Enquiry/enquiry_list_view/10'); ?>" id="cancel_cost_sheet_id" data-toggle="tooltip" data-original-title="Itinerary Details" style="float:left;">Cancel</a>
									<?php } ?>
									<?php if($final_save_flag == 1 || $iti_edit_id == 1){ 
										if($extension_disable == 0){
										?>
										<button type="" id="view_cost_sheet_id" class="btn btn-success" style="float:right;">Update Costing Sheet</button>
									<?php } } ?>
							
							<?php
							} } ?>
                            </div>
							</div>
							</form>
							</div>
						</div>
						
						<!-- row closed -->
					</div>
				</div>
				<!-- App-content closed -->
			</div>

			<!-- Footer opened -->
			<footer class="footer-main icon-footer">
				<div class="container">
					<div class="  mt-2 mb-2 text-center">
					Copyright © 2025 <a href="#" class="fs-14 text-primary">KHM</a>. Designed by <a href="https://megatrendkms.co.in" class="fs-14 text-primary" target="_blank">Megatrend Knowledge Management Systems Pvt Ltd</a> All rights reserved.
					</div>
				</div>
			</footer>
			<!-- Footer closed -->
		</div>

		<!-- Back to top -->
		<a href="#top" id="back-to-top"><i class="fa fa-angle-double-up"></i></a>

		<!-- Jquery-scripts -->
		<script src="<?php echo base_url('assets/js/vendors/jquery-3.2.1.min.js'); ?>"></script>

		<!-- Moment js-->
        <script src="<?php echo base_url('assets/plugins/moment/moment.min.js'); ?>"></script>

		<!-- Bootstrap-scripts js -->
		<script src="<?php echo base_url('assets/js/vendors/bootstrap.bundle.min.js'); ?>"></script>

		<!-- Sparkline JS-->
		<script src="<?php echo base_url('assets/js/vendors/jquery.sparkline.min.js'); ?>"></script>

		<!-- Bootstrap-daterangepicker js -->
		<script src="<?php echo base_url('assets/plugins/bootstrap-daterangepicker/daterangepicker.js'); ?>"></script>

		<!-- Bootstrap-datepicker js -->
		<script src="<?php echo base_url('assets/plugins/bootstrap-datepicker/bootstrap-datepicker.js'); ?>"></script>

		<!-- Chart-circle js -->
		<script src="<?php echo base_url('assets/js/vendors/circle-progress.min.js'); ?>"></script>

		<!-- Rating-star js -->
		<script src="<?php echo base_url('assets/plugins/rating/jquery.rating-stars.js'); ?>"></script>

		<!-- Custom scroll bar js-->
		<script src="<?php echo base_url('assets/plugins/scroll-bar/jquery.mCustomScrollbar.concat.min.js'); ?>"></script>

		<!-- Nice-select js-->
		<script src="<?php echo base_url('assets/plugins/jquery-nice-select/js/jquery.nice-select.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/jquery-nice-select/js/nice-select.js'); ?>"></script>

        <!-- P-scroll js -->
		<script src="<?php echo base_url('assets/plugins/p-scroll/p-scroll.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/p-scroll/p-scroll-1.js'); ?>"></script>

		<!-- Sidemenu js-->
		<script src="<?php echo base_url('assets/plugins/sidemenu/icon-sidemenu.js'); ?>"></script>

		<!-- Sidemenu-respoansive-tabs js -->
		<script src="<?php echo base_url('assets/plugins/sidemenu-responsive-tabs/js/sidemenu-responsive-tabs.js'); ?>"></script>

		<!-- Leftmenu js -->
		<script src="<?php echo base_url('assets/js/left-menu.js'); ?>"></script>

		<!-- Data tables -->
		<script src="<?php echo base_url('assets/plugins/datatable1/js/jquery.dataTables.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/datatable1/js/dataTables.bootstrap4.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/datatable1/js/dataTables.buttons.min.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/datatable1/js/buttons.bootstrap4.min.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/datatable1/dataTables.responsive.min.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/datatable1/responsive.bootstrap4.min.js'); ?>"></script>
		<script src="<?php echo base_url('assets/js/editable.js'); ?>"></script>

		<!-- Rightsidebar js -->
		<script src="<?php echo base_url('assets/plugins/sidebar/sidebar.js'); ?>"></script>

		<!-- Custom js -->
		<script src="<?php echo base_url('assets/js/custom.js'); ?>"></script>
		<script src="<?php echo base_url('assets/plugins/select2/select2.full.min.js'); ?>"></script>
		<script src="<?php echo base_url('assets/js/select2.js'); ?>"></script>

	</body>
</html>
<script>
    function selectagent() {
        var change_value = $('#agent_state').val();
        if (change_value == "") {
            alert('Select a state!');
        } else {
            $.ajax({
                url: "<?=site_url('Enquiry/getAgents');?>",
                method: "POST",
                data: {
                    location_id: change_value
                },
                success: function (data) {
                    $('#agent_id').html(data);
                }
            });
        }
    } 
</script>

<script>
    function select_vehicle() {
        var change_value = $('#hub_location').val();
        if (hub_location == "") {
            alert('Select Hub Location!');
        } else {
            $.ajax({
                url: "<?=site_url('Enquiry/getVehicleTypes');?>",
                method: "POST",
                data: {
                    location_id: change_value
                },
                success: function (data) {
                    $('#vehicle_type').html(data);
                }
            });
        }
    } 
</script>

<script>
function selectagentdet() {
        var agent_id = $('#agent_id').val();
        if (agent_id == "") {
            alert('Select Agent');
        } else {
            $.ajax({
                url: '<?=site_url('Enquiry/getAgentDetails');?>',
                type: 'POST',
                data: {
                    agent_id: agent_id
                },
                dataType: 'json',
                success: function (data) {
					var address_temp = data[0].entity_address;
                    $('#agent_address').text(address_temp);
                },
                error: function (xhr, status, error) {
                    console.error(error);
                }
            });
        }
    }
	</script>
	<script>
      function switchroles(role_id,role_name) {
        const newUrl = '<?php echo site_url('Dashboard'); ?>'
        $.ajax({
          url: '<?php echo site_url('Dashboard/system_role_change'); ?>',
          type: 'POST',
          data: {role_id:role_id,role_name:role_name},
          success: function(response) {
            location.reload();

          },
          error: function(xhr, status, error) {
            // Handle any errors
            console.error(error);
          }
        });
      }
</script>
<script>
      function switchsystems(system_id,system_name) {
        const newUrl = '<?php echo site_url('Enquiry/add_object_enquiry/10'); ?>'
        $.ajax({
          url: '<?php echo site_url('Dashboard/khm_system_change'); ?>',
          type: 'POST',
          data: {system_id:system_id,system_name:system_name},
          success: function(response) {
			location.reload();

          },
          error: function(xhr, status, error) {
            // Handle any errors
            console.error(error);
          }
        });
      }
</script>

<script>
	$(document).ready(function () {
    function calculateTotalPax() {
        var noOfAdult = parseInt($('#no_of_adult').val()) || 0;
        var noOfChildWithBed = parseInt($('#no_of_child_with_bed').val()) || 0;
        var noOfChildWithoutBed = parseInt($('#no_of_child_without_bed').val()) || 0;

        var totalPax = noOfAdult + noOfChildWithBed + noOfChildWithoutBed;
        $('#total_no_of_pax').val(totalPax);
    }

    $('#no_of_adult, #no_of_child_with_bed, #no_of_child_without_bed').on('input', calculateTotalPax);
});
</script>
<script type="text/javascript">
    $(document).ready(function () {
        var i = 0;
        $('#vehicle_type').on('change', function () {
            var v_id = $("#vehicle_type").val();
            $('#vehicle_dynamic_head').html('<tr><th>Vehicle Type</th><th>Count</th><th>Remove</th></tr>');
            $.ajax({
                type: "POST",
                url: "<?= base_url() ?>/Enquiry/get_vehicle_name",
                data: {
                    v_id: v_id
                },
                dataType: 'json',
                success: function (response) {
                    i++;
                    $('#vehicle_dynamic_field').append('<tr id="row' + i + '" class="dynamic-added"><td><input type="hidden" name="addmore[' + i + '][v_id]" value="' + response[0].vehicle_type_id + '"/><input type="text" name="addmore[' + i + '][v_name]" value="' + response[0].vehicle_model_name + '" class="form-control form-control-sm"></td><td><select class="form-control select2 custom-select" name="addmore[' + i + '][v_count]" aria-label="Default select example"><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option></select></td><td><button type="button" name="remove" id="' + i + '" class="btn btn-danger btn_agency_remove">X</button></td></tr>');
                }
            });
        });
        $(document).on('click', '.btn_agency_remove', function () {
            var button_id = $(this).attr("id");
            $('#row' + button_id + '').remove();
        });
    });
</script>
<script>
	$(document).ready(function () {
		$("#btn_back").click(function () {
            $('.nav a[href="#tab-5"]').tab('show');
    	});
	});
</script>
<script>
    $(document).ready(function () {
        function toggleVehicleFields() {
            var isVehicleRequired = $("#is_vehicle_req").val();
            if (isVehicleRequired === "1") {
                $("#hub_location, #vehicle_type").prop("disabled", false);
            } else {
                $("#hub_location, #vehicle_type").prop("disabled", true).val(""); // Clear selection when disabled
				$("#vehicle_dynamic_field").html('');
            }
        }

        // Call on page load (in case of pre-selected value)
        toggleVehicleFields();

        // Attach change event
        $("#is_vehicle_req").change(function () {
            toggleVehicleFields();
        });
    });
</script>
<script>
$(document).ready(function () {
    $('#no_of_days, #tour_start_date').on('input change', function () {
        var startDate = $('#tour_start_date').val();
        var noOfDays = parseInt($('#no_of_days').val());

        if (startDate && noOfDays > 0) {
            var startDateObj = new Date(startDate);
            startDateObj.setDate(startDateObj.getDate() + noOfDays);

            var yyyy = startDateObj.getFullYear();
            var mm = String(startDateObj.getMonth() + 1).padStart(2, '0');
            var dd = String(startDateObj.getDate()).padStart(2, '0');
            var endDate = yyyy + '-' + mm + '-' + dd;

            $('#tour_end_date').val(endDate);
        } else {
			if(startDate == null || startDate == '' || startDate == 'undefined'){
				var alerttHTML = `<div class="alert alert-warning alert-dismissible fade show" role="alert">
					<span class="alert-inner--icon"><i class="fe fe-info"></i></span>
					<span class="alert-inner--text">Required</span>
					<button type="button" class="close text-white" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>`;

				$('#startdate-alert').html(alerttHTML);
				setTimeout(function () {
					$(".alert").fadeOut("slow", function () {
						$(this).remove();
					});
				}, 2000);
			}
            $('#tour_end_date').val('');
        }
    });
});
</script>
<script>
$(document).ready(function(){
    var emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z]+(\.[a-zA-Z]+)+$/;

    $("#guest_email").on("input keyup", function() {
        var email = $(this).val();

        if (emailPattern.test(email)) {
            $("#email_error").hide();
            $(this).css("border", "2px solid green");
        } else {
            $("#email_error").show();
            $(this).css("border", "2px solid red");
        }
    });

    // Clear field when clicking outside if invalid
    $("#guest_email").on("blur", function() {
        var email = $(this).val();

        if (!emailPattern.test(email)) {
            $(this).val("");  // Clear input
            $(this).css("border", "");  // Reset border color
            $("#email_error").hide();  // Hide error message
        }
    });
});
</script>

<script>
$(document).ready(function(){
    $("#guest_mobile").on("keyup", function() {
        var mobile = $(this).val();
        
        // Remove non-numeric characters
        mobile = mobile.replace(/\D/g, '');
        $(this).val(mobile); // Set cleaned value back

        // Check if exactly 10 digits
        if (mobile.length === 10) {
            $("#mobile_error").hide();
            $(this).css("border", "2px solid green");
        } else {
            $("#mobile_error").show();
            $(this).css("border", "2px solid red");
        }
    });

    // Clear field if invalid when clicking outside
    $("#guest_mobile").on("blur", function() {
        var mobile = $(this).val();

        if (mobile.length !== 10) {
            $(this).val("");  // Clear input
            $(this).css("border", "");  // Reset border color
            $("#mobile_error").hide();  // Hide error message
        }
    });
});
</script>
<script>
$(document).on('click', '#btn_add_bt', function (e) {
    e.preventDefault();
	var tour_plan_div = $('.tour_plan_div').val();
	var hotel_categories = <?php echo json_encode($hotel_categories); ?>;
	var hotel_category_exist = <?php echo $object_det[0]['hotel_category']; ?>;
	var meal_plan_exist = <?php echo $object_det[0]['meal_plan']; ?>;
	
	var no_of_night = <?php echo $object_det[0]['no_of_night']; ?>;
	var total_no_of_pax = <?php echo $object_det[0]['total_no_of_pax']; ?>;
	var enquiry_header_id = <?php echo $object_det[0]['enquiry_header_id']; ?>;
	var enquiry_details_id = <?php echo $object_det[0]['enquiry_details_id']; ?>;
	var no_of_adult = <?php echo $object_det[0]['no_of_adult']; ?>;
	var no_of_child_with_bed = <?php echo $object_det[0]['no_of_child_with_bed']; ?>;
	var no_of_child_without_bed = <?php echo $object_det[0]['no_of_child_without_bed']; ?>;
	var no_of_double_room = <?php echo $object_det[0]['no_of_double_room']; ?>;
	var no_of_single_room = <?php echo $object_det[0]['no_of_single_room']; ?>;
	var no_of_extra_bed = <?php echo $object_det[0]['no_of_extra_bed']; ?>;
	var is_vehicle_required = <?php echo $object_det[0]['is_vehicle_required']; ?>;
	var is_quick_quote = <?php echo $object_det[0]['is_quick_quote']?$object_det[0]['is_quick_quote']:0; ?>;
	var vehicle_models = <?php echo json_encode($vehicle_data); ?>;

	var vehicle_from_location_id = <?php echo $object_det[0]['vehicle_from_location']; ?>;
	var arrival_location_id = <?php echo $object_det[0]['arrival_location']; ?>;
	var departure_location_id = <?php echo $object_det[0]['departure_location']; ?>;

    var start_date = <?= json_encode($start_date); ?>;
    var tour_location_id = $('#tour_location').val();
	var dyn_list_data = '';
	
	var lastLocationId = $('.tour_plan_div .location-card:last').find('input[name^="addloc["][name$="[tour_location_id]"]').val();
	var vid;
	var newCard = ``;
	var breadcrumb = ``;
	var si_nos;
    if (!tour_location_id) {
        alert("Please select location");
    }
	else if (lastLocationId == tour_location_id) {
        alert("You cannot add same location continuously");
    }
	else {
		//var $link = $(this);
        var $spinner = $('#csspinner');
        //$link.addClass('disabled-link');
		$('#btn_add_bt').attr('disabled', true);
        $spinner.show();
        $.ajax({
            url: '<?= site_url('Enquiry/getLocationName'); ?>',
            method: 'POST',
            data: { tour_location_id: tour_location_id, hotel_category_exist:hotel_category_exist},
            dataType: 'json',
            success: function (response) {
				if(response.length > 0){
					var count = $('.tour_plan_div .location-card').length + 1;
					
					if(count > 0){
						//$("#btn_save_tour_plan").show();
						$("#btn_savedraft_tour_plan").show();
					}
					else{
						//$("#btn_save_tour_plan").hide();
						$("#btn_savedraft_tour_plan").hide();
					}
					$('#btn_add_bt').prop('disabled', false);
				
					
					var isFirst = count === 1;
					var prevCheckout = $('.tour_plan_div .location-card:last input[name^="addloc["][name$="[checkout]"]').val();
					var checkinDate = isFirst ? start_date : prevCheckout || '';
					ep_sel = '';
					cp_sel = '';
					map_sel = '';
					ap_sel = '';
					if(meal_plan_exist == 1){
						ep_sel = "selected";
					}
					if(meal_plan_exist == 2){
						cp_sel = "selected";
					}
					if(meal_plan_exist == 3){
						map_sel = "selected";
					}
					if(meal_plan_exist == 4){
						ap_sel = "selected";
					}
					newCard += `
					
						<div class="col-md-12 col-lg-12 col-xl-12 location-card" data-index="${count}">
							<div class="card">
								<div class="card-header">
									<input type="hidden" id="own_arrange${count}" name="addloc[${count}][own_arrange]" value="0">
									<input type="hidden" id="tour_location_id${count}" name="addloc[${count}][tour_location_id]" value="${response[0].geog_id}">
									<input type="hidden" id="location_sequence${count}" name="addloc[${count}][location_sequence]" value="${count}">
									<div class="card-title"><span class="card-seq" style="color:#339966;">${count}</span>. <span style="color:#339966;">${response[0].geog_name}</span></div>
									<div class="card-options">
										<a href="#" class="card-options-remove"><i class="fe fe-x"></i></a>
									</div>
								</div>
								<div class="card-body">
									<div class="ibox teams mb-30 bg-boxshadow">
										<div class="ibox-content teams">
											<div class="row mt-2">
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Checkin</b></div>
													<span class="text-muted">
														<input type="date" value="${checkinDate}" id="checkin${count}" name="addloc[${count}][checkin]" class="form-control input-sm" required readonly>
													</span>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Nights</b></div>
													<span class="text-muted">
														<input type="text" id="no_of_night${count}" name="addloc[${count}][no_of_night]" class="form-control input-sm no_of_night" maxlength="2" oninput="validateNumericInput(this); calculateCheckout(${count});" required>
													</span>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Checkout</b></div>
													<span class="text-muted">
														<input type="date" id="checkout${count}" name="addloc[${count}][checkout]" class="form-control input-sm" required readonly>
													</span>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Hotel Category</b></div>
														<select id="hotelcat${count}" name="addloc[${count}][hotelcat]" class="form-control select2-show-search input-sm hotel_cat_change" data-id="${count}" required>
														<option value="">Select</option>
														</select>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Hotel</b></div>
													<span class="text-muted">
														<select id="hotelid${count}" name="addloc[${count}][hotelid]" class="form-control select2-show-search input-sm" data-id="${count}" required>
														<option value="">Select</option>
														</select>
													</span>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Room Category</b></div>
														<select id="roomcat${count}" name="addloc[${count}][roomcat]" class="form-control select2-show-search input-sm" data-id="${count}" required>
														<option value="">Select</option>
														</select>
												</div>
											</div>

										
											<div class="row mt-2">
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Meal Plan</b></div>
													<span class="text-muted">
														<select id="mealplan${count}" name="addloc[${count}][mealplan]" class="form-control select2-show-search input-sm mp_change" data-id="${count}" required>
														<option value="">Select</option>
														<option value="1" ${ep_sel}>EP</option>
														<option value="2" ${cp_sel}>CP</option>
														<option value="3" ${map_sel}>MAP</option>
														<option value="4" ${ap_sel}>AP</option>
														</select>
													</span>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>No Of Adult</b></div>
													<input type="text" id="no_of_adult${count}" name="addloc[${count}][no_of_adult]" value="${no_of_adult}" class="form-control input-sm" maxlength="2" oninput="validateNumericInput(this);" readonly>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>C.With Bed Qty</b></div>
													<input type="text" id="no_of_ch${count}" name="addloc[${count}][no_of_ch]" value="${no_of_child_with_bed}" class="form-control input-sm" maxlength="2" oninput="validateNumericInput(this);" readonly>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>C.Without Bed Qty</b></div>
													<input type="text" id="no_of_cw${count}" name="addloc[${count}][no_of_cw]" value="${no_of_child_without_bed}" class="form-control input-sm" maxlength="2" oninput="validateNumericInput(this);" readonly>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Extra Bed Qty</b></div>
													<input type="text" id="no_of_extra${count}" name="addloc[${count}][no_of_extra]" value="${no_of_extra_bed}" class="form-control input-sm" maxlength="2" oninput="validateNumericInput(this);" readonly>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Total Pax</b></div>
													<input type="text" id="no_of_pax${count}" name="addloc[${count}][no_of_pax]" value="${total_no_of_pax}" class="form-control input-sm" maxlength="3" oninput="validateNumericInput(this);" readonly>
												</div>
												
											</div>`;
                                            if(no_of_double_room > 0) {
											
												newCard += `<div class="row mt-2 double_row">
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Double Room</b></div>
														<input type="text" id="double${count}" name="addloc[${count}][double]" value="${no_of_double_room}" class="form-control input-sm" maxlength="2" oninput="validateNumericInput(this);" readonly>
													</div>
										
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Daily Room Rate</b></div>
														<input type="text" id="d_adult_rate${count}" name="addloc[${count}][d_adult_rate]" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" required>
													</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>C.With Bed Rate</b></div>
														<input type="text" id="d_child_rate${count}" name="addloc[${count}][d_child_rate]" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);">
													</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>C.Without Bed Rate</b></div>
														<input type="text" id="d_child_wb_rate${count}" name="addloc[${count}][d_child_wb_rate]" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);">
													</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Extra Bed Rate</b></div>
														<input type="text" id="d_extra_bed_rate${count}" name="addloc[${count}][d_extra_bed_rate]" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);">
													</div>
														<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Total</b></div>
														<input type="text" id="d_total_rate${count}" name="addloc[${count}][d_total_rate]" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" readonly>
													</div>
													
												</div>`;
											}
											else{
												newCard += `<input type="hidden" id="double${count}" name="addloc[${count}][double]" value="0">
															<input type="hidden" id="d_adult_rate${count}" name="addloc[${count}][d_adult_rate]" value="0">
															<input type="hidden" id="d_child_rate${count}" name="addloc[${count}][d_child_rate]" value="0">
															<input type="hidden" id="d_child_wb_rate${count}" name="addloc[${count}][d_child_wb_rate]" value="0">
															<input type="hidden" id="d_extra_bed_rate${count}" name="addloc[${count}][d_extra_bed_rate]" value="0">
															<input type="hidden" id="d_total_rate${count}" name="addloc[${count}][d_total_rate]" value="0">`;
											}
											if(no_of_single_room > 0) {
											newCard += `<div class="row mt-2 single_row">
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Single Room</b></div>
													<input type="text" id="single${count}" name="addloc[${count}][single]" value="${no_of_single_room}" class="form-control input-sm" maxlength="2" oninput="validateNumericInput(this);" readonly>
												</div>
									
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Daily Room Rate</b></div>
													<input type="text" id="s_adult_rate${count}" name="addloc[${count}][s_adult_rate]" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);">
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>C.With Bed Rate</b></div>
													<input type="text" id="s_child_rate${count}" name="addloc[${count}][s_child_rate]" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" readonly>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>C.Without Bed Rate</b></div>
													<input type="text" id="s_child_wb_rate${count}" name="addloc[${count}][s_child_wb_rate]" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" readonly>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Extra Bed Rate</b></div>
													<input type="text" id="s_extra_bed_rate${count}" name="addloc[${count}][s_extra_bed_rate]" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" readonly>
												</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Total</b></div>
													<input type="text" id="s_total_rate${count}" name="addloc[${count}][s_total_rate]" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" readonly>
												</div>
												
											</div>`;
											}
											else{
												newCard += `<input type="hidden" id="single${count}" name="addloc[${count}][single]" value="0">
															<input type="hidden" id="s_adult_rate${count}" name="addloc[${count}][s_adult_rate]" value="0">
															<input type="hidden" id="s_child_rate${count}" name="addloc[${count}][s_child_rate]" value="0">
															<input type="hidden" id="s_child_wb_rate${count}" name="addloc[${count}][s_child_wb_rate]" value="0">
															<input type="hidden" id="s_extra_bed_rate${count}" name="addloc[${count}][s_extra_bed_rate]" value="0">
															<input type="hidden" id="s_total_rate${count}" name="addloc[${count}][s_total_rate]" value="0">`;
											}
											if(is_vehicle_required == 1) {
												newCard += `
												<div class="row mt-2">
													<div class="col-xl-1 col-sm-12 col-md-1">
													<a id="loadvehs${count}" class="nav-link load_vehs_click" data-id="${count}"><i class="fa fa-refresh"></i></a>
													</div>
													<div class="col-xl-11 col-sm-12 col-md-11"><h5 style="color:#003300;">Vehicle Details<span id="v_from_to${count}"></span></h5>
													</div>
												</div>
												<input type="hidden" id="veh_header${count}" name="addloc[${count}][veh_header]" value="">
												<div class="row mt-2 single_row">
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Vehicle Model</b></div>
												    </div>		
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Vehicle Count</b></div>
													</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Daily Rent</b></div>
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Max KM/Day</b></div>
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Distance</b></div>
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Extra KM</b></div>
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Extra KM Rate</b></div>
													</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Total</b></div>
													</div>
												</div>
														`;
												$.each(vehicle_models, function (vindex, vmodel) {
												si_nos = vindex + 1;
												vid = count + vmodel.vehicle_type_id;
												newCard += `
												
												<div class="row mt-2 single_row">
													<div class="col-xl-2 col-sm-12 col-md-2">
														
														<input type="text" id="veh_model${vid}" name="addloc[${count}][veh_model][${vindex}]" value="${vmodel.vehicle_model_name}" class="form-control input-sm veh_model${vindex}" readonly>
														<input type="hidden" id="veh_type_id${vid}" name="addloc[${count}][veh_type_id][${vindex}]" value="${vmodel.vehicle_type_id}" class="form-control input-sm veh_type_id${vindex}">
													</div>
										
													<div class="col-xl-2 col-sm-12 col-md-2">
														
														<input type="text" id="veh_count${vid}" name="addloc[${count}][veh_count][${vindex}]" value="${vmodel.vehicle_count}" class="form-control input-sm veh_count${vindex}" maxlength="2" oninput="validateNumericInput(this);" readonly>
													</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
														
														<input type="text" id="day_rent${vid}" name="addloc[${count}][day_rent][${vindex}]" value="0" class="form-control input-sm cls_daily day_rent${vindex}" data-id="${vid}" data-cid="${count}" maxlength="5" oninput="validateNumericInput(this);">
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
														
														<input type="text" id="max_km_day${vid}" name="addloc[${count}][max_km_day][${vindex}]" value="0" class="form-control input-sm max_km_day${vindex}" maxlength="5" oninput="validateNumericInput(this);" readonly>
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
														
														<input type="text" id="travel_distance${vid}" name="addloc[${count}][travel_distance][${vindex}]" value="0" class="form-control input-sm cls_dist travel_distance${vindex}" data-id="${vid}" data-cid="${count}" maxlength="5" oninput="validateNumericInput(this);">
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
														
														<input type="text" id="extra_kilometer${vid}" name="addloc[${count}][extra_kilometer][${vindex}]" value="0" class="form-control input-sm extra_kilometer${vindex}" maxlength="5" oninput="validateNumericInput(this);" readonly>
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
														
														<input type="text" id="extra_km_rate${vid}" name="addloc[${count}][extra_km_rate][${vindex}]" value="0" class="form-control input-sm extra_km_rate${vindex}" maxlength="5" oninput="validateNumericInput(this);" readonly>
													</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
														
														<input type="text" id="veh_total${vid}" name="addloc[${count}][veh_total][${vindex}]" value="0" class="form-control input-sm veh_total${vindex}" maxlength="5" oninput="validateNumericInput(this);" readonly>
													</div>
													
												</div>`;
												});
											}
											else{
												newCard += `<input type="hidden" id="veh_model${count}0" name="addloc[${count}][veh_model][0]" value="">
															<input type="hidden" id="veh_count${count}0" name="addloc[${count}][veh_count][0]" value="0">
															<input type="hidden" id="day_rent${count}0" name="addloc[${count}][day_rent][0]" value="0">
															<input type="hidden" id="max_km_day${count}0" name="addloc[${count}][max_km_day][0]" value="0">
															<input type="hidden" id="extra_km_rate${count}0" name="addloc[${count}][extra_km_rate][0]" value="0">
															<input type="hidden" id="veh_total${count}0" name="addloc[${count}][veh_total][0]" value="0">`;
											}
											newCard += `

										</div>
									</div>
								</div>
							</div>
							
						</div>
						
					`;
				
					$(".tour_plan_div").append(newCard);
					$('#tour_location').val('').trigger('change');

					breadcrumb += `
					    <li class="bc-card" data-index="${count}">
							<a>
								<span class="bc-card-seq" style="color:#fff">${count}</span>.<span style="color:#fff">${response[0].geog_name}(<span id="span_night_id${count}" style="color:#fff"></span>)<span id="loc_total${count}" style="color:#fff"></span></span>
							</a>
						</li>
					`;
                  
					$('.dyn_list').append(breadcrumb);

					var totalNights  = calculateTotalNights();
					if(totalNights == no_of_night){ 
						$("#btn_save_tour_plan").show();
						$('#btn_add_bt').prop('disabled', true);
					}
					else{
						$("#btn_save_tour_plan").hide();
						$('#btn_add_bt').prop('disabled', false);
					}
					/* Load Hotel Category */ 
					var hotelCat = $('#hotelcat' + count);
						hotelCat.empty();
						
						if (hotel_categories.length > 1) {
							$.each(hotel_categories, function (index, hotelcat) {
								if(hotelcat.hotel_category_id == hotel_category_exist){
									hotelCat.append('<option value="' + hotelcat.hotel_category_id + '" selected>' + hotelcat.hotel_category_name + '</option>');
								}
								else{
									hotelCat.append('<option value="' + hotelcat.hotel_category_id  + '">' + hotelcat.hotel_category_name + '</option>');
								}
							});
						}
						else{
							hotelCat.append('<option value="">Hotel Category Not Found</option>');
						}
						hotelCat.trigger('change');
					updateSequenceNumbers();
				}
				else{
					var halert = `<div class="alert alert-success alert-dismissible fade show" role="alert">
						<span class="alert-inner--icon"><i class="fe fe-info"></i></span>
						<span class="alert-inner--text">No hotels configured at this location with this hotel category</span>
						<button type="button" class="close text-white" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">×</span>
						</button>
					</div>`;

					$('#hotel_alert').html(halert);
					setTimeout(function () {
						$(".alert").fadeOut("slow", function () {
							$(this).remove();
						});
					}, 2000);
				}
            },
			complete: function() {
				$('#btn_add_bt').attr('disabled', false);
				$spinner.hide();
			},
            error: function (xhr, status, error) {
                console.error('Error adding node:', error);
            }
        });
    }
});
function calculateTotalNights() {
    var totalNights = 0;
    $('.no_of_night').each(function() {
        var nights = parseInt($(this).val()) || 0;
        totalNights += nights;
    });
    return totalNights;
}
// Remove location card and update sequence numbers
$(document).on("click", ".card-options-remove", function (e) {
    e.preventDefault();
    var card = $(this).closest(".location-card");
    var removedIndex = card.index(); // Get index before removing
	var bcid = card.attr("data-index");
    card.remove();
	$('.dyn_list li').each(function() {
        if ($(this).text().trim().startsWith(bcid + ".")) {
            $(this).remove();
        }
    });
    updateSequenceNumbers();
    var remainingCards = $('.tour_plan_div .location-card');
    if (remainingCards.length === 0) {
        $("#btn_save_tour_plan").hide();
    } else {
        remainingCards.each(function (index) {
            if (index >= removedIndex) {
                calculateCheckout(index);
            }
        });
    }
});

// Function to update sequence numbers and adjust checkin/checkout dates
function updateSequenceNumbers() {
	if ($('.tour_plan_div .location-card').length === 0) {
		location.reload();
	}
    $('.tour_plan_div .location-card').each(function (index) {
        let newIndex = index + 1;
        $(this).attr("data-index", newIndex);
        $(this).find('.card-seq').text(newIndex);

        // Update IDs and Names of input fields
		$(this).find('[id^="own_arrange"]').attr("id", `own_arrange${newIndex}`).attr("name", `addloc[${newIndex}][own_arrange]`);
        $(this).find('[id^="tour_location_id"]').attr("id", `tour_location_id${newIndex}`).attr("name", `addloc[${newIndex}][tour_location_id]`);
		$(this).find('[id^="location_sequence"]').attr("id", `location_sequence${newIndex}`).attr("name", `addloc[${newIndex}][location_sequence]`).val(newIndex);
        $(this).find('[id^="checkin"]').attr("id", `checkin${newIndex}`).attr("name", `addloc[${newIndex}][checkin]`);
        $(this).find('[id^="no_of_night"]').attr("id", `no_of_night${newIndex}`).attr("name", `addloc[${newIndex}][no_of_night]`);
        $(this).find('[id^="checkout"]').attr("id", `checkout${newIndex}`).attr("name", `addloc[${newIndex}][checkout]`);
		$(this).find('[id^="v_from_to"]').attr("id", `v_from_to${newIndex}`);
		$(this).find('[id^="veh_header"]').attr("id", `veh_header${newIndex}`).attr("name", `addloc[${newIndex}][veh_header]`);

		$(this).find('[id^="hotelcat"]').attr("id", `hotelcat${newIndex}`).attr("name", `addloc[${newIndex}][hotelcat]`).attr("data-id", newIndex);
		$(this).find('[id^="hotelid"]').attr("id", `hotelid${newIndex}`).attr("name", `addloc[${newIndex}][hotelid]`).attr("data-id", newIndex);
		$(this).find('[id^="roomcat"]').attr("id", `roomcat${newIndex}`).attr("name", `addloc[${newIndex}][roomcat]`).attr("data-id", newIndex);

		$(this).find('[id^="mealplan"]').attr("id", `mealplan${newIndex}`).attr("name", `addloc[${newIndex}][mealplan]`).attr("data-id", newIndex);
		$(this).find('[id^="no_of_adult"]').attr("id", `no_of_adult${newIndex}`).attr("name", `addloc[${newIndex}][no_of_adult]`);
		$(this).find('[id^="no_of_ch"]').attr("id", `no_of_ch${newIndex}`).attr("name", `addloc[${newIndex}][no_of_ch]`);
		$(this).find('[id^="no_of_cw"]').attr("id", `no_of_cw${newIndex}`).attr("name", `addloc[${newIndex}][no_of_cw]`);
		$(this).find('[id^="no_of_extra"]').attr("id", `no_of_extra${newIndex}`).attr("name", `addloc[${newIndex}][no_of_extra]`);
		$(this).find('[id^="no_of_pax"]').attr("id", `no_of_pax${newIndex}`).attr("name", `addloc[${newIndex}][no_of_pax]`);

		$(this).find('[id^="double"]').attr("id", `double${newIndex}`).attr("name", `addloc[${newIndex}][double]`);
		$(this).find('[id^="d_adult_rate"]').attr("id", `d_adult_rate${newIndex}`).attr("name", `addloc[${newIndex}][d_adult_rate]`);
		$(this).find('[id^="d_child_rate"]').attr("id", `d_child_rate${newIndex}`).attr("name", `addloc[${newIndex}][d_child_rate]`);
		$(this).find('[id^="d_child_wb_rate"]').attr("id", `d_child_wb_rate${newIndex}`).attr("name", `addloc[${newIndex}][d_child_wb_rate]`);
		$(this).find('[id^="d_extra_bed_rate"]').attr("id", `d_extra_bed_rate${newIndex}`).attr("name", `addloc[${newIndex}][d_extra_bed_rate]`);
		$(this).find('[id^="d_total_rate"]').attr("id", `d_total_rate${newIndex}`).attr("name", `addloc[${newIndex}][d_total_rate]`);

		$(this).find('[id^="single"]').attr("id", `single${newIndex}`).attr("name", `addloc[${newIndex}][single]`);
		$(this).find('[id^="s_adult_rate"]').attr("id", `s_adult_rate${newIndex}`).attr("name", `addloc[${newIndex}][s_adult_rate]`);
		$(this).find('[id^="s_child_rate"]').attr("id", `s_child_rate${newIndex}`).attr("name", `addloc[${newIndex}][s_child_rate]`);
		$(this).find('[id^="s_child_wb_rate"]').attr("id", `s_child_wb_rate${newIndex}`).attr("name", `addloc[${newIndex}][s_child_wb_rate]`);
		$(this).find('[id^="s_extra_bed_rate"]').attr("id", `s_extra_bed_rate${newIndex}`).attr("name", `addloc[${newIndex}][s_extra_bed_rate]`);
		$(this).find('[id^="s_total_rate"]').attr("id", `s_total_rate${newIndex}`).attr("name", `addloc[${newIndex}][s_total_rate]`);

		$(this).find('[id^="loadvehs"]').attr("id", `loadvehs${newIndex}`).attr("data-id", newIndex);

		var vehicle_models = <?php echo json_encode($vehicle_data); ?>;
		var is_vehicle_required = <?php echo $object_det[0]['is_vehicle_required']; ?>;
		if(is_vehicle_required == 1) {
			let cardElement = $(this);

			$.each(vehicle_models, function (vindex, vmodel) {
				let vid = `${newIndex}${vmodel.vehicle_type_id}`;
				cardElement.find(`.veh_model${vindex}`).attr("id", `veh_model${vid}`).attr("name", `addloc[${newIndex}][veh_model][${vindex}]`);
				cardElement.find(`.veh_type_id${vindex}`).attr("id", `veh_type_id${vid}`).attr("name", `addloc[${newIndex}][veh_type_id][${vindex}]`);
				cardElement.find(`.veh_count${vindex}`).attr("id", `veh_count${vid}`).attr("name", `addloc[${newIndex}][veh_count][${vindex}]`);
				cardElement.find(`.day_rent${vindex}`).attr("id", `day_rent${vid}`).attr("name", `addloc[${newIndex}][day_rent][${vindex}]`).attr("data-id", vid).attr("data-cid", newIndex);
				cardElement.find(`.max_km_day${vindex}`).attr("id", `max_km_day${vid}`).attr("name", `addloc[${newIndex}][max_km_day][${vindex}]`);
				cardElement.find(`.extra_km_rate${vindex}`).attr("id", `extra_km_rate${vid}`).attr("name", `addloc[${newIndex}][extra_km_rate][${vindex}]`);
				cardElement.find(`.veh_total${vindex}`).attr("id", `veh_total${vid}`).attr("name", `addloc[${newIndex}][veh_total][${vindex}]`);
				cardElement.find(`.travel_distance${vindex}`).attr("id", `travel_distance${vid}`).attr("name", `addloc[${newIndex}][travel_distance][${vindex}]`).attr("data-id", vid).attr("data-cid", newIndex);
				cardElement.find(`.extra_kilometer${vindex}`).attr("id", `extra_kilometer${vid}`).attr("name", `addloc[${newIndex}][extra_kilometer][${vindex}]`);
			});
		}
        // Update Check-in Dates
        var checkinInput = document.getElementById(`checkin${newIndex}`);
        var checkoutInput = document.getElementById(`checkout${newIndex}`);

        if (index === 0) {
            checkinInput.value = <?= json_encode($start_date); ?>;
        } else {
            var prevCheckout = document.getElementById(`checkout${newIndex - 1}`)?.value;
            checkinInput.value = prevCheckout || '';
        }

        // Recalculate checkout for each location
        var nightsInput = document.getElementById(`no_of_night${newIndex}`).value;
        if (nightsInput) {
            calculateCheckout(newIndex);
        }

		var no_of_night = <?php echo $object_det[0]['no_of_night']; ?>;
		var totalNights  = calculateTotalNights();
		$('#planned_night').text(totalNights+" / ");
		if(totalNights == no_of_night){ 
			$("#btn_save_tour_plan").show();
			$('#btn_add_bt').prop('disabled', true);
		}
		else{
			$("#btn_save_tour_plan").hide();
			$('#btn_add_bt').prop('disabled', false);
		}
		/*var dvalue = parseInt($('#d_total_rate'+newIndex).val());
		var svalue = parseInt($('#s_total_rate'+newIndex).val());
		$('#loc_total'+newIndex).text(dvalue + svalue);*/
    });

	$('.dyn_list .bc-card').each(function (index1) {
        let bcIndex = index1 + 1; 
        $(this).attr("data-index", bcIndex);
		$(this).find('.bc-card-seq').text(bcIndex);
	});

	
	var accom_grand_total = get_accom_grand_total();
	if(accom_grand_total > 0){
		$('#a_total').text(accom_grand_total);
	}
	else{
		$('#a_total').text(0);
	}
	var veh_grand_total = get_veh_grand_total();
	if(veh_grand_total > 0){
	    veh_grand_total += parseFloat($('#extraklm_hidden').val()) || 0;
		$('#v_total').text(veh_grand_total);
	}
	else{
		$('#v_total').text(0);
	}
	var g_total = parseInt(accom_grand_total) + parseInt(veh_grand_total);
	if(g_total > 0){
		$('#g_total').text(g_total);
	}
	else{
		$('#g_total').text(0);
	}
}

// Function to allow only numeric input
function validateNumericInput(input) {
    input.value = input.value.replace(/\D/g, '');
}

// Function to calculate the checkout date
function calculateCheckout(count) {
	var totalDuration = <?php echo $object_det[0]['no_of_night']; ?>;
        var sum = 0;
        $(".no_of_night").each(function() {
            let nights = parseInt($(this).val()) || 0; // Ensure numeric value
            sum += nights;
        });
        if (sum > totalDuration) {
            alert("Total nights exceed the allowed duration!");
            $('#no_of_night'+count).val('');
        }
    var checkin = document.getElementById(`checkin${count}`)?.value;
    var nights = document.getElementById(`no_of_night${count}`)?.value;
    var checkoutField = document.getElementById(`checkout${count}`);
//alert(checkin);alert(nights);alert(checkoutField);
    if (checkin && nights) {
        var checkinDate = new Date(checkin);
        checkinDate.setDate(checkinDate.getDate() + parseInt(nights, 10));
        var checkoutDate = checkinDate.toISOString().split('T')[0]; // Format YYYY-MM-DD
        checkoutField.value = checkoutDate;

        // Update checkin for all locations after the current one
        $('.tour_plan_div .location-card').each(function (index) {
            if (index >= count) {
                var nextIndex = index + 1;
                var nextCheckinField = document.getElementById(`checkin${nextIndex}`);
                var prevCheckout = document.getElementById(`checkout${nextIndex - 1}`)?.value;
                if (nextCheckinField && prevCheckout) {
                    nextCheckinField.value = prevCheckout;
                }
            }
        });
    }
}
</script>
<script>
$(document).on('change', '.hotel_change', function() {
    var hotel_id = $(this).val();
	var id = $(this).attr('data-id');
	var no_of_double_room = <?php echo $object_det[0]['no_of_double_room']; ?>;
	var no_of_single_room = <?php echo $object_det[0]['no_of_single_room']; ?>;
    $.ajax({
        url: "<?=site_url('Enquiry/getTourRoomCategory');?>",
        method: "POST",
        data: {
            hotel_id: hotel_id,
			no_of_double_room:no_of_double_room,
			no_of_single_room:no_of_single_room
        },
        success: function (data) {
            $('#roomcat'+id).html(data);
        }
    });

	$.ajax({
        url: "<?=site_url('Enquiry/getHotelfacilities');?>",
        method: "POST",
        data: {
            hotel_id: hotel_id,
        },
        success: function (data) {
            $('#hotfac'+id).html(data);
			$('#hotfac'+id).trigger('change');
        }
    });
    
});
</script>
<script>
$(document).on('change', '.hotel_change_draft', function() {
    var hotel_id = $(this).val();
	var id = $(this).attr('data-id');
	var rid = $(this).attr('data-rid');
	var no_of_double_room = <?php echo $object_det[0]['no_of_double_room']; ?>;
	var no_of_single_room = <?php echo $object_det[0]['no_of_single_room']; ?>;
    $.ajax({
        url: "<?=site_url('Enquiry/getTourRoomCategoryDraft');?>",
        method: "POST",
        data: {
            hotel_id: hotel_id,
			rid:rid,
			no_of_double_room:no_of_double_room,
			no_of_single_room:no_of_single_room
        },
        success: function (data) {
            $('#roomcat'+id).html(data);
        }
    });

	$.ajax({
        url: "<?=site_url('Enquiry/getHotelfacilities');?>",
        method: "POST",
        data: {
            hotel_id: hotel_id,
        },
        success: function (data) {
            $('#hotfac'+id).html(data);
			$('#hotfac'+id).trigger('change');
        }
    });
    
});
</script>
<script>
$(document).on('change', '.hotel_cat_change', function() {
    var hotel_cat_id = $(this).val(); 
	var id = $(this).attr('data-id');
	var tour_location_id = $('#tour_location_id'+id).val();
	var is_quick_quote = <?php echo $object_det[0]['is_quick_quote']?$object_det[0]['is_quick_quote']:0; ?>;
    $.ajax({
        url: "<?=site_url('Enquiry/getTourHotels');?>",
        method: "POST",
        data: {
            hotel_cat_id: hotel_cat_id,
			is_quick_quote:is_quick_quote,
			tour_location_id:tour_location_id
        },
        success: function (data) {
            $('#hotelid'+id).html(data);
			$('#roomcat'+id).empty().append('<option value="">Select</option>');
			$('#hotelid'+id).trigger('change');
        }
    });
});
</script>
<script>
$(document).on('change', '.hotel_cat_change_draft', function() {
    var hotel_cat_id = $(this).val(); 
	var id = $(this).attr('data-id');
	var hid = $(this).attr('data-hid');
	var tour_location_id = $('#tour_location_id'+id).val();
	var is_quick_quote = <?php echo $object_det[0]['is_quick_quote']?$object_det[0]['is_quick_quote']:0; ?>;
    $.ajax({
        url: "<?=site_url('Enquiry/getTourHotelsDraft');?>",
        method: "POST",
        data: {
            hotel_cat_id: hotel_cat_id,
			is_quick_quote:is_quick_quote,
			tour_location_id:tour_location_id,
			hid:hid
        },
        success: function (data) {
            $('#hotelid'+id).html(data);
			$('#roomcat'+id).empty().append('<option value="">Select</option>');
			$('#hotelid'+id).trigger('change');
        }
    });
});
</script>
<script>
$(document).on('change', '.room_cat_change', function() {
	var iti_edit_id = <?php echo isset($iti_edit_id) && $iti_edit_id !== '' ? $iti_edit_id : 0; ?>;
	var id = $(this).attr('data-id');
	var sid = $(this).attr('data-sid');
	if(sid == "2"){

		var dataIndex = $(this).closest('[data-index]').data('index');
		var first_hotel = $('#hotelid'+dataIndex).val(); 
		var first_rc = $('#roomcat'+dataIndex).val(); 

		var $row = $(this).closest('.dynamic-added');
		var currentId = $row.attr('id');
		var selectedHotel = $row.find('.hotel').val();
		var selectedRoomCat = $row.find('.room_cat').val();
		var isDuplicate = false;

		$('[data-index="' + dataIndex + '"] .dynamic-added').each(function () {
			var rowId = $(this).attr('id');
			if (rowId !== currentId) {
				var hotel = $(this).find('.hotel').val();
				var roomcat = $(this).find('.room_cat').val();
				if (hotel === selectedHotel && roomcat === selectedRoomCat) {
					isDuplicate = true;
					return false;
				}
			}
		});
		if (selectedHotel === first_hotel && selectedRoomCat === first_rc) {
			isDuplicate = true;
		}
		
		if (isDuplicate) {
			alert("This hotel and room category combination already exists.");
			$row.find('.room_cat').val('');
		}
        else{
		var room_cat_id = $(this).val();
		if(room_cat_id == 0){
			$('#own_arrange'+id).val(1);
			$('#d_adult_rate'+id).val(0).prop('readonly', true);
			$('#d_child_rate'+id).val(0).prop('readonly', true);
			$('#d_child_wb_rate'+id).val(0).prop('readonly', true);
			$('#d_extra_bed_rate'+id).val(0).prop('readonly', true);
			
			$('#s_adult_rate'+id).val(0).prop('readonly', true);
			$('#s_child_rate'+id).val(0).prop('readonly', true);
			$('#s_child_wb_rate'+id).val(0).prop('readonly', true);
			$('#s_extra_bed_rate'+id).val(0).prop('readonly', true);
			
		}
		else{
			$('#own_arrange'+id).val(0);
			if(iti_edit_id == 0){
				$('#d_adult_rate'+id).prop('readonly', false);
				$('#d_child_rate'+id).prop('readonly', false);
				$('#d_child_wb_rate'+id).prop('readonly', false);
				$('#d_extra_bed_rate'+id).prop('readonly', false);
			
				$('#s_adult_rate'+id).prop('readonly', false);
			}
			//$('#s_child_rate'+id).prop('readonly', false);
			//$('#s_child_wb_rate'+id).prop('readonly', false);
			//$('#s_extra_bed_rate'+id).prop('readonly', false);
			
		var mealplan = $('#meal_plan_id'+id).val();
		var hotel_id = $('#hotelid'+id).val();
		var double = $('#double'+id).val();
		var single = $('#single'+id).val();
		var tour_date = $('#tour_date'+id).val();
		var tour_location_id = $('#tour_location_id'+id).val();

			$.ajax({
				url: "<?=site_url('Enquiry/getTourTariffDetailsbydate');?>",
				method: "POST",
				data: {
					hotel_id: hotel_id,
					room_cat_id:room_cat_id,
					mealplan:mealplan,
					double:double,
					single:single,
					id:id,
					tour_location_id:tour_location_id,
					tour_date:tour_date
				},
				dataType: 'json',
				success: function (data) {
					//if(data.length > 0){

						var no_of_ch = parseInt($('#no_of_ch'+id).val()) || 0;
						var no_of_cw = parseInt($('#no_of_cw'+id).val()) || 0;
						var no_of_extra = parseInt($('#no_of_extra'+id).val()) || 0;

						var ndouble = parseInt($('#double'+id).val());
						var nsingle = parseInt($('#single'+id).val());
						var room_r = parseInt(data.d_room_tariff);
						var child_r = parseInt(data.d_child_tariff);
						var child_wb_r = parseInt(data.d_child_wb_tariff);
						var extra_r = parseInt(data.d_extra_tariff);
		
						$('#d_adult_rate'+id).val(data.d_room_tariff);
						$('#d_child_rate'+id).val(data.d_child_tariff);
						$('#d_child_wb_rate'+id).val(data.d_child_wb_tariff);
						$('#d_extra_bed_rate'+id).val(data.d_extra_tariff);
						var total_double = (ndouble*room_r) + (no_of_ch*child_r) + (no_of_cw*child_wb_r) + (no_of_extra*extra_r);

						$('#s_adult_rate'+id).val(data.s_room_tariff);
						$('#s_child_rate'+id).val(data.s_child_tariff);
						$('#s_child_wb_rate'+id).val(data.s_child_wb_tariff);
						$('#s_extra_bed_rate'+id).val(data.s_extra_tariff);
						var total_single = parseInt(data.s_room_tariff)*parseInt(nsingle);

						$('#acc_total'+id).val(total_double + total_single);
						setTimeout(() => calculateGrandTotal(dataIndex), 300);
					//}
				}
			});
	
		}
	}
	}
	else{
		var dataIndex = $(this).closest('[data-index]').data('index');
		var room_cat_id = $(this).val();
		if(room_cat_id == 0){
			$('#own_arrange'+id).val(1);
			$('#d_adult_rate'+id).val(0).prop('readonly', true);
			$('#d_child_rate'+id).val(0).prop('readonly', true);
			$('#d_child_wb_rate'+id).val(0).prop('readonly', true);
			$('#d_extra_bed_rate'+id).val(0).prop('readonly', true);
			
			$('#s_adult_rate'+id).val(0).prop('readonly', true);
			$('#s_child_rate'+id).val(0).prop('readonly', true);
			$('#s_child_wb_rate'+id).val(0).prop('readonly', true);
			$('#s_extra_bed_rate'+id).val(0).prop('readonly', true);
			
		}
		else{
			$('#own_arrange'+id).val(0);
			if(iti_edit_id == 0){
				$('#d_adult_rate'+id).prop('readonly', false);
				$('#d_child_rate'+id).prop('readonly', false);
				$('#d_child_wb_rate'+id).prop('readonly', false);
				$('#d_extra_bed_rate'+id).prop('readonly', false);
				
				$('#s_adult_rate'+id).prop('readonly', false);
			}
			//$('#s_child_rate'+id).prop('readonly', false);
			//$('#s_child_wb_rate'+id).prop('readonly', false);
			//$('#s_extra_bed_rate'+id).prop('readonly', false);
			
		var mealplan = $('#meal_plan_id'+id).val();
		var hotel_id = $('#hotelid'+id).val();
		var double = $('#double'+id).val();
		var single = $('#single'+id).val();
		var tour_date = $('#tour_date'+id).val();
		var tour_location_id = $('#tour_location_id'+id).val();

			$.ajax({
				url: "<?=site_url('Enquiry/getTourTariffDetailsbydate');?>",
				method: "POST",
				data: {
					hotel_id: hotel_id,
					room_cat_id:room_cat_id,
					mealplan:mealplan,
					double:double,
					single:single,
					id:id,
					tour_location_id:tour_location_id,
					tour_date:tour_date
				},
				dataType: 'json',
				success: function (data) {
					//if(data.length > 0){

						var no_of_ch = parseInt($('#no_of_ch'+id).val()) || 0;
						var no_of_cw = parseInt($('#no_of_cw'+id).val()) || 0;
						var no_of_extra = parseInt($('#no_of_extra'+id).val()) || 0;

						var ndouble = parseInt($('#double'+id).val());
						var nsingle = parseInt($('#single'+id).val());
						var room_r = parseInt(data.d_room_tariff);
						var child_r = parseInt(data.d_child_tariff);
						var child_wb_r = parseInt(data.d_child_wb_tariff);
						var extra_r = parseInt(data.d_extra_tariff);
		
						$('#d_adult_rate'+id).val(data.d_room_tariff);
						$('#d_child_rate'+id).val(data.d_child_tariff);
						$('#d_child_wb_rate'+id).val(data.d_child_wb_tariff);
						$('#d_extra_bed_rate'+id).val(data.d_extra_tariff);
						var total_double = (ndouble*room_r) + (no_of_ch*child_r) + (no_of_cw*child_wb_r) + (no_of_extra*extra_r);

						$('#s_adult_rate'+id).val(data.s_room_tariff);
						$('#s_child_rate'+id).val(data.s_child_tariff);
						$('#s_child_wb_rate'+id).val(data.s_child_wb_tariff);
						$('#s_extra_bed_rate'+id).val(data.s_extra_tariff);
						var total_single = parseInt(data.s_room_tariff)*parseInt(nsingle);

						$('#acc_total'+id).val(total_double + total_single);
						setTimeout(() => calculateGrandTotal(dataIndex), 300);
					//}
				}
			});
		
	}
}
});
</script>
<script type="text/javascript">
    /*$(document).on('click', '.tour_view', function(e) {
        e.preventDefault();
		var tourPlanDet = <?php echo json_encode($tour_plan_det); ?>;
		var vehicle_models = <?php echo json_encode($vehicle_data); ?>;
		var html = '';
		html += '<table class="table table-bordered table-responsive-md table-striped mb-0 text-nowrap">';
		html += '<tr>';
		html += '<th colspan="7" style="text-align:center;"> Accommodation </th>';
		html += '</tr>';
		html += '<tr>';
						html += '<th> Si No </th>';
						html += '<th> Location </th>';
						html += '<th> Start Date </th>';
						html += '<th> Nights </th>';
						html += '<th> End Date </th>';
						html += '<th> Hotel </th>';
						html += '<th> Room Category </th>';
					html += '</tr>';
		$.each(tourPlanDet, function (index, item) {
			var sino = index + 1;
			
					
					html += '<tr>';
						html += '<td>'+sino+'</td>';
						html += '<td>'+item.geog_name+'</td>';
						html += '<td>'+item.check_in_date+'</td>';
						html += '<td>'+item.no_of_days+'</td>';
						html += '<td>'+item.check_out_date+'</td>';
						html += '<td>'+item.object_name+'</td>';
						html += '<td>'+item.room_category_name+'</td>';
					html += '</tr>';
					
					
		});
		html += '</table>';

		html += '<table class="table table-bordered table-responsive-md table-striped mb-0 text-nowrap">';
		html += '<tr>';
		html += '<th colspan="7" style="text-align:center;"> Transportation </th>';
		html += '</tr>';
		html += '<tr>';
						html += '<th> Si No </th>';
						html += '<th> Vehicle Model </th>';
						html += '<th> Vehicle Count </th>';
					html += '</tr>';
		$.each(vehicle_models, function (index1, item1) {
			var sino = index1 + 1;		
					html += '<tr>';
						html += '<td>'+sino+'</td>';
						html += '<td>'+item1.vehicle_model_name+'</td>';
						html += '<td>'+item1.vehicle_count+'</td>';
					
					html += '</tr>';
						
		});
		html += '</table>';
		$('.tab_con').html(html);
        $('#modal_tour').modal('show');
    });*/

	$(document).on('click', '.tour_view', function() {
    var enquiry_header_id = <?php echo $object_det[0]['enquiry_header_id']; ?>;
    var enquiry_details_id = <?php echo $object_det[0]['enquiry_details_id']; ?>;
    var hotel_categories = <?php echo json_encode($hotel_categories); ?>;
	var hotel_category_exist = <?php echo $object_det[0]['hotel_category']; ?>;
	var meal_plan_exist = <?php echo $object_det[0]['meal_plan']; ?>;
	var no_of_night = <?php echo $object_det[0]['no_of_night']; ?>;
	var total_no_of_pax = <?php echo $object_det[0]['total_no_of_pax']; ?>;
	var enquiry_header_id = <?php echo $object_det[0]['enquiry_header_id']; ?>;
	var enquiry_details_id = <?php echo $object_det[0]['enquiry_details_id']; ?>;
	var no_of_adult = <?php echo $object_det[0]['no_of_adult']; ?>;
	var no_of_child_with_bed = <?php echo $object_det[0]['no_of_child_with_bed']; ?>;
	var no_of_child_without_bed = <?php echo $object_det[0]['no_of_child_without_bed']; ?>;
	var no_of_double_room = <?php echo $object_det[0]['no_of_double_room']; ?>;
	var no_of_single_room = <?php echo $object_det[0]['no_of_single_room']; ?>;
	var no_of_extra_bed = <?php echo $object_det[0]['no_of_extra_bed']; ?>;
	var is_vehicle_required = <?php echo $object_det[0]['is_vehicle_required']; ?>;
	var is_quick_quote = <?php echo $object_det[0]['is_quick_quote']?$object_det[0]['is_quick_quote']:0; ?>;
	var vehicle_models = <?php echo json_encode($vehicle_data); ?>;

	var child_t_d = 0;
	var child_t_s = 0;

	var child_wb_t_d = 0;
	var child_wb_t_s = 0;

	var extra_t_d = 0;
	var extra_t_s = 0;

	var room_t_d = 0;
	var room_t_s = 0;

    var start_date = <?= json_encode($start_date); ?>;
    var totalDays = 0;
	
	var vid_t;
	var v_day_rent;
	var v_max_km_day;
	var v_extra_km_rate;
	var v_veh_total;	
	var v_veh_header;
	
	
    $.ajax({
        url: '<?=site_url('Enquiry/loadTourLocation');?>',
        type: 'POST',
        data: {
            enquiry_header_id: enquiry_header_id,
            enquiry_details_id: enquiry_details_id
        },
        dataType: 'json',
        success: function (response) {
            // Clear existing location cards if necessary
           
			var newCard = ``;
            $.each(response, function (index, item) {
                // Create a new location card element
				var vehicleDetails = JSON.parse(item.vehicle_details);
				var count = index+1;
			
					var isFirst = count === 1;
					var prevCheckout = $('.tour_plan_div .location-card:last input[name^="addloc["][name$="[checkout]"]').val();
					var checkinDate = isFirst ? start_date : prevCheckout || '';
					ep_sel = '';
					cp_sel = '';
					map_sel = '';
					ap_sel = '';
					if(item.meal_plan_id == 1){
						ep_sel = "selected";
					}
					if(item.meal_plan_id == 2){
						cp_sel = "selected";
					}
					if(item.meal_plan_id == 3){
						map_sel = "selected";
					}
					if(item.meal_plan_id == 4){
						ap_sel = "selected";
					}
					$.each(item.cost, function (index1, item3) {
						if((item3.cost_component_id == "6" || item3.cost_component_id == "7") && item3.room_type_id == "2"){
							room_t_d = item3.quick_quote_tariff;
						}
						if((item3.cost_component_id == "12" || item3.cost_component_id == "13") && item3.room_type_id == "2"){
							child_t_d = item3.quick_quote_tariff;
						}
						if((item3.cost_component_id == "15" || item3.cost_component_id == "16") && item3.room_type_id == "2"){
							child_wb_t_d = item3.quick_quote_tariff;
						}
						if((item3.cost_component_id == "9" || item3.cost_component_id == "10") && item3.room_type_id == "2"){
							extra_t_d = item3.quick_quote_tariff;
						}
						if((item3.cost_component_id == "6" || item3.cost_component_id == "7") && item3.room_type_id == "1"){
							room_t_s = item3.quick_quote_tariff;
						}
						if((item3.cost_component_id == "12" || item3.cost_component_id == "13") && item3.room_type_id == "1"){
							child_t_s = item3.quick_quote_tariff;
						}
						if((item3.cost_component_id == "15" || item3.cost_component_id == "16") && item3.room_type_id == "1"){
							child_wb_t_s = item3.quick_quote_tariff;
						}
						if((item3.cost_component_id == "9" || item3.cost_component_id == "10") && item3.room_type_id == "1"){
							extra_t_s = item3.quick_quote_tariff;
						}
					});	
					var room_total = parseInt(no_of_double_room)*parseInt(room_t_d);
					var child_total = parseInt(no_of_child_with_bed)*parseInt(child_t_d);
					var child_wb_total = parseInt(no_of_child_without_bed)*parseInt(child_wb_t_d);
					var extra_total = parseInt(no_of_extra_bed)*parseInt(extra_t_d);
					var d_totals = (room_total + child_total + child_wb_total + extra_total)*parseInt(item.no_of_days);
					var s_totals = (parseInt(no_of_single_room)*parseInt(room_t_s))*parseInt(item.no_of_days);
                newCard += `
					
						<div class="col-md-12 col-lg-12 col-xl-12 location-card" data-index="${count}">
							<div class="card">
								<div class="card-header">
									<input type="hidden" id="own_arrange${count}" name="addloc[${count}][own_arrange]" value="${item.is_own_arrangement}">
									<input type="hidden" id="tour_location_id${count}" name="addloc[${count}][tour_location_id]" value="${item.tour_location}">
									<input type="hidden" id="location_sequence${count}" name="addloc[${count}][location_sequence]" value="${count}">
									<div class="card-title"><span class="card-seq" style="color:#339966;">${count}</span>. <span style="color:#339966;">${item.geog_name}</span></div>
								</div>
								<div class="card-body">
									<div class="ibox teams mb-30 bg-boxshadow">
										<div class="ibox-content teams">
											<div class="row mt-2">
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Checkin</b></div>
													<span class="text-muted">
														<input type="date" value="${item.check_in_date}" id="checkin${count}" name="addloc[${count}][checkin]" class="form-control input-sm" required readonly>
													</span>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Nights</b></div>
													<span class="text-muted">
														<input type="text" id="no_of_night${count}" name="addloc[${count}][no_of_night]" value="${item.no_of_days}" class="form-control input-sm no_of_night" maxlength="2" oninput="validateNumericInput(this); calculateCheckout(${count});" readonly>
													</span>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Checkout</b></div>
													<span class="text-muted">
														<input type="date" id="checkout${count}" value="${item.check_out_date}" name="addloc[${count}][checkout]" class="form-control input-sm" required readonly>
													</span>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Hotel Category</b></div>
														<select id="hotelcat${count}" name="addloc[${count}][hotelcat]" class="form-control select2-show-search input-sm hotel_cat_change_draft" data-id="${count}" data-hid="${item.hotel_id}" readonly>
														<option value="">Select</option>
														</select>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Hotel</b></div>
													<span class="text-muted">
														<select id="hotelid${count}" name="addloc[${count}][hotelid]" class="form-control select2-show-search input-sm hotel_change_draft" data-rid="${item.room_category_id}" data-id="${count}" readonly>
														<option value="">Select</option>
														</select>
													</span>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Room Category</b></div>
														<select id="roomcat${count}" name="addloc[${count}][roomcat]" class="form-control select2-show-search input-sm" data-id="${count}" readonly>
														<option value="">Select</option>
														</select>
												</div>
											</div>

										
											<div class="row mt-2">
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Meal Plan</b></div>
													<span class="text-muted">
														<select id="mealplan${count}" name="addloc[${count}][mealplan]" class="form-control select2-show-search input-sm mp_change" data-id="${count}" readonly>
														<option value="">Select</option>
														<option value="1" ${ep_sel}>EP</option>
														<option value="2" ${cp_sel}>CP</option>
														<option value="3" ${map_sel}>MAP</option>
														<option value="4" ${ap_sel}>AP</option>
														</select>
													</span>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>No Of Adult</b></div>
													<input type="text" id="no_of_adult${count}" name="addloc[${count}][no_of_adult]" value="${no_of_adult}" class="form-control input-sm" maxlength="2" oninput="validateNumericInput(this);" readonly>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>C.With Bed Qty</b></div>
													<input type="text" id="no_of_ch${count}" name="addloc[${count}][no_of_ch]" value="${no_of_child_with_bed}" class="form-control input-sm" maxlength="2" oninput="validateNumericInput(this);" readonly>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>C.Without Bed Qty</b></div>
													<input type="text" id="no_of_cw${count}" name="addloc[${count}][no_of_cw]" value="${no_of_child_without_bed}" class="form-control input-sm" maxlength="2" oninput="validateNumericInput(this);" readonly>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Extra Bed Qty</b></div>
													<input type="text" id="no_of_extra${count}" name="addloc[${count}][no_of_extra]" value="${no_of_extra_bed}" class="form-control input-sm" maxlength="2" oninput="validateNumericInput(this);" readonly>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Total Pax</b></div>
													<input type="text" id="no_of_pax${count}" name="addloc[${count}][no_of_pax]" value="${total_no_of_pax}" class="form-control input-sm" maxlength="3" oninput="validateNumericInput(this);" readonly>
												</div>
												
											</div>`;
                                            if(no_of_double_room > 0) {
											
												newCard += `<div class="row mt-2 double_row">
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Double Room</b></div>
														<input type="text" id="double${count}" name="addloc[${count}][double]" value="${no_of_double_room}" class="form-control input-sm" maxlength="2" oninput="validateNumericInput(this);" readonly>
													</div>
										
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Daily Room Rate</b></div>
														<input type="text" id="d_adult_rate${count}" name="addloc[${count}][d_adult_rate]" value="${room_t_d}" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" readonly>
													</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>C.With Bed Rate</b></div>
														<input type="text" id="d_child_rate${count}" name="addloc[${count}][d_child_rate]" value="${child_t_d}" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" readonly>
													</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>C.Without Bed Rate</b></div>
														<input type="text" id="d_child_wb_rate${count}" name="addloc[${count}][d_child_wb_rate]" value="${child_wb_t_d}" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" readonly>
													</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Extra Bed Rate</b></div>
														<input type="text" id="d_extra_bed_rate${count}" name="addloc[${count}][d_extra_bed_rate]" value="${extra_t_d}" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" readonly>
													</div>
														<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Total</b></div>
														<input type="text" id="d_total_rate${count}" name="addloc[${count}][d_total_rate]" value="${d_totals}" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" readonly>
													</div>
													
												</div>`;
											}
											else{
												newCard += `<input type="hidden" id="double${count}" name="addloc[${count}][double]" value="0">
															<input type="hidden" id="d_adult_rate${count}" name="addloc[${count}][d_adult_rate]" value="0">
															<input type="hidden" id="d_child_rate${count}" name="addloc[${count}][d_child_rate]" value="0">
															<input type="hidden" id="d_child_wb_rate${count}" name="addloc[${count}][d_child_wb_rate]" value="0">
															<input type="hidden" id="d_extra_bed_rate${count}" name="addloc[${count}][d_extra_bed_rate]" value="0">
															<input type="hidden" id="d_total_rate${count}" name="addloc[${count}][d_total_rate]" value="0">`;
											}
											if(no_of_single_room > 0) {
											newCard += `<div class="row mt-2 single_row">
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Single Room</b></div>
													<input type="text" id="single${count}" name="addloc[${count}][single]" value="${no_of_single_room}" class="form-control input-sm" maxlength="2" oninput="validateNumericInput(this);" readonly>
												</div>
									
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Daily Room Rate</b></div>
													<input type="text" id="s_adult_rate${count}" name="addloc[${count}][s_adult_rate]" value="${room_t_s}" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" readonly>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>C.With Bed Rate</b></div>
													<input type="text" id="s_child_rate${count}" name="addloc[${count}][s_child_rate]" value="${child_t_s}" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" readonly>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>C.Without Bed Rate</b></div>
													<input type="text" id="s_child_wb_rate${count}" name="addloc[${count}][s_child_wb_rate]" value="${child_wb_t_s}" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" readonly>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Extra Bed Rate</b></div>
													<input type="text" id="s_extra_bed_rate${count}" name="addloc[${count}][s_extra_bed_rate]" value="${extra_t_s}" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" readonly>
												</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Total</b></div>
													<input type="text" id="s_total_rate${count}" name="addloc[${count}][s_total_rate]" value="${s_totals}" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" readonly>
												</div>
												
											</div>`;
											}
											else{
												newCard += `<input type="hidden" id="single${count}" name="addloc[${count}][single]" value="0">
															<input type="hidden" id="s_adult_rate${count}" name="addloc[${count}][s_adult_rate]" value="0">
															<input type="hidden" id="s_child_rate${count}" name="addloc[${count}][s_child_rate]" value="0">
															<input type="hidden" id="s_child_wb_rate${count}" name="addloc[${count}][s_child_wb_rate]" value="0">
															<input type="hidden" id="s_extra_bed_rate${count}" name="addloc[${count}][s_extra_bed_rate]" value="0">
															<input type="hidden" id="s_total_rate${count}" name="addloc[${count}][s_total_rate]" value="0">`;
											}
											if(is_vehicle_required == 1) {
												
												$.each(vehicle_models, function (vindex, vmodel) {
													$.each(vehicleDetails, function (v_index, v_item) {
														if(vmodel.vehicle_type_id == v_item.veh_type_id){
															vid_t = count + vmodel.vehicle_type_id;
															v_day_rent = v_item.day_rent;
															v_max_km_day = v_item.max_km_day;
															v_travel_distance = v_item.travel_distance;
															v_extra_kilometer = v_item.extra_kilometer;
															v_extra_km_rate = v_item.extra_km_rate;
															v_veh_total = v_item.veh_total;
															v_veh_header = v_item.veh_header;
														}
													});
													if(vindex == 0){
													newCard += `
												<center><div class="col-md-12 col-lg-12 col-xl-12"style="padding-top:10px;"><h5 style="color:#003300;">Vehicle Details<span id="v_from_to${count}">${v_veh_header}</span></h5></div></center>
												<input type="hidden" id="veh_header${count}" name="addloc[${count}][veh_header]" value="${v_veh_header}">
												<div class="row mt-2 single_row">
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Vehicle Model</b></div>
												    </div>		
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Vehicle Count</b></div>
													</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Daily Rent</b></div>
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Max KM/Day</b></div>
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Distance</b></div>
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Extra KM</b></div>
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Extra KM Rate</b></div>
													</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Total</b></div>
													</div>
												</div>
														`;
													}
												vid = count + vmodel.vehicle_type_id;
												newCard += `<div class="row mt-2 single_row">
													<div class="col-xl-2 col-sm-12 col-md-2">
														
														<input type="text" id="veh_model${vid}" name="addloc[${count}][veh_model][${vindex}]" value="${vmodel.vehicle_model_name}" class="form-control input-sm veh_model${vindex}" readonly>
														<input type="hidden" id="veh_type_id${vid}" name="addloc[${count}][veh_type_id][${vindex}]" value="${vmodel.vehicle_type_id}" class="form-control input-sm veh_type_id${vindex}">
													</div>
										
													<div class="col-xl-2 col-sm-12 col-md-2">
														
														<input type="text" id="veh_count${vid}" name="addloc[${count}][veh_count][${vindex}]" value="${vmodel.vehicle_count}" class="form-control input-sm veh_count${vindex}" maxlength="2" oninput="validateNumericInput(this);" readonly>
													</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
													
														<input type="text" id="day_rent${vid}" name="addloc[${count}][day_rent][${vindex}]" value="${v_day_rent}" class="form-control input-sm cls_daily day_rent${vindex}" data-id="${vid}" data-cid="${count}" maxlength="5" oninput="validateNumericInput(this);" readonly>
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
													
														<input type="text" id="max_km_day${vid}" name="addloc[${count}][max_km_day][${vindex}]" value="${v_max_km_day}" class="form-control input-sm max_km_day${vindex}" maxlength="5" oninput="validateNumericInput(this);" readonly>
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
													
														<input type="text" id="travel_distance${vid}" name="addloc[${count}][travel_distance][${vindex}]" value="${v_travel_distance}" class="form-control input-sm cls_dist travel_distance${vindex}" data-id="${vid}" data-cid="${count}" maxlength="5" oninput="validateNumericInput(this);" readonly>
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
													
														<input type="text" id="extra_kilometer${vid}" name="addloc[${count}][extra_kilometer][${vindex}]" value="${v_extra_kilometer}" class="form-control input-sm extra_kilometer${vindex}" maxlength="5" oninput="validateNumericInput(this);" readonly>
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
														
														<input type="text" id="extra_km_rate${vid}" name="addloc[${count}][extra_km_rate][${vindex}]" value="${v_extra_km_rate}" class="form-control input-sm extra_km_rate${vindex}" maxlength="5" oninput="validateNumericInput(this);" readonly>
													</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
														
														<input type="text" id="veh_total${vid}" name="addloc[${count}][veh_total][${vindex}]" value="${v_veh_total}" class="form-control input-sm veh_total${vindex}" maxlength="5" oninput="validateNumericInput(this);"readonly>
													</div>
													
												</div>`;
												});
											}
											else{
												newCard += `<input type="hidden" id="veh_model${count}0" name="addloc[${count}][veh_model][0]" value="">
															<input type="hidden" id="veh_count${count}0" name="addloc[${count}][veh_count][0]" value="0">
															<input type="hidden" id="day_rent${count}0" name="addloc[${count}][day_rent][0]" value="0">
															<input type="hidden" id="max_km_day${count}0" name="addloc[${count}][max_km_day][0]" value="0">
															<input type="hidden" id="extra_km_rate${count}0" name="addloc[${count}][extra_km_rate][0]" value="0">
															<input type="hidden" id="veh_total${count}0" name="addloc[${count}][veh_total][0]" value="0">`;
											}
											newCard += `
											
										</div>
									</div>
								</div>
							</div>
						</div>
						
					`;		
					setTimeout(function() {
						var hotelCat = $('#hotelcat' + count);
						console.log("Dropdown found?", hotelCat.length);

						if (hotelCat.length > 0) {
							hotelCat.empty();
							hotelCat.append('<option value="">Select</option>');

							$.each(hotel_categories, function (hIndex, hotelcat) {
								var selected = (hotelcat.hotel_category_id == item.hot_cat_id) ? "selected" : "";
								hotelCat.append('<option value="' + hotelcat.hotel_category_id + '" ' + selected + '>' + hotelcat.hotel_category_name + '</option>');
							});

							hotelCat.trigger('change');
						} else {
							console.log("Dropdown not found. Ensure it exists before updating.");
						}
					}, 500); 	
            });
			//$(".tour_plan_div").append(newCard);

			$('.tab_con').html(newCard);
        	$('#modal_tour').modal('show');
        },
        error: function (xhr, status, error) {
            console.error(error);
        }
    });
});
</script>

<script type="text/javascript">
    $(document).on('click', '.qq_view', function(e) {
        e.preventDefault();
		var tourPlanDet = <?php echo json_encode($tour_plan_det); ?>;
		var vehicle_models = <?php echo json_encode($vehicle_data); ?>;
		var quick_quote_det = <?php echo json_encode($quick_quote_det); ?>;
        var rts;
		var room_types = JSON.parse(tourPlanDet[0]['room_type']);
		var vehicle_details = JSON.parse(tourPlanDet[0]['vehicle_details']);
		var rt_count = 0;
		var sino;
		var room_t_d = 0;
		var room_t_s = 0;

		var child_t_d = 0;
		var child_t_s = 0;

		var child_wb_t_d = 0;
		var child_wb_t_s = 0;

		var extra_t_d = 0;
		var extra_t_s = 0;

		var no_of_double = 0;
		var no_of_single = 0;

		var room_total;
		var child_total;
		var child_wb_total;
		var extra_total;
		var d_totals = 0;
		var s_totals = 0;
		var g_total = 0;
		var veh_total;
		var veh_totals;
		var extra_cost;
		var ttc= 0;
		$.each(room_types, function (index1, item1) {
			if (parseInt(item1.double) > 0) {
				rt_count += 1;
				no_of_double = item1.double;
			}
			if (parseInt(item1.single) > 0) { 
				rt_count += 1;
				no_of_single = item1.single;
			}
		});

		var html = '';
		html += '<table class="table table-bordered table-responsive-md">';
		html += '<tr>';
		html += '<th colspan="7" style="text-align:center;"> Accommodation </th>';
		html += '<th colspan="6" style="text-align:center;"> Quantity </th>';
		html += '<th colspan="6" style="text-align:center;"> Tariff Rates </th>';
		html += '</tr>';
		html += '<tr>';
						html += '<th> Si No </th>';
						html += '<th> Location </th>';
						html += '<th> Start Date </th>';
						html += '<th> Nights </th>';
						html += '<th> End Date </th>';
						html += '<th> Hotel </th>';
						html += '<th> Room Category </th>';
						if(no_of_double > 0){
							html += '<th> Double </th>';
						}
						if(no_of_single > 0){
							html += '<th> Single </th>';
						}
						html += '<th> Adult </th>';
						html += '<th> C.With Bed </th>';
						html += '<th> C.Without Bed </th>';
						html += '<th> Extra Bed </th>';
						
						html += '<th> Room Type </th>';
						html += '<th> Adult </th>';
						html += '<th> C.With Bed </th>';
						html += '<th> C.Without Bed </th>';
						html += '<th> Extra Bed </th>';

						html += '<th> Total </th>';
					html += '</tr>';
		$.each(quick_quote_det, function (index, item) {
			sino = index + 1;
			rts = JSON.parse(item.room_type);
					html += '<tr>';
						
						if(item.is_own_arrangement == 1){
							html += '<td>'+sino+'</td>';
						html += '<td>'+item.geog_name+'</td>';
						html += '<td>'+item.check_in_date+'</td>';
						html += '<td>'+item.no_of_days+'</td>';
						html += '<td>'+item.check_out_date+'</td>';
						html += '<td>'+item.object_name+'</td>';
						html += '<td>'+item.room_category_name+'</td>';

						if(no_of_double > 0){
							html += '<td>'+item.no_of_double_room+'</td>';
						}
						if(no_of_single > 0){
							html += '<td>'+item.no_of_single_room+'</td>';
						}
						html += '<td>'+item.no_of_adult+'</td>';
						html += '<td>'+item.no_of_child_with_bed+'</td>';
						html += '<td>'+item.no_of_child_without_bed+'</td>';
						html += '<td>'+item.no_of_extra_bed+'</td>';
							html += '<td colspan="6">Own Arrangement</td>';
						
						}
						else{
							html += '<td rowspan="'+rt_count+'">'+sino+'</td>';
						html += '<td rowspan="'+rt_count+'">'+item.geog_name+'</td>';
						html += '<td rowspan="'+rt_count+'">'+item.check_in_date+'</td>';
						html += '<td rowspan="'+rt_count+'">'+item.no_of_days+'</td>';
						html += '<td rowspan="'+rt_count+'">'+item.check_out_date+'</td>';
						html += '<td rowspan="'+rt_count+'">'+item.object_name+'</td>';
						html += '<td rowspan="'+rt_count+'">'+item.room_category_name+'</td>';

						if(no_of_double > 0){
							html += '<td rowspan="'+rt_count+'">'+item.no_of_double_room+'</td>';
						}
						if(no_of_single > 0){
							html += '<td rowspan="'+rt_count+'">'+item.no_of_single_room+'</td>';
						}
						html += '<td rowspan="'+rt_count+'">'+item.no_of_adult+'</td>';
						html += '<td rowspan="'+rt_count+'">'+item.no_of_child_with_bed+'</td>';
						html += '<td rowspan="'+rt_count+'">'+item.no_of_child_without_bed+'</td>';
						html += '<td rowspan="'+rt_count+'">'+item.no_of_extra_bed+'</td>';
							$.each(rts, function (index2, item2) {
								if(item2.double>0){
									html += '<td>Double</td>';
									$.each(item.cost, function (index3, item3) {
										if(item3.cost_component_id == "6" && item3.room_type_id == "2"){
											room_t_d = item3.quick_quote_tariff;
										}
										if(item3.cost_component_id == "12" && item3.room_type_id == "2"){
											child_t_d = item3.quick_quote_tariff;
										}
										if(item3.cost_component_id == "15" && item3.room_type_id == "2"){
											child_wb_t_d = item3.quick_quote_tariff;
										}
										if(item3.cost_component_id == "9" && item3.room_type_id == "2"){
											extra_t_d = item3.quick_quote_tariff;
										}
									});		
									html += '<td>'+room_t_d+'</td>';
									html += '<td>'+child_t_d+'</td>';
									html += '<td>'+child_wb_t_d+'</td>';
									html += '<td>'+extra_t_d+'</td>';
									room_total = parseInt(item.no_of_double_room)*parseInt(room_t_d);
									child_total = parseInt(item.no_of_child_with_bed)*parseInt(child_t_d);
									child_wb_total = parseInt(item.no_of_child_without_bed)*parseInt(child_wb_t_d);
									extra_total = parseInt(item.no_of_extra_bed)*parseInt(extra_t_d);
									var d_totals = (room_total + child_total + child_wb_total + extra_total)*parseInt(item.no_of_days);
									g_total = g_total + d_totals;
									html += '<td><b>'+d_totals+'</b></td>';
								}
								
						html += '</tr>';
								html += '<tr>';
								if(item2.single>0){
									html += '<td>Single</td>';
									$.each(item.cost, function (index3, item3) {
										if(item3.cost_component_id == "6" && item3.room_type_id == "1"){
											room_t_s = item3.quick_quote_tariff;
										}
										if(item3.cost_component_id == "12" && item3.room_type_id == "1"){
											child_t_s = item3.quick_quote_tariff;
										}
										if(item3.cost_component_id == "15" && item3.room_type_id == "1"){
											child_wb_t_s = item3.quick_quote_tariff;
										}
										if(item3.cost_component_id == "9" && item3.room_type_id == "1"){
											extra_t_s = item3.quick_quote_tariff;
										}
									});		
									html += '<td>'+room_t_s+'</td>';
									html += '<td>'+child_t_s+'</td>';
									html += '<td>'+child_wb_t_s+'</td>';
									html += '<td>'+extra_t_s+'</td>';
									s_totals = (parseInt(item.no_of_single_room)*parseInt(room_t_s))*parseInt(item.no_of_days);
									g_total = g_total + s_totals;
									html += '<td><b>'+s_totals+'</b></td>';
								}
								
							});	
						}
					
						html += '</tr>';
		});
		html += '</table>';
		html += '<h4 style="float:right;">Total Accommodation Cost : Rs. '+g_total+'.00</h4>';
		if(vehicle_details!=null){
			html += '<table class="table table-bordered table-responsive-md">';
			html += '<tr>';
			html += '<th colspan="12" style="text-align:center;"> Transportation </th>';
			html += '</tr>';
			html += '<tr>';
							html += '<th> Si No </th>';
							html += '<th> Location </th>';
							html += '<th> Checkin </th>';
							html += '<th> Night </th>';
							html += '<th> Checkout </th>';

							html += '<th> Vehicle Model </th>';
							html += '<th> Vehicle Count </th>';
							html += '<th> Day Rent </th>';
							html += '<th> Distance </th>';
							html += '<th> Extra KM </th>';
							html += '<th> Extra KM Rate </th>';
							html += '<th> Total </th>';
						html += '</tr>';
						var vehicleDetails;
						$.each(quick_quote_det, function (index5, item5) {
							sino = index5 + 1;
							vehicleDetails = JSON.parse(item5.vehicle_details);
									html += '<tr>';
										html += '<td rowspan="'+vehicle_details.length+'">'+sino+'</td>';
										html += '<td rowspan="'+vehicle_details.length+'">'+item5.geog_name+'</td>';
										html += '<td rowspan="'+vehicle_details.length+'">'+item5.check_in_date+'</td>';
										html += '<td rowspan="'+vehicle_details.length+'">'+item5.no_of_days+'</td>';
										html += '<td rowspan="'+vehicle_details.length+'">'+item5.check_out_date+'</td>';
											$.each(vehicleDetails, function (indexv, itemv) {
											extra_cost = parseInt(itemv.extra_kilometer)*parseInt(itemv.extra_km_rate);
											veh_totals = (parseInt(itemv.vehicle_count)*parseInt(itemv.day_rent))*parseInt(item5.no_of_days);
											veh_total = veh_totals + extra_cost;
												
														html += '<td>'+itemv.vehicle_model+'</td>';
														html += '<td>'+itemv.vehicle_count+'</td>';
														html += '<td>'+itemv.day_rent+'</td>';
														html += '<td>'+itemv.travel_distance+'</td>';
														html += '<td>'+itemv.extra_kilometer+'</td>';
														html += '<td>'+itemv.extra_km_rate+'</td>';
														html += '<td>'+veh_total+'</td>';
													html += '</tr>';
													html += '<tr>';
													ttc = ttc + veh_total;		
												});
											html += '</tr>';
											
						});
						
			html += '</table>';
		}
		html += '<h4 style="float:right;">Total Transportation Cost : Rs. '+ttc+'.00</h4>';
        var grand_total = ttc+g_total;
		html += '<br><br><h4 style="float:right;">Grand Total : Rs. '+grand_total+'.00</h4>';


		$('.tab_con_qq').html(html);
        $('#modal_qq').modal('show');
    });
</script>
<script>
	function double_total_update(id,dataIndex){
		var double = parseInt($('#double'+id).val()) || 0;
		var single = parseInt($('#single'+id).val()) || 0;

		var no_of_ch = parseInt($('#no_of_ch'+id).val()) || 0;
		var no_of_cw = parseInt($('#no_of_cw'+id).val()) || 0;
		var no_of_extra = parseInt($('#no_of_extra'+id).val()) || 0;

		let maxDouble = <?php echo $object_det[0]['no_of_double_room']; ?>;
		let maxSingle = <?php echo $object_det[0]['no_of_single_room']; ?>; 

		let maxChild = <?php echo $object_det[0]['no_of_child_with_bed']; ?>;
		let maxChild_wb = <?php echo $object_det[0]['no_of_child_without_bed']; ?>;
		let maxExtra = <?php echo $object_det[0]['no_of_extra_bed']; ?>;

		/***********child */
		let currentChildVal = parseInt($('#no_of_ch' + id).val()) || 0;
		let totalChildUsed = 0;
		$('[data-index="' + dataIndex + '"] input[id^="no_of_ch"]').each(function () {
			let rowIdch = $(this).attr('id').replace('no_of_ch', '');
			let valch = parseInt($(this).val()) || 0;
			if (rowIdch !== id) {
				totalChildUsed += valch;
			}
		});
		let maxAllowedForCurrentch = maxChild - totalChildUsed;
		if (currentChildVal > maxAllowedForCurrentch) {
			alert("Only " + maxAllowedForCurrentch + " Child with bed room(s) available for this day.");
			$('#no_of_ch' + id).val(maxAllowedForCurrentch);
			currentChildVal = maxAllowedForCurrentch;
		}
		/***********child End*/

		/***********child Without bed*/
		let currentChildwbVal = parseInt($('#no_of_cw' + id).val()) || 0;
		let totalChildwbUsed = 0;
		$('[data-index="' + dataIndex + '"] input[id^="no_of_cw"]').each(function () {
			let rowIdchw = $(this).attr('id').replace('no_of_cw', '');
			let valchw = parseInt($(this).val()) || 0;
			if (rowIdchw !== id) {
				totalChildwbUsed += valchw;
			}
		});
		let maxAllowedForCurrentchw = maxChild_wb - totalChildwbUsed;
		if (currentChildwbVal > maxAllowedForCurrentchw) {
			alert("Only " + maxAllowedForCurrentchw + " Child without bed room(s) available for this day.");
			$('#no_of_cw' + id).val(maxAllowedForCurrentchw);
			currentChildwbVal = maxAllowedForCurrentchw;
		}
		/***********child Without bed end*/

		/***********Extra bed*/
		let currentExtraVal = parseInt($('#no_of_extra' + id).val()) || 0;
		let totalExtraUsed = 0;
		$('[data-index="' + dataIndex + '"] input[id^="no_of_extra"]').each(function () {
			let rowIde = $(this).attr('id').replace('no_of_extra', '');
			let vale = parseInt($(this).val()) || 0;
			if (rowIde !== id) {
				totalExtraUsed += vale;
			}
		});
		let maxAllowedForCurrente = maxExtra - totalExtraUsed;
		if (currentExtraVal > maxAllowedForCurrente) {
			alert("Only " + maxAllowedForCurrente + " Extra bed room(s) available for this day.");
			$('#no_of_extra' + id).val(maxAllowedForCurrente);
			currentExtraVal = maxAllowedForCurrente;
		}
		/***********Extra bed end*/

		let currentDoubleVal = parseInt($('#double' + id).val()) || 0;
		let currentSingleVal = parseInt($('#single' + id).val()) || 0;
		let totalDoubleUsed = 0;
		$('[data-index="' + dataIndex + '"] input[id^="double"]').each(function () {
			let rowIdd = $(this).attr('id').replace('double', '');
			let vald = parseInt($(this).val()) || 0;
			if (rowIdd !== id) {
				totalDoubleUsed += vald;
			}
		});
		let maxAllowedForCurrent = maxDouble - totalDoubleUsed;
		if (currentDoubleVal > maxAllowedForCurrent) {
			alert("Only " + maxAllowedForCurrent + " double room(s) available for this day.");
			$('#double' + id).val(maxAllowedForCurrent);
			currentDoubleVal = maxAllowedForCurrent;
		}

		let totalSingleUsed = 0;
		$('[data-index="' + dataIndex + '"] input[id^="single"]').each(function () {
			let rowIds = $(this).attr('id').replace('single', '');
			let vals = parseInt($(this).val()) || 0;
			if (rowIds !== id) {
				totalSingleUsed += vals;
			}
		});
		let maxAllowedForCurrents = maxSingle - totalSingleUsed;
		if (currentSingleVal > maxAllowedForCurrents) {
			alert("Only " + maxAllowedForCurrents + " single room(s) available for this day.");
			$('#single' + id).val(maxAllowedForCurrents);
			currentSingleVal = maxAllowedForCurrents;
		}
		
		var room = parseInt($('#d_adult_rate'+id).val()) || 0;
		var child = parseInt($('#d_child_rate'+id).val()) || 0;
		var child_wb = parseInt($('#d_child_wb_rate'+id).val()) || 0;
		var extra = parseInt($('#d_extra_bed_rate'+id).val()) || 0;
		var dtotal = (double*room) + (no_of_ch*child) + (no_of_cw*child_wb) + (no_of_extra*extra);

		var sroom = parseInt($('#s_adult_rate'+id).val()) || 0;
		var stotal = single*sroom;

		$('#acc_total'+id).val(dtotal + stotal);
		setTimeout(() => calculateGrandTotal(dataIndex), 300);
	
	}
	$(document).on('input', '[id^="double"],[id^="single"],[id^="no_of_ch"],[id^="no_of_cw"],[id^="no_of_extra"],[id^="d_adult_rate"], [id^="d_child_rate"], [id^="d_child_wb_rate"], [id^="d_extra_bed_rate"], [id^="s_adult_rate"], [id^="s_child_rate"], [id^="s_child_wb_rate"], [id^="s_extra_bed_rate"]', function() {
		//var id = this.id.replace(/^[a-z_]+/, '');
		if ($(this).val() === '' || $(this).val() === null) {
            $(this).val(0);
        }
		var id = $(this).data('id');
		var dataIndex = $(this).closest('[data-index]').data('index');
		double_total_update(id,dataIndex);
	});
</script>


<script>
	function night_single_total_update(id){
		var no_of_night = parseInt($('#no_of_night'+id).val()) || 0; 
		var single = parseInt($('#single'+id).val()) || 0;
		var room = parseInt($('#s_adult_rate'+id).val()) || 0;
		var child = parseInt($('#s_child_rate'+id).val()) || 0;
		var child_wb = parseInt($('#s_child_wb_rate'+id).val()) || 0;
		var extra = parseInt($('#s_extra_bed_rate'+id).val()) || 0;
		var total = (single*room)*no_of_night;
		$('#s_total_rate'+id).val(total);

		var dvalue = parseInt($('#d_total_rate'+id).val());
		//$('#loc_total'+id).text(total+dvalue);
		var veh_grand_totalloc = get_veh_grand_total_byloc(id);
		var actotals = total+dvalue;
		$('#loc_total'+id).text(actotals+" + "+veh_grand_totalloc);
		var accom_grand_total = get_accom_grand_total();
		$('#a_total').text(accom_grand_total);

		var veh_grand_total = get_veh_grand_total();
		var g_total = parseInt(accom_grand_total) + parseInt(veh_grand_total);
		$('#g_total').text(g_total);
	}
	$(document).on('input', '[id^="no_of_night"]', function() {
		var id = this.id.match(/\d+/)[0];
		var no_of_nights = <?php echo $object_det[0]['no_of_night']; ?>;
		var totalNights  = calculateTotalNights(); 
		$('#planned_night').text(totalNights+" / ");
		if(totalNights == no_of_nights){ 
			$("#btn_save_tour_plan").show();
			$('#btn_add_bt').prop('disabled', true);
		}
		else{
			$("#btn_save_tour_plan").hide();
			$('#btn_add_bt').prop('disabled', false);
		}
		night_single_total_update(id);
	});
</script>

<script type="text/javascript">
    $(document).on('keyup', '.cls_daily', function(e) {
		var id = $(this).attr('data-id');
		var cid = $(this).attr('data-cid');

		var extra_kilometer = parseInt($('#extra_kilometer'+id).val());
		var extra_km_rate = parseInt($('#extra_km_rate'+id).val());
		var extra_cost = extra_kilometer*extra_km_rate;

		var day_rent = parseInt($('#day_rent'+id).val());
		var veh_count = parseInt($('#veh_count'+id).val());
		var no_of_night = parseInt($('#no_of_night'+cid).val());
		var total = (veh_count*day_rent)*no_of_night;
		$('#veh_total'+id).val(total+extra_cost);

		var veh_grand_total = get_veh_grand_total();
		veh_grand_total += parseFloat($('#extraklm_hidden').val()) || 0;
		$('#v_total').text(veh_grand_total);

		var accom_grand_total = get_accom_grand_total();
		var g_total = parseInt(accom_grand_total) + parseInt(veh_grand_total);
		$('#g_total').text(g_total);

		var veh_grand_totalloc = get_veh_grand_total_byloc(cid); 
		var accom_grand_totalloc = get_accom_grand_total_byloc(cid);
		$('#loc_total'+cid).text(accom_grand_totalloc+" + "+veh_grand_totalloc);

	});	
</script>
<script type="text/javascript">
    $(document).on('keyup', '.cls_dist', function(e) {
		var id = $(this).attr('data-id');
		var cid = $(this).attr('data-cid');
		var extra_klm = 0;
		var max_km_day = parseInt($('#max_km_day'+id).val());
		var travel_distance = parseInt($('#travel_distance'+id).val());
		if(travel_distance > max_km_day){
			extra_klm = travel_distance - max_km_day;
		}
		else{
			extra_klm = 0;
		}

		$('#extra_kilometer'+id).val(extra_klm);
		var extra_km_rate = parseInt($('#extra_km_rate'+id).val());
		var extra_cost = extra_klm*extra_km_rate;

		var day_rent = parseInt($('#day_rent'+id).val());
		var veh_count = parseInt($('#veh_count'+id).val());
		var no_of_night = parseInt($('#no_of_night'+cid).val());
		var total = (veh_count*day_rent)*no_of_night;
		$('#veh_total'+id).val(total+extra_cost);

		var veh_grand_total = get_veh_grand_total();
		veh_grand_total += parseFloat($('#extraklm_hidden').val()) || 0;
		$('#v_total').text(veh_grand_total);

		var accom_grand_total = get_accom_grand_total();
		var g_total = parseInt(accom_grand_total) + parseInt(veh_grand_total);
		$('#g_total').text(g_total);

		var veh_grand_totalloc = get_veh_grand_total_byloc(cid);
		var accom_grand_totalloc = get_accom_grand_total_byloc(cid);
		$('#loc_total'+cid).text(accom_grand_totalloc+" + "+veh_grand_totalloc);
	});	
</script>

<script>
$(document).on('change', '.mp_change', function() {
	var id = $(this).attr('data-id');
	var no_of_night = $('#no_of_night'+id)
    var room_cat_id = $('#roomcat'+id).val();
	var no_of_night = $('#no_of_night'+id).val();
	var hotel_id = $('#hotelid'+id).val();
	var mealplan = $(this).val();
	var checkin = $('#checkin'+id).val();
	var checkout = $('#checkout'+id).val();
	var double = $('#double'+id).val();
	var single = $('#single'+id).val();
	var vid;
	var veh_total = 0;
	var is_vehicle_required = <?php echo $object_det[0]['is_vehicle_required']; ?>;
	if(is_vehicle_required == 1){
		var vehicle_models = <?php echo json_encode($vehicle_data); ?>;
	}
	else{
		var vehicle_models = null;
	}
	if(no_of_night == '' || no_of_night == null || no_of_night == 'undefined'){
		alert("Please enter number of nights");
		$("#roomcat"+id)[0].selectedIndex = 0; 
	}
	else if(no_of_night == 0){
		alert("Number of nights must be greater than zero");
		$('#no_of_night'+id).val('');
	}
	else{
		$.ajax({
			url: "<?=site_url('Enquiry/getTourTariffDetails');?>",
			method: "POST",
			data: {
				hotel_id: hotel_id,
				room_cat_id:room_cat_id,
				mealplan:mealplan,
				checkin:checkin,
				checkout:checkout,
				no_of_night:no_of_night,
				double:double,
				single:single,
				vehicle_models:vehicle_models
			},
			dataType: 'json',
			success: function (data) {
				//if(data.length > 0){
					var no_of_ch = parseInt($('#no_of_ch'+id).val()) || 0;
					var no_of_cw = parseInt($('#no_of_cw'+id).val()) || 0;
					var no_of_extra = parseInt($('#no_of_extra'+id).val()) || 0;

					var ndouble = parseInt($('#double'+id).val());
					var nsingle = parseInt($('#single'+id).val());
					var room_r = parseInt(data.d_room_tariff);
					var child_r = parseInt(data.d_child_tariff);
					var child_wb_r = parseInt(data.d_child_wb_tariff);
					var extra_r = parseInt(data.d_extra_tariff);

					$('#d_adult_rate'+id).val(data.d_room_tariff);
					$('#d_child_rate'+id).val(data.d_child_tariff);
					$('#d_child_wb_rate'+id).val(data.d_child_wb_tariff);
					$('#d_extra_bed_rate'+id).val(data.d_extra_tariff);
					var total_double = ((ndouble*room_r) + (no_of_ch*child_r) + (no_of_cw*child_wb_r) + (no_of_extra*extra_r))*parseInt(no_of_night);
					$('#d_total_rate'+id).val(total_double);

					$('#s_adult_rate'+id).val(data.s_room_tariff);
					$('#s_child_rate'+id).val(data.s_child_tariff);
					$('#s_child_wb_rate'+id).val(data.s_child_wb_tariff);
					$('#s_extra_bed_rate'+id).val(data.s_extra_tariff);
					var total_single = (parseInt(data.s_room_tariff)*parseInt(nsingle))*parseInt(no_of_night);
					$('#s_total_rate'+id).val(total_single);
					$('#loc_total'+id).text(total_double + total_single);

					
					var veh_grand_tot = 0;
					if(data.vehicles.length > 0){
						$.each(data.vehicles, function (index, item) {
							vid = id+item.vehicle_type_id;
							veh_total = (parseInt(item.vehicle_count) * parseInt(item.rate_per_day))*parseInt(no_of_night);
							$('#day_rent'+vid).val(item.rate_per_day);
							$('#max_km_day'+vid).val(item.max_km_day);
							$('#extra_km_rate'+vid).val(item.extra_km_rate);
							$('#veh_total'+vid).val(veh_total);
							veh_grand_tot = veh_grand_tot + veh_total;
						});
					}
					var accom_temp = total_double + total_single;
					$('#loc_total'+id).text(accom_temp + " + " + veh_grand_tot);
					var accom_grand_total = get_accom_grand_total();
					$('#a_total').text(accom_grand_total);

					var veh_grand_total = get_veh_grand_total();
					veh_grand_total += parseFloat($('#extraklm_hidden').val()) || 0;
					$('#v_total').text(veh_grand_total);

					var g_total = parseInt(accom_grand_total) + parseInt(veh_grand_total);
					$('#g_total').text(g_total);
				//}
			}
		});
	}
});
</script>
<script>
$(document).on('click', '.save_location', function() {
    var vehicle_models = <?php echo json_encode($vehicle_data); ?>;
	var no_of_double_room = <?php echo $object_det[0]['no_of_double_room']; ?>;
	var is_quick_quote = <?php echo $object_det[0]['is_quick_quote']?$object_det[0]['is_quick_quote']:0; ?>;
	var no_of_single_room = <?php echo $object_det[0]['no_of_single_room']; ?>;
	var enquiry_header_id = <?php echo $object_det[0]['enquiry_header_id']; ?>;
	var enquiry_details_id = <?php echo $object_det[0]['enquiry_details_id']; ?>;
	var id = $(this).attr('data-id');
  
						var pre_tour_location = $('#tour_location_id'+id).val();
						var pre_no_of_night = $('#no_of_night'+id).val();
						var pre_checkin = $('#checkin'+id).val();
						var pre_checkout = $('#checkout'+id).val();
						var pre_hotelid = $('#hotelid'+id).val();
						var pre_roomcat = $('#roomcat'+id).val();

						var pre_d_adult_rate = $('#d_adult_rate'+id).val();
						var pre_s_adult_rate = $('#s_adult_rate'+id).val();
						var pre_d_child_rate = $('#d_child_rate'+id).val();
						var pre_s_child_rate = $('#s_child_rate'+id).val();
						var pre_d_child_wb_rate = $('#d_child_wb_rate'+id).val();
						var pre_s_child_wb_rate = $('#s_child_wb_rate'+id).val();
						var pre_d_extra_bed_rate = $('#d_extra_bed_rate'+id).val();
						var pre_s_extra_bed_rate = $('#s_extra_bed_rate'+id).val();

						var pre_room_type = [
							{ "double": no_of_double_room, "single": no_of_single_room }
						];
						var pre_vehicle_details = [];
						$.each(vehicle_models, function (veh_index, veh_model) {
							var vid = id + veh_model.vehicle_type_id;
							var pre_veh_model = $('#veh_model'+vid).val();
							var pre_veh_count = $('#veh_count'+vid).val();
							var pre_day_rent = $('#day_rent'+vid).val();
							var pre_max_km_day = $('#max_km_day'+vid).val();
							var pre_extra_km_rate = $('#extra_km_rate'+vid).val();
							var pre_veh_total = $('#veh_total'+vid).val();
							pre_vehicle_details.push({
								"day_rent": pre_day_rent,
								"veh_total": pre_veh_total,
								"vehicle_count": pre_veh_count,
								"vehicle_model": pre_veh_model
							});
						});

						$.ajax({
							url: '<?=site_url('Enquiry/saveTourLocation');?>',
							type: 'POST',
							data: {
								enquiry_header_id: enquiry_header_id,
								enquiry_details_id: enquiry_details_id,
								tour_location: pre_tour_location,
								no_of_days: pre_no_of_night,
								check_in_date: pre_checkin,
								check_out_date: pre_checkout,
								hotel_id: pre_hotelid,
								room_category_id: pre_roomcat,
								room_type: pre_room_type,
								vehicle_details: pre_vehicle_details,
								location_sequence:id,

								d_adult_rate:pre_d_adult_rate,
								s_adult_rate:pre_s_adult_rate,
								d_child_rate:pre_d_child_rate,
								s_child_rate:pre_s_child_rate,
								d_child_wb_rate:pre_d_child_wb_rate,
								s_child_wb_rate:pre_s_child_wb_rate,
								d_extra_bed_rate:pre_d_extra_bed_rate,
								s_extra_bed_rate:pre_s_extra_bed_rate,
								is_quick_quote:is_quick_quote,

								is_active: 1,
								is_draft: 1,
								enterprise_id: 1
							},
							dataType: 'json',
							success: function (data) {
								alert("updated");
							},
							error: function (xhr, status, error) {
								console.error(error);
							}
						});
    
});
</script>
<script>
$(document).on('click', '.draft_view', function() {
    var enquiry_header_id = <?php echo $object_det[0]['enquiry_header_id']; ?>;
    var enquiry_details_id = <?php echo $object_det[0]['enquiry_details_id']; ?>;
    var hotel_categories = <?php echo json_encode($hotel_categories); ?>;
	var hotel_category_exist = <?php echo $object_det[0]['hotel_category']; ?>;
	var meal_plan_exist = <?php echo $object_det[0]['meal_plan']; ?>;
	var no_of_night = <?php echo $object_det[0]['no_of_night']; ?>;
	var total_no_of_pax = <?php echo $object_det[0]['total_no_of_pax']; ?>;
	var enquiry_header_id = <?php echo $object_det[0]['enquiry_header_id']; ?>;
	var enquiry_details_id = <?php echo $object_det[0]['enquiry_details_id']; ?>;
	var no_of_adult = <?php echo $object_det[0]['no_of_adult']; ?>;
	var no_of_child_with_bed = <?php echo $object_det[0]['no_of_child_with_bed']; ?>;
	var no_of_child_without_bed = <?php echo $object_det[0]['no_of_child_without_bed']; ?>;
	var no_of_double_room = <?php echo $object_det[0]['no_of_double_room']; ?>;
	var no_of_single_room = <?php echo $object_det[0]['no_of_single_room']; ?>;
	var no_of_extra_bed = <?php echo $object_det[0]['no_of_extra_bed']; ?>;
	var is_vehicle_required = <?php echo $object_det[0]['is_vehicle_required']; ?>;
	var is_quick_quote = <?php echo $object_det[0]['is_quick_quote']?$object_det[0]['is_quick_quote']:0; ?>;
	var vehicle_models = <?php echo json_encode($vehicle_data); ?>;

	var child_t_d = 0;
	var child_t_s = 0;

	var child_wb_t_d = 0;
	var child_wb_t_s = 0;

	var extra_t_d = 0;
	var extra_t_s = 0;

	var room_t_d = 0;
	var room_t_s = 0;

    var start_date = <?= json_encode($start_date); ?>;
    var totalDays = 0;
	
	var vid_t;
	var v_day_rent;
	var v_max_km_day;
	var v_extra_km_rate;
	var v_veh_total;	
	var v_veh_header;
	var plus = " + ";
	$('#btn_add_bt').prop('disabled', false);
    $.ajax({
        url: '<?=site_url('Enquiry/loadTourLocation');?>',
        type: 'POST',
        data: {
            enquiry_header_id: enquiry_header_id,
            enquiry_details_id: enquiry_details_id
        },
        dataType: 'json',
        success: function (response) {
            // Clear existing location cards if necessary
            $('.tour_plan_div').empty();
			var newCard = ``;
			var breadcrumb = ``;
            $.each(response, function (index, item) {
                // Create a new location card element
				var vehicleDetails = JSON.parse(item.vehicle_details);
				var count = index+1;
				if(count > 0){
						//$("#btn_save_tour_plan").show();
						$("#btn_savedraft_tour_plan").show();
					}
					else{
						//$("#btn_save_tour_plan").hide();
						$("#btn_savedraft_tour_plan").hide();
					}
					var isFirst = count === 1;
					var prevCheckout = $('.tour_plan_div .location-card:last input[name^="addloc["][name$="[checkout]"]').val();
					var checkinDate = isFirst ? start_date : prevCheckout || '';
					ep_sel = '';
					cp_sel = '';
					map_sel = '';
					ap_sel = '';
					if(item.meal_plan_id == 1){
						ep_sel = "selected";
					}
					if(item.meal_plan_id == 2){
						cp_sel = "selected";
					}
					if(item.meal_plan_id == 3){
						map_sel = "selected";
					}
					if(item.meal_plan_id == 4){
						ap_sel = "selected";
					}

					$.each(item.cost, function (index1, item3) {
						var vtots = 0;
						if((item3.cost_component_id == "6" || item3.cost_component_id == "7") && item3.room_type_id == "2"){
							room_t_d = item3.quick_quote_tariff;
						}
						if((item3.cost_component_id == "12" || item3.cost_component_id == "13") && item3.room_type_id == "2"){
							child_t_d = item3.quick_quote_tariff;
						}
						if((item3.cost_component_id == "15" || item3.cost_component_id == "16") && item3.room_type_id == "2"){
							child_wb_t_d = item3.quick_quote_tariff;
						}
						if((item3.cost_component_id == "9" || item3.cost_component_id == "10") && item3.room_type_id == "2"){
							extra_t_d = item3.quick_quote_tariff;
						}
						if((item3.cost_component_id == "6" || item3.cost_component_id == "7") && item3.room_type_id == "1"){
							room_t_s = item3.quick_quote_tariff;
						}
						if((item3.cost_component_id == "12" || item3.cost_component_id == "13") && item3.room_type_id == "1"){
							child_t_s = item3.quick_quote_tariff;
						}
						if((item3.cost_component_id == "15" || item3.cost_component_id == "16") && item3.room_type_id == "1"){
							child_wb_t_s = item3.quick_quote_tariff;
						}
						if((item3.cost_component_id == "9" || item3.cost_component_id == "10") && item3.room_type_id == "1"){
							extra_t_s = item3.quick_quote_tariff;
						}
					});	
					var room_total = parseInt(no_of_double_room)*parseInt(room_t_d);
					var child_total = parseInt(no_of_child_with_bed)*parseInt(child_t_d);
					var child_wb_total = parseInt(no_of_child_without_bed)*parseInt(child_wb_t_d);
					var extra_total = parseInt(no_of_extra_bed)*parseInt(extra_t_d);
					var d_totals = (room_total + child_total + child_wb_total + extra_total)*parseInt(item.no_of_days);
					var s_totals = (parseInt(no_of_single_room)*parseInt(room_t_s))*parseInt(item.no_of_days);
                newCard += `
					
						<div class="col-md-12 col-lg-12 col-xl-12 location-card" data-index="${count}">
							<div class="card">
								<div class="card-header" style="background-color:#c2d6d6;">
									<input type="hidden" id="own_arrange${count}" name="addloc[${count}][own_arrange]" value="${item.is_own_arrangement}">
									<input type="hidden" id="tour_location_id${count}" name="addloc[${count}][tour_location_id]" value="${item.tour_location}">
									<input type="hidden" id="location_sequence${count}" name="addloc[${count}][location_sequence]" value="${count}">
									<div class="card-title"><span class="card-seq" style="color:#339966;">${count}</span>. <span style="color:#339966;">${item.geog_name}</span></div>
									<div class="card-options">
										<a href="#" class="card-options-remove"><i class="fe fe-x"></i></a>
									</div>
								</div>
								<div class="card-body">
									<div class="ibox teams mb-30 bg-boxshadow">
										<div class="ibox-content teams">
											<div class="row mt-2">
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Checkin</b></div>
													<span class="text-muted">
														<input type="date" value="${item.check_in_date}" id="checkin${count}" name="addloc[${count}][checkin]" class="form-control input-sm" required readonly>
													</span>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Nights</b></div>
													<span class="text-muted">
														<input type="text" id="no_of_night${count}" name="addloc[${count}][no_of_night]" value="${item.no_of_days}" class="form-control input-sm no_of_night" maxlength="2" oninput="validateNumericInput(this); calculateCheckout(${count});" required>
													</span>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Checkout</b></div>
													<span class="text-muted">
														<input type="date" id="checkout${count}" value="${item.check_out_date}" name="addloc[${count}][checkout]" class="form-control input-sm" required readonly>
													</span>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Hotel Category</b></div>
														<select id="hotelcat${count}" name="addloc[${count}][hotelcat]" class="form-control select2-show-search input-sm hotel_cat_change_draft" data-id="${count}" data-hid="${item.hotel_id}" required>
														<option value="">Select</option>
														</select>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Hotel</b></div>
													<span class="text-muted">
														<select id="hotelid${count}" name="addloc[${count}][hotelid]" class="form-control select2-show-search input-sm hotel_change_draft" data-rid="${item.room_category_id}" data-id="${count}" required>
														<option value="">Select</option>
														</select>
													</span>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Room Category</b></div>
														<select id="roomcat${count}" name="addloc[${count}][roomcat]" class="form-control select2-show-search input-sm" data-id="${count}" required>
														<option value="">Select</option>
														</select>
												</div>
											</div>

										
											<div class="row mt-2">
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Meal Plan</b></div>
													<span class="text-muted">
														<select id="mealplan${count}" name="addloc[${count}][mealplan]" class="form-control select2-show-search input-sm mp_change" data-id="${count}" required>
														<option value="">Select</option>
														<option value="1" ${ep_sel}>EP</option>
														<option value="2" ${cp_sel}>CP</option>
														<option value="3" ${map_sel}>MAP</option>
														<option value="4" ${ap_sel}>AP</option>
														</select>
													</span>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>No Of Adult</b></div>
													<input type="text" id="no_of_adult${count}" name="addloc[${count}][no_of_adult]" value="${no_of_adult}" class="form-control input-sm" maxlength="2" oninput="validateNumericInput(this);" readonly>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>C.With Bed Qty</b></div>
													<input type="text" id="no_of_ch${count}" name="addloc[${count}][no_of_ch]" value="${no_of_child_with_bed}" class="form-control input-sm" maxlength="2" oninput="validateNumericInput(this);" readonly>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>C.Without Bed Qty</b></div>
													<input type="text" id="no_of_cw${count}" name="addloc[${count}][no_of_cw]" value="${no_of_child_without_bed}" class="form-control input-sm" maxlength="2" oninput="validateNumericInput(this);" readonly>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Extra Bed Qty</b></div>
													<input type="text" id="no_of_extra${count}" name="addloc[${count}][no_of_extra]" value="${no_of_extra_bed}" class="form-control input-sm" maxlength="2" oninput="validateNumericInput(this);" readonly>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Total Pax</b></div>
													<input type="text" id="no_of_pax${count}" name="addloc[${count}][no_of_pax]" value="${total_no_of_pax}" class="form-control input-sm" maxlength="3" oninput="validateNumericInput(this);" readonly>
												</div>
												
											</div>`;
                                            if(no_of_double_room > 0) {
											
												newCard += `<div class="row mt-2 double_row">
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Double Room</b></div>
														<input type="text" id="double${count}" name="addloc[${count}][double]" value="${no_of_double_room}" class="form-control input-sm" maxlength="2" oninput="validateNumericInput(this);" readonly>
													</div>
										
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Daily Room Rate</b></div>
														<input type="text" id="d_adult_rate${count}" name="addloc[${count}][d_adult_rate]" value="${room_t_d}" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" required>
													</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>C.With Bed Rate</b></div>
														<input type="text" id="d_child_rate${count}" name="addloc[${count}][d_child_rate]" value="${child_t_d}" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);">
													</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>C.Without Bed Rate</b></div>
														<input type="text" id="d_child_wb_rate${count}" name="addloc[${count}][d_child_wb_rate]" value="${child_wb_t_d}" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);">
													</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Extra Bed Rate</b></div>
														<input type="text" id="d_extra_bed_rate${count}" name="addloc[${count}][d_extra_bed_rate]" value="${extra_t_d}" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);">
													</div>
														<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Total</b></div>
														<input type="text" id="d_total_rate${count}" name="addloc[${count}][d_total_rate]" value="${d_totals}" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" readonly>
													</div>
													
												</div>`;
											}
											else{
												newCard += `<input type="hidden" id="double${count}" name="addloc[${count}][double]" value="0">
															<input type="hidden" id="d_adult_rate${count}" name="addloc[${count}][d_adult_rate]" value="0">
															<input type="hidden" id="d_child_rate${count}" name="addloc[${count}][d_child_rate]" value="0">
															<input type="hidden" id="d_child_wb_rate${count}" name="addloc[${count}][d_child_wb_rate]" value="0">
															<input type="hidden" id="d_extra_bed_rate${count}" name="addloc[${count}][d_extra_bed_rate]" value="0">
															<input type="hidden" id="d_total_rate${count}" name="addloc[${count}][d_total_rate]" value="0">`;
											}
											if(no_of_single_room > 0) {
											newCard += `<div class="row mt-2 single_row">
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Single Room</b></div>
													<input type="text" id="single${count}" name="addloc[${count}][single]" value="${no_of_single_room}" class="form-control input-sm" maxlength="2" oninput="validateNumericInput(this);" readonly>
												</div>
									
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Daily Room Rate</b></div>
													<input type="text" id="s_adult_rate${count}" name="addloc[${count}][s_adult_rate]" value="${room_t_s}" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);">
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>C.With Bed Rate</b></div>
													<input type="text" id="s_child_rate${count}" name="addloc[${count}][s_child_rate]" value="${child_t_s}" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" readonly>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>C.Without Bed Rate</b></div>
													<input type="text" id="s_child_wb_rate${count}" name="addloc[${count}][s_child_wb_rate]" value="${child_wb_t_s}" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" readonly>
												</div>
												<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Extra Bed Rate</b></div>
													<input type="text" id="s_extra_bed_rate${count}" name="addloc[${count}][s_extra_bed_rate]" value="${extra_t_s}" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" readonly>
												</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
													<div class="teams-rank"><b>Total</b></div>
													<input type="text" id="s_total_rate${count}" name="addloc[${count}][s_total_rate]" value="${s_totals}" class="form-control input-sm" maxlength="6" oninput="validateNumericInput(this);" readonly>
												</div>
												
											</div>`;
											}
											else{
												newCard += `<input type="hidden" id="single${count}" name="addloc[${count}][single]" value="0">
															<input type="hidden" id="s_adult_rate${count}" name="addloc[${count}][s_adult_rate]" value="0">
															<input type="hidden" id="s_child_rate${count}" name="addloc[${count}][s_child_rate]" value="0">
															<input type="hidden" id="s_child_wb_rate${count}" name="addloc[${count}][s_child_wb_rate]" value="0">
															<input type="hidden" id="s_extra_bed_rate${count}" name="addloc[${count}][s_extra_bed_rate]" value="0">
															<input type="hidden" id="s_total_rate${count}" name="addloc[${count}][s_total_rate]" value="0">`;
											}
											if(is_vehicle_required == 1) {
												vtots = 0;
												$.each(vehicle_models, function (vindex, vmodel) {
													
													$.each(vehicleDetails, function (v_index, v_item) {
														if(vmodel.vehicle_type_id == v_item.veh_type_id){
															vid_t = count + vmodel.vehicle_type_id;
															v_day_rent = v_item.day_rent;
															v_max_km_day = v_item.max_km_day;
															v_travel_distance = v_item.travel_distance;
															v_extra_kilometer = v_item.extra_kilometer;
															v_extra_km_rate = v_item.extra_km_rate;
															v_veh_total = v_item.veh_total;
															v_veh_header = v_item.veh_header;
															vtots = parseInt(vtots) + parseInt(v_veh_total);
														}
													});
													if(vindex == 0){
													newCard += `
													<div class="row mt-2">
														<div class="col-xl-1 col-sm-12 col-md-1">
														<a id="loadvehs${count}" class="nav-link load_vehs_click" data-id="${count}"><i class="fa fa-refresh"></i></a>
														</div>
														<div class="col-xl-11 col-sm-12 col-md-11"><h5 style="color:#003300;">Vehicle Details<span id="v_from_to${count}">${v_veh_header}</span></h5>
														</div>
													</div>
												
												<input type="hidden" id="veh_header${count}" name="addloc[${count}][veh_header]" value="${v_veh_header}">
												<div class="row mt-2 single_row">
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Vehicle Model</b></div>
												    </div>		
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Vehicle Count</b></div>
													</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Daily Rent</b></div>
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Max KM/Day</b></div>
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Distance</b></div>
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Extra KM</b></div>
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Extra KM Rate</b></div>
													</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
														<div class="teams-rank"><b>Total</b></div>
													</div>
												</div>
														`;
													}
												vid = count + vmodel.vehicle_type_id;
												newCard += `<div class="row mt-2 single_row">
													<div class="col-xl-2 col-sm-12 col-md-2">
														
														<input type="text" id="veh_model${vid}" name="addloc[${count}][veh_model][${vindex}]" value="${vmodel.vehicle_model_name}" class="form-control input-sm veh_model${vindex}" readonly>
														<input type="hidden" id="veh_type_id${vid}" name="addloc[${count}][veh_type_id][${vindex}]" value="${vmodel.vehicle_type_id}" class="form-control input-sm veh_type_id${vindex}">
													</div>
										
													<div class="col-xl-2 col-sm-12 col-md-2">
														
														<input type="text" id="veh_count${vid}" name="addloc[${count}][veh_count][${vindex}]" value="${vmodel.vehicle_count}" class="form-control input-sm veh_count${vindex}" maxlength="2" oninput="validateNumericInput(this);" readonly>
													</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
													
														<input type="text" id="day_rent${vid}" name="addloc[${count}][day_rent][${vindex}]" value="${v_day_rent}" class="form-control input-sm cls_daily day_rent${vindex}" data-id="${vid}" data-cid="${count}" maxlength="5" oninput="validateNumericInput(this);">
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
													
														<input type="text" id="max_km_day${vid}" name="addloc[${count}][max_km_day][${vindex}]" value="${v_max_km_day}" class="form-control input-sm max_km_day${vindex}" maxlength="5" oninput="validateNumericInput(this);" readonly>
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
													
														<input type="text" id="travel_distance${vid}" name="addloc[${count}][travel_distance][${vindex}]" value="${v_travel_distance}" class="form-control input-sm cls_dist travel_distance${vindex}" data-id="${vid}" data-cid="${count}" maxlength="5" oninput="validateNumericInput(this);">
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
													
														<input type="text" id="extra_kilometer${vid}" name="addloc[${count}][extra_kilometer][${vindex}]" value="${v_extra_kilometer}" class="form-control input-sm extra_kilometer${vindex}" maxlength="5" oninput="validateNumericInput(this);" readonly>
													</div>
													<div class="col-xl-1 col-sm-12 col-md-2">
														
														<input type="text" id="extra_km_rate${vid}" name="addloc[${count}][extra_km_rate][${vindex}]" value="${v_extra_km_rate}" class="form-control input-sm extra_km_rate${vindex}" maxlength="5" oninput="validateNumericInput(this);" readonly>
													</div>
													<div class="col-xl-2 col-sm-12 col-md-2">
														
														<input type="text" id="veh_total${vid}" name="addloc[${count}][veh_total][${vindex}]" value="${v_veh_total}" class="form-control input-sm veh_total${vindex}" maxlength="5" oninput="validateNumericInput(this);"readonly>
													</div>
													
												</div>`;
												
												});
											}
											else{
												newCard += `<input type="hidden" id="veh_model${count}0" name="addloc[${count}][veh_model][0]" value="">
															<input type="hidden" id="veh_count${count}0" name="addloc[${count}][veh_count][0]" value="0">
															<input type="hidden" id="day_rent${count}0" name="addloc[${count}][day_rent][0]" value="0">
															<input type="hidden" id="max_km_day${count}0" name="addloc[${count}][max_km_day][0]" value="0">
															<input type="hidden" id="extra_km_rate${count}0" name="addloc[${count}][extra_km_rate][0]" value="0">
															<input type="hidden" id="veh_total${count}0" name="addloc[${count}][veh_total][0]" value="0">`;
											}
											newCard += `
											
										</div>
									</div>
								</div>
							</div>
						</div>
						
					`;		
					
					breadcrumb += `
					    
						<li class="bc-card" data-index="${count}">
							<a>
								<span class="bc-card-seq" style="color:#fff">${count}</span>.<span style="color:#fff">${item.geog_name}(<span id="span_night_id${count}" style="color:#fff">${item.no_of_days}</span>)<span id="loc_total${count}" style="color:#fff">${d_totals + s_totals} ${plus} ${vtots}</span></span>
							</a>
						</li>
					`;
                  
					$('.dyn_list').html(breadcrumb);

					setTimeout(function() {
						var hotelCat = $('#hotelcat' + count);
						console.log("Dropdown found?", hotelCat.length);

						if (hotelCat.length > 0) {
							hotelCat.empty();
							hotelCat.append('<option value="">Select</option>');

							$.each(hotel_categories, function (hIndex, hotelcat) {
								var selected = (hotelcat.hotel_category_id == item.hot_cat_id) ? "selected" : "";
								hotelCat.append('<option value="' + hotelcat.hotel_category_id + '" ' + selected + '>' + hotelcat.hotel_category_name + '</option>');
							});

							hotelCat.trigger('change');
						} else {
							console.log("Dropdown not found. Ensure it exists before updating.");
						}
					}, 500); 	
            });
			$(".tour_plan_div").append(newCard);

			var totalNights  = calculateTotalNights();
			if(totalNights == no_of_night){ 
				$("#btn_save_tour_plan").show();
				$('#btn_add_bt').prop('disabled', true);
			}
			else{
				$("#btn_save_tour_plan").hide();
				$('#btn_add_bt').prop('disabled', false);
			}
			
            updateSequenceNumbers();
        },
        error: function (xhr, status, error) {
            console.error(error);
        }
    });
});
</script>

<script>
	function get_accom_grand_total() {
		var grand_tot = 0;
		$('.tour_plan_div .location-card').each(function (index) {
			let id = index + 1;
			
			var double_value = parseInt($('#d_total_rate'+id).val());
			var single_value = parseInt($('#s_total_rate'+id).val());
			grand_tot = grand_tot + double_value + single_value;
			
		});
		return grand_tot;
	}
</script>
<script>
	function get_veh_grand_total() {
		var grand_tot = 0;
		var vehicle_models = <?php echo json_encode($vehicle_data); ?>;
		var vid;
		var id;
		var grand_tot = 0;
		var vsum;
		$('.tour_plan_div .location-card').each(function (index) {
			id = index + 1;
			vsum = 0;
			$.each(vehicle_models, function (veh_index, veh_model) {
				vid = id + veh_model.vehicle_type_id;
				vsum = vsum + parseInt($('#veh_total'+vid).val());
			});
			grand_tot = grand_tot + vsum;
		});
		return grand_tot;
	}

function get_veh_grand_total_byloc(idt){
	var grand_tot = 0;
		var vehicle_models = <?php echo json_encode($vehicle_data); ?>;
		var vid;
		var id;
		var grand_tot = 0;
		var vsum;
		$('.tour_plan_div .location-card').each(function (index) {
			id = index + 1;
			if(id == idt){
				vsum = 0;
				$.each(vehicle_models, function (veh_index, veh_model) {
					vid = id + veh_model.vehicle_type_id;
					vsum = vsum + parseInt($('#veh_total'+vid).val());
				});
				grand_tot = grand_tot + vsum;
			}
		});
		return grand_tot;
}

function get_accom_grand_total_byloc(idt){
	var grand_tot = 0;
		$('.tour_plan_div .location-card').each(function (index) {
			let id = index + 1;
			if(id == idt){
				var double_value = parseInt($('#d_total_rate'+id).val());
				var single_value = parseInt($('#s_total_rate'+id).val());
				grand_tot = grand_tot + double_value + single_value;
			}
			
		});
		return grand_tot;
}
</script>

<script>
$(document).on('click', '.load_vehs_click', function() {
	var id = $(this).attr('data-id');
	var no_of_night = $('#no_of_night'+id).val();
	var checkin = $('#checkin'+id).val();
	var checkout = $('#checkout'+id).val();
	var vehicle_from_location = <?php echo $object_det[0]['vehicle_from_location']; ?>;
	var arrival_location = <?php echo $object_det[0]['arrival_location']; ?>;
	var departure_location = <?php echo $object_det[0]['departure_location']; ?>;
	var tour_location_id = $('#tour_location_id'+id).val();
	if(id > 1){
		var pid = parseInt(id)-1;
		var previous_location_id = $('#tour_location_id'+pid).val();
	}
	else{
		var previous_location_id = null;
	}
	var duration = <?php echo $object_det[0]['no_of_night']; ?>;
	var totalNights  = calculateTotalNights();
	var vid;
	var veh_total = 0;
	var extra_klm = 0;
	var extra_cost = 0;
	var veh_totals = 0;
	var is_vehicle_required = <?php echo $object_det[0]['is_vehicle_required']; ?>;
	if(is_vehicle_required == 1){
		var vehicle_models = <?php echo json_encode($vehicle_data); ?>;
	}
	else{
		var vehicle_models = null;
	}
	if(no_of_night == '' || no_of_night == null || no_of_night == 'undefined'){
		alert("Please enter number of nights");
		$("#roomcat"+id)[0].selectedIndex = 0; 
	}
	else if(no_of_night == 0){
		alert("Number of nights must be greater than zero");
		$('#no_of_night'+id).val('');
	}
	else{
		$.ajax({
			url: "<?=site_url('Enquiry/getVehicleTariffDetails');?>",
			method: "POST",
			data: {
				no_of_night:no_of_night,
				vehicle_models:vehicle_models,
				id:id,
				duration:duration,
				totalNights:totalNights,
				tour_location_id:tour_location_id,
				vehicle_from_location:vehicle_from_location,
				arrival_location:arrival_location,
				departure_location:departure_location,
				checkin:checkin,
				checkout:checkout,
				previous_location_id:previous_location_id
			},
			dataType: 'json',
			success: function (data) { console.log(data);
				//if(data.length > 0){
					var total_double = parseInt($('#d_total_rate'+id).val());
					var total_single = parseInt($('#s_total_rate'+id).val());
                    
					if(data.distance_type == 1){
						var v_from_to_data = " - (Hub Location to Arrival - "+data.dist1+" KM, Arrival to Location - "+data.dist2+" KM, Location to Departure - "+data.dist3+" KM, Departure to Hub Location - "+data.dist4+ "KM)";
						$('#v_from_to'+id).html(v_from_to_data);
						$('#veh_header'+id).val(v_from_to_data);
					}
					else if(data.distance_type == 2){
						var v_from_to_data = " - (Hub Location to Arrival - "+data.dist1+" KM, Arrival to Location - "+data.dist2+" KM)";
						$('#v_from_to'+id).html(v_from_to_data);
						$('#veh_header'+id).val(v_from_to_data);
					}
					else if(data.distance_type == 3){
						var v_from_to_data = " - (Location to Departure - "+data.dist1+" KM, Departure to Hub Location - "+data.dist2+ "KM)";
						$('#v_from_to'+id).html(v_from_to_data);
						$('#veh_header'+id).val(v_from_to_data);
					}
					else{
						var v_from_to_data = " - (Previous Location to Current Location - "+data.total_distance+" KM)";
						$('#v_from_to'+id).html(v_from_to_data);
						$('#veh_header'+id).val(v_from_to_data);
					}
					var veh_grand_tot = 0;
					if(data.vehicles.length > 0){
						
						$.each(data.vehicles, function (index, item) { 
							if (parseInt(data.total_distance, 10) > parseInt(item.max_km_day, 10)) {
								extra_klm = parseInt(data.total_distance) - parseInt(item.max_km_day);
							}
							else{
								extra_klm = 0;
							} 
							extra_cost = parseInt(extra_klm)*parseInt(item.extra_km_rate);
							vid = id+item.vehicle_type_id;
							veh_totals = (parseInt(item.vehicle_count) * parseInt(item.rate_per_day))*parseInt(no_of_night);
							veh_total = veh_totals + parseInt(extra_cost);
							$('#day_rent'+vid).val(item.rate_per_day);
							$('#max_km_day'+vid).val(item.max_km_day);
							$('#extra_km_rate'+vid).val(item.extra_km_rate);
							$('#veh_total'+vid).val(veh_total);
							$('#travel_distance'+vid).val(data.total_distance);
							$('#extra_kilometer'+vid).val(extra_klm);
							veh_grand_tot = veh_grand_tot + veh_total;
						});
					}
					var accom_temp = total_double + total_single;
					$('#loc_total'+id).text(accom_temp + " + " + veh_grand_tot);
					var veh_grand_total = get_veh_grand_total();
					veh_grand_total += parseFloat($('#extraklm_hidden').val()) || 0;
					$('#v_total').text(veh_grand_total);
					var accom_grand_total = get_accom_grand_total();
					$('#a_total').text(accom_grand_total);
					var g_total = parseInt(accom_grand_total) + parseInt(veh_grand_total);
					$('#g_total').text(g_total);
				//}
			}
		});
	}
});
</script>

<script>
$(document).on('change', '.hotel_fac_change', function() {
    var facility_id = $(this).val();
	var id = $(this).attr('data-id');
	
    $.ajax({
        url: "<?=site_url('Enquiry/getHotelFacilityTariff');?>",
        method: "POST",
        data: {
            facility_id: facility_id
        },
		dataType: 'json',
        success: function (data) {
			if(data.length > 0){
            	$('#fac_rate'+id).val(data[0].tariff);
			}
			else{
				$('#fac_rate'+id).val(0);
			}
        }
    });
    
});
</script>

<script>
$(document).on('change', '.ss_change', function() {
    var sight_seeing_id = $(this).val();
	var id = $(this).attr('data-id');
	if(sight_seeing_id == null || sight_seeing_id == '' || sight_seeing_id=='undefined'){
		$('#ss_distance' + id).val(0);
		$('#ss_distance' + id).prop('readonly', true);
	}
	else{
		$('#ss_distance' + id).prop('readonly', false);
	}

    $.ajax({
        url: "<?=site_url('Enquiry/getSightSeeingTariff');?>",
        method: "POST",
        data: {
            sight_seeing_id: sight_seeing_id
        },
		dataType: 'json',
        success: function (data) {
			if(data == 0){
				var ss_distance = 0;
			}
			else{
            	var ss_distance = parseInt(data[0].sightseeing_distance) || 0;
			}
            $('#ss_distance' + id).val(ss_distance);

			$(`input[id^='travel_distance${id}']`).each(function () {
                var $travelInput = $(this);
                var travelId = $travelInput.attr('id');
                var baseDistance = parseFloat($travelInput.data('base') || 0);
                var newDistance = baseDistance + ss_distance;
                $travelInput.val(newDistance);

                // Extract the unique vid from travel_distance input ID
                var vid = travelId.replace('travel_distance', '');

                // Fetch other values
                var maxKm = parseFloat($('#max_km_day' + vid).val()) || 0;
                var extraKmRate = parseFloat($('#extra_km_rate' + vid).val()) || 0;
                var dayRent = parseFloat($('#day_rent' + vid).val()) || 0;

                // Calculate extra km
                var extraKm = Math.max(newDistance - maxKm, 0);
                $('#extra_kilometer' + vid).val(extraKm);

                // Calculate total
                var vehTotal = dayRent + (extraKm * extraKmRate);
                $('#veh_total' + vid).val(vehTotal.toFixed(2));
            });
        }
    });
    
});
</script>
<script>
	$(document).on('input', 'input[id^="ss_distance"]', function () {
    var $ssInput = $(this);
    var id = $ssInput.attr('id').replace('ss_distance', '');
    var ss_distance = parseFloat($ssInput.val()) || 0;

    // Loop through related travel_distance inputs
    $(`input[id^='travel_distance${id}']`).each(function () {
		var itinerary_details_draft = <?= json_encode($itinerary_details_draft); ?>;
        var $travelInput = $(this);
        var travelId = $travelInput.attr('id');
        var vid = travelId.replace('travel_distance', '');

        // Get base travel distance
        var baseDistance = parseFloat($travelInput.data('base') || 0);

        // New travel distance
        var travelDistance = baseDistance + ss_distance;
		if ($.isArray(itinerary_details_draft) && itinerary_details_draft.length > 0) {
			$travelInput.val(baseDistance);
		}
		else{
			$travelInput.val(travelDistance);
		}
        //$travelInput.val(travelDistance);

        // Fetch other values
        var maxKm = parseFloat($('#max_km_day' + vid).val()) || 0;
        var extraKmRate = parseFloat($('#extra_km_rate' + vid).val()) || 0;
        var dayRent = parseFloat($('#day_rent' + vid).val()) || 0;

        // Calculate extra kilometers
        var extraKm = Math.max(travelDistance - maxKm, 0);
        $('#extra_kilometer' + vid).val(extraKm);

        // Calculate total vehicle cost
        var vehTotal = dayRent + (extraKm * extraKmRate);
        $('#veh_total' + vid).val(vehTotal.toFixed(2));
    });
});
</script>
<script>
$(document).ready(function () {
    // Define a reusable function
    function toggleVehicleFields(checkbox) {
        var isChecked = $(checkbox).is(':checked');
        var vid = $(checkbox).val();

        const fields = [
            '#veh_model' + vid,
            '#day_rent' + vid,
            '#max_km_day' + vid,
            '#travel_distance' + vid,
            '#extra_kilometer' + vid,
            '#extra_km_rate' + vid,
            '#veh_total' + vid
        ];

        fields.forEach(function (selector) {
            $(selector).prop('disabled', !isChecked);
            $(selector).css('background-color', isChecked ? '#ffffff' : '#669999');
        });

	
    }

    // Trigger on checkbox change
    $(document).on('change', '.chk_vehicle', function () {
        toggleVehicleFields(this);
    });

    // Call once on document ready for all .chk_vehicle checkboxes
		var itinerary_details_draft = <?php echo json_encode($itinerary_details_draft); ?>;
		if(Array.isArray(itinerary_details_draft) && itinerary_details_draft.length > 0){
			$('.chk_vehicle').each(function () {
				toggleVehicleFields(this);
				var vid = $(this).attr('data-id');
				setTimeout(() => calculateGrandTotal(vid), 300);
			});
			$('input[id^="ss_distance"]').trigger('input');
			//$('.ss_change').trigger('change');
		}
});
</script>
<script>

function updateTotalAccommodationCost() {
	setTimeout(function () {
    let totalAccommodationCost = 0;
	let totalTransportationCost = 0;
	let specialEventTotal = 0;
	let dailyAddonTotal = 0;
	let totalNetRate = 0;

    // Sum all visible and hidden fac_rate inputs
    $('input[id^="fac_rate"]').each(function () {
        totalAccommodationCost += parseFloat($(this).val()) || 0;
    });

    // Sum all visible and hidden total inputs
    $('input[id^="acc_total"]').each(function () {
        totalAccommodationCost += parseFloat($(this).val()) || 0;
    });
    // Update the span
    $('#tac_span').text(totalAccommodationCost.toFixed(2));
	$('#tac_hidden').val(totalAccommodationCost.toFixed(2));
	$('#a_total').text(totalAccommodationCost.toFixed(2));

	$('input.chk_vehicle:checked').each(function () {
        const vid = $(this).val();
        const vehTotal = parseFloat($('#veh_total' + vid).val()) || 0;
        totalTransportationCost += vehTotal;
    });
	
	totalTransportationCost += parseFloat($('#extraklm_hidden').val()) || 0;
    $('#ttc_span').text(totalTransportationCost.toFixed(2));
	$('#ttc_hidden').val(totalTransportationCost.toFixed(2));
	$('#v_total').text(totalTransportationCost.toFixed(2));

	$('input[id^="spcl_tariff"]').each(function () {
        specialEventTotal += parseFloat($(this).val()) || 0;
    });
    $('#spcl_span').text(specialEventTotal.toFixed(2));
	$('#spcl_hidden').val(specialEventTotal.toFixed(2));

	$('input[id^="daily_addon"]').each(function () {
        dailyAddonTotal += parseFloat($(this).val()) || 0;
    });
    $('#daily_span').text(dailyAddonTotal.toFixed(2));
	$('#daily_hidden').val(dailyAddonTotal.toFixed(2));

	$('input.grand_total').each(function () {
        totalNetRate += parseFloat($(this).val()) || 0;
    });
	totalNetRate += parseFloat($('#extraklm_hidden').val()) || 0;
    $('#tnr_span').text(totalNetRate.toFixed(2));
	$('#tnr_hidden').val(totalNetRate.toFixed(2));
	$('#g_total').text(totalNetRate.toFixed(2));
   }, 300);
}


	function calculateGrandTotal(vid) { 
		let total = 0;

		// Use vid as a prefix selector within that tab
		const $scope = $(`[data-index="${vid}"]`);

		if ($scope.length) {
			// 1. Checked vehicle totals within this vid
			$scope.find('.chk_vehicle:checked').each(function () {
				const v = $(this).val();
				const vehTotal = parseFloat($('#veh_total' + v).val()) || 0;
				total += vehTotal;
			});

			// 2. fac_rate
			$scope.find('input[id^="fac_rate"]').each(function () {
				total += parseFloat($(this).val()) || 0;
			});

			// 3. total
			$scope.find('input[id^="acc_total"]').each(function () {
				total += parseFloat($(this).val()) || 0;
			});

			// 4. spcl_tariff
			$scope.find('input[id^="spcl_tariff"]').each(function () {
				total += parseFloat($(this).val()) || 0;
			});

			// 5. daily_addon
			$scope.find('input[id^="daily_addon"]').each(function () {
				total += parseFloat($(this).val()) || 0;
			});
			// Output to a grand total field within this block

			$scope.find('.grand_total').val(total.toFixed(2));
			$('#span_bread_id'+vid).text(total.toFixed(2));
		}

		updateTotalAccommodationCost();
		setTimeout(function () {
			updateMarginTotal();
			updateTourAddonTotal();
			updateGSTandTotalPackageCost();
		}, 500); 
	
	}

	$(document).on('change', '.hotel_fac_change', function () {
		var vid = $(this).attr('data-id');
		var dataIndex = $(this).closest('[data-index]').data('index');
		setTimeout(() => calculateGrandTotal(dataIndex), 300);
	});

	$(document).on('click', '.chk_vehicle', function () {
		var vid = $(this).attr('data-id');
		setTimeout(() => calculateGrandTotal(vid), 300);
	});

	$(document).on('change', '.ss_change', function () {
		var vid = $(this).data('id');
		setTimeout(() => calculateGrandTotal(vid), 300);
	});

	$(document).on('input', 'input[id^="ss_distance"]', function () {
		var vid = $(this).attr('id').replace('ss_distance', '');
		setTimeout(() => calculateGrandTotal(vid), 300);
	});

	$(document).on('input', 'input[id^="spcl_tariff"]', function () {
		var vid = $(this).attr('id').replace('spcl_tariff', '');
		setTimeout(() => calculateGrandTotal(vid), 300);
	});
	$(document).on('input', 'input[id^="daily_addon"]', function () {
		var vid = $(this).attr('id').replace('daily_addon', '');
		setTimeout(() => calculateGrandTotal(vid), 300);
	});

</script>
<script>
    $(document).ready(function(){
		
        $("#btn_savedraft_iti_plan").click(function(){
            $("#submit_type").val("draft");
        });

        $("#btn_save_iti_plan").click(function(){
            $("#submit_type").val("final");
        });
		
    });
</script>
<script>
$(document).ready(function () {
    $(document).on('change', '.chk_vehicle', function () {
        let isChecked = $(this).is(':checked');
        let checkboxName = $(this).attr('name');
        let hiddenName = checkboxName.replace('chk_vehicle', 'chk_vehicle_hidden');

        // Set value to 1 if checked, else 0
        $('input[name="' + hiddenName + '"]').val(isChecked ? '1' : '0');
    });
});
</script>

<script>
$(document).ready(function () {
    var lastTourDetailsId = "<?= end($tour_plan_det)['tour_details_id']; ?>";

    var lastInnerTabId = "<?php 
        $last = end($tour_plan_det);
        $start = new DateTime($last['check_in_date']);
        $end = new DateTime($last['check_out_date']);
        $end->modify('+1 day');
        $lastInner = '';
        while ($start < $end) {
            $lastInner = $last['tour_details_id'] . '_' . $start->format('d-m-Y');
            $start->modify('+1 day');
        }
        echo $lastInner;
    ?>";

    function toggleFinalSaveButton() {
        const activeOuter = $('.tabs-menu1 .nav a.active').attr('href');
        const activeInner = $('.tab-pane.show.active .nav-link.active').attr('href');

        if (activeOuter === "#tab-" + lastTourDetailsId && activeInner === "#tabi-" + lastInnerTabId) {
            $('#btn_save_iti_plan').show();
            $('#btn_savedraft_iti_plan').hide();
        } else {
            $('#btn_save_iti_plan').hide();
            $('#btn_savedraft_iti_plan').show();
        }
    }

    toggleFinalSaveButton();
    $('a[data-toggle="tab"]').on('shown.bs.tab', toggleFinalSaveButton);
});
</script>
<script>

	function updateMarginTotal() {
		var tnr = parseFloat($('#tnr_hidden').val()) || 0;
		var margin_value = parseFloat($('#margin_value').val()) || 0;
		var tour_addon_value = parseFloat($('#tour_addon_total').val()) || 0;
		var marginPercent = (margin_value/100) * tnr;
		$('#margin_total').val(marginPercent.toFixed(2));
		var total_final = tnr + marginPercent + tour_addon_value;
		$('#total_final').val(total_final.toFixed(2));

		var gst_value = parseFloat($('#gst_value').val()) || 0;
		var gst_final = (gst_value/100) * total_final;
		$('#gst_final').val(gst_final.toFixed(2));

		var tpc = total_final + gst_final;
		$('#tpc').val(tpc.toFixed(2));
	}

	$(document).on('input', '#margin_value', function () {
		updateMarginTotal();
	});

	function updateTourAddonTotal() {
		var tnr = parseFloat($('#tnr_hidden').val()) || 0;
		var margin_value = parseFloat($('#margin_value').val()) || 0;
		var tour_addon_value = parseFloat($('#tour_addon_value').val()) || 0;
		$('#tour_addon_total').val(tour_addon_value);
		var marginPercent = (margin_value/100) * tnr;
		$('#margin_total').val(marginPercent.toFixed(2));
		var total_final = tnr + marginPercent + tour_addon_value;
		$('#total_final').val(total_final.toFixed(2));

		var gst_value = parseFloat($('#gst_value').val()) || 0;
		var gst_final = (gst_value/100) * total_final;
		$('#gst_final').val(gst_final.toFixed(2));
		
		var tpc = total_final + gst_final;
		$('#tpc').val(tpc.toFixed(2));
	}
	$(document).on('input', '#tour_addon_value', function () {
		updateTourAddonTotal();
	});

	function updateGSTandTotalPackageCost() {
		var totalFinal = parseFloat($('#total_final').val()) || 0;
		var gst_value = parseFloat($('#gst_value').val()) || 0;
		var gstPercent = (gst_value/100)*totalFinal;
		var totalPackageCost = totalFinal + gstPercent;
		$('#gst_final').val(gstPercent.toFixed(2));
		$('#tpc').val(totalPackageCost.toFixed(2));
	}
	$(document).on('change', '#gst_value', function () {
		updateGSTandTotalPackageCost();
	});
</script>

<script type="text/javascript">
    $(document).ready(function () {
        var i = 0;
		var no_of_double_room = <?php echo $object_det[0]['no_of_double_room']; ?>;
		var no_of_adult = <?php echo $object_det[0]['no_of_adult']; ?>;
		var no_of_single_room = <?php echo $object_det[0]['no_of_single_room']; ?>;
		var no_of_ch = <?php echo $object_det[0]['no_of_child_with_bed']; ?>;
		var no_of_cw = <?php echo $object_det[0]['no_of_child_without_bed']; ?>;
		var no_of_extra = <?php echo $object_det[0]['no_of_extra_bed']; ?>;
		
		var iti_edit_id = <?php echo isset($iti_edit_id) && $iti_edit_id !== '' ? $iti_edit_id : 0; ?>;
		if(iti_edit_id == 1){
			var read_only = "readonly";
			var dis_abled = 'style="pointer-events: none; background-color: #eee;"';
		}
		else{
			var read_only = "";
			var dis_abled = "";
		}
        $('.add_hotel').on('click', function () { 

			var $btn = $(this);
			var sequenceAttr = $btn.attr('data-sequence');
			if (sequenceAttr !== undefined && sequenceAttr !== '') {
				i = parseInt(sequenceAttr);
			} else {
				i++;
			}
			var html = '';
			//i++;
			var id_t = $(this).attr('data-id');
			var hotelRowCount = $('#hotel_dynamic_fields' + id_t + ' .dynamic-added').length;
			if (hotelRowCount >= 2) {
				$btn.prop('disabled', true);
				return;
			}


			var tour_date = $(this).attr('data-td'); 
			var tour_location_id = $(this).attr('data-tl'); 
			var meal_plan_id = $(this).attr('data-mp'); 
			var old_id = $(this).attr('data-oid'); 
			var hlist = JSON.parse($(this).attr('data-hid'));
            var id = id_t+"_"+i;
			html += '<div id="row' + id + '" class="dynamic-added card" data-index="' + id_t + '">';
				html += '<div class="row mt-2">';																																											
		    		html += '<div class="col-xl-2 col-sm-12 col-md-2">';
						html += '<input type="hidden" id="id'+id+'" name="hotel_additi['+i+'][id]" value="'+id_t+'">';
						html += '<input type="hidden" id="sequence'+id+'" name="hotel_additi['+i+'][sequence]" value="'+i+'">';
						html += '<input type="hidden" id="idvalue'+id+'" name="hotel_additi['+i+'][idvalue]" value="'+id+'">';
						html += '<input type="hidden" id="own_arrange'+id+'" name="hotel_additi['+i+'][own_arrange]" value="0">';
						html += '<input type="hidden" id="tour_date'+id+'" name="hotel_additi['+i+'][tour_date]" value="'+tour_date+'">';
						html += '<input type="hidden" id="tour_location_id'+id+'" name="hotel_additi['+i+'][tour_location_id]" value="'+tour_location_id+'">';
						html += '<input type="hidden" id="meal_plan_id'+id+'" name="hotel_additi['+i+'][meal_plan_id]" value="'+meal_plan_id+'">';

						html += '<div class="teams-rank"><b>Hotel</b></div>';
						html += '<select id="hotelid'+id+'" name="hotel_additi['+i+'][hotelid]" data-id="'+id+'" class="form-control input-sm hotel_change hotel" required '+dis_abled+'>';
						html += '<option value="">Select</option>';
						$.each(hlist, function (index, item) { 																					
							html += '<option value="'+item.hotel_id+'">'+item.object_name+'</option>';
						});																								
						html += '</select>';																					
					html += '</div>';
																																																	
					html += '<div class="col-xl-2 col-sm-12 col-md-2">';
						html += '<div class="teams-rank"><b>Room Category</b></div>';
						html += '<select id="roomcat'+id+'" name="hotel_additi['+i+'][roomcat]" data-id="'+id+'" data-sid="2" class="form-control input-sm room_cat_change room_cat" required '+dis_abled+'>';
						html += '<option value="">Select</option>';
																						
						html += '</select>';																							
					html += '</div>';
					html += '<div class="col-xl-2 col-sm-12 col-md-2">';
						html += '<div class="teams-rank"><b>No Of Adult</b></div>';
						html += '<input type="text" id="no_of_adult'+id+'" data-id="'+id+'" name="hotel_additi['+i+'][no_of_adult]" value="'+no_of_adult+'" class="form-control input-sm" maxlength="2" readonly>';
					html += '</div>';
					html += '<div class="col-xl-2 col-sm-12 col-md-2">';
						html += '<div class="teams-rank"><b>C.With Bed Qty</b></div>';
						html += '<input type="text" id="no_of_ch'+id+'" data-id="'+id+'" name="hotel_additi['+i+'][no_of_ch]" value="0" class="form-control input-sm" maxlength="2" required '+read_only+'>';
					html += '</div>';
					html += '<div class="col-xl-2 col-sm-12 col-md-2">';
						html += '<div class="teams-rank"><b>C.Without Bed Qty</b></div>';
						html += '<input type="text" id="no_of_cw'+id+'" data-id="'+id+'" name="hotel_additi['+i+'][no_of_cw]" value="0" class="form-control input-sm" maxlength="2" required '+read_only+'>';
					html += '</div>';
					html += '<div class="col-xl-2 col-sm-12 col-md-2">';
						html += '<div class="teams-rank"><b>Extra Bed Qty</b></div>';
						html += '<input type="text" id="no_of_extra'+id+'" data-id="'+id+'" name="hotel_additi['+i+'][no_of_extra]" value="0" class="form-control input-sm" maxlength="2" required '+read_only+'>';
					html += '</div>';
					
				html += '</div>';	

				html += '<div class="row mt-2">';																																											
					html += '<div class="col-xl-2 col-sm-12 col-md-2">';
						html += '<div class="teams-rank"><b>Room Type</b></div>';
					html += '</div>';
					html += '<div class="col-xl-2 col-sm-12 col-md-2">';
						html += '<div class="teams-rank"><b>No Of Rooms</b></div>';
					html += '</div>';
					html += '<div class="col-xl-2 col-sm-12 col-md-2">';
						html += '<div class="teams-rank"><b>Daily Room Rate</b></div>';
					html += '</div>';
					html += '<div class="col-xl-2 col-sm-12 col-md-2">';
						html += '<div class="teams-rank"><b>C.With Bed Rate</b></div>';
					html += '</div>';
					html += '<div class="col-xl-2 col-sm-12 col-md-2">';
						html += '<div class="teams-rank"><b>C.Without Bed Rate</b></div>';
					html += '</div>';
					html += '<div class="col-xl-2 col-sm-12 col-md-2">';
						html += '<div class="teams-rank"><b>Extra Bed Rate</b></div>';
					html += '</div>';
				html += '</div>';	
				if(no_of_double_room > 0){
					html += '<div class="row mt-2">';																																											
						html += '<div class="col-xl-2 col-sm-12 col-md-2">';
							html += '<input type="text" value="Double" class="form-control input-sm" maxlength="2" readonly>';
						html += '</div>';
						html += '<div class="col-xl-2 col-sm-12 col-md-2">';
							html += '<input type="text" id="double'+id+'" data-id="'+id+'" name="hotel_additi['+i+'][double]" class="form-control input-sm" maxlength="6" value="0" required '+read_only+'>';
						html += '</div>';
						html += '<div class="col-xl-2 col-sm-12 col-md-2">';
							html += '<input type="text" id="d_adult_rate'+id+'" data-id="'+id+'" name="hotel_additi['+i+'][d_adult_rate]" class="form-control input-sm" maxlength="6" value="" required '+read_only+'>';
						html += '</div>';
						html += '<div class="col-xl-2 col-sm-12 col-md-2">';
							html += '<input type="text" id="d_child_rate'+id+'" data-id="'+id+'" name="hotel_additi['+i+'][d_child_rate]" class="form-control input-sm" maxlength="6" value="" required '+read_only+'>';
						html += '</div>';
						html += '<div class="col-xl-2 col-sm-12 col-md-2">';
							html += '<input type="text" id="d_child_wb_rate'+id+'" data-id="'+id+'" name="hotel_additi['+i+'][d_child_wb_rate]" class="form-control input-sm" maxlength="6" value="" required '+read_only+'>';
						html += '</div>';
						html += '<div class="col-xl-2 col-sm-12 col-md-2">';
							html += '<input type="text" id="d_extra_bed_rate'+id+'" data-id="'+id+'" name="hotel_additi['+i+'][d_extra_bed_rate]" class="form-control input-sm" maxlength="6" value="" required '+read_only+'>';
						html += '</div>';
					html += '</div>';	
				}
				else{
					html += '<input type="hidden" id="double'+id+'" name="hotel_additi['+i+'][double]" class="form-control input-sm" maxlength="6" value="0">';
					html += '<input type="hidden" id="d_adult_rate'+id+'" name="hotel_additi['+i+'][d_adult_rate]" class="form-control input-sm" maxlength="6" value="0">';
					html += '<input type="hidden" id="d_child_rate'+id+'" name="hotel_additi['+i+'][d_child_rate]" class="form-control input-sm" maxlength="6" value="0">';
					html += '<input type="hidden" id="d_child_wb_rate'+id+'" name="hotel_additi['+i+'][d_child_wb_rate]" class="form-control input-sm" maxlength="6" value="0">';
					html += '<input type="hidden" id="d_extra_bed_rate'+id+'" name="hotel_additi['+i+'][d_extra_bed_rate]" class="form-control input-sm" maxlength="6" value="0">';
				}
				if(no_of_single_room > 0){
					html += '<div class="row mt-2">';																																											
						html += '<div class="col-xl-2 col-sm-12 col-md-2">';
							html += '<input type="text" value="Single" class="form-control input-sm" maxlength="2" readonly>';
						html += '</div>';
						html += '<div class="col-xl-2 col-sm-12 col-md-2">';
							html += '<input type="text" id="single'+id+'" data-id="'+id+'" name="hotel_additi['+i+'][single]" class="form-control input-sm" maxlength="6" value="0" required '+read_only+'>';
						html += '</div>';
						html += '<div class="col-xl-2 col-sm-12 col-md-2">';
							html += '<input type="text" id="s_adult_rate'+id+'" data-id="'+id+'" name="hotel_additi['+i+'][s_adult_rate]" class="form-control input-sm" maxlength="6" value="" required '+read_only+'>';
						html += '</div>';
						html += '<div class="col-xl-2 col-sm-12 col-md-2">';
							html += '<input type="text" id="s_child_rate'+id+'" data-id="'+id+'" name="hotel_additi['+i+'][s_child_rate]" class="form-control input-sm" maxlength="6" value="" readonly>';
						html += '</div>';
						html += '<div class="col-xl-2 col-sm-12 col-md-2">';
							html += '<input type="text" id="s_child_wb_rate'+id+'" data-id="'+id+'" name="hotel_additi['+i+'][s_child_wb_rate]" class="form-control input-sm" maxlength="6" value="" readonly>';
						html += '</div>';
						html += '<div class="col-xl-2 col-sm-12 col-md-2">';
							html += '<input type="text" id="s_extra_bed_rate'+id+'" data-id="'+id+'" name="hotel_additi['+i+'][s_extra_bed_rate]" class="form-control input-sm" maxlength="6" value="" readonly>';
						html += '</div>';
					html += '</div>';
				}
				else{
					html += '<input type="hidden" id="single'+id+'" name="hotel_additi['+i+'][single]" class="form-control input-sm" maxlength="6" value="0">';
					html += '<input type="hidden" id="s_adult_rate'+id+'" name="hotel_additi['+i+'][s_adult_rate]" class="form-control input-sm" maxlength="6" value="0">';
					html += '<input type="hidden" id="s_child_rate'+id+'" name="hotel_additi['+i+'][s_child_rate]" class="form-control input-sm" maxlength="6" value="0">';
					html += '<input type="hidden" id="s_child_wb_rate'+id+'" name="hotel_additi['+i+'][s_child_wb_rate]" class="form-control input-sm" maxlength="6" value="0">';
					html += '<input type="hidden" id="s_extra_bed_rate'+id+'" name="hotel_additi['+i+'][s_extra_bed_rate]" class="form-control input-sm" maxlength="6" value="0">';	
				}
				
				html += '<div class="row mt-2">';																																											
					html += '<div class="col-xl-2 col-sm-12 col-md-2">';
						html += '<div class="teams-rank"><b>Hotel Facility</b></div>';
						html += '<select id="hotfac'+id+'" name="hotel_additi['+i+'][hotfac]" class="form-control input-sm hotel_fac_change hot_fac" data-id="'+id+'" '+dis_abled+'>';
						html += '<option value="">Select</option>';
									
						html += '</select>';
					html += '</div>';
					html += '<div class="col-xl-2 col-sm-12 col-md-2">';
						html += '<div class="teams-rank"><b>Facility Rate</b></div>';
						html += '<input type="text" id="fac_rate'+id+'" name="hotel_additi['+i+'][fac_rate]" class="form-control input-sm" maxlength="6" value="" readonly>';
					html += '</div>';
					html += '<div class="col-xl-6 col-sm-12 col-md-6">';
						html += '<div class="teams-rank"><b>Remarks</b></div>';
						html += '<textarea id="remarks'+id+'" name="hotel_additi['+i+'][remarks]" class="form-control input-sm" '+read_only+'></textarea>';
					html += '</div>';
					html += '<div class="col-xl-1 col-sm-12 col-md-1">';
						html += '<div class="teams-rank"><b>Total</b></div>';
						html += '<input type="text" id="acc_total'+id+'" name="hotel_additi['+i+'][acc_total]" class="form-control input-sm" maxlength="6" value="" readonly>';
					html += '</div>';
					html += '<div class="col-xl-1 col-sm-12 col-md-1" style="padding-top:20px;">';															
						html += '<button type="button" name="remove" id="' + id + '" data-oid="'+old_id+'" data-nid="'+id+'" class="btn btn-danger btn-sm btn_agency_remove" '+dis_abled+'>X</button>';																							
					html += '</div>';
				html += '</div>';	
				
																								
			html += '</div>';		
            $('#hotel_dynamic_fields'+id_t).append(html);
			
        });
        $(document).on('click', '.btn_agency_remove', function () {
            var button_id = $(this).attr("id");
			var old_id = $(this).attr('data-oid'); 
			var id = $(this).attr('data-nid'); 
            $('#row' + button_id + '').remove();

			var hotelCount = $('#hotel_dynamic_fields' + old_id + ' .dynamic-added').length;
			if (hotelCount < 2) {
				$('.add_hotel[data-id="' + old_id + '"]').prop('disabled', false);
			}

			setTimeout(() => calculateGrandTotal(old_id), 300);
        });
    });
</script>
<script>
function waitForElement(selector, callback) {
	let attempts = 0;
	const maxAttempts = 20;
	const interval = setInterval(function () {
		if ($(selector).length) {
			clearInterval(interval);
			callback($(selector));
		}
		if (++attempts >= maxAttempts) {
			clearInterval(interval);
			console.warn("Element not found after max attempts:", selector);
		}
	}, 200);
}

$(document).ready(function () {
	const d_hotels = <?php echo json_encode($d_hotels); ?>;
	console.log(d_hotels);

	if (Array.isArray(d_hotels) && d_hotels.length > 0) {
		setTimeout(() => {
			$.each(d_hotels, function (index, item) {
				const selector =
					'.add_hotel' +
					'[data-mp="' + item.meal_plan_id + '"]' +
					'[data-tl="' + item.tour_location_id + '"]' +
					'[data-td="' + item.tour_date + '"]' +
					'[data-id="' + item.id + '"]' +
					'[data-oid="' + item.id + '"]';

				const $btn = $(selector);

				if ($btn.length > 0) {
					console.log("Triggering add for:", item.idvalue);
					$btn.attr('data-sequence', item.sequence);
					$btn.trigger("click");
					$btn.removeAttr('data-sequence');
					// Wait for dynamic block to render
					waitForElement('#hotelid' + item.idvalue, function () {
						const id = item.idvalue;

						$('#hotelid' + id).val(item.hotelid).trigger('change');

						// Wait again for hotel dropdown to load room/facility
						setTimeout(() => {
							$('#roomcat' + id).val(item.roomcat).trigger('change');
							$('#hotfac' + id).val(item.hotfac).trigger('change');

							// Wait a little before setting rate inputs
							setTimeout(() => {
								$('#no_of_ch' + id).val(item.no_of_ch);
								$('#no_of_cw' + id).val(item.no_of_cw);
								$('#no_of_extra' + id).val(item.no_of_extra);
								$('#double' + id).val(item.double);
								$('#single' + id).val(item.single);

								$('#d_adult_rate' + id).val(item.d_adult_rate);
								$('#d_child_rate' + id).val(item.d_child_rate);
								$('#d_child_wb_rate' + id).val(item.d_child_wb_rate);
								$('#d_extra_bed_rate' + id).val(item.d_extra_bed_rate);

								$('#s_adult_rate' + id).val(item.s_adult_rate);
								$('#s_child_rate' + id).val(item.s_child_rate);
								$('#s_child_wb_rate' + id).val(item.s_child_wb_rate);
								$('#s_extra_bed_rate' + id).val(item.s_extra_bed_rate);

								$('#remarks' + id).val(item.remarks);

								// Set total last (readonly, no .trigger needed)
								$('#acc_total' + id).val(item.total);

								console.log("Set all fields for ID:", id);
							}, 400);
						}, 400);
					});
				} else {
					console.warn("Add button not found for selector:", selector);
				}
			});
		}, 500);
	}
});
</script>
<script>
$(document).ready(function () {
    $('#myTourplanForm').on('submit', function (e) {
		var $saveDraft = $('#btn_savedraft_iti_plan');
        var $finalSave = $('#btn_save_iti_plan');
        $saveDraft.prop('disabled', true);
        $finalSave.prop('disabled', true);
        if ($saveDraft.is(':visible')) {
            $saveDraft.html('<i class="fa fa-spinner fa-spin"></i> Saving...');
        }
        if ($finalSave.is(':visible')) {
            $finalSave.html('<i class="fa fa-spinner fa-spin"></i> Finalizing...');
        }

        let isValid = true;
        $('.location-card').each(function () {
            const $card = $(this);
            const dataIndex = $card.data('index');
			var dates_new = dataIndex.split("_");

            let sumDouble = 0;
            let sumSingle = 0;
            let sumCH = 0;
            let sumCW = 0;
            let sumExtra = 0;

            let maxDouble = <?php echo $object_det[0]['no_of_double_room']; ?>;
            let maxSingle = <?php echo $object_det[0]['no_of_single_room']; ?>;
            let maxCH = <?php echo $object_det[0]['no_of_child_with_bed']; ?>;
            let maxCW = <?php echo $object_det[0]['no_of_child_without_bed']; ?>;
            let maxExtra = <?php echo $object_det[0]['no_of_extra_bed']; ?>;

            $card.find('input[id^="double"]').each(function () {
                sumDouble += parseInt($(this).val()) || 0;
            });

            $card.find('input[id^="single"]').each(function () {
                sumSingle += parseInt($(this).val()) || 0;
            });

            $card.find('input[id^="no_of_ch"]').each(function () {
                sumCH += parseInt($(this).val()) || 0;
            });

            $card.find('input[id^="no_of_cw"]').each(function () {
                sumCW += parseInt($(this).val()) || 0;
            });

            $card.find('input[id^="no_of_extra"]').each(function () {
                sumExtra += parseInt($(this).val()) || 0;
            });

            if (sumDouble !== maxDouble) {
                alert("Total Double Room count must be " + maxDouble + " for date: " + dates_new[1]);
                isValid = false;
                return false;
            }

            if (sumSingle !== maxSingle) {
                alert("Total Single Room count must be " + maxSingle + " for date: " + dates_new[1]);
                isValid = false;
                return false;
            }

            if (sumCH !== maxCH) {
                alert("Total Child with Bed count must be " + maxCH + " for date: " + dates_new[1]);
                isValid = false;
                return false;
            }

            if (sumCW !== maxCW) {
                alert("Total Child without Bed count must be " + maxCW + " for date: " + dates_new[1]);
                isValid = false;
                return false;
            }

            if (sumExtra !== maxExtra) {
                alert("Total Extra Bed count must be " + maxExtra + " for date: " + dates_new[1]);
                isValid = false;
                return false;
            }
        });

        if (!isValid) {
            e.preventDefault();
			$saveDraft.prop('disabled', false);
    		$finalSave.prop('disabled', false);
			if ($saveDraft.is(':visible')) {
				$saveDraft.html('Save Draft');
			}
			if ($finalSave.is(':visible')) {
				$finalSave.html('Finalize');
			}
        }
    });
});
</script>

<script>
async function initDynamicHotels() {
		await sleep(5000);

		setTimeout(() => {
			$('input[id^="ss_distance"]').trigger('input');
			updateTotalAccommodationCost();
			updateMarginTotal();
			updateTourAddonTotal();
			updateGSTandTotalPackageCost();
		}, 100);
	
}

function sleep(ms) {
	return new Promise(resolve => setTimeout(resolve, ms));
}

$(document).ready(function () {
	initDynamicHotels();
});
</script>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const cursor = document.createElement("div");
    cursor.classList.add("stylish-cursor");
    document.body.appendChild(cursor);

    document.addEventListener("mousemove", function(e) {
        cursor.style.top = `${e.clientY}px`;
        cursor.style.left = `${e.clientX}px`;
    });
});
</script>
<script>
$('form').on('submit', function (e) {
    // Find the first invalid element
    let $firstInvalid = $(this).find(':invalid').first();

    if ($firstInvalid.length) {
        // Prevent form submission
        e.preventDefault();

        // Get the tab pane that contains the invalid element
        let $tabPane = $firstInvalid.closest('.tab-pane');

        if ($tabPane.length) {
            // Get the ID of the tab pane
            let tabId = $tabPane.attr('id');

            // Activate the corresponding tab (assuming Bootstrap 4/5 tabs)
            $('a[href="#' + tabId + '"]').tab('show');

            // Optionally focus the invalid input
            $firstInvalid.focus();
        }
    }
});
</script>

<script>
$(document).ready(function () {
    $('#loading-spinner').show(); // Show spinner

    initDynamicHotels().then(() => {
        $('#loading-spinner').hide(); // Hide spinner after loading is done
    });
});
</script>

<script>
/*$(document).ready(function () {
    $('#myTourplanForm').on('submit', function (e) {
        let $form = $(this);
        let $firstInvalid = $form.find(':invalid').first();

        if ($firstInvalid.length) {
            e.preventDefault();

            // Find the closest inner tab-pane (date tab)
            let $innerTabPane = $firstInvalid.closest('.tab-pane');
            if (!$innerTabPane.length) return;

            let innerTabId = $innerTabPane.attr('id');

            // Activate date tab
            let $innerTabLink = $('a[href="#' + innerTabId + '"][data-toggle="tab"]');
            if ($innerTabLink.length) {
                $innerTabLink.tab('show');
            }

            // Then find outer tab-pane (location tab) and activate
            setTimeout(function () {
                let $outerTabPane = $innerTabPane.parents('.tab-pane').first();
                if (!$outerTabPane.length) return;

                let outerTabId = $outerTabPane.attr('id');
                let $outerTabLink = $('a[href="#' + outerTabId + '"][data-toggle="tab"]');

                if ($outerTabLink.length) {
                    $outerTabLink.tab('show');

                    // Re-show the inner tab after outer is shown
                    setTimeout(function () {
                        $innerTabLink.tab('show');
                        $firstInvalid[0].focus();
                    }, 150);
                } else {
                    // If outer tab doesn't exist (only one level deep), just focus
                    $firstInvalid[0].focus();
                }
            }, 150);
        }
    });
});*/
</script>
<script type="text/javascript">
    $(document).ready(function () {
        $('.select_make_current').on('change', function () { 
			var d_adult_rate = 0;
			var d_child_rate = 0;
			var d_child_wb_rate= 0;
			var d_extra_bed_rate = 0;

			var s_adult_rate = 0;
			var s_child_rate = 0;
			var s_child_wb_rate= 0;
			var s_extra_bed_rate = 0;

			var special_tariff = 0;
			var hotel_fac_id = 0;
			var hotel_fac_rate = 0;
			var ss_id = 0;
			var ss_distance = 0;
			var daily_addon = 0;

			var maxDouble = <?php echo $object_det[0]['no_of_double_room']; ?>;
            var maxSingle = <?php echo $object_det[0]['no_of_single_room']; ?>;
			var vehicle_models = <?php echo json_encode($vehicle_data); ?>;
			var id = $(this).attr('data-id');
			var itinerary_id = $('#make_current'+id).val();
			if(itinerary_id == null || itinerary_id == '' || itinerary_id=='undefined'){
				alert("Please Select Edit History");
			}
			else{
				$.ajax({
					url: "<?=site_url('Enquiry/getItineraryDetailsById');?>",
					method: "POST",
					data: {
						itinerary_id:itinerary_id
					},
					dataType: 'json',
					success: function (data) {
    					$('#hotelid' + id).val(data[0].hotel_id).trigger('change');
						setTimeout(function () {
							$('#roomcat' + id).val(data[0].room_category_id).trigger('change');
						}, 300);

						$('#no_of_ch' + id).val(data[0].child_with_bed);
                    	$('#no_of_cw' + id).val(data[0].child_without_bed);
                    	$('#no_of_extra' + id).val(data[0].extra_bed);

						$.each(data[0].cost, function (index, val) {
							if(val.cost_component_id == 6 && val.room_type_id == 2){
								d_adult_rate = val.tariff;
							}
							if(val.cost_component_id == 12 && val.room_type_id == 2){
								d_child_rate = val.tariff;
							}
							if(val.cost_component_id == 15 && val.room_type_id == 2){
								d_child_wb_rate = val.tariff;
							}
							if(val.cost_component_id == 9 && val.room_type_id == 2){
								d_extra_bed_rate = val.tariff;
							}

							if(val.cost_component_id == 6 && val.room_type_id == 1){
								s_adult_rate = val.tariff;
							}
							if(val.cost_component_id == 12 && val.room_type_id == 1){
								s_child_rate = val.tariff;
							}
							if(val.cost_component_id == 15 && val.room_type_id == 1){
								s_child_wb_rate = val.tariff;
							}
							if(val.cost_component_id == 9 && val.room_type_id == 1){
								s_extra_bed_rate = val.tariff;
							}

							if(val.cost_component_id == 17 && val.room_type_id == 1){
								special_tariff = val.tariff;
							}

							if(val.cost_component_id == 18 && val.room_type_id == 1){
								hotel_fac_id = val.tariff;
							}
							if(val.cost_component_id == 19 && val.room_type_id == 1){
								hotel_fac_rate = val.tariff;
							}

							if(val.cost_component_id == 21 && val.room_type_id == 1){
								ss_id = val.tariff;
							}
							if(val.cost_component_id == 22 && val.room_type_id == 1){
								ss_distance = val.tariff;
							}

							if(val.cost_component_id == 23 && val.room_type_id == 1){
								daily_addon = val.tariff;
							}
								
						});

						if(maxDouble > 0){
							$('#double' + id).val(data[0].double_room);
							$('#d_adult_rate' + id).val(d_adult_rate);
							$('#d_child_rate' + id).val(d_child_rate);
							$('#d_child_wb_rate' + id).val(d_child_wb_rate);
							$('#d_extra_bed_rate' + id).val(d_extra_bed_rate);
						}
						if(maxSingle > 0){
							$('#single' + id).val(data[0].single_room);
							$('#s_adult_rate' + id).val(s_adult_rate);
							$('#s_child_rate' + id).val(s_child_rate);
							$('#s_child_wb_rate' + id).val(s_child_wb_rate);
							$('#s_extra_bed_rate' + id).val(s_extra_bed_rate);
						}
						
						if(hotel_fac_id > 0){
							setTimeout(function () {
								$('#hotfac' + id).val(hotel_fac_id).trigger('change');
							}, 300);

							$('#fac_rate' + id).val(hotel_fac_rate);
						}
						$('#remarks' + id).val(data[0].remarks);
						$('#spcl_event' + id).val(data[0].special_event_name);
						if(ss_id > 0){
							setTimeout(function () {
								$('#sight' + id).val(ss_id).trigger('change');
							}, 300);
							$('#ss_distance' + id).val(ss_distance);
						}
						$('#spcl_tariff' + id).val(special_tariff);
						$('#daily_addon' + id).val(daily_addon);

						var vehicleDetails = JSON.parse(data[0].vehicle_details);
						var v_flag;
						var chkbox;
						$.each(vehicle_models, function (vindex, vmodel) { 
							chkbox = $('#chk_vehicle' + id + vmodel.vehicle_type_id + '_0');
							chkbox.prop('checked', true).trigger('change');
							v_flag = 0;
							$.each(vehicleDetails, function (v_index, v_item) { 
								if(vmodel.vehicle_type_id == v_item.veh_type_id){
									v_flag = 1;
								}
							});
							if (v_flag == 0) {
								var chkbox = $('#chk_vehicle' + id + vmodel.vehicle_type_id + '_0');
								if (chkbox.length > 0) {
									chkbox.prop('checked', false).trigger('change');
								}
							}
						});
						var hotelDetails = data[0].hotel_details;
						if (typeof hotelDetails === 'string') {
							hotelDetails = JSON.parse(hotelDetails);
						}
						var hotelDetails_len = hotelDetails.length;
					
						
							const container = $('#hotel_dynamic_fields' + id);
							if (container.children().length > 0) {
								container.find('.btn_agency_remove').each(function () {
									var button_id = $(this).attr("id");
									$('#row' + button_id + '').remove();
								});
							}
						
						if (Array.isArray(hotelDetails) && hotelDetails.length > 0) {
							setTimeout(() => {
								if ($('.add_hotel').length === 0) {
									console.warn("Add buttons not rendered yet. Retrying...");
									return;
								}
								$.each(hotelDetails, function (index, item) {
									const selector =
										'.add_hotel' +
										'[data-mp="' + item.meal_plan_id + '"]' +
										'[data-tl="' + item.tour_location_id + '"]' +
										'[data-td="' + item.tour_date + '"]' +
										'[data-id="' + item.id + '"]' +
										'[data-oid="' + item.id + '"]';

									const $btn = $(selector);

									if ($btn.length > 0) {
										console.log("Triggering add for:", item.idvalue);
										$btn.attr('data-sequence', item.sequence);
										$btn.trigger("click");
										$btn.removeAttr('data-sequence');
										// Wait for dynamic block to render
										waitForElement('#hotelid' + item.idvalue, function () {
											const id = item.idvalue;

											$('#hotelid' + id).val(item.hotelid).trigger('change');

											// Wait again for hotel dropdown to load room/facility
											setTimeout(() => {
												$('#roomcat' + id).val(item.roomcat).trigger('change');
												$('#hotfac' + id).val(item.hotfac).trigger('change');

												// Wait a little before setting rate inputs
												setTimeout(() => {
													$('#no_of_ch' + id).val(item.no_of_ch);
													$('#no_of_cw' + id).val(item.no_of_cw);
													$('#no_of_extra' + id).val(item.no_of_extra);
													$('#double' + id).val(item.double);
													$('#single' + id).val(item.single);

													$('#d_adult_rate' + id).val(item.d_adult_rate);
													$('#d_child_rate' + id).val(item.d_child_rate);
													$('#d_child_wb_rate' + id).val(item.d_child_wb_rate);
													$('#d_extra_bed_rate' + id).val(item.d_extra_bed_rate);

													$('#s_adult_rate' + id).val(item.s_adult_rate);
													$('#s_child_rate' + id).val(item.s_child_rate);
													$('#s_child_wb_rate' + id).val(item.s_child_wb_rate);
													$('#s_extra_bed_rate' + id).val(item.s_extra_bed_rate);

													$('#remarks' + id).val(item.remarks);

													// Set total last (readonly, no .trigger needed)
													$('#acc_total' + id).val(item.total);

													console.log("Set all fields for ID:", id);
												}, 400);
											}, 400);
										});
									} else {
										console.warn("Add button not found for selector:", selector);
									}
								});
							}, 500);

						}

						var dataIndex = $(this).closest('[data-index]').data('index');
						setTimeout(() => calculateGrandTotal(dataIndex), 500);
					}
				});
			}
		});
	});
</script>
<script>
$(document).ready(function () {
    $('#myTourplanForm1').on('submit', function () {
        $('#gen_cost_sheet_id, #view_cost_sheet_id').prop('disabled', true);
        if ($('#gen_cost_sheet_id').is(':visible')) {
            $('#gen_cost_sheet_id').html('<i class="fa fa-spinner fa-spin"></i> Saving...');
        }
        if ($('#view_cost_sheet_id').is(':visible')) {
            $('#view_cost_sheet_id').html('<i class="fa fa-spinner fa-spin"></i> Updating...');
        }
    });
});
</script>

<script>
$(document).ready(function () {
    $('#btn_savedraft_iti_plan').click(function () {
        console.log("👉 Clicked Next >>");

        // ✅ Step 1: Get outer location tabs (e.g., Cochin, Munnar, Cherai)
        var $outerTabs = $('#outer-location-tabs .nav-link');
        var $currentOuterNav = $outerTabs.filter('.active');
        var $currentOuterLi = $currentOuterNav.closest('li');
        var $nextOuterLi = $currentOuterLi.next('li');

        if (!$currentOuterNav.length) {
            console.log("❌ No active outer location tab found.");
            return;
        }

        var currentOuterTabId = $currentOuterNav.attr('href'); // e.g., #tab-190
        console.log("✅ Correct OUTER tab ID:", currentOuterTabId);

        var $activeOuterPane = $(currentOuterTabId);

        // ✅ Step 2: Get inner date tabs inside current outer tab
        var $innerTabs = $activeOuterPane.find('ul.nav-tabs .nav-link');
        var $currentInnerNav = $innerTabs.filter('.active');
        var $currentInnerLi = $currentInnerNav.closest('li');
        var $nextInnerLi = $currentInnerLi.next('li');

        if ($nextInnerLi.length) {
            console.log("➡️ Moving to NEXT inner date tab");
            $nextInnerLi.find('a.nav-link').tab('show');
        } else if ($nextOuterLi.length) {
            var $nextOuterNav = $nextOuterLi.find('a.nav-link');
            var nextOuterTabId = $nextOuterNav.attr('href');
            console.log("➡️ Moving to NEXT OUTER location tab:", nextOuterTabId);
            $nextOuterNav.tab('show');

            // Activate the first date tab of the new outer location
            setTimeout(function () {
                var $newOuterPane = $(nextOuterTabId);
                var $firstInnerTab = $newOuterPane.find('ul.nav-tabs .nav-link').first();
                if ($firstInnerTab.length) {
                    console.log("✅ Activating first inner date tab:", $firstInnerTab.attr('href'));
                    $firstInnerTab.tab('show');
                } else {
                    console.log("⚠️ No inner date tabs found in next outer tab");
                }
            }, 300);
        } else {
            console.log("✅ You are on the LAST outer and LAST inner tab.");
            $('#btn_savedraft_iti_plan').hide();
            $('#btn_save_iti_plan').show();
        }
    });
});
</script>