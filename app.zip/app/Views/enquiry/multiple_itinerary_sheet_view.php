<?php
use App\Models\Enquiry_m;
$Enquiry_model = new Enquiry_m();
$total_count = count($response)-1;
foreach($response as $index => $item){
$arr_name = $Enquiry_model->getLocationNamebyid($item['object_det'][0]['arrival_location']);
$dep_name = $Enquiry_model->getLocationNamebyid($item['object_det'][0]['departure_location']);
$user_details = $Enquiry_model->getuserdetails(session('user_id'));
$plus = " + ";
$comma = " , ";
if($index == 0){
?>
<textarea name="multiple_iti_sheet_template" id="multiple_iti_sheet_template" style="width:100%; height:1000px;"> 
    <div class="container">
    	<p>Dear Sir / Madam,</p> <p><b><i>Greetings from Touracle – The preferred South India Tour operator.</i></b><p>
    	<p>Thank you for your enquiry. We are pleased to submit the travel itinerary we have prepared exclusively for you</p>
    	<p>Please review the details at your earliest convenience, and we look forward to receiving your confirmation. If you require any amendments or support regarding the itinerary from our end, please do not hesitate to contact us. </p><p>Thank you for the opportunity to assist you with your enquiries.</p>  
        <p><b>Dates : </b><?php echo date("d-m-Y", strtotime($item['object_det'][0]['start_date'])); ?> to <?php echo date("d-m-Y", strtotime($item['object_det'][0]['end_date'])); ?></p>
    	<p><b>Duration : </b><?php echo $item['object_det'][0]['no_of_night'];?> Nights and <?php echo $item['object_det'][0]['no_of_night']+1; ?> Days</p>
		<p><b>No of Persons : </b>
			<?php if($item['object_det'][0]['no_of_adult'] > 0) { echo $item['object_det'][0]['no_of_adult']; ?> Adults <?php } ?>
			<?php if($item['object_det'][0]['no_of_child_with_bed'] > 0) { echo $comma.$item['object_det'][0]['no_of_child_with_bed']; ?> Child with Bed<?php } ?>
			<?php if($item['object_det'][0]['no_of_child_without_bed'] > 0) { echo $comma.$item['object_det'][0]['no_of_child_without_bed']; ?> Child without Bed <?php } ?>
		</p>
		<p><b>Number of room : </b>
			<?php if($item['object_det'][0]['no_of_double_room'] > 0) { echo $item['object_det'][0]['no_of_double_room']; ?> Double Room <?php } ?>
			<?php if($item['object_det'][0]['no_of_single_room'] > 0) { echo $plus.$item['object_det'][0]['no_of_single_room']; ?> Single Room <?php } ?>
			<?php if($item['object_det'][0]['no_of_extra_bed'] > 0) { echo $plus.$item['object_det'][0]['no_of_extra_bed']; ?> Extra Bed <?php } ?>
		</p>
		<?php if($item['object_det'][0]['is_vehicle_required'] == 1) { ?>
			<p><b>Arrival : </b><?php echo $arr_name[0]['geog_name']; ?></p>
			<p><b>Departure : </b><?php echo $dep_name[0]['geog_name']; ?></p>
		<?php } } ?>

		<table style="width:100%;border-collapse: collapse;border: 1px solid black;">
                <thead>
                    <tr>
                        <td style="border:1px solid black;text-align:center;background-color:#4baf58;color:#fff;"><b>Check In</b></td>
                        <td style="border:1px solid black;text-align:center;background-color:#4baf58;color:#fff;"><b>Check Out</b></td>
                        <td style="border:1px solid black;text-align:center;background-color:#4baf58;color:#fff;"><b>No Of Night</b></td>
                        <td style="border:1px solid black;text-align:center;background-color:#4baf58;color:#fff;"><b>Place</b></td>
                        <td style="border:1px solid black;text-align:center;background-color:#4baf58;color:#fff;"><b>Hotel</b></td>
                        <td style="border:1px solid black;text-align:center;background-color:#4baf58;color:#fff;"><b>Room Type</b></td>
                        <td style="border:1px solid black;text-align:center;background-color:#4baf58;color:#fff;"><b>Meal Plan</b></td>
                        <?php if($item['object_det'][0]['no_of_double_room'] > 0){ ?>
                            <td style="border:1px solid black;text-align:center;background-color:#4baf58;color:#fff;"><b>No of Rooms(Dbl)</b></td>
                        <?php } ?>
                        <?php if($item['object_det'][0]['no_of_single_room'] > 0){ ?>
                            <td style="border:1px solid black;text-align:center;background-color:#4baf58;color:#fff;"><b>No of Rooms(Sgl)</b></td>
                        <?php } ?>
                    </tr>
                </thead>
				<tbody>
                    <?php
                    $k = 1;
                    $sum = 0;
                    $ep = 0;
                    $cp = 0;
                    $map = 0;
                    $ap = 0;
                    foreach ($item['tour_plan_det'] as $key => $val) {
                        if($val['meal_plan_id'] == 1){
                            $ep = 1;
							$meal_name = "EP";
                        }
                        if($val['meal_plan_id'] == 2){
                            $cp = 1;
							$meal_name = "CP";
                        }
                        if($val['meal_plan_id'] == 3){
                            $map = 1;
							$meal_name = "MAP";
                        }
                        if($val['meal_plan_id'] == 4){
                            $ap = 1;
							$meal_name = "AP";
                        }
                        if ($val['is_own_arrangement'] == 1) { ?>
                            <tr>
                                <td style="border:1px solid black;text-align: center"><?php echo date("d-m-Y", strtotime($val['check_in_date'])); ?></td>
                                <td style="border:1px solid black;text-align: center"><?php echo date("d-m-Y", strtotime($val['check_out_date'])); ?></td>
                                <td style="border:1px solid black;text-align: center">Own Arrangements</td>
                                <td></td><td></td><td></td><td></td><td></td><td></td>
                            </tr>
                            <?php } else {
                            $sdate = $val['check_in_date'];
                            $hname = $val['object_name'];
                            $cat = $val['room_category_name'];
                           ?>
                            <tr><td style="border:1px solid black;text-align: center"><?php echo date("d-m-Y", strtotime($val['check_in_date'])); ?></td>
                            <td style="border:1px solid black;text-align: center"><?php echo date("d-m-Y", strtotime($val['check_out_date'])); ?></td>

                            <td style="border:1px solid black;text-align: center"><?php echo $val['no_of_days']; ?></td>
                            <td style="border:1px solid black;text-align: center"><?php echo $val['geog_name']; ?></td>
                            <td style="border:1px solid black;text-align: center"><?php echo $hname; ?></td>
                            <td style="border:1px solid black;text-align: center"><?php echo $cat; ?></td>
                            <td style="border:1px solid black;text-align: center"><?php echo $meal_name; ?></td>
                            <?php if($item['object_det'][0]['no_of_double_room'] > 0){ ?>
                                <td style="border:1px solid black;text-align: center"><?php echo $val['no_of_double_room']; ?></td>
                            <?php } ?>
                            <?php if($item['object_det'][0]['no_of_single_room'] > 0){ ?>
                                <td style="border:1px solid black;text-align: center"><?php echo $val['no_of_single_room']; ?></td>
                            <?php } ?>
                            </tr>
                        <?php }

                    } ?>
                </tbody>
            </table>

	<?php
        if($item['object_det'][0]['no_of_adult'] > 0){
            $enquiry_no_of_adult = $item['object_det'][0]['no_of_adult']." Adults";
        }
        else{
            $enquiry_no_of_adult = "";
        }
       if($item['object_det'][0]['no_of_child_with_bed'] > 0){
            $enquiry_no_of_child = " + ".$item['object_det'][0]['no_of_child_with_bed']." Child";
       }
       else{
            $enquiry_no_of_child = "";
       }
       if($item['object_det'][0]['no_of_child_without_bed'] > 0){
            $enquiry_no_of_child_wb = " + ".$item['object_det'][0]['no_of_child_without_bed']." Child Without Bed";
        }
        else{
            $enquiry_no_of_child_wb = "";
        }
        $tpcfor = $enquiry_no_of_adult.$enquiry_no_of_child.$enquiry_no_of_child_wb;
    ?>

	<label style="background-color:yellow;"><b>Total Package cost for <?php echo $tpcfor; ?> : Rs.<?php echo $item['iti_cost_datas'][0]['tpc']; ?>/-Inclusive of all taxes.</b></label>
    <?php if ($cp > 0) { ?><p>CP: Room + Breakfast Only</p> <?php } ?>
    <?php if ($map > 0) { ?><p>MAP: Room + Breakfast + Lunch/ Dinner only</p><?php } ?>
    <?php if ($ap > 0) { ?><p>AP: Room + Breakfast + Lunch + Dinner Only</p><?php } ?>
    <?php if($index == $total_count){ ?>
    <p id="dyn_multiple_iti"></p>
    <label style="background-color:#ff99c2;"><b>Rooms/Rates are subject to availability at the time of booking.</b></label><br><br><br>
    <?php if($item['object_det'][0]['is_vehicle_required'] == 1) { ?>
    <b><u>Itinerary</u></b>
	<?php
    $k = 1;
    $ssdet = [];
    
    foreach ($item['iti_data'] as $keys => $vals) {
        $loc_name = $vals['geog_name'];
        /*if(!empty($val['departure'])){
            $dep_name = $Enquiry_model->getLocationName($val['departure']);
        }
        else{
            $dep_name = '';
        }*/
		//$dep_name = $dep_name[0]['geog_name'];
		$ss_id = 0;
        foreach ($vals['cost'] as $key1 => $val1) {
            if($val1['cost_component_id'] == "21") {
				$ss_id = $val1['tariff'];
			}
		}
			$ss_details = $Enquiry_model->getSightName($ss_id);

            if(!empty($ss_details)){
                $ss_name = $ss_details[0]['object_name'];
                $description = $ss_details[0]['object_name']." - ".$ss_details[0]['sightseeing_description'];
            }
            else{
                $ss_name = "Liesure";
                $description = "Liesure";
            }
           
        ?>
            <p><b>Day <?php echo $k++; ?> (<?php echo date("d-m-Y", strtotime($vals['tour_date'])); ?>) - <?php echo $loc_name; ?></b></p>
            <p><?php echo $description; ?></p>
            <?php 
        
    	} ?>
		<p><b>Day <?php echo $k++; ?> (<?php echo date("d-m-Y", strtotime($item['object_det'][0]['end_date'])); ?>) - Departure Transfer</b></p>
		<p>Departure Transfer to <?php echo $arr_name[0]['geog_name']; ?></p>
	<?php
	} 
        $v_lists = '';
		$vehicle_details = json_decode($item['tour_plan_det'][0]['vehicle_details']);
        if(!empty($vehicle_details)){
            foreach ($vehicle_details as $keyv => $valv) {
                $veh = $valv->vehicle_model;
                $v_lists = $v_lists.$veh.", ";
            }
            //$newv_lists = substr($v_lists, 0, -2);
        }
    }
    if($index == $total_count){
    ?>

    <p><b>Package Includes:</b></p>
    <div><ul>
            <li>Accommodation on twin/double sharing basis on food plan stated above.</li>
            <?php if($item['object_det'][0]['is_vehicle_required'] == 1) { ?>
                <li>All transfers and sightseeing arrangements by<b><?php echo $v_lists; ?></b> as per itinerary.</li>
            <?php } ?>
            <li>Vehicle at your disposal as per the itinerary.</li>
            <li>Services of well experienced driver.</li>
            <li>Driver Allowance, toll, parking fee, Night halt charges, inter- state permit and govt. applicable service tax.</li>
            <li>Child below 5 years on Complimentary basis.</li>
            <li>All applicable taxes.</li>
            <li style='list-style-type: none;'>
            <b>Houseboat (Applicable, if included in the itinerary).</b><ul>
            <li>Check in 12.30 PM and Check out Time in 09.00 AM at Houseboat.</li>
            <li>One night accommodation with Lunch, Evening Tea Snacks, Dinner, and Breakfast; only Traditional Kerala Food will be Served On Houseboat.</li>
            <li>As per Government Regulation cruising will not permitted after 06.00PM.</li>
            <li>A/c will be provided from 08.30 PM to next day morning 06.00 AM.</li>
            <li>In House boat Air condition will be available only on bedrooms, in all category.</li>
            <li>Stable electricity couldn't be guaranteed being it depends on weather conditions.</li>
            <li>Do not compare Houseboat rooms with the hotel rooms, as they are compact & smaller in size.</li>
            <li>Houseboat shall be sailing through small streams & canals through villages and by the sunset shall be anchored near shore / jetty till morning.</li>
            <li>Because of the water body, just to avoid flying insects / mosquito; lights shall be operational only in the room after sunset.</li>
            <li>There won’t be anything for the entertainment in the houseboat like TV / Indoor games. Houseboats are just to experience the back waters of Kerala.</li>
            <li>Houseboat crew members are not hospitality professionals. Majority are local villagers and could not expect fluent Hindi / English.</li>
            </ul>
    </li></ul></div>
    <p><b>Package Excludes:</b></p>
    <div><ul>
            <li>Any other services or food which are not mentioned in the above "Includes" section.</li>
            <li>Expense of personal nature such as tips, laundry, telephones, beverages etc</li>
            <li>Airfares and Train ticket charges if any</li>
            <li>Christmas Eve /New year Eve supplement charges if applicable.</li>
            <li>Any entrance Fees / Activities charges unless specific in inclusion.</li>
    </ul></div>
    <p><b>Note:</b></p>
        <?php 
        if($item['object_det'][0]['no_of_adult'] > 0){
            $noadults = $item['object_det'][0]['no_of_adult']." Adult"; 
        }
        else{
            $noadults = '';
        }    
        if($item['object_det'][0]['no_of_child_with_bed'] > 0){
            $nocbed = " + ".$item['object_det'][0]['no_of_child_with_bed']." Child With Bed"; 
        }
        else{
            $nocbed = '';
        }    
        if($item['object_det'][0]['no_of_child_without_bed'] > 0){
            $nocwbed = " + ".$item['object_det'][0]['no_of_child_without_bed']." Child Without Bed"; 
        }
        else{
            $nocwbed = '';
        }
        if($item['object_det'][0]['no_of_double_room'] > 0){
            $no_of_double = " ( ".$item['object_det'][0]['no_of_double_room']." Double Room"; 
        }
        else{
            $no_of_double = '';
        }   
        if($item['object_det'][0]['no_of_single_room'] > 0){
            $no_of_single = ", ".$item['object_det'][0]['no_of_single_room']." Single Room"; 
        }
        else{
            $no_of_single = '';
        }   
        if($item['object_det'][0]['no_of_single_room'] > 0){
            $noextras = ", ".$item['object_det'][0]['no_of_single_room']." Extra Bed"; 
        }
        else{
            $noextras = '';
        }     
        $noadults_tot = $noadults.$nocbed.$nocwbed.$no_of_double.$no_of_single.$noextras." ) ";   
        ?>
    <div><ul>
            <li>Given quote is valid for minimum <b><?php echo $noadults_tot ; ?></b> paying persons only.</li>
            <li>Confirmations of hotels are subject to availability.</li>
            <li>Slight alterations in the accommodation may become unavoidable due to unavailability of rooms in mentioned hotels, but the accommodation so provided will be of the same class.</li>
            <li>Check in time 1400 Hrs and Check out time 1200 Hrs for all Hotels</li>
            <li>This quote is valid for 7 days only.</li>
            <li>Rooms mentioned at all Hill Stations (Munnar, Thekkady, Ooty, Wayanad, Kodaikanal etc) are generally Non A/c, Otherwise specified.</li>
            <li>Vehicle at disposable from 8 AM to 8 PM as per above itinerary. Any additional sightseeing will be charged extra.</li>
            <li>Hotels will provide either extra Mattress or extra bed as per the Hotel Policy and availability, in case applicable in the package.</li>
            <li>The food service at respective hotels depends on hotel occupancy. In case of low occupancy a Set Menu for a fixed price will be provided by the hotel as per your chosen food plan.</li>
            <li>Please provide your GST no and billing details at the time of booking. Changes of GST details will not be entertained later.</li>
            <li>Kindly note that if agent does not provided GST number at the time of confirmation the final invoice will be treated as unregistered dealer.</li>
            <li>We will not be responsible for any loss which may happen by availing additional paid activities through the driver or other sources during the tour.</li>
    </ul></div>
    <p><b>Payments</b></p>
    <p><b>Please refer the Proforma Invoice to make the payments</b></p>
    <p><b>Cancellation policy:</b></p>
    <p>
    Cancellation Charges are based on how many days before your booked arrival time KHM receives your cancellation notice. These charges are a percentage of the total cost of your booked accommodation.
    </p>
    <table style='border:1px solid black !important;width:75%;'><tr style='border:1px solid black !important;'><td style='border:1px solid black !important;text-align:center;'>In the case of Holiday Package Bookings Period within which written notice of cancellation is received</td><td style='border:1px solid black !important;text-align:center;'>Cancellation charges will be - -% of total booking price</td></tr>
    <tr style='border:1px solid black !important;'><td style='border:1px solid black !important;text-indent:25%;'>0 – 10 days</td><td style='border:1px solid black !important;text-indent:25%;'>100%</td></tr>
    <tr style='border:1px solid black !important;'><td style='border:1px solid black !important;text-indent:25%;'>11 - 30 days</td><td style='border:1px solid black !important;text-indent:25%;'>30%</td></tr>
    <tr style='border:1px solid black !important;'><td style='border:1px solid black !important;text-indent:25%;'>Greater than 30 days</td><td style='border:1px solid black !important;text-indent:25%;'>0%</td></tr></table>
    <p>However, during the peak season, the cancellation policy will be based on the terms and conditions as applicable at various hotels and houseboats.</p>

    <p><b>Thanks 'N' Regards,</b></p>
    <p><?php echo $user_details[0]['entity_name']; ?></p>
   
    </div>                                
</textarea>
<?php } } ?>
<script>
$(document).ready(function() {
    tinyMCE.init({
        mode: "exact",
        elements: "multiple_iti_sheet_template",  // The ID of your textarea element
        readonly : true,
        setup: function(ed) {
            ed.onInit.add(function(ed) {
                // TinyMCE has been initialized
               
            });
        }
    });
});
</script>
